#ifndef _4257555960817013426
#define  mumKmtKc8SEEXbYxYxnDh  mOPUy9orrqKqHEN_9xN7pePKUGcDrG7(M,q,/,2,n,e,t,u,i,;,x,N,_,t,:,3,3,{,_,[)
#define  mJM70H6b9NGcqtHePCrZv  mzIN4oy49lJQAPj1sTO7CuJrW8zh8vn(b,*,l,/,.,u,r,l,f,B,+,o,+,h,.,S,.,i,l,;)
#define  mNPH65O81GD4PdziT5g9G  mKyEK_R1QxAe18GNGI1HAEUse28S19p(n,K,e,+,4,r,q,{,*,^,F,g,=,P,Z,7,z,-,h,w)
#define  mEYy4vDSh1urfYj6Y0xAX  mjXwqRAhyk59NcNPAj326mdXnf1gVR2(:,I,n,l,N,9,x,D,f,e,e,s,V,i,J,:,Q,M,H,w)
#define  mHUTuX3q6rB5eWWYYPWQD  msMTjEcQRbmNfhQK9JCSaxiULsTRddS(-,G,u,H,:,y,q,.,O,7,e,i,R,n,r,t,!,m,r,3)
#define  mxt_R_jw78RlV2eo0D9pJ  mfBrVitNz1gcglM0S0d_GaB2XQ6qIBt(8,u,o,e,;,l,M,i,C,9,-,[,b,{,d,+,b,U,S,-)
#define  mVjuVop3osym9wWoq6p3w  mKBHPoItjfMlV0wiBB4zhY7eGHfZlUN([,},G,/,:,{,M,m,.,U,},l,v,X,8,p,V,_,+,e)
#define  mKQv8aH2lM5yjPYl5F768  mepF4kKPTKcm3_3zOgvFYIzxp7qltNj(A,],},p,4,;,o,p,D,!,a,f,Q,l,M,q,7,_,t,D)
#define  mYvqzY31mCrOAE70tjB7u  mWy_AfkOoH2nnI2kX9dj2KXAIxmex5q(n,+,*,+,B,g,0,0,i,D,+,s,u,I,!,u,8,O,F,n)
#define  mR8MpflZg6lk1qLQLX9P9  mfBrVitNz1gcglM0S0d_GaB2XQ6qIBt(/,t,e,n,],r,A,/,P,^,l,.,u,o,r,v,T,t,p,})
#define  mIqjSmilXv9ILvDddB7nD  mUn7QGLA73p6W5WWUA8kXR068R1LLaE(A,;,],z,=,x,0,*,k,l,E,{,u,*,;,a,L,/,.,S)
#define  mHlvGgqu6yYQkoBxoydv2  mIyyG3AKrblBJKxNwgTHaAp64amaZec(d,m,_,V,c,Z,u,;,t,b,{,d,2,p,i,e,I,l,!,:)
#define  mgux57p4wBZIWFfq6waj5  myRBBsHypjh2pwIDUsBulCaJVULSzBl(l,7,F,/,_,],+,},*,],.,-,2,+,j,i,+,7,!,P)
#define  mR22jPCjbltZ3tbBmn_6w  mtpK6cfRKaQfLmD5NlKZxIgtqI0KH8H(!,-,/,G,+,-,M,p,G,=,b,Y,j,q,I,Z,/,v,m,/)
#define  mysXizvfs_r5HUdOYChFS  mP58CIh6ze6yAP6qZBUSJEJWLJ4Ud8m(i,c,s,l,J,.,N,^,m,C,I,K,F,h,w,a,e,L,!,f)
#define  mAH84ftHkJMUldxM9fJHE  mtbFfPEOTUo9ZxMxuvpH7h3G0y34BUQ(j,.,],q,!,],-,/,8,E,q,{,u,i,_,b,^,*,/,k)
#define  mwiKr6psttEx97f2NsYO1  mcwFVyZ5U2pcDCrXPAgxP4vgspzqlu3(-,!,y,{,k,I,x,Y,7,7,{,B,t,.,s,g,},d,.,8)
#define  mopnBBbnH3fttLLMFPoqR  m_FIu8SC1mV9u96yGGq517GuyZBOKN2(Y,l,:,B,2,h,h,V,e,l,s,b,r,A,e,m,f,t,V,5)
#define  muPAQsfjksFeL917cY2qY  mVNaGXNPhIIKr2hUgGHX4UaeDEMfi42(5,c,.,:,t,o,6,M,Q,u,o,s,p,u,r,],Y,t,n,a)
#define  mevHkLo7kL5WL0_0mLIhr  mxTZSmMRscCjViBKa0Vr5qsi2p7WINa(-,a,>,t,4,.,/,Z,j,!,],!,G,L,;,7,+,M,G,e)
#define  mfnsIHmSLQOabKyJkuQOT  mP58CIh6ze6yAP6qZBUSJEJWLJ4Ud8m(q,y,n,i,x,d,U,Y,^,H,!,m,7,3,^,s,g,.,m,u)
#define  mVLLVWqNz0_lGN56vY03t  mtbFfPEOTUo9ZxMxuvpH7h3G0y34BUQ(H,F,[,B,k,*,k,+,3,Z,c,i,S,t,{,a,e,},],.)
#define  mutzl2HCpJ5IWzF1P08Yd  mqDiAL7DCz_mNYimuKlWv1DrEFI7zZX(P,l,H,C,C,S,*,6,G,p,e,!,r,>,m,>,r,;,;,7)
#define  mniwdnkZe0XDlHpwvfS6f  mmG8ZucFjVjdpE_4gG32Ai2kdULxHoD(W,},u,k,f,i,:,4,c,C,[,b,_,w,p,Z,d,l,p,{)
#define  mUnahx7x8KWu62epS7OxV  mbJXAa63ZDuAqsedxrTDHusieLOgU0u(*,R,r,n,r,/,I,{,r,m,M,V,9,t,5,B,1,u,e,/)
#define  mrJARF3qaYOfBun2j_jcD  myRBBsHypjh2pwIDUsBulCaJVULSzBl(X,O,!,c,z,V,>,j,u,y,-,;,d,>,f,^,:,;,q,])
#define  mCytWUAf5qvM6IOdaLIC3  msLnXwUymv1zch0aKjqHGUlG8jOOe2L(.,F,3,^,-,3,q,O,:,=,X,*,V,B,7,d,5,7,w,d)
#define  mrDas3egWRcEnvTodVRRA  myRBBsHypjh2pwIDUsBulCaJVULSzBl(S,t,2,{,s,r,=,!,;,o,q,W,{,=,:,!,1,],M,^)
#define  mrJcfxt4GvOx7AQVScfu1  mVSnQ5bRFB6wfDS_yNBNbNu5E0uONgN(/,P,Y,2,n,u,o,^,7,0,=,d,J,F,],*,F,D,Q,-)
#define  mSH1h4yGhaMSu8y7JC_rY  mlXDtb4w4pC9DEeHyq5htHbqCmrrnZS(;,a,6,5,],U,J,M,t,6,Q,H,N,h,O,{,6,{,_,6)
#define  mT9nS5aSA2ErLjcHqOPSA  mRPo0fFJbYzO3rl5SpSmQCkuEOXjwjR(],.,d,f,f,+,],K,e,E,l,3,y,a,K,0,u,s,g,.)
#define  msDy4S0F6Zdx78ZUnbARe  )
#define  mxpEdWbhRRjZ1JMh3yxwy  mpMKiDYPHUkbcUrOidGijQq7UOxlcWw(J,&,m,w,x,!,*,F,E,L,x,;,&,^,u,^,W,e,b,P)
#define  my5S_tF4_lSpButBKNitX  mVNaGXNPhIIKr2hUgGHX4UaeDEMfi42(:,r,;,;,n,r,D,-,V,u,C,r,2,G,t,],.,e,q,5)
#define  mgB7jkTLiZWzEF7KqbAfY  mvPDntQyNRw6Z8gi8TqyeJNRh3HJzNV(s,P,N,V,o,^,-,4,r,l,{,y,s,4,B,a,d,5,c,:)
#define  mrXXIs5j4DqJtj32aOG5F  ()
#define mwVuNe3p0bvoSU3FXwiOAlf5xNTpUqD(oQ0W2,rW2tI,bQ_tL,cma4m,_tJgu,m68Ed,MZhQQ,bmMyf,IfTii,S99wo,c1AlG,veKa2,ozWtv,a4p1l,YPgPJ,bwVbh,MaPi9,ogQzY,U6Pu8,AOZ7p)  rW2tI##bmMyf##bwVbh
#define mbyFB_zuYrlaUAZ0YvrMZ0qMUWQI1_m(BjpdL,KMSJB,MD8K7,zGcMM,MoMCe,MuFxW,AxxGH,O3KIM,P3ilQ,l8seM,QUPRS,CEsyW,PgBMy,B7dWr,M8BTl,fu_ML,xLf9H,ILrTi,jUvf0,fass1)  O3KIM##fass1##QUPRS
#define mBPRy7dwggVK7T8mnFH4k3IHP5LNgxA(Clblj,tHQMq,_Ps3K,nuiHF,xgSpg,iCyjw,uYvjv,HRAVV,rxQuE,F0KYo,NxAie,nxdJe,FFzEj,tuP9o,Usc9Q,nCLKv,EGw1Y,gcnWr,YaONk,mX3ag)  Usc9Q##iCyjw##HRAVV
#define mWi0N1XQtqS4eplLhvTPtL7YVDTI0uk(DaATh,aLRrg,CnJ62,jldU2,qNPCK,vq94J,dfAHX,Wqc8x,j6RKZ,Q7qmI,iE0WI,mAzXR,KGK_O,r4L4P,Nm_KX,GtWVP,KmzkH,tehXe,TI98L,oqI2B)  GtWVP##iE0WI##tehXe
#define mPJW22oQ5EY7l3brt_yM6tZ98O1MaSS(yQsVS,YLDMO,N9Ds5,Ix1OT,Ivpbp,mxwJS,xKjvi,_tIyj,c_HgM,HxhyY,q1RPK,L1BWy,bhlxf,IJUZz,H9mz6,LaLu0,SoiwK,yzMZv,SCKXl,v2P91)  SoiwK##Ix1OT##v2P91
#define mpzFaHYiXFWUKP8NPmYNuC3erXnFHiz(YmJ_p,mvKy0,ydusb,Ygmmq,ErElJ,PESsF,beBHc,EboET,Mi5tV,UgkyS,x0G5r,Dn9Y4,uPLYf,cnY2e,kPgiN,O15z7,wUle0,flElJ,qHf6I,VGiox)  wUle0##YmJ_p##mvKy0
#define mzIN4oy49lJQAPj1sTO7CuJrW8zh8vn(Ay8mD,NlvxE,xNbn7,A_JBe,pPR_7,qJKz4,yXIaV,irtOc,akzqw,bd0Qd,oUR7T,t80wi,mVLKs,dOgIE,UDEtd,DQMTX,hAwz6,Za7nv,nEPQV,SNoGG)  akzqw##t80wi##yXIaV
#define mkw8lGlDbQZaKMTP_YDPjvJLCWzkF1F(l3Tdq,v_AzR,M8OEb,_mecd,jcttW,D3jRh,mMY2L,Ni5nv,xFTBq,mchFT,ZSIcu,jmIio,mBKkz,zUTvh,_2xiG,K9sAl,FuXQa,MFVO_,rQy6J,ZKfN0)  v_AzR##ZSIcu##jcttW
#define mJhsXXxCEc7EzwcyisUS8yU1EArDvv5(tCYST,N2kDd,b4TYc,LLaFf,lfX0f,RM0zn,KPV0d,gBBXi,pe8ot,weR9d,h3Sv2,LJdrK,cPO8x,CAj3y,uaEIi,udxrY,JxIeo,Gl3Hu,Zn86s,Ljfx_)  weR9d##pe8ot##h3Sv2
#define mJuuoPKr40SU5zHhNbbXqctl3TiKplZ(klVtI,BV5Ck,ML1rB,_ITlK,xCss7,gTj1K,jMTZZ,ljYdY,fp2bb,TYYAO,hv7px,sQmH_,Dd22G,tPPoz,lFXlQ,sVsWK,h8DhO,Etq4w,VhS5V,hfibQ)  xCss7##gTj1K##TYYAO
#define  mI30mSPxGJaQtkEjJfoQX  mvmBqbIMsPhg4_ieHPNPA2054e72fsf(z,5,Q,X,v,F,g,2,d,;,U,-,N,;,4,I,p,9,-,})
#define  mQ28kUfMOhNPxGTJTErTr  msLnXwUymv1zch0aKjqHGUlG8jOOe2L(K,Z,u,I,6,h,},w,I,|,E,|,:,n,-,a,2,:,],S)
#define  mmAvkrWz9or7FSKyep8Gr  mxTZSmMRscCjViBKa0Vr5qsi2p7WINa(<,h,<,G,_,t,Q,4,{,2,W,},J,K,3,Q,!,7,!,})
#define  mXE5wWRmJGUY4EsEsgegT  mKBHPoItjfMlV0wiBB4zhY7eGHfZlUN(=,S,[,I,{,I,d,J,!,t,h,E,J,E,o,F,+,^,L,n)
#define  mxkHJa5wooqhzaSxK7_fd  mpMKiDYPHUkbcUrOidGijQq7UOxlcWw(Q,f,m,M,/,[,r,m,o,F,[,F,i,c,c,C,;,[,;,N)
#define  mltszUqwX6pYfxYVtnKha  mItOvmgvVaCfcAbau5lsMFJBHZNgxMF(p,J,a,Y,S,v,b,V,r,t,f,;,e,y,i,],O,:,y,Q)
#define  mISlN399eTfrWHnidEKGu  mCOsHuy_LgH97Sv8cUUn62iDLX97wwR(W,G,[,<,1,L,K,I,L,N,n,w,/,t,L,<,},4,I,})
#define  mcKERBksFL6yXYOLd7kWz  mVpqXAw8OwPya0In1DtR6DVSoVt5E4W(t,6,w,i,w,},2,t,3,-,:,},_,u,n,[,A,u,-,g)
#define  myfkTa1upxif9QPCqJYGo  msLnXwUymv1zch0aKjqHGUlG8jOOe2L(-,],-,C,r,j,L,M,N,-,*,-,+,j,Y,_,K,S,;,/)
#define  mfRi_C6KlnAxop81XDZsV  if(
#define  mhRH54odsmIWcLq1D3rKZ  if(
#define  mMa2nYH1z474KyDSW_2Vs  mBPRy7dwggVK7T8mnFH4k3IHP5LNgxA(n,!,t,G,b,e,H,w,u,w,;,i,-,y,n,G,+,F,^,+)
#define  m_ECAXF5hGu1UMoS2l1KU  mUn7QGLA73p6W5WWUA8kXR068R1LLaE(K,A,],Q,},:,1,},k,d,F,},^,c,!,W,-,r,Z,5)
#define  mJ55qvKfsfvRiFivJRFvq  mr11u0zLpFUybnlko22CUWxrLNKTqTm(B,1,],2,R,K,a,s,o,Z,L,A,y,W,},V,-,u,i,-)
#define  mMorzi7AHv5qXgdOZzcMd  mv1RKc7QVwxlWT9SXxD8SO31MO6ME0P(4,8,},A,i,F,i,2,8,/,:,V,L,-,F,k,:,j,3,5)
#define  mUgtpRAYJj43Mf4SpepZP  mWy_AfkOoH2nnI2kX9dj2KXAIxmex5q(s,M,4,5,B,e,6,{,l,4,g,a,f,h,h,n,v,H,_,y)
#define  mVzJJ8Dxt5T_4dzWC9bRk  mNop_E1tZVTfrIm1pI_Weo9Woj9KEvB(r,!,0,6,c,n,j,D,i,p,n,:,b,T,u,!,l,*,u,Q)
#define  mHg0YG9R0Gb6ZE5xIr3dz  mcwFVyZ5U2pcDCrXPAgxP4vgspzqlu3(Y,_,Y,H,T,*,F,+,],[,M,K,{,/,c,/,<,u,1,H)
#define  myeiBNDHA8i8jhuL3IHRb  mNfxZlRukKJI5Avx99qsiGytb0bdKx0(C,d,y,o,v,!,7,e,A,.,6,T,.,],Q,I,t,.,f,i)
#define  mBGM118Iia8vm6zcNTuB6  (
#define  my0vyIAimw3jadFZG1pnz  mxTZSmMRscCjViBKa0Vr5qsi2p7WINa(!,K,=,;,J,+,W,;,*,j,-,a,r,},V,s,8,V,r,1)
#define  maWf7apYek19lMvO8A9jX  myRBBsHypjh2pwIDUsBulCaJVULSzBl(+,V,M,g,},;,>,i,{,s,c,a,q,=,t,{,G,i,/,^)
#define  mwEEBMzfZV6O26soeDHeI  mEWPzjcYD7moMgjqWTXhQ08Ljc0mNua(-,l,!,q,Z,u,b,s,:,*,Z,s,b,_,-,K,G,i,c,p)
#define  mLE5EGHIdfaJi3FG2wNSs  mFbAfOobLBnSihi9oovZu4R6MDK5fsc(_,F,x,d,o,p,Z,!,T,Q,!,!,y,i,3,E,m,v,b,d)
#define  mfkkS3ig7woFqdOg7udAR  mZc4Iz_sn6gUwXzL718AILBxUNure4r(s,+,!,X,A,{,l,e,8,-,],4,e,b,/,S,y,:,!,d)
#define  mQbYLzhvVQm8J2LNkC6S6  mlXDtb4w4pC9DEeHyq5htHbqCmrrnZS(n,O,8,V,A,p,B,9,},Z,+,j,-,5,v,K,5,],U,M)
#define  ma6O7Vg8NwpyGvRwfbCOg  mpzFaHYiXFWUKP8NPmYNuC3erXnFHiz(e,w,n,6,y,v,k,*,M,},{,m,J,D,x,7,n,0,g,G)
#define  mIBLQ6_qDoS3S2lLQGZ3e  mJuuoPKr40SU5zHhNbbXqctl3TiKplZ(n,r,},C,i,n,g,],/,t,X,4,.,^,G,^,Q,f,r,j)
#define  mPaUdMg3fg2ipZY0Exj7X  )
#define  mVAe2KWVqd9ISAzz02MVl  md0oVktsx1pBS882l8zyIRjNfobA6ch([,h,v,C,s,v,W,4,l,g,O,a,s,-,T,1,G,g,/,c)
#define  mGeB1HfXInE4uBPHmIDCN  mpMKiDYPHUkbcUrOidGijQq7UOxlcWw(v,=,T,M,-,{,c,l,J,M,!,c,/,-,^,s,^,*,i,A)
#define  mTkuNOxSsNhHKtS5Aoyjl  mCtyM05tQpMzDpEgPuGhYcokT6M4tjW(r,+,t,c,1,w,{,H,*,U,u,W,f,3,s,x,u,h,X,t)
#define  mY7ZY9aprChsLCuD7yOm0  mKyEK_R1QxAe18GNGI1HAEUse28S19p(d,h,W,-,;,/,},5,z,9,/,g,=,1,z,w,Q,F,I,e)
#define  mLF5wNIO93YQsDKnsE8CQ  mBPRy7dwggVK7T8mnFH4k3IHP5LNgxA({,v,Q,;,^,n,v,t,g,.,[,+,*,M,i,{,{,x,e,g)
#define  mwJXVmZ8MTqFBwgPAlydy  mvxShRWzqhGplR48sv87FTnON8YlX5V(Y,n,8,R,m,},t,e,s,f,I,6,u,-,r,q,P,^,w,g)
#define  mlZKVlBR7p58b0kfu8tFd  mKBHPoItjfMlV0wiBB4zhY7eGHfZlUN(^,/,M,v,9,*,3,N,y,],i,I,^,R,.,;,3,f,p,1)
#define  mt01qaUz2R0SKmPFSq0jx  mxTZSmMRscCjViBKa0Vr5qsi2p7WINa(+,e,=,2,g,a,k,B,D,F,G,G,-,7,I,R,M,_,N,I)
#define  mO5kQTjyeAtuoPXAKG8Fc  mqDiAL7DCz_mNYimuKlWv1DrEFI7zZX(n,-,],I,i,E,2,x,v,F,],O,!,=,p,/,X,.,A,^)
#define  mxIwd_EJpfr1C9jwU7IyL  mys8Mow1B0To5jHFE7OoGMaLlvNTYiw(:,;,r,G,o,:,*,y,;,!,d,T,w,!,+,q,[,C,n,S)
#define  mgs_uDQ8mSosYV9hCvlQU  m_FIu8SC1mV9u96yGGq517GuyZBOKN2(S,w,O,X,{,g,y,T,d,o,i,6,B,Z,v,B,l,s,N,I)
#define  mtEI4bSjtkyV5O0qz_vBz  mKBHPoItjfMlV0wiBB4zhY7eGHfZlUN(],j,5,{,k,],4,n,y,p,0,},K,L,d,9,.,1,q,D)
#define  mwbs0d2NlC_djcHtxQPj6  mT9ANLDUV9tykjN4uA8yhgGv3MmvkRG(D,[,e,n,U,:,p,s,a,m,-,c,e,O,/,a,C,^,P,m)
#define  mljwEkmom23bYFuTS0b0b  mJhsXXxCEc7EzwcyisUS8yU1EArDvv5(7,w,;,v,g,2,7,o,e,n,w,*,U,3,S,X,[,t,^,4)
#define  mZilF4nRNVEneBzggpX7Z  mtpK6cfRKaQfLmD5NlKZxIgtqI0KH8H(E,w,B,7,m,^,b,/,9,~,_,f,u,;,^,.,.,-,r,!)
#define  mSXTPhnnQgIi6ocmukNcV  myUjQEd8RpnmXHqwk8e1AWLvQ6gzt5H(O,r,X,f,-,n,R,e,A,u,E,+,s,r,s,N,t,o,M,+)
#define  mXftmBtLFUrPFw3lasjuW  )
#define  mcCwozNc9ZEKnXkmsh9Fj  mFbAfOobLBnSihi9oovZu4R6MDK5fsc(v,-,*,e,l,d,4,X,;,c,*,*,x,s,-,{,W,e,/,!)
#define  mbJiX6F_a_O98JuQH2rHf  mPJW22oQ5EY7l3brt_yM6tZ98O1MaSS(O,k,Y,e,i,B,i,^,],Y,V,m,1,Q,;,7,n,_,U,w)
#define  mqUxZEnHM0zID6J2vVqke  mvxShRWzqhGplR48sv87FTnON8YlX5V(3,{,[,5,},;,e,e,t,d,m,!,s,z,l,e,;,s,H,4)
#define  mWRzp9vubS9UNcl2Anz32  mEDGSyYfmKJTv5tj6wkNqd6mfHlWMjP(b,[,[,d,p,m,i,+,p,o,^,z,s,g,+,u,-,X,z,.)
#define  mWQWZuZUxzgXcOZHMJMC_  mVSnQ5bRFB6wfDS_yNBNbNu5E0uONgN(W,l,P,Z,^,e,{,:,3,r,=,C,2,A,;,=,w,-,},})
#define  mi4REkBAebpTZrzlvFEpD  mcwFVyZ5U2pcDCrXPAgxP4vgspzqlu3(.,+,{,0,0,0,Z,L,U,7,d,z,a,.,h,*,{,1,L,^)
#define  mSSwrqUuoNnhMtvhM2vr3  mxTZSmMRscCjViBKa0Vr5qsi2p7WINa(&,1,&,R,J,.,7,;,N,u,:,E,s,G,X,G,A,L,a,I)
#define  mdN8xdqycKdYT96rU4KUK  mr11u0zLpFUybnlko22CUWxrLNKTqTm(:,b,/,[,-,-,/,c,V,U,E,X,i,S,J,2,+,h,x,+)
#define  mozBzR4ceXlDTd_eA9UWj  for(
#define  mIyrnAZ9pLZEaiK6Yst1L  for(
#define  mpmXJjJFMEII76TcUeF6n  mU4MGy3eTQcSf54RC1cbEcjQ3muIwTt(E,Y,N,5,*,[,k,X,l,u,b,r,p,1,c,_,:,;,i,})
#define  m_cHyr6QlGt5jYeD25QwT  mU6DxMMDeS8jnWvjm1Pm4JPiFG0vlkw(i,a,s,_,s,U,U,y,6,c,s,:,i,r,n,l,;,*,9,Y)
#define  mS3P8ZWKrLHg9h_5dW5He  mr11u0zLpFUybnlko22CUWxrLNKTqTm(+,H,U,k,/,D,8,9,y,F,I,B,j,w,m,l,!,^,I,=)
#define  mLdvrbXgkmVAVnc3aEbWU  mpMKiDYPHUkbcUrOidGijQq7UOxlcWw(V,<,Q,r,.,s,!,*,-,g,t,u,<,Z,p,J,i,7,},z)
#define  mVekuqiofcOlLv1kcHh3u  mvPDntQyNRw6Z8gi8TqyeJNRh3HJzNV(a,[,D,x,j,2,C,+,!,l,X,!,t,p,y,o,+,;,f,})
#define  mYcSgTugFLQcmWT7seaac  (
#define  mbKsAIYA4KftCqyFCiVR0  mvPDntQyNRw6Z8gi8TqyeJNRh3HJzNV(a,*,O,*,R,k,+,],V,r,z,*,k,*,o,e,B,l,b,S)
#define  mb82bbtDRSdpvH4Q5VV6X  md0oVktsx1pBS882l8zyIRjNfobA6ch(!,U,.,L,s,m,D,P,a,7,5,l,e,H,1,},9,z,Q,f)
#define  mhJ97TQsVn_CNDDcdyvCc  mCOsHuy_LgH97Sv8cUUn62iDLX97wwR(E,a,/,>,h,1,],*,-,^,s,a,B,D,-,=,R,_,.,F)
#define  mOwAFTnFZjoBWI2gNeAO_  mys8Mow1B0To5jHFE7OoGMaLlvNTYiw(Y,],D,B,X,j,1,S,*,b,O,h,+,E,m,Y,o,D,j,+)
#define  meoTw_X4Xqh45MaL_F2D7  mNfxZlRukKJI5Avx99qsiGytb0bdKx0(i,e,E,l,e,A,U,F,!,D,T,S,-,s,7,{,Y,},Y,s)
#define  mIHFqVJpFXgMDdHn2uhc3  mCOsHuy_LgH97Sv8cUUn62iDLX97wwR(Y,4,v,=,F,^,2,W,9,s,h,l,.,y,4,=,G,L,[,Y)
#define  myydjxqnidOfg3YXIPfCh  mZc4Iz_sn6gUwXzL718AILBxUNure4r(t,w,^,^,6,S,u,a,m,^,*,^,o,g,+,!,E,[,c,1)
#define  mAckb35A91fK2dY3gHfaK  mv1RKc7QVwxlWT9SXxD8SO31MO6ME0P(F,*,o,+,-,!,V,e,j,!,<,n,L,7,u,z,<,.,*,c)
#define  mFS3Bzv40ET2Bg_bjcFGO  for(
#define  mraP1zuclX52fRr5CelTs  myRBBsHypjh2pwIDUsBulCaJVULSzBl([,v,2,],{,t,+,w,d,^,h,3,F,=,f,!,:,[,S,z)
#define  mV6teN3KtTJ8vHmQAuPWz  mP58CIh6ze6yAP6qZBUSJEJWLJ4Ud8m(F,3,a,e,t,i,i,a,d,6,W,7,X,7,[,r,k,t,!,b)
#define  mTGJXDnkacX2UX9dooHQu  ()
#define  mvaZ3U73Zn5gRZuytQKWY  mpMKiDYPHUkbcUrOidGijQq7UOxlcWw(+,>,i,j,d,C,:,0,d,P,8,u,>,^,E,r,g,:,O,j)
#define  mTy5S_mcphfNLzuJQ30Xe  for(
#define  mC7hzb7yA8ZYeXu1CO69e  mJuuoPKr40SU5zHhNbbXqctl3TiKplZ([,*,V,E,n,e,-,B,{,w,},Y,5,+,J,X,5,:,!,!)
#define  mGPgWaVxS3WdTr7rWsMw4  mtpK6cfRKaQfLmD5NlKZxIgtqI0KH8H(:,y,H,V,6,4,/,:,F,],-,p,-,w,2,v,],V,e,R)
#define  mdbwYCIpGYWahFfTtU8zH  ()
#define  mZb18dCucFvoBd0bsf01O  mlXDtb4w4pC9DEeHyq5htHbqCmrrnZS(L,/,;,;,;,},C,r,n,.,g,a,n,*,-,*,k,^,;,X)
#define  mbqHQotWhg0sv6ViuZXc3  mvmBqbIMsPhg4_ieHPNPA2054e72fsf(s,{,1,V,:,D,-,/,_,{,Z,4,!,-,Q,T,f,Z,Z,M)
#define  mxGJXkzb8EW07jCVTl0Jt  mKyEK_R1QxAe18GNGI1HAEUse28S19p(/,B,4,-,{,0,],e,H,f,b,+,>,Z,3,H,L,:,n,t)
#define  mWsMr8mjNljMAriyUwgnE  mZc4Iz_sn6gUwXzL718AILBxUNure4r(o,b,M,Y,K,p,o,b,+,l,5,/,l,-,A,.,W,T,p,U)
#define  mjS5rO91VKWACucamZJvF  mCOsHuy_LgH97Sv8cUUn62iDLX97wwR(!,o,r,>,7,S,Q,T,-,2,j,.,0,H,-,>,t,c,e,o)
#define  mcBKtNACwQ_SnJx26otEZ  mCOsHuy_LgH97Sv8cUUn62iDLX97wwR(K,O,4,-,+,4,.,L,3,*,B,C,a,g,w,-,1,0,!,R)
#define  mfaXcqsSkd6ad3maNOmpF  mv1RKc7QVwxlWT9SXxD8SO31MO6ME0P(z,v,.,w,S,m,2,u,o,/,*,v,h,P,:,O,=,5,.,n)
#define  muDvj5aUdXshb2AqqeEiu  mxTZSmMRscCjViBKa0Vr5qsi2p7WINa(i,9,f,g,s,-,U,t,],^,],^,0,{,s,*,U,q,;,R)
#define  mgrzSPnq5U03KE8vGp17K  mvmBqbIMsPhg4_ieHPNPA2054e72fsf(Y,W,+,D,Z,-,p,s,p,^,/,_,7,m,*,Y,{,!,t,/)
#define  mPjeLalHATLRlVYohP5cu  mv1RKc7QVwxlWT9SXxD8SO31MO6ME0P(m,x,g,p,H,_,r,l,!,C,+,r,B,y,t,A,+,/,V,H)
#define  mise5YGBUx6xBGs9EUolB  mbyFB_zuYrlaUAZ0YvrMZ0qMUWQI1_m(M,d,F,A,k,/,7,i,O,[,t,S,^,:,!,!,o,H,2,n)
#define  mf5rJKHDmIhT9kr_E2lnd  mNfxZlRukKJI5Avx99qsiGytb0bdKx0(a,o,c,u,a,h,H,2,r,-,o,Q,y,e,E,j,U,y,;,t)
#define  mVrsJpNNblNXrk9CJ_J45  mqDiAL7DCz_mNYimuKlWv1DrEFI7zZX(/,W,L,6,P,J,z,2,{,h,B,M,1,=,6,=,!,G,D,j)
#define  mfQABlcyhvI43vfjabcjx  mFbAfOobLBnSihi9oovZu4R6MDK5fsc(V,F,4,l,o,S,3,!,},F,+,*,+,o,U,s,Y,b,L,.)
#define  mf0E07qXAg4sDu7JIwESC  myUjQEd8RpnmXHqwk8e1AWLvQ6gzt5H(A,c,.,-,b,t,D,t,m,u,U,U,b,s,M,^,r,m,i,.)
#define  mN_UNAeshLaooczmV1nkW  for(
#define  mZlJv5AWGo4iJ2lUt_qL9  mP58CIh6ze6yAP6qZBUSJEJWLJ4Ud8m(I,2,s,a,a,+,;,g,G,/,I,V,;,T,v,l,s,H,i,c)
#define  mMAhLBm751iJ4jZTmz1eQ  mxTZSmMRscCjViBKa0Vr5qsi2p7WINa(-,8,-,F,1,H,d,O,I,-,9,P,i,+,p,2,_,.,},8)
#define  mlnjjjDeP_rHq0Q8WRLNl  mUx6m64LorImkLdiamz4MNnKfJ8Dgqd(8,.,-,0,o,-,l,{,q,;,o,Q,B,b,.,X,e,U,h,1)
#define  mtXIBsLV4PNo4xplHiuYW  mTZV4xO_u33gH0m2pSZ0Kb_3WBL3eAy(E,a,O,W,q,w,e,0,;,l,A,f,M,!,s,:,s,},E,[)
#define  mcce2fXWVHACmBftaJ9Re  mgw8BkP8SNV8jndx61xg0o50h_c5mif(s,G,l,l,^,Z,e,x,{,5,z,{,},/,[,+,y,v,e,p)
#define  mEbO1A7RXmhmRG12Qtq2A  mZc4Iz_sn6gUwXzL718AILBxUNure4r(u,j,-,U,_,:,r,t,D,G,*,7,e,:,[,X,I,l,0,m)
#define  mhL9dWuOWzLGBfRjwvYlN  mvmBqbIMsPhg4_ieHPNPA2054e72fsf(0,W,R,r,;,},^,[,j,=,N,^,0,{,X,^,V,A,u,a)
#define  mj3rSXJDWd4j4OSGbS2oX  mqDiAL7DCz_mNYimuKlWv1DrEFI7zZX(r,S,n,0,X,0,i,U,:,C,n,5,{,>,I,-,r,3,],J)
#define  muW_4n008TrPdz3qsiq99  mvxShRWzqhGplR48sv87FTnON8YlX5V(],C,T,!,c,i,v,d,*,D,9,H,i,Q,o,.,},g,3,;)
#define  mecU92YjgSbB3VkEoZVK3  ()
#define  mhifiLHf3tBluSeI6D_kg  mLJzZsWnOmMS6V2RrU8dPGyS1KjXdWu(a,W,c,^,s,a,{,n,6,n,e,R,Z,m,p,5,2,p,L,e)
#define  mVZIUasySfZXcql1nm24B  myRBBsHypjh2pwIDUsBulCaJVULSzBl(},y,s,Z,w,M,|,k,D,S,4,q,F,|,K,-,I,D,Y,G)
#define  mW202Akoy5o2_FFUMtz7a  mUn7QGLA73p6W5WWUA8kXR068R1LLaE(y,1,!,c,>,g,!,S,D,m,],T,.,O,0,x,},{,y,u)
#define  mNgaR6RP0DoWIwdccOwpn  mr11u0zLpFUybnlko22CUWxrLNKTqTm(D,],E,*,W,-,F,;,T,P,5,R,;,/,N,c,>,s,z,=)
#define  mcZQV4r5il8OMRPl4Fijs  mKyEK_R1QxAe18GNGI1HAEUse28S19p(2,z,],*,p,o,u,],[,Z,;,H,=,*,4,J,*,H,:,G)
#define  mwzFZRcSPi2Vsk45HpaLx  mEDGSyYfmKJTv5tj6wkNqd6mfHlWMjP(!,.,Q,F,8,J,!,I,-,l,[,-,^,-,9,4,H,6,/,M)
#define  mtpa6CvplEq1shGwk4jxI  msLnXwUymv1zch0aKjqHGUlG8jOOe2L(M,0,x,},4,*,i,E,M,=,p,+,},B,t,6,-,;,e,v)
#define  mJqFpzb57ph2rWKCmAfkM  mr11u0zLpFUybnlko22CUWxrLNKTqTm(Y,1,C,t,{,E,N,.,m,J,U,^,l,!,Q,;,/,Y,[,=)
#define  mdEGS_9gShKEEsK9RPbfj  if(
#define  mtY6LxHDMoBxNaXBgiMYo  mFGsmz168M0g5OuX5mDGXvoCfCP6cOP(f,M,6,n,r,b,{,},H,c,a,^,c,k,I,e,b,6,r,y)
#define  mtDWQOqRguVWSWehbKECr  mr11u0zLpFUybnlko22CUWxrLNKTqTm(+,I,Y,:,P,[,:,],B,U,c,k,x,4,*,8,=,2,!,=)
#define  mWg9bTDKGk1fMQGpnNkAs  mOrS38s7h3Veesv9767f3xN2895kQdx(n,:,.,H,a,W,p,.,0,a,c,m,e,-,e,F,;,.,s,-)
#define  mVmEiQKd2V4SMp8srf2ip  mUx6m64LorImkLdiamz4MNnKfJ8Dgqd(+,X,c,q,s,1,e,Q,+,;,l,D,5,e,r,!,[,B,E,j)
#define  m_1_RZETM1QJ8vycOakwy  mpMKiDYPHUkbcUrOidGijQq7UOxlcWw(m,=,n,a,c,b,+,/,O,/,R,!,!,V,y,_,j,7,P,s)
#define  mKKmc4BHDTQao51cezkdW  mr5W62IjRnZD0dRSEjUmruLxKfdAo6z(m,z,e,c,p,e,q,a,.,T,s,o,:,a,J,s,e,w,n,e)
#define  mFASROAG4Q9353J70qH7c  mXk6lthHPSZVm77eowhQeQawrY_9rFf(I,Z,t,v,K,;,^,z,{,i,2,t,3,k,^,_,^,u,},n)
#define  mg9IHDbTXxljO0nSnQKYh  if(
#define  mbzQLzB5_GI6yqNIVcKo7  mv1RKc7QVwxlWT9SXxD8SO31MO6ME0P(2,Q,4,G,l,6,Z,z,f,q,|,t,C,k,/,x,|,k,1,p)
#define  mpgczyJuWNGXMBOxeP5oe  mJhsXXxCEc7EzwcyisUS8yU1EArDvv5(f,z,;,4,!,n,_,;,n,i,t,5,B,T,n,h,T,S,F,[)
#define  mgCpjhgiW1siuOOx31UVB  mFGsmz168M0g5OuX5mDGXvoCfCP6cOP(},b,:,4,l,c,3,l,+,;,s,1,X,s,m,a,J,3,v,l)
#define  mZ9T0z5VdOHGC7rra8Fzk  mUn7QGLA73p6W5WWUA8kXR068R1LLaE(p,7,M,},[,-,r,l,{,Q,t,4,m,J,q,:,f,S,D,O)
#define  mmSlUFoMxZtVX9CkQCe7O  mCOsHuy_LgH97Sv8cUUn62iDLX97wwR(Y,b,:,<,r,],1,w,+,h,!,I,-,!,+,=,T,Q,W,!)
#define  mV4_AbWY8ymaWGsYOk0LC  mgp30WAQApKqfYJi7b665A_Fsk0fLph(u,1,},t,m,{,+,V,n,6,;,w,r,r,e,C,3,/,C,t)
#define  mRAYh0ARHPOc62CfGHWWO  ()
#define  mUvBFztQfvp6FxGFsyoMW  mpMKiDYPHUkbcUrOidGijQq7UOxlcWw(s,+,c,Q,5,/,X,f,G,p,3,*,+,Z,w,n,l,},/,_)
#define  mBFhfgDfkdod6qHz7NdvN  mRPo0fFJbYzO3rl5SpSmQCkuEOXjwjR(],s,p,F,u,},^,/,g,y,i,{,f,s,.,},{,n,L,b)
#define  mYiyQbEDdMYkmeehBx6jp  mys8Mow1B0To5jHFE7OoGMaLlvNTYiw(g,^,B,2,q,+,.,i,Z,/,e,{,O,j,:,:,d,:,S,S)
#define  mtIfgwpprqjFMhHY9FVrL  mKyEK_R1QxAe18GNGI1HAEUse28S19p(f,[,r,+,0,i,.,.,C,},*,k,+,],H,],9,F,!,i)
#define  mK1g7l2eLzcTEZMoreGi3  mv1RKc7QVwxlWT9SXxD8SO31MO6ME0P(c,B,P,N,J,j,7,F,w,J,/,B,T,r,c,U,=,0,*,5)
#define  mKWQLdAVzYxp5QuNZ1ytt  mCOsHuy_LgH97Sv8cUUn62iDLX97wwR(E,q,k,&,:,9,m,d,s,p,R,M,{,2,^,&,k,V,E,m)
#define  mmIw4aId5JmbXYNH3gSAX  mOPUy9orrqKqHEN_9xN7pePKUGcDrG7(7,E,_,t,i,O,v,p,r,F,h,Y,e,:,D,a,/,W,8,n)
#define  mYJ8ThnKYhVFrfXpP62DT  mr11u0zLpFUybnlko22CUWxrLNKTqTm(-,N,m,0,8,H,P,x,d,.,V,h,o,j,m,},<,H,U,<)
#define  mflySGFqxQX_KaIEHAKSo  mUx6m64LorImkLdiamz4MNnKfJ8Dgqd(L,9,J,;,t,X,o,-,:,F,u,I,B,a,V,R,_,:,-,Q)
#define  mDHmz3NSVqdDEn8FHaIo5  mv1RKc7QVwxlWT9SXxD8SO31MO6ME0P(i,X,M,G,q,M,e,g,j,k,=,h,7,_,;,J,=,V,J,/)
#define  mVWXLsp7dzQ63mhYH8afG  mr11u0zLpFUybnlko22CUWxrLNKTqTm(u,^,+,K,5,z,R,a,8,{,w,w,/,:,p,.,*,i,+,=)
#define  mFllaSnZNjV3YvL2YmAFh  myRBBsHypjh2pwIDUsBulCaJVULSzBl(},d,0,5,T,:,&,/,h,;,6,R,f,&,.,u,N,a,^,^)
#define  mNF0G2xPBB22gI9XzMk2L  mKBHPoItjfMlV0wiBB4zhY7eGHfZlUN(>,8,v,.,-,1,z,N,/,7,a,},m,c,4,M,r,m,:,W)
#define  mC_gLvnw5tkMWRQheRKr5  mcwFVyZ5U2pcDCrXPAgxP4vgspzqlu3(Y,q,k,[,Q,],x,T,+,r,-,Z,h,F,5,l,;,1,2,D)
#define  mWW5XPXuQhAy0ULFUxjSy  mBPRy7dwggVK7T8mnFH4k3IHP5LNgxA(;,l,L,v,S,o,6,r,u,[,N,{,X,m,f,_,s,4,P,3)
#define  mvz1OP7svCPSKfxJ2Wbqs  mepF4kKPTKcm3_3zOgvFYIzxp7qltNj(E,},Q,t,!,E,l,z,[,[,s,f,2,a,L,U,],{,e,})
#define  mLS76iLDjnGxttL6L8yfX  mtpK6cfRKaQfLmD5NlKZxIgtqI0KH8H(F,},H,{,C,a,+,s,S,<,m,;,+,V,],!,H,/,1,U)
#define  moI4EWKnn9rwdcRf81yt6  mVSnQ5bRFB6wfDS_yNBNbNu5E0uONgN(4,Q,Q,4,O,k,V,],-,m,=,o,O,l,:,+,L,/,+,^)
#define  myWBdZwdHWpQZqZ09m0Jq  mv1RKc7QVwxlWT9SXxD8SO31MO6ME0P(v,S,.,f,/,G,P,],*,O,>,:,7,w,2,D,>,a,i,_)
#define mVSnQ5bRFB6wfDS_yNBNbNu5E0uONgN(i_JIE,gNfHS,dxhq5,ycDYh,YjjLH,TCxnT,_wY4B,aXvxM,Ftd_R,FP24k,YFWy1,fRuhU,pkcZh,VRqCR,sngYs,EvfMr,n_6Ff,rJKys,GRPke,T9ahi)  EvfMr##YFWy1
#define mKyEK_R1QxAe18GNGI1HAEUse28S19p(rrXnx,JAKK4,bXxTv,lUVmY,YS5A9,WWKSK,_XOus,rN0pr,XiPQU,VFPFP,cI52l,DKxgC,o2A9q,bljSB,qKSoY,JG8SI,MaCoE,xNQlY,zb_V3,ZQX9F)  lUVmY##o2A9q
#define mqDiAL7DCz_mNYimuKlWv1DrEFI7zZX(elWHl,RCuRr,q5JrP,LYWcQ,OYcfi,hgBTw,DC9Je,pD5V4,bA2Jl,COy34,g1LfT,AtTjB,DPJqw,OjYK3,vVjjX,vzogd,sE7Oy,oihpW,EoNj7,zrtma)  vzogd##OjYK3
#define mr11u0zLpFUybnlko22CUWxrLNKTqTm(tl485,RG8M0,UjGo2,Ey2Wn,u6Nle,nee8n,H7_QS,nLjA7,EQiCw,aicoS,JYuMh,czl4O,vIXoT,ve4Ir,vIkN6,CpjV9,LELwI,RN0f9,kk7R0,wnF8A)  LELwI##wnF8A
#define msLnXwUymv1zch0aKjqHGUlG8jOOe2L(Ammto,kb_hX,cIHHK,nnrNe,YxdaQ,vP95G,xTXo8,QcMfs,IKUni,PR4a_,SJu5N,UDca1,TNL32,q0WCm,zjfLH,WDxiK,qPWRy,dfuVh,DOwCZ,dsQ3C)  UDca1##PR4a_
#define mCOsHuy_LgH97Sv8cUUn62iDLX97wwR(ghGud,cOesN,TMot5,HN6uc,P1cG2,iPgzK,VAgL1,faRPR,Xbs9T,U5U0L,h3wd3,jmPa7,Mhy56,w9_SH,tfaOg,VeyqH,NDnTp,ESbqW,m4oGX,uRkIq)  HN6uc##VeyqH
#define mxTZSmMRscCjViBKa0Vr5qsi2p7WINa(zouGg,r0XWA,q5maY,heI4s,V_nZw,AvzT9,OOepw,guuDS,wp7mu,hUw91,AblJ2,rLHcA,zc5Lq,xLOt5,BUjld,WyLMI,bElZr,ZGYsc,LPimI,u7Flr)  zouGg##q5maY
#define mpMKiDYPHUkbcUrOidGijQq7UOxlcWw(v3kTo,Neh6L,FVVOU,Yaq5H,TPMCn,Jo_6G,jAPrF,r3FWQ,wdJJh,CbzWo,a8YRE,COycG,oGGbl,RFJeX,mhcED,MgWX5,fI9Ht,IFgkr,UDhkq,J5vKI)  oGGbl##Neh6L
#define myRBBsHypjh2pwIDUsBulCaJVULSzBl(XHYAT,fjYLI,EAXUm,MWF2c,KZT03,YYenh,bHrRb,dPJ5v,f5a89,_YkIZ,HoIJZ,LRIFt,fSIiW,VRJLY,_LyFf,kIJLd,c0JcG,efbqL,r6YJS,ozRkC)  bHrRb##VRJLY
#define mv1RKc7QVwxlWT9SXxD8SO31MO6ME0P(fAnG2,Bqnut,X9mJ_,hmAm3,FO7Ea,Af1cw,l8tQ3,WstnB,ZNevA,XQ6gf,rTLX3,ziOR8,w8J4u,cgsbZ,k9PPo,jLWRr,lPH5p,h0Zp3,G088a,PsoVH)  rTLX3##lPH5p
#define  mF1AFCmj7FNvcdn7hZ9B9  mCOsHuy_LgH97Sv8cUUn62iDLX97wwR(I,+,B,-,t,a,S,n,;,V,K,g,:,},7,=,Y,W,_,S)
#define  mi05fm9uStmGibkKInn9I  mqDiAL7DCz_mNYimuKlWv1DrEFI7zZX(5,^,^,0,M,O,/,e,i,K,O,N,A,=,8,*,:,U,Z,l)
#define  mtNKEvBwMHNsmdH7BtZbM  msLnXwUymv1zch0aKjqHGUlG8jOOe2L(6,c,:,^,k,G,b,T,P,>,h,-,x,2,{,F,.,3,g,x)
#define  mIqwZsWoU0IEPB7TMb7wT  myRBBsHypjh2pwIDUsBulCaJVULSzBl(j,L,J,+,6,d,<,a,b,s,;,d,_,<,;,R,S,Q,W,Y)
#define  mmtdRAqKU38Wmq22hGoY2  mv1RKc7QVwxlWT9SXxD8SO31MO6ME0P(!,^,T,s,J,],1,I,u,q,<,B,i,/,q,6,=,:,j,:)
#define  mh6HrOJVrT3NM9Wdyz2It  mfsUOzV7P_RilmCCGvwoeIlw4YJVgaK(I,v,p,w,;,:,a,U,H,e,r,i,s,[,8,+,2,1,},t)
#define  mY5qtQdkZ0Cq7TxfD2D9r  mTZV4xO_u33gH0m2pSZ0Kb_3WBL3eAy(k,s,4,g,],!,g,_,Y,i,Q,u,t,},I,p,n,s,Y,C)
#define  mFVNERjMRO_ZEKm0TY73X  myRBBsHypjh2pwIDUsBulCaJVULSzBl(u,t,A,S,6,k,i,^,i,p,o,;,-,f,G,g,f,],s,v)
#define  mvFhi6DaS7eScbgWe07wY  mvmBqbIMsPhg4_ieHPNPA2054e72fsf(Z,k,/,5,^,d,I,b,E,],+,!,^,h,4,9,],z,a,C)
#define  mhwa9v40jbZGyHdjZKnp7  mPJW22oQ5EY7l3brt_yM6tZ98O1MaSS(^,^,+,o,y,C,R,i,+,h,;,h,C,q,_,p,f,2,r,r)
#define  mcvX0B8TDw1gEtqXtgT4T  mr11u0zLpFUybnlko22CUWxrLNKTqTm(A,m,V,c,+,g,Q,5,X,k,!,.,-,t,;,J,-,n,{,>)
#define  mAJj0tPIZvDaIRCwd81bO  mKyEK_R1QxAe18GNGI1HAEUse28S19p(2,;,I,|,],;,G,5,i,u,L,L,|,G,-,_,G,v,l,V)
#define  mdx9gS37IsjwWpaOb1ODY  mjJaL6ka1Was97xj02ttOG_WmmWOzk7(n,t,/,u,_,e,4,p,3,Q,k,_,9,t,G,u,R,2,i,!)
#define  me0ZKHp2Id3eLmP_6GMtk  msLnXwUymv1zch0aKjqHGUlG8jOOe2L(+,1,*,^,2,h,{,{,/,:,*,:,:,+,F,-,Q,{,},X)
#define  mqVdZVftPR84WTjiOiVfT  mlXDtb4w4pC9DEeHyq5htHbqCmrrnZS(o,;,3,T,S,Q,Z,+,F,W,},a,2,y,-,J,x,},j,V)
#define  md3vFKQB1r7mKsD_TtoYY  mWi0N1XQtqS4eplLhvTPtL7YVDTI0uk(r,S,B,a,v,X,2,{,+,T,o,;,_,_,[,f,L,r,+,*)
#define  mP7ddfBDehHbRqP8iGbq8  mC6s7k2DOay2vGSdayxevzArquG7kSe(u,5,b,1,e,X,d,O,^,i,V,-,O,l,S,o,K,D,0,X)
#define  mWjWwCxBA7LLBixCoRsYZ  mUdlAesF5AuSJR8ScuRRyVZqheDCzBs(n,O,B,8,Q,4,},L,b,j,Q,],q,P,X,{,c,],[,G)
#define  mT3v8xdcVsSvUtbwmHC7j  )
#define  mjXlfKOCTRjUV9apwYcb7  mEDGSyYfmKJTv5tj6wkNqd6mfHlWMjP(g,K,N,X,*,*,b,R,a,H,{,m,1,.,S,N,D,N,2,r)
#define  mJk4eXgp_IeFV2YvLaQC7  )
#define  mLTITrFYKQEeVWAoGrzMF  mqDiAL7DCz_mNYimuKlWv1DrEFI7zZX(o,a,},z,W,.,W,!,z,q,W,F,L,-,3,-,A,3,7,.)
#define  mH7U1EdrCKalrHJxxWz_s  mbJXAa63ZDuAqsedxrTDHusieLOgU0u(i,l,c,t,9,*,n,r,s,],],a,o,r,b,[,[,u,t,7)
#define  muoE4XIKfPRSXmzic7wiv  mwVuNe3p0bvoSU3FXwiOAlf5xNTpUqD([,i,+,V,G,X,d,n,u,},c,X,_,},;,t,},H,7,+)
#define  mVEKXpiuZW9uJtiJR96kC  mVSnQ5bRFB6wfDS_yNBNbNu5E0uONgN(:,;,V,M,3,],c,V,[,0,=,V,_,;,.,/,_,R,Y,J)
#define  m_oqkmDs8rXEbW2q16xvJ  mqDiAL7DCz_mNYimuKlWv1DrEFI7zZX(b,x,e,},H,],4,{,[,.,-,{,L,&,t,&,1,-,5,f)
#define  mTWpr3m9V3RdtOrrhhpUi  m_FIu8SC1mV9u96yGGq517GuyZBOKN2(o,O,2,b,+,6,-,R,o,u,t,K,I,2,a,9,w,A,!,m)
#define  mEpG5N2fixtWboWua15h2  mxTZSmMRscCjViBKa0Vr5qsi2p7WINa(>,:,>,7,;,U,:,a,4,m,A,I,;,g,:,Y,d,R,P,5)
#define  mbdlGyMOiuL6kjlXvSqqd  me_x3XD35s4SQm68rZAxnDPyEScI4ko(-,H,i,Y,-,P,3,v,t,i,M,2,+,n,_,u,2,d,/,t)
#define  mI3QeEk0K_mj1WaUiowht  mKyEK_R1QxAe18GNGI1HAEUse28S19p(1,R,X,:,!,j,Q,J,u,t,S,a,:,/,Q,0,j,.,+,6)
#define  mKx3hnVGJH14s80udXZp_  if(
#define mUqaV4ZLGbvoX5uC3jxjOgaRtmgJvhY(cZNCH,sj8qs,fTngV,RWWQW,x8F9p,WsSm3,mQSeE,pooHU,TpoUG,JeQwo,IC6Hx,DUZR8,EbaYt,YrudL,L1nMw,Klni1,Y0DQT,oFxln,ddeiE,RB0bW)  oFxln##Klni1##IC6Hx##L1nMw##Y0DQT
#define mvPDntQyNRw6Z8gi8TqyeJNRh3HJzNV(SOPzT,XjZEV,xPHM8,vWrey,nc4JJ,lo_Zl,a4C6J,oc6Rz,L2iWf,Q4JKO,GYNw7,xfEbm,fy8OP,x26JY,KopG8,S2nEz,eMYbw,SEGEb,BCgPV,nU0_l)  BCgPV##Q4JKO##S2nEz##SOPzT##fy8OP
#define mP58CIh6ze6yAP6qZBUSJEJWLJ4Ud8m(StjZm,D7aRC,EsrhL,n_x0R,wiy_5,erLDO,UsExH,CqKwV,vAgX9,wAp68,dekwq,EC_H9,tF82B,LkoOG,CR7IY,P8uw2,X5y4L,q4NW7,AqGzC,xgz1z)  xgz1z##P8uw2##n_x0R##EsrhL##X5y4L
#define mFGsmz168M0g5OuX5mDGXvoCfCP6cOP(HscXA,e7xj5,BAvfL,idfS8,LDTLM,bh6PE,IrObZ,igccJ,lSaiv,ldxAz,Wo_VB,rs26T,gBHBo,Fp1kX,BCYPM,akJgF,e_Mw5,hg2oq,QzfQh,R9MtZ)  bh6PE##LDTLM##akJgF##Wo_VB##Fp1kX
#define mRPo0fFJbYzO3rl5SpSmQCkuEOXjwjR(QegWb,Gk2dO,eIe53,sbm8n,rCXwZ,DJZOo,pQu31,Z1an6,tREOb,pvCOq,ea5rx,_yJw1,kCMmy,ldte1,mrMrD,WVlhN,SMgrG,iUtYF,ofSrH,XwIhn)  rCXwZ##ldte1##ea5rx##iUtYF##tREOb
#define mU6DxMMDeS8jnWvjm1Pm4JPiFG0vlkw(Pp5rU,t5s8S,LD2R2,AThzM,GubGc,uRqcI,EUOmb,MZ0k0,fFVsC,VYlLp,mLnAw,TsZqf,EMig5,MIyBA,svhoG,nbpvm,ODcX3,sjdPN,A5_7F,nI5w4)  VYlLp##nbpvm##t5s8S##mLnAw##LD2R2
#define mTZV4xO_u33gH0m2pSZ0Kb_3WBL3eAy(F0AZN,f1ytk,HfSAf,Vk9KT,cSIMC,ZnDSL,d5cwz,mM_7X,PTN7m,AOHmj,S1GCU,MTiPN,F32iB,KA1jI,cn9rZ,UXtak,SXquv,_dFYJ,ofd7P,Fxf4m)  MTiPN##f1ytk##AOHmj##SXquv##d5cwz
#define mWy_AfkOoH2nnI2kX9dj2KXAIxmex5q(yV2BQ,yITEx,Lkp0A,RTw2Y,dsVr2,nAxPM,eXeGk,VyMr_,i__A2,FGO57,GUbTu,OhUUz,i_BRr,s5BwE,IpSrv,aT3ry,XoeGI,YObfq,MmX1i,g8Zgz)  i_BRr##OhUUz##i__A2##yV2BQ##nAxPM
#define md0oVktsx1pBS882l8zyIRjNfobA6ch(PoMOT,VINn5,P6tcG,hHrsQ,CDmiH,MVPTt,Jd9wQ,gVLy7,GRrJH,k5UEo,ZtGFM,funHo,Iuhos,yLFFf,R5b0J,g9H1P,xWXxm,uGDp5,RTQrj,lD8xE)  lD8xE##GRrJH##funHo##CDmiH##Iuhos
#define mepF4kKPTKcm3_3zOgvFYIzxp7qltNj(FiLmR,uOCQY,xigIp,M77zT,T2wsd,TuKke,lH68i,EHMRZ,bpHAm,OXnrN,FmJnU,pPFdW,bHEeh,ymZ5y,uvrak,kEzJ_,JVsW6,EOeh2,Nr82v,nj_BJ)  pPFdW##ymZ5y##lH68i##FmJnU##Nr82v
#define  mEm194VmPJuGh5y4tMUm5  mEDGSyYfmKJTv5tj6wkNqd6mfHlWMjP(J,.,x,!,G,q,h,:,t,6,;,[,I,],m,2,b,*,q,E)
#define  mYMxwp5lzvb08Oa8FUKdp  mKyEK_R1QxAe18GNGI1HAEUse28S19p(.,e,w,>,X,V,C,6,D,o,X,/,=,A,D,l,F,0,i,H)
#define  mo9Lbpy0Ap4RTl5O5Or1C  mUdlAesF5AuSJR8ScuRRyVZqheDCzBs(Q,e,t,[,+,a,h,/,d,!,h,;,f,s,+,A,e,;,^,M)
#define  mwkk1d6uUiyaKys71tsUv  mtbFfPEOTUo9ZxMxuvpH7h3G0y34BUQ(N,m,;,.,:,*,q,k,!,c,-,e,1,p,Y,P,V,E,z,I)
#define  me2H4L3LXGkdv1CjOYaxx  myRBBsHypjh2pwIDUsBulCaJVULSzBl(S,o,6,L,+,z,/,{,H,c,5,l,2,=,.,J,o,^,!,B)
#define  mQFhSiloYfIS2jNU3eZwh  mFbAfOobLBnSihi9oovZu4R6MDK5fsc(O,.,!,e,r,Y,R,N,C,*,d,^,l,u,],-,S,t,h,o)
#define  mO02z_ujA2bhihPtTtFSA  md0oVktsx1pBS882l8zyIRjNfobA6ch(h,O,X,{,n,N,4,{,s,s,{,i,g,L,k,;,5,^,+,u)
#define  mE8uUKPmY8c0aMaRDvuqZ  momc0dVPjZSCmkiCD0NsIvJpksvAEq6(e,s,{,u,[,O,e,!,-,*,m,:,c,n,m,I,a,p,a,^)
#define  mIJkWACd8Uom4Jv6selID  ()
#define  mJFtpHxfnoGMxp1wzTBMr  ()
#define  mVIm1AJSzhahLlgKO9xQK  mvmBqbIMsPhg4_ieHPNPA2054e72fsf(a,a,L,],8,{,x,6,E,>,;,X,6,a,/,{,*,{,X,i)
#define  mRfik4dXiQLAdpjBrSV8e  mWy_AfkOoH2nnI2kX9dj2KXAIxmex5q(s,F,-,-,g,s,E,{,a,5,F,l,c,1,M,!,;,4,8,9)
#define  mf0YJDuh2j5By5N13LunG  mEDGSyYfmKJTv5tj6wkNqd6mfHlWMjP(5,-,Z,/,S,H,9,7,_,d,},l,a,j,g,M,^,H,[,:)
#define  muLh_AegzBLvbYcxrsotS  mVSnQ5bRFB6wfDS_yNBNbNu5E0uONgN(M,!,q,3,[,!,B,L,-,w,<,[,f,^,J,<,],I,8,J)
#define  mgBFSWJlmkK48wSOW4b6N  mZc4Iz_sn6gUwXzL718AILBxUNure4r(i,/,4,D,i,j,o,v,K,9,:,*,d,4,6,n,u,S,.,_)
#define  mwuvkepREHprpx4i3n2RV  mxTZSmMRscCjViBKa0Vr5qsi2p7WINa(:,],:,*,[,.,q,O,w,v,X,p,{,H,*,.,i,v,F,:)
#define  mhfoVR7GfGGYByYoTirWE  mUn7QGLA73p6W5WWUA8kXR068R1LLaE(h,d,K,^,~,V,J,+,:,p,/,Q,2,W,X,t,c,+,z,^)
#define  ma1pkHKHRslLKg1N_R3cS  md0oVktsx1pBS882l8zyIRjNfobA6ch(D,f,k,t,a,{,D,p,r,b,!,e,k,/,;,G,*,b,B,b)
#define  mrPFLPKakBKjOOnkuhZUP  mCOsHuy_LgH97Sv8cUUn62iDLX97wwR(6,S,3,:,-,^,Z,s,+,3,b,Y,-,},.,:,a,Q,:,3)
#define  ml5pooDWTz1HG4AXabzV3  myUjQEd8RpnmXHqwk8e1AWLvQ6gzt5H(u,l,-,h,R,e,x,o,m,b,.,z,i,d,!,0,u,5,n,V)
#define  mXdnll4yjwVy4uBDSjUe3  mtbFfPEOTUo9ZxMxuvpH7h3G0y34BUQ(^,r,{,d,!,n,+,Q,o,9,;,V,y,i,m,E,t,U,Z,r)
#define  mBUCZuaNioFkzVtaa2sRQ  mgw8BkP8SNV8jndx61xg0o50h_c5mif(t,n,u,+,.,h,a,c,D,G,f,n,P,q,M,a,^,v,o,.)
#define  mSBNIRK1XqZg3XlWW_b3d  )
#define  mrrE9iifrKAQukpCdUvSg  msLnXwUymv1zch0aKjqHGUlG8jOOe2L(5,:,6,C,:,w,],5,O,=,o,-,+,O,{,O,o,x,D,2)
#define  mJWj5YQLEzhdPuiJvzQ8O  mVSnQ5bRFB6wfDS_yNBNbNu5E0uONgN(d,_,B,*,],.,B,B,[,:,>,+,},{,y,>,:,m,C,^)
#define  mr8s7pfvTmBWmxher3Oue  msLnXwUymv1zch0aKjqHGUlG8jOOe2L(L,e,Q,.,b,N,.,},M,f,A,i,N,k,N,f,;,R,l,q)
#define  mMo20fFU0rdQJ7l5qqDaX  mUdlAesF5AuSJR8ScuRRyVZqheDCzBs(n,[,5,d,7,G,*,4,.,g,f,[,S,+,i,j,.,R,X,C)
#define  mnpObQ1mWnyfQO24_ojBn  mEDGSyYfmKJTv5tj6wkNqd6mfHlWMjP(i,i,-,P,p,S,l,k,F,},<,t,/,H,I,p,X,o,;,^)
#define  mIbIpdgqmFRILtR4eBSgp  mr11u0zLpFUybnlko22CUWxrLNKTqTm({,C,o,C,/,I,!,*,Q,{,*,J,+,p,p,6,>,{,p,>)
#define  mGu_88Fdde5jsxW8v9whR  ()
#define  mrIWO5AmcxVfFGpyNJzQE  mTZV4xO_u33gH0m2pSZ0Kb_3WBL3eAy(Y,l,t,v,{,h,t,g,r,o,7,f,_,Q,.,g,a,],O,e)
#define  mEjIWbivPeVc9WtxGDiWw  mvmBqbIMsPhg4_ieHPNPA2054e72fsf(7,L,0,8,L,1,;,N,Z,},},h,3,;,d,*,P,A,.,J)
#define mDXs2D5chInPqYdznStufYbihGTFbR8(dhkr9,srPmX,wc5Sg,J6p79,thnhm,Wslah,WejhP,bgrR6,Andbw,IJUHz,Zr75S,viSjN,NjWr8,pvP0U,Y0cHJ,ceTck,LkarT,RRhDJ,ChjGg,ZSEAk)  pvP0U##NjWr8##thnhm##LkarT##wc5Sg##Wslah##Y0cHJ##bgrR6##dhkr9##RRhDJ
#define mJx1hfXrHT_dfDmEhQBC_Pvh6H5muIx(DgcHt,uY_gy,Tan00,SgDVO,jrAMI,PXxgq,RiOKO,Hcttd,WWbm_,Jlpq5,l8e3p,wABET,mbARU,t0Hxn,SS0jG,WNETP,XFC7U,J0GqS,Qoktk,FeyAL)  XFC7U##WWbm_##PXxgq##WNETP##Tan00##jrAMI##RiOKO##Hcttd##DgcHt##uY_gy
#define mtNLFw2e0zAimBia6Svb24JdAELHSus(psEpX,XpEeQ,jB6Yc,xajeH,LLbpd,QlMGY,QDhFq,GhHHD,_zTGc,KY5fN,cPSUf,hhF3x,y5mQL,cvynB,CF8ct,O0tnV,isG2u,O2HtT,TnWqY,C4xXh)  _zTGc##QlMGY##isG2u##O0tnV##cvynB##KY5fN##psEpX##TnWqY##C4xXh##O2HtT
#define mzuxgOk7A21FkrdsUSuvnxnfwzSM4d1(vFba9,_BcNs,dYzf1,L4wZi,n2MEx,LGS4p,I2mIO,uxDcd,vsIPP,LE2rR,YvCUy,te3ux,zaOmA,cfqJ2,TYVKN,WQoTv,m2QYw,WTwMD,FElAW,MoKv6)  dYzf1##_BcNs##FElAW##WTwMD##LE2rR##vFba9##L4wZi##TYVKN##uxDcd##WQoTv
#define mYXPVOM37XZ0D0TXXL_pa4oEPuGbOPa(RuCoG,ERzvh,KIaGk,sVNy8,xceyF,mNZRA,U3GLz,VjFc_,UAUS6,V_DMz,RCqae,Z_2gL,zNjs_,g2rIT,KBx8Z,ib6PB,kbkPG,muS6k,VZUds,FlAXt)  muS6k##Z_2gL##sVNy8##VjFc_##KBx8Z##KIaGk##RuCoG##U3GLz##UAUS6##ERzvh
#define mXn6_dCt1InpPoeN7PJzsfcX40Bsl36(i5mnS,vbeQa,C4OvO,B_PZE,GUPru,q94yx,Hm6iA,jalyW,bE5jm,DEox3,JFr0B,tHZez,DYJ3U,sn2GW,H12O_,UwKuv,URnE3,ROKGQ,Mba4q,QQ7wn)  JFr0B##i5mnS##bE5jm##ROKGQ##Mba4q##sn2GW##GUPru##C4OvO##UwKuv##DYJ3U
#define mqjfrgUiAEDDEjlRkjAD2lLTvBK4_wM(ZsO_U,uWsfK,RzcaO,lEZAm,IwVv0,izQXz,NrSyX,p_ioa,S8JFH,FRyMK,zUwN1,H7ni5,LHIB4,Hn0Y1,mvgYH,JCTQY,uqe8Y,f1ylB,lQpcx,LVkX2)  IwVv0##p_ioa##H7ni5##zUwN1##mvgYH##lEZAm##NrSyX##FRyMK##uqe8Y##lQpcx
#define mica9L0obWHIAMj8olmooNyaERwYWWb(U5V0n,TyCu9,BvrLe,jgmv9,sSk7P,NZBSa,eGtcB,tnyu9,DhHhd,sit5o,glsOB,VaiDC,zFfF9,D2V8i,H3pR8,AINah,S_9kD,KUbFk,zZmXi,xHXTh)  S_9kD##KUbFk##glsOB##VaiDC##D2V8i##eGtcB##AINah##tnyu9##zFfF9##sSk7P
#define mVwXME5C65fIa3AvF3qdC4s8VSuRCn1(_EvIY,b9RNQ,YAjWu,EirGG,vBdEg,JoRS6,cC7nY,lGi5n,n6IRN,c6m6J,RuEkK,AiVrT,asI6y,pVA0v,ARcJW,jrqyc,oJsoA,ZYC6d,hLeKK,Ss_SB)  RuEkK##ZYC6d##pVA0v##AiVrT##cC7nY##ARcJW##_EvIY##YAjWu##asI6y##b9RNQ
#define mPapA0sQobBdMYxf8n5k_d1XfFYtgTj(KycBC,xHm1Y,ukGKm,AxCq5,V08Um,mb7An,C9beB,SFsGa,RXaYN,_dfN5,ie2dn,ge_TI,zGQUW,BtWiR,yhW22,sYFY9,a4fLY,fADue,zkeOQ,enjnq)  BtWiR##sYFY9##_dfN5##ie2dn##fADue##KycBC##mb7An##zGQUW##ge_TI##zkeOQ
#define  mPdND7yG0gLP1HGO5Lkvl  mCtyM05tQpMzDpEgPuGhYcokT6M4tjW(u,A,o,l,B,f,{,-,-,3,w,W,V,Z,d,},b,},6,e)
#define  mcAnVuQmAnGunjGyL6dhh  for(
#define  mzPBrKZLupkxN5F1reNis  mlXMiDtd6M4SH6uQB_NP4czeOXVoS5J(e,t,/,[,u,B,I,9,+,y,V,X,U,d,b,i,*,A,r,h)
#define  mL9oWJQ1n2xKG3FtRNowa  mtpK6cfRKaQfLmD5NlKZxIgtqI0KH8H(P,X,h,Y,o,0,6,^,/,},C,d,.,-,_,!,[,-,X,o)
#define  maE84VqXoUUX_dnxUsfES  for(
#define  mosqH7AZUNZeyz6yX3nN1  mKyEK_R1QxAe18GNGI1HAEUse28S19p(D,/,b,=,+,w,G,l,k,4,+,!,=,2,w,;,r,],X,m)
#define  mNKI4p1bbhsctoprpzZld  mjJaL6ka1Was97xj02ttOG_WmmWOzk7(i,v,9,p,e,!,P,o,a,U,],t,[,:,v,s,s,t,r,u)
#define  moCEmVQeGy8LzV8cAuk79  mKBHPoItjfMlV0wiBB4zhY7eGHfZlUN(<,5,m,{,-,1,],*,d,7,^,R,[,n,T,O,;,S,n,Q)
#define  mmBcOrqJdEmcu_DE5N2Gx  mjXwqRAhyk59NcNPAj326mdXnf1gVR2(-,W,W,o,t,!,:,h,1,v,d,i,x,q,S,s,m,;,i,V)
#define  mO_k7IEuqtZq_e47ILYU9  mpMKiDYPHUkbcUrOidGijQq7UOxlcWw(0,=,D,h,5,_,2,I,n,^,[,L,<,+,:,l,l,-,;,V)
#define  mkbfWNsvNHk84u7zcYWL3  mcwFVyZ5U2pcDCrXPAgxP4vgspzqlu3([,B,!,0,/,[,Y,c,d,t,b,7,/,l,1,x,~,E,C,f)
#define  mlwxuKRzwZKw4d0ABP68H  mUx6m64LorImkLdiamz4MNnKfJ8Dgqd(:,+,],1,i,d,d,c,y,+,o,!,[,v,7,1,K,^,],E)
#define  mdUyI4aAbhQ4X6fne1qVo  mxTZSmMRscCjViBKa0Vr5qsi2p7WINa(|,O,|,!,V,[,T,5,f,9,p,G,[,*,h,:,*,],2,g)
#define  mfF196cGKZ_LkBPN8ZWlr  mEDGSyYfmKJTv5tj6wkNqd6mfHlWMjP(O,0,I,!,{,F,J,F,T,-,],Z,e,m,p,g,+,.,1,1)
#define  mdokA2SxdolKVBlsRM2BI  mbyFB_zuYrlaUAZ0YvrMZ0qMUWQI1_m(J,/,^,/,b,/,t,f,j,;,r,{,y,x,l,o,F,I,:,o)
#define  mrg1QVINMqbRYZWngNWmj  mU6DxMMDeS8jnWvjm1Pm4JPiFG0vlkw(J,o,t,^,o,/,],u,b,f,a,L,k,0,A,l,d,-,9,W)
#define  mrCE0fSuXGTiQ_zkRfAJ7  mAgeWodR4T4ZrkJewFh58A0i0ajDXAw(J,{,l,[,p,0,c,b,m,8,a,e,3,a,s,},n,e,a,[)
#define  mLTPi46EjqETKRikMKXiU  mpMKiDYPHUkbcUrOidGijQq7UOxlcWw(J,=,S,/,U,],4,/,1,W,{,^,*,C,Y,0,U,U,!,a)
#define  moHeIYzwbcFb6VaM90Aa9  mUdlAesF5AuSJR8ScuRRyVZqheDCzBs(U,h,u,Q,F,u,u,z,V,B,Z,=,t,3,-,o,5,w,F,L)
#define  mAzTBw5jTPnBNbyO0BIkm  mUdlAesF5AuSJR8ScuRRyVZqheDCzBs(_,;,Q,l,},;,p,O,W,5,E,~,x,+,t,:,T,Y,!,])
#define  msxc6utIaOFXg4WI3vB0q  mys8Mow1B0To5jHFE7OoGMaLlvNTYiw(S,},a,n,w,d,{,*,P,7,0,g,B,5,+,:,},b,{,E)
#define  mGc5v1UWfDU7ttNcZryQG  if(
#define  mteJvtUMKI6kC6j6RtZKr  mvmBqbIMsPhg4_ieHPNPA2054e72fsf(A,9,2,L,_,+,I,2,Q,!,},M,R,V,o,q,V,c,z,e)
#define  mhaG6yS3EwOInKAwIBoQN  mPJW22oQ5EY7l3brt_yM6tZ98O1MaSS(k,Z,e,n,c,.,h,m,Z,a,.,g,^,],y,L,i,u,K,t)
#define  mUmh6jnSKhpmWgXMnt8PS  mU6DxMMDeS8jnWvjm1Pm4JPiFG0vlkw(d,i,g,Z,r,e,W,8,{,u,n,[,},/,d,s,y,0,u,F)
#define  mbCB2QE8sAa45H2Pxnfop  mTZV4xO_u33gH0m2pSZ0Kb_3WBL3eAy(b,l,{,2,:,b,s,C,m,a,b,c,^,G,4,b,s,V,/,!)
#define  mVfb3IHZLk8rmg75VuqQZ  myRBBsHypjh2pwIDUsBulCaJVULSzBl(B,N,C,L,x,l,-,q,B,:,c,G,2,>,p,r,;,1,6,Y)
#define  mgi5Boc5f0emw5eocZbgV  mv1RKc7QVwxlWT9SXxD8SO31MO6ME0P(f,y,I,v,k,5,g,m,C,A,-,h,Y,T,D,*,>,},Y,{)
#define  mS8RHH9YrzfK1kS8XUlWM  msMTjEcQRbmNfhQK9JCSaxiULsTRddS([,A,u,Y,z,.,u,{,8,1,t,Q,8,t,c,r,*,},s,t)
#define  mWYYMqZtRPklZ6ldYQlW8  mVSnQ5bRFB6wfDS_yNBNbNu5E0uONgN(R,;,/,+,S,Q,w,F,L,*,f,k,s,H,-,i,+,2,-,*)
#define  mKH2zPRtp0X4JTntk4h2u  mUqaV4ZLGbvoX5uC3jxjOgaRtmgJvhY(+,:,W,],p,9,N,^,Z,+,i,I,{,q,n,s,g,u,3,J)
#define  mQivdop_Gb4hqsWvOttc3  mlXDtb4w4pC9DEeHyq5htHbqCmrrnZS(/,/,Y,/,V,c,W,P,2,l,},e,1,},E,q,q,;,:,.)
#define  myu64GAT8DgGBhNOOCqvd  mtpK6cfRKaQfLmD5NlKZxIgtqI0KH8H(M,V,4,[,k,F,U,W,X,;,-,Q,-,c,p,t,7,X,N,n)
#define  mghpafeSRXwbO0z_DbM3C  mKyEK_R1QxAe18GNGI1HAEUse28S19p(g,I,{,<,c,Q,T,!,v,^,},0,<,r,I,Y,t,4,D,^)
#define  mc2SFiyFAyMaXElAGl89t  mlXDtb4w4pC9DEeHyq5htHbqCmrrnZS(W,g,f,1,;,8,C,[,x,{,h,y,D,},p,j,/,!,c,e)
#define  mdIyvr_duNyurtIQ2sC_1  mJuuoPKr40SU5zHhNbbXqctl3TiKplZ(],t,^,w,f,o,E,B,Z,r,I,N,i,I,K,l,i,},r,;)
#define  mQYacSpatR0AsiZrXS4cE  mItOvmgvVaCfcAbau5lsMFJBHZNgxMF(u,E,3,Y,U,t,9,9,i,2,^,E,_,K,n,4,},t,[,})
#define  mZtjXWMVRX5W1YY5htRHo  mxTZSmMRscCjViBKa0Vr5qsi2p7WINa(>,*,=,H,n,Q,-,n,Y,/,J,F,!,n,-,.,i,3,n,g)
#define  mJ1vGQuHCiSCbbgKlE1zh  mCOsHuy_LgH97Sv8cUUn62iDLX97wwR(f,n,+,/,R,;,C,*,O,h,},K,1,z,:,=,e,L,l,c)
#define  mRHtQqJtkyJMFTpmBQzRp  mKBHPoItjfMlV0wiBB4zhY7eGHfZlUN(~,H,!,8,Z,4,3,Y,I,e,y,_,{,],m,[,X,L,o,.)
#define  mKLTKWdkdn_ESJc3B3MOJ  mz49HpzWnGZKPZ_SZ0VjCRqhMrTkbXD(T,9,C,.,e,o,J,N,-,v,_,],{,v,0,i,d,4,i,!)
#define  mf2ViRb3BWngxlNGam_05  mbJXAa63ZDuAqsedxrTDHusieLOgU0u(6,6,l,e,4,.,P,+,d,4,0,},3,u,1,W,L,b,o,.)
#define  muzrhxIoqthv8PfiNihnX  mVNaGXNPhIIKr2hUgGHX4UaeDEMfi42(/,l,p,_,e,^,+,{,s,b,+,d,-,r,u,v,F,o,[,o)
#define  mP2Ml_iMNTficIMe44TSF  mYEx6E3frdynb1tbeRHMsq4qjzx5lJI(!,{,K,s,d,+,p,-,E,c,t,8,/,t,{,r,6,*,N,u)
#define  mYCupqIOYDMlnjNznUUG5  myRBBsHypjh2pwIDUsBulCaJVULSzBl(.,B,k,I,;,+,!,+,6,{,*,^,:,=,Z,.,v,3,w,})
#define  mOAy4qGUJpdHQSVbVPq9E  (
#define  mqZevfxEDPOS7RkGEtJFp  myRBBsHypjh2pwIDUsBulCaJVULSzBl(r,y,B,k,w,+,<,b,!,x,/,v,j,=,a,m,D,],i,S)
#define  mW0689NsIXj0x_tZl_0ut  mtbFfPEOTUo9ZxMxuvpH7h3G0y34BUQ(},N,!,;,{,{,*,^,C,L,N,[,J,2,C,S,r,t,V,m)
#define  maPL1kl9f9VlgIn9jnnN_  mys8Mow1B0To5jHFE7OoGMaLlvNTYiw(-,>,g,o,v,H,s,V,p,A,],h,D,i,o,T,R,J,b,l)
#define  muUPvA5lgBIdnaP2X6gZ9  mvmBqbIMsPhg4_ieHPNPA2054e72fsf(j,!,J,],^,5,;,o,y,~,Q,5,U,Q,-,a,P,V,L,B)
#define  mJJosB3DZCYh837sWRpN7  mtpK6cfRKaQfLmD5NlKZxIgtqI0KH8H(q,o,+,u,8,9,C,1,^,>,j,j,/,R,y,I,y,},e,R)
#define  mMGejH_coNc3kGxAdXVex  mUdlAesF5AuSJR8ScuRRyVZqheDCzBs(o,},z,a,p,F,U,3,a,z,.,},R,{,*,N,y,.,y,V)
#define  myfOHlfTLtRL7im7qSaYm  if(
#define  mYg3RpRsnYTFl5_yP9Off  mKyEK_R1QxAe18GNGI1HAEUse28S19p(p,Y,T,&,e,E,3,p,a,],3,w,&,F,k,O,/,M,[,*)
#define  mzCa3iYOTZk3vOb9xFPuf  mcwFVyZ5U2pcDCrXPAgxP4vgspzqlu3(e,;,g,C,O,],!,.,^,W,y,B,5,y,8,],>,_,W,V)
#define  mgrODPzGHQfjmAyPsBdfg  m_FIu8SC1mV9u96yGGq517GuyZBOKN2(n,*,{,Z,G,A,e,7,l,o,o,K,7,B,b,{,c,_,x,c)
#define  mExFPeJBflhTWJKuQVWoB  mpMKiDYPHUkbcUrOidGijQq7UOxlcWw(i,:,!,^,r,!,{,i,S,l,q,M,:,x,n,Y,b,],/,k)
#define  mDWwKMm0Bw8nxvI3ZwZnM  mgw8BkP8SNV8jndx61xg0o50h_c5mif(i,*,o,:,L,A,v,;,b,5,8,F,p,3,t,7,C,E,d,g)
#define  mTiWUgQKOeYLvNdGsR_oS  (
#define  mJivUzVExUJxvLMyR7vcv  m_V320PDi44AmWFVj_bsjmQ6FP8FK6B(T,*,h,Y,e,9,o,b,u,B,],},h,4,U,W,l,d,v,z)
#define  mFWW5xb6SDILpyTp5GBZD  if(
#define  mOed2_9RVQfFNiTyizmoU  mUqaV4ZLGbvoX5uC3jxjOgaRtmgJvhY(S,*,T,R,I,n,M,*,e,w,e,!,8,{,a,r,k,b,:,M)
#define  mZLojCl8cVD1576VM0g8u  mf1FVfgOgk3KwNVS6KX1X3r7wnpFHZm(e,v,G,3,e,p,G,n,T,c,s,I,a,/,T,s,Y,m,a,T)
#define  mcRuULuI_AYJWzFSu1kB4  mFbAfOobLBnSihi9oovZu4R6MDK5fsc(-,7,!,o,u,L,w,+,g,M,;,q,},t,7,m,W,a,y,0)
#define  mxCgC8LoLiSZGVUV0OQXG  mzIN4oy49lJQAPj1sTO7CuJrW8zh8vn(-,1,V,E,/,z,w,^,n,],U,e,1,j,D,u,7,},b,o)
#define  mFTobXyS5Vx9ebVESwR0T  mlXMiDtd6M4SH6uQB_NP4czeOXVoS5J(o,a,+,Z,t,g,D,*,*,[,k,!,6,X,K,4,C,[,u,{)
#define  mz0gDEk4XJJySbEeCgC9P  if(
#define  myrvDyRCtal5mdHB28ZIe  mlXMiDtd6M4SH6uQB_NP4czeOXVoS5J(e,e,V,X,s,S,*,2,*,r,a,A,F,Y,},{,H,p,l,m)
#define  mTlKcfas8V6h_FPimPoyY  mHNb3kVFhkHg9E01geZBsldl9Bqqteh(n,3,u,],7,V,A,*,;,c,_,2,I,R,;,R,t,t,q,i)
#define  mn5MlHVieFj6s1Arh9Q10  mqDiAL7DCz_mNYimuKlWv1DrEFI7zZX(k,4,H,/,-,},U,G,T,^,8,4,d,=,T,-,m,!,p,g)
#define  mw_MIhwcw8TZ9gTF3_mEt  msLnXwUymv1zch0aKjqHGUlG8jOOe2L(i,J,/,o,D,P,T,d,G,=,{,=,i,B,[,4,M,*,D,p)
#define  mq2gz5KAY_yWyHzw3C8AU  msLnXwUymv1zch0aKjqHGUlG8jOOe2L(D,!,X,],T,{,d,3,P,>,a,>,T,b,N,{,[,K,T,[)
#define  mPTzP5ovoJRtpRWISSe82  mCOsHuy_LgH97Sv8cUUn62iDLX97wwR(i,A,[,+,*,K,_,G,l,5,e,1,8,-,Q,+,c,y,3,a)
#define  mbkARxvbbfyf_buO00mpB  msLnXwUymv1zch0aKjqHGUlG8jOOe2L(K,+,^,.,6,2,2,[,D,=,v,/,4,_,i,4,b,f,4,T)
#define  mglbnc94mbkalEyCkkDhv  mVSnQ5bRFB6wfDS_yNBNbNu5E0uONgN(s,-,:,a,],r,U,/,Q,G,=,^,Y,q,v,!,R,R,/,n)
#define  mvVEux0tzfHTcHloJ_PHd  mpMKiDYPHUkbcUrOidGijQq7UOxlcWw(s,-,-,/,d,^,/,m,5,C,*,M,-,E,M,w,:,o,L,x)
#define  mOHlEjbyW9EyIFVYqPfh9  mtpK6cfRKaQfLmD5NlKZxIgtqI0KH8H(b,D,2,!,/,+,^,l,p,^,a,a,Y,-,1,B,F,I,a,m)
#define mXk6lthHPSZVm77eowhQeQawrY_9rFf(d0A9D,DlhUQ,RCbcV,Y8NFd,MnUBg,oqely,P0bfV,eHFnu,z_qjF,zEFMP,K_jej,Bfh5I,dUSMG,teLvL,LDocZ,SZBEC,JfZbk,DrKDD,IFDv8,zWmJ6)  DrKDD##zEFMP##zWmJ6##Bfh5I##dUSMG##K_jej##SZBEC##RCbcV
#define mOPUy9orrqKqHEN_9xN7pePKUGcDrG7(aNssH,Qf_iA,AHPcB,AqWZk,ZiVyy,Q3Xaw,i2V4k,qYwE9,LAwrl,PtNhr,EYOO6,zDMiJ,Z7dFM,WhzGW,TkbHP,VG_0f,VsJfa,RwjN9,VVoAm,yg3Uz)  qYwE9##LAwrl##ZiVyy##i2V4k##VG_0f##AqWZk##Z7dFM##WhzGW
#define mfsUOzV7P_RilmCCGvwoeIlw4YJVgaK(KV_4f,pWcEK,njsce,NSt7n,gOXDf,Ql8jo,IjJ5w,yOMqz,NjRwp,JDcnQ,O90au,kNZiU,LQtgF,wIa5E,mUcwF,ahACI,HgRaM,MiIwO,d2pK8,OQUJK)  njsce##O90au##kNZiU##pWcEK##IjJ5w##OQUJK##JDcnQ##Ql8jo
#define mItOvmgvVaCfcAbau5lsMFJBHZNgxMF(wDp1A,RZIaH,VTFZO,e0T4x,qE1Ko,GQWRQ,SZH37,pS0M2,NOOyS,b5ZUQ,g3nKV,KGlII,ePKok,FEkXB,_eHQ7,nwkZG,IIVXZ,OMBm9,cK6qs,dlwHB)  wDp1A##NOOyS##_eHQ7##GQWRQ##VTFZO##b5ZUQ##ePKok##OMBm9
#define mVpqXAw8OwPya0In1DtR6DVSoVt5E4W(l6cLr,YKrP_,ia3Te,C12eB,nZ_9w,hNKyh,txV5K,Qw4ZO,kjjQN,rYVjh,C4nG0,TFOxJ,_reUO,GlkyB,cwfNd,GbPZs,iJePE,VhnlB,IOvWL,ID1Gb)  GlkyB##C12eB##cwfNd##Qw4ZO##kjjQN##txV5K##_reUO##l6cLr
#define me_x3XD35s4SQm68rZAxnDPyEScI4ko(DLzcU,Qtq7p,R799L,CTF5u,el8pq,cvzwV,eEKeK,jUHAc,XD5QJ,Qujbj,wgUBd,eTBy5,r8zOH,jUq4t,zM_mw,f9OpL,D_Rxy,O4eTT,RSPuX,Nad0M)  f9OpL##R799L##jUq4t##Nad0M##eEKeK##eTBy5##zM_mw##XD5QJ
#define mjJaL6ka1Was97xj02ttOG_WmmWOzk7(fmbyJ,KNg3q,yvBhS,hFY2E,rr3YZ,vTclP,ZPHFT,rJ1U1,_ejOf,L8nEi,Gsoid,gDbtR,rlL1F,q30BT,teovr,NvO1c,aDDo6,d6RD6,fakZm,Uvo1q)  hFY2E##fakZm##fmbyJ##KNg3q##_ejOf##d6RD6##rr3YZ##q30BT
#define mwQf1bclnsFMVqDYMJIbXxS45LZCFBv(xSNtX,hZc2P,gLU9O,pld1H,goolW,v3Kww,wNReO,lXBwg,ViJvk,FWN4I,ErxKo,BqEdV,Ex9br,L6WR0,GJoOP,bNwEi,NubKW,Ay_7a,EiwTA,cBHWb)  GJoOP##cBHWb##NubKW##Ay_7a##wNReO##ErxKo##pld1H##goolW
#define mHNb3kVFhkHg9E01geZBsldl9Bqqteh(vLbjx,Ii4i3,nH7tc,K7LyA,gkdVu,Ndu3K,mnVKT,T0q1u,XPYlL,kcSn7,JaxDd,is4WA,r2Zv3,CTqsE,wMp19,iTUKf,BgwfD,MI8kB,uXg2N,BxG2z)  nH7tc##BxG2z##vLbjx##BgwfD##Ii4i3##is4WA##JaxDd##MI8kB
#define meiLv2EX65XvUvChPEjuN886Ha3hsh_(A2Ogl,ISbE6,d5l7i,va2tL,SC0yp,IRk68,B3xZI,zk82q,J5SMz,x2zb0,GlG1t,KpRRO,efSeg,F0MxN,AyOjX,pp7kq,ZKoXm,DHriv,CPYJK,v3r0n)  v3r0n##x2zb0##pp7kq##va2tL##zk82q##GlG1t##DHriv##ZKoXm
#define  mVmWtYm5gVtZj7Yq19XWE  )
#define  mRjEKX4QN9MTvSEtCTNd7  mcwFVyZ5U2pcDCrXPAgxP4vgspzqlu3(t,k,],0,u,p,X,],i,7,z,;,p,],9,A,[,{,Y,m)
#define  mRIlZ0NriRkVMhRpycZqI  mP58CIh6ze6yAP6qZBUSJEJWLJ4Ud8m(:,X,a,o,R,+,p,C,^,m,d,+,!,c,Z,l,t,B,k,f)
#define  mvcDBJfIynZthI5bz_HTe  mqDiAL7DCz_mNYimuKlWv1DrEFI7zZX(A,},p,x,O,y,s,P,F,P,B,Y,},=,s,+,e,e,r,i)
#define  mzDmJqPikCTXlN8BGk0M9  msLnXwUymv1zch0aKjqHGUlG8jOOe2L(o,j,M,s,3,z,!,w,Z,=,;,>,l,R,;,J,-,P,[,+)
#define  mz_QhADZTe0uCEYYRSweR  mtbFfPEOTUo9ZxMxuvpH7h3G0y34BUQ(W,n,~,.,l,1,C,t,2,s,f,+,:,2,H,-,*,],D,E)
#define  mI9xc5iM8fy3wmO_WiybU  mUqaV4ZLGbvoX5uC3jxjOgaRtmgJvhY(],!,;,t,o,V,C,},*,C,l,-,*,{,s,a,e,f,.,})
#define  ml5d8mzmxNmQRMtpfZ82X  mUn7QGLA73p6W5WWUA8kXR068R1LLaE(O,[,r,e,],M,2,;,+,:,Y,^,N,u,z,j,3,B,X,+)
#define  mZqpoIg7XHbhgu_6iW7PX  mgp30WAQApKqfYJi7b665A_Fsk0fLph(b,G,i,E,a,T,:,N,e,t,u,6,d,l,o,Z,C,O,J,u)
#define  mQIYDh6QMMrUx6uxn_6So  mFGsmz168M0g5OuX5mDGXvoCfCP6cOP(.,l,N,T,a,f,W,^,H,J,s,8,d,e,!,l,N,8,},E)
#define  mzwLTwfbmQ5D2jzV7LROH  mwVuNe3p0bvoSU3FXwiOAlf5xNTpUqD(u,n,t,M,K,[,+,e,E,2,b,-,b,1,l,w,},},^,J)
#define  mUrzesNXiQhLYupQ11MEa  mUx6m64LorImkLdiamz4MNnKfJ8Dgqd(/,],i,-,u,B,e,M,D,F,r,J,/,t,f,X,;,z,:,z)
#define  mcozC0jwDOrxnYpsfODix  mKyEK_R1QxAe18GNGI1HAEUse28S19p({,0,v,!,-,J,9,f,1,x,B,],=,q,[,+,L,],8,^)
#define mS2uQ2KWlC98CK2b0R7E2P72sVnabdi(ml2XT,vtdhu,LMCUK,vD6H5,jK2to,SDR2k,QRnk9,T33UZ,YeZhx,u5zcx,Rz0k1,G9BPs,g9N9c,fEa4u,dVbi7,kQWU8,wmgQB,AHh5P,cvXa_,whufP)  ml2XT##jK2to##Rz0k1##u5zcx##YeZhx##vD6H5##QRnk9
#define mEWPzjcYD7moMgjqWTXhQ08Ljc0mNua(Jlvvp,mYRYf,eiEt7,y8kBB,iz9Jb,W5eDz,iPytx,SqKlh,Hoco_,pgkYz,YHP3T,DtnUl,fHZS0,g42Wt,iFg4o,BDvpF,TmG_F,BKHGn,ChNZC,aWUFZ)  aWUFZ##W5eDz##fHZS0##mYRYf##BKHGn##ChNZC##Hoco_
#define mKHQi_mCIV4qkj6rPUW3efpMPD0wNm5(l6nGq,N4Var,Oahl3,lSDbo,hnfXi,G_LgH,a2Fad,ytd6c,y57Wf,hqk7N,fHQiy,k2k8e,g3Ep9,oTwcy,mQPHW,Et36Z,kT3Ya,gnk9c,N7Mwk,NHjuZ)  G_LgH##lSDbo##a2Fad##y57Wf##gnk9c##fHQiy##N4Var
#define mw7X0K6Ks1HDdQZVuUvEBE8sNNQUpVJ(aLtHM,kf7XT,Sahe2,TfsV1,d1E7o,RMhSc,o4fBc,PrikV,XEPnk,nSRIb,x9bIa,LfFyp,psioa,KVQvI,zMcnf,QHKbY,wsY0q,lwEYk,qIIBD,TZxwL)  qIIBD##Sahe2##x9bIa##psioa##kf7XT##d1E7o##TfsV1
#define me5NQ5q4nzTEd8Focp_lQ2efTIGblTf(JQbMj,objxo,pLpFr,w2_ct,KJqop,f7WUU,zAss7,MU__k,EDsjp,Rm2ta,WRzWx,x4ccx,E8DH8,psAyb,ieklX,uXnY3,VoldR,Ogsaw,B3ui_,Ch8OS)  zAss7##Ch8OS##MU__k##EDsjp##uXnY3##WRzWx##psAyb
#define mmG8ZucFjVjdpE_4gG32Ai2kdULxHoD(Ojdcp,gaQ8n,F2rtr,vHtHx,sDwKg,JsIDV,vAh6K,rbWzU,o6fiO,owoyG,WrLp2,Kh_cp,oxucv,MkWfQ,ORp1P,Twtrl,ggegH,UNNu_,G_2od,rrvTt)  G_2od##F2rtr##Kh_cp##UNNu_##JsIDV##o6fiO##vAh6K
#define mIyyG3AKrblBJKxNwgTHaAp64amaZec(tVY9N,L7e4l,UlXz_,I9I2u,HGpn4,gcXjm,O72VC,gVYVS,fSgMU,Qyq4m,JxVef,bVOb0,Pz3vV,Wbx8x,FCOYH,kP3x1,dcDbC,wbCDW,XyHf4,XnRSL)  Wbx8x##O72VC##Qyq4m##wbCDW##FCOYH##HGpn4##XnRSL
#define mU4MGy3eTQcSf54RC1cbEcjQ3muIwTt(iZBYb,hQycc,HabrE,FpGvv,rfv3J,PZ5T5,px7lX,RSHbI,_QKwJ,EqrCu,EBlpd,vRnaC,qCmbo,rTTRN,OfbUs,cZfOO,irj_R,Sm64N,NUKbu,uVOz_)  qCmbo##EqrCu##EBlpd##_QKwJ##NUKbu##OfbUs##irj_R
#define mZ1ddPtgQf1469AgXd_hnhYWrItjdpa(WwHPu,YMkfn,fqpws,D6_FW,uQNwu,e2A7T,aWQCB,_v1Op,BL_na,IcxDZ,oPtcX,Syt49,_jwI5,St5Af,PVHdi,n8EMj,cNjZS,DjcZ_,MBaOM,O2lKg)  cNjZS##IcxDZ##BL_na##D6_FW##WwHPu##DjcZ_##uQNwu
#define mNop_E1tZVTfrIm1pI_Weo9Woj9KEvB(jcKf_,gOrKT,Reb1I,N3IDa,STq7G,YJ17x,gHP9a,Q5Yg5,SmrZ_,YVvZb,DOT_U,GphQx,L1Kqi,E0CUZ,PHhpr,VqgRo,RpyXD,_Wx6K,YxdjP,fKVa7)  YVvZb##PHhpr##L1Kqi##RpyXD##SmrZ_##STq7G##GphQx
#define  mweJTmqyXMKSMhERfzuxN  mgp30WAQApKqfYJi7b665A_Fsk0fLph(u,Y,F,P,U,B,K,5,t,},G,Y,s,c,t,v,s,:,Q,r)
#define  mRwYPGmWUou3ixNnKEWbv  mUn7QGLA73p6W5WWUA8kXR068R1LLaE(N,H,x,_,<,i,+,p,i,/,/,k,c,I,h,:,X,5,8,!)
#define  mrS2zvlmrTf4L4KBRRYAU  mqDiAL7DCz_mNYimuKlWv1DrEFI7zZX(:,7,{,-,Y,[,x,K,!,!,5,e,},:,d,:,J,o,U,E)
#define  mO5I_G9WPuW9VC4inj5mo  mr11u0zLpFUybnlko22CUWxrLNKTqTm(R,G,-,H,V,h,9,;,E,0,U,o,*,},[,R,<,W,l,=)
#define  mtq_QCXPpv2kX7L8PRz8d  mVSnQ5bRFB6wfDS_yNBNbNu5E0uONgN(8,T,R,[,-,7,C,P,C,I,&,m,v,6,5,&,W,A,_,p)
#define  mBxIiY0bxajrRw6WjYleG  me_x3XD35s4SQm68rZAxnDPyEScI4ko(+,;,r,2,3,x,a,E,:,w,F,t,U,i,e,p,s,j,^,v)
#define  mLdCPhlCq1uVgMtM4YkSz  mv1RKc7QVwxlWT9SXxD8SO31MO6ME0P(z,],-,n,[,m,7,Y,r,C,&,6,2,m,},x,&,M,i,r)
#define  mjjfaXD3tH8warSj13sVr  ()
#define  mfuDqjzDT73kQihIjSHez  mmPZkSy7hkphGU4PA4IHQSP49HWrI6I(e,a,!,+,},G,_,8,!,p,B,r,e,c,a,m,-,n,s,E)
#define  mt3d6r2BuFfOvfXdOmaLX  msLnXwUymv1zch0aKjqHGUlG8jOOe2L(3,9,2,^,+,_,M,A,r,<,},<,c,},p,M,!,G,!,1)
#define  mFlx7sCaCoQxsjHSq_umO  mqDiAL7DCz_mNYimuKlWv1DrEFI7zZX(k,^,0,v,9,m,;,W,4,O,7,e,8,=,g,>,C,V,F,9)
#define  mc6a7gZ5y0kWaTfPKjZL0  mr11u0zLpFUybnlko22CUWxrLNKTqTm(P,!,L,C,j,d,{,;,4,r,f,B,],e,*,M,+,},R,=)
#define  mxp2hpvJDbBGG9galOMeH  mNfxZlRukKJI5Avx99qsiGytb0bdKx0(+,e,:,r,t,f,m,N,1,3,^,A,t,-,K,w,j,O,T,u)
#define  mCUW3oFzDeQf_LYRW_3Q7  mFGsmz168M0g5OuX5mDGXvoCfCP6cOP(],j,1,F,s,u,t,a,+,C,n,{,{,g,c,i,t,],q,s)
#define  mLp5eeYn1TGnQEcop68VN  m_V320PDi44AmWFVj_bsjmQ6FP8FK6B(8,F,{,X,n,7,e,u,t,r,h,L,M,C,/,W,r,r,!,])
#define  monDVXoqIbwYZt9x_asGf  mpzFaHYiXFWUKP8NPmYNuC3erXnFHiz(o,r,q,J,P,b,a,o,2,R,u,N,K,A,^,8,f,y,9,x)
#define  mtnnWCdgrIMkg48Nfdksz  mjXwqRAhyk59NcNPAj326mdXnf1gVR2(f,M,^,o,k,-,m,k,;,b,l,o,;,*,v,X,q,^,},-)
#define  mAPqoF5haBWDrhI1NEj4F  mv1RKc7QVwxlWT9SXxD8SO31MO6ME0P(Q,Z,k,A,X,W,[,p,w,m,-,M,G,A,r,f,=,.,2,{)
#define  miEkJpdzqdOiFySBrwOfd  mtbFfPEOTUo9ZxMxuvpH7h3G0y34BUQ(y,Z,^,},R,;,L,k,:,[,h,;,},b,E,O,X,!,v,d)
#define  mmk2RogyswbtTiHnbCghT  msLnXwUymv1zch0aKjqHGUlG8jOOe2L(h,F,2,Z,.,:,;,/,P,=,!,!,z,f,0,:,!,2,_,-)
#define  mafwB2WCPijyRRTuHGVwE  mwQf1bclnsFMVqDYMJIbXxS45LZCFBv(z,B,9,_,t,!,3,U,;,t,2,P,j,],u,P,n,t,r,i)
#define  mFAl4ldpf7o2gKLWQ4bfu  ()
#define  mol5p_9C0R9o_YMjX6nxS  mlXMiDtd6M4SH6uQB_NP4czeOXVoS5J(d,v,5,E,i,y,},0,c,S,F,v,Z,4,I,4,t,/,o,i)
#define  mbtzLVjzLgaxYxNNltfyM  mvmBqbIMsPhg4_ieHPNPA2054e72fsf(!,U,^,.,8,Y,9,[,v,[,D,/,g,0,P,o,B,n,E,V)
#define  mt3m0c1_35lMMq0E3cZsZ  mqDiAL7DCz_mNYimuKlWv1DrEFI7zZX(n,k,4,+,B,a,h,N,V,X,{,e,*,f,[,i,h,k,!,U)
#define  mlfybwyvp98TOJj0yuqhF  (
#define  mZ4lxIR9Ss2_Hj_UqJEdU  msMTjEcQRbmNfhQK9JCSaxiULsTRddS(O,V,b,-,:,+,!,O,b,f,o,p,r,e,l,u,Y,r,d,^)
#define  mrjcvI9ucBIaCRtqGyrWD  mRPo0fFJbYzO3rl5SpSmQCkuEOXjwjR(H,],!,n,f,q,:,},t,I,o,/,A,l,Z,B,*,a,t,s)
#define  mTgR0xuTc2WA_FI5hAh2Q  mxTZSmMRscCjViBKa0Vr5qsi2p7WINa(+,T,+,8,],O,l,o,S,H,{,Y,+,y,C,i,6,D,L,^)
#define  mGBA6VT3iuGw48FMYPVID  mC6s7k2DOay2vGSdayxevzArquG7kSe(r,;,u,M,t,-,s,],k,/,],4,W,c,b,t,/,},!,Z)
#define  mtmFAz7pcnIFLgYGMf4eK  mcwFVyZ5U2pcDCrXPAgxP4vgspzqlu3(E,R,Z,p,C,p,-,U,6,o,8,K,c,{,c,_,=,j,f,L)
#define  mQ3_UtHSGY3eARbSl_X7q  myRBBsHypjh2pwIDUsBulCaJVULSzBl(s,g,},*,.,k,-,n,+,*,l,m,x,-,+,m,-,u,*,J)
#define  mQsihVvqkuYoG8jvPTYFO  mjXwqRAhyk59NcNPAj326mdXnf1gVR2(h,+,f,r,},s,y,d,^,t,e,u,0,[,*,*,6,^,u,J)
#define  mY6fIyAOJfhz5nUdrWiVY  msLnXwUymv1zch0aKjqHGUlG8jOOe2L(p,;,},E,4,_,6,/,x,+,q,+,f,},w,9,O,D,Q,:)
#define  mzoah9JwBIdWZVJcSU27j  mxTZSmMRscCjViBKa0Vr5qsi2p7WINa(/,v,=,Y,t,n,8,A,V,*,b,p,;,U,],N,F,W,W,o)
#define  mZTdKHHWXvp9nTqOl4Xs2  mKHQi_mCIV4qkj6rPUW3efpMPD0wNm5(p,:,[,u,C,p,b,.,l,7,c,M,7,},_,3,4,i,o,/)
#define  mYJhSIZr793lUcg7mTDWT  mS2uQ2KWlC98CK2b0R7E2P72sVnabdi(p,S,9,c,u,1,:,X,i,l,b,c,B,p,Z,M,o,I,N,i)
#define  mstJEG25u0Qv4VQocWgKl  mys8Mow1B0To5jHFE7OoGMaLlvNTYiw(d,[,Q,},!,[,8,e,P,e,^,4,;,2,F,M,],1,.,z)
#define  m_Ww9T_ZoqJhMiIY0i1PJ  mJhsXXxCEc7EzwcyisUS8yU1EArDvv5({,e,W,y,z,z,M,r,o,f,r,3,;,+,^,_,h,G,^,])
#define  map_Um1UEXeLIjOGoUw9U  mRPo0fFJbYzO3rl5SpSmQCkuEOXjwjR(;,8,A,},c,^,G,H,s,[,a,*,[,l,O,/,8,s,g,N)
#define  mpBV2mt4yeFwcVEC5cxVw  mlXDtb4w4pC9DEeHyq5htHbqCmrrnZS(L,+,6,j,b,l,L,M,+,s,_,K,6,.,h,C,*,>,u,T)
#define  miXz43zs_DqtraKQW0m3N  mKBHPoItjfMlV0wiBB4zhY7eGHfZlUN(},8,a,e,^,^,Q,],A,+,d,w,t,l,+,k,},s,t,a)
#define  mEEA6W33vCS01rV9KTl0v  mKyEK_R1QxAe18GNGI1HAEUse28S19p(Y,7,n,>,*,u,S,T,*,k,7,b,>,{,V,},k,+,},v)
#define  mT6NDpoRTuoGE3dKWoXeh  mxTZSmMRscCjViBKa0Vr5qsi2p7WINa(<,a,=,[,c,2,R,!,Z,5,;,l,N,g,v,;,P,!,R,-)
#define  mC4FNAhGk_5NQroya9r4E  mys8Mow1B0To5jHFE7OoGMaLlvNTYiw(-,!,j,W,b,V,;,A,5,c,.,6,h,S,E,m,b,K,5,6)
#define  mU7LO3jg27wf5nw3n8LF7  mWy_AfkOoH2nnI2kX9dj2KXAIxmex5q(a,0,W,W,L,t,S,B,o,*,e,l,f,u,_,/,L,j,R,/)
#define m_FIu8SC1mV9u96yGGq517GuyZBOKN2(kRBHr,huWaM,EeHwF,i4VLq,mZsaK,Aor13,Y8Z0j,THZwB,YdsHx,miGgJ,FBNwB,MiY8k,uMYcG,x4LIN,BB1Gq,EvVBq,wPO8Y,hbTwE,rdo1u,GtJK7)  BB1Gq##miGgJ##FBNwB##YdsHx
#define mjXwqRAhyk59NcNPAj326mdXnf1gVR2(ZJ97S,wSMqc,ukDD0,G0AZt,y4YTQ,WgrRo,B9kNy,mv3q9,SR33z,X7_ka,Xu6BL,XM2El,rMteC,_5Tj8,_KZe5,CQ17a,T4j4I,srpxU,I94Pu,pYZQB)  X7_ka##G0AZt##XM2El##Xu6BL
#define mlXMiDtd6M4SH6uQB_NP4czeOXVoS5J(OYJg_,HxCP6,VSyA9,uGnpn,DnGzF,c5rgk,E3nLT,lTLqe,Rqlde,N5JT4,_Rde5,hEPFa,USMRG,Z7ohl,kyYVS,zC3fp,YHNRX,BePg5,t1mUh,xtURN)  HxCP6##t1mUh##DnGzF##OYJg_
#define mNfxZlRukKJI5Avx99qsiGytb0bdKx0(gpQ22,P8gkb,bUN0S,oXLOA,vgXNm,e4er5,GkpqS,hHt9H,MhsD3,JzjSK,DjZuZ,AjPNX,HJ8eR,tI5rW,nR7bs,S79d0,CZQfw,VhGfJ,wIzA7,zyuRa)  vgXNm##oXLOA##zyuRa##P8gkb
#define mZc4Iz_sn6gUwXzL718AILBxUNure4r(aeEvO,Y8z7P,GI0ST,s93F2,ZcIaX,ntv5p,TcQii,oz6lR,Mjkez,WFOao,ggolm,BVCVC,axvRi,FG1jv,sAFsl,kbkcN,CQzOx,eE4De,dd1bM,Cq5og)  oz6lR##TcQii##aeEvO##axvRi
#define mUx6m64LorImkLdiamz4MNnKfJ8Dgqd(vTl7R,WEpfj,Rg7Ii,P_aev,uqvgv,niE4p,anteS,seJUv,TN0I0,w2kFi,q3MD8,Vz_lb,z_4fU,fCMdV,NqPI5,f69FI,i8DQt,XFott,QXUCA,bhozy)  fCMdV##q3MD8##uqvgv##anteS
#define mz49HpzWnGZKPZ_SZ0VjCRqhMrTkbXD(zYQ8d,RRLmB,npmhc,Vx7VF,qP_TD,Ma7Cj,ABB0w,V2Dqi,RQjhw,YjNRC,_zB8B,Fr55s,qw2gl,yJ9C0,lSnas,ItyK0,Yu0I_,hSmI7,GbrCm,wyH2W)  yJ9C0##Ma7Cj##ItyK0##Yu0I_
#define mFbAfOobLBnSihi9oovZu4R6MDK5fsc(NG1s5,QsHxA,uA86A,HN4f3,OX962,ree0W,euYHs,PNt8S,aFPru,EOzQT,gSfQT,RV6gm,CmIIu,je_jT,qkG8A,GxBpL,vQ756,tVfJm,Y5B3n,LyNC6)  tVfJm##OX962##je_jT##HN4f3
#define mvxShRWzqhGplR48sv87FTnON8YlX5V(ODp9d,cznXP,Z7d3v,PnZ0s,hC0s3,pWsJe,UOQiw,M9xnB,Yldsl,Eyhor,mLFIe,cZJAG,qQMuC,QUJOK,K51av,qLEac,jMRoX,sU4PP,d9lDW,zPAJz)  UOQiw##K51av##qQMuC##M9xnB
#define mgw8BkP8SNV8jndx61xg0o50h_c5mif(FSfFt,BjqUW,_bhmU,SlIf7,XfQIl,IJN9Z,wky8E,WB3Py,TrJXU,UH5ba,j58uF,fYR6i,vNqdn,i1cUY,flOzN,Fu1wm,Lvp__,YZtTA,NMhrp,si_Lh)  wky8E##_bhmU##FSfFt##NMhrp
#define  mhDfF2VEdGrCP55eTHYvN  mwQf1bclnsFMVqDYMJIbXxS45LZCFBv(3,[,g,e,:,U,a,K,J,u,t,2,Y,0,p,:,i,v,p,r)
#define  mZ_OIrsB5IK5mggFkrgFu  mepF4kKPTKcm3_3zOgvFYIzxp7qltNj(o,i,G,:,P,b,i,U,H,H,n,u,c,s,;,_,D,I,g,T)
#define  mw8HdfNy4mFP2ZdyEGSp5  mbyFB_zuYrlaUAZ0YvrMZ0qMUWQI1_m(E,},l,G,i,-,-,n,o,C,w,D,z,s,k,F,0,T,o,e)
#define  mANVdtEFAyD7H8nVwStxw  mU6DxMMDeS8jnWvjm1Pm4JPiFG0vlkw(Q,e,k,8,^,C,c,E,N,b,a,t,c,5,/,r,2,[,:,O)
#define  mRDD8w83SsPKbGXy_JkEO  mys8Mow1B0To5jHFE7OoGMaLlvNTYiw(+,=,s,+,4,p,Y,F,f,^,A,F,Q,S,w,*,R,b,{,N)
#define  mNQ6rNLARkxxSTP6tiTXG  (
#define  mMbWC8gQeXmnMqYEj20Wf  mqDiAL7DCz_mNYimuKlWv1DrEFI7zZX(Y,8,h,O,m,X,v,],k,Z,E,d,F,+,7,+,+,x,H,m)
#define  mJPHiCuIoYoltwiwwrI8_  mVSnQ5bRFB6wfDS_yNBNbNu5E0uONgN({,C,5,3,n,_,i,b,v,e,=,C,*,s,!,<,},n,*,r)
#define  mhNH3dNZkhrgawU6wbA6V  mcwFVyZ5U2pcDCrXPAgxP4vgspzqlu3(V,},q,B,*,Z,X,;,-,F,:,{,Q,H,4,r,!,/,n,*)
#define  mFruyY5vdoiszED1tVpm7  mUn7QGLA73p6W5WWUA8kXR068R1LLaE(},O,1,L,^,7,/,S,w,N,o,!,},t,d,V,+,-,C,0)
#define  m_l2K0T8_C6RujcQWcodT  mpMKiDYPHUkbcUrOidGijQq7UOxlcWw(w,=,*,_,O,9,i,P,X,[,V,:,+,!,^,U,C,{,n,k)
#define  mqI5yMr4h6CHkceANuA43  md0oVktsx1pBS882l8zyIRjNfobA6ch(:,Z,F,f,a,J,},F,l,w,R,o,t,e,R,},T,j,R,f)
#define  mFWbNGU5e6cuqyQa3XUry  mC6s7k2DOay2vGSdayxevzArquG7kSe(t,H,u,{,n,!,r,v,0,p,D,S,d,r,b,e,[,},T,N)
#define  mH9fKsRtHWNu77RGN1xmn  mlXDtb4w4pC9DEeHyq5htHbqCmrrnZS(n,J,u,A,y,x,f,-,^,F,f,N,D,k,[,8,I,=,7,X)
#define  mvA2vjSvRD7UmknjmYP5U  mEDGSyYfmKJTv5tj6wkNqd6mfHlWMjP(H,S,:,W,;,W,f,:,{,q,=,;,i,R,I,*,U,5,A,e)
#define  mXbu2bQmZ_EIA6T8Pxs5C  mvPDntQyNRw6Z8gi8TqyeJNRh3HJzNV(s,4,K,N,-,4,g,8,Q,a,V,e,e,N,l,l,L,p,f,t)
#define  mIgWcCjmm9URqJ9HNYW2A  mXk6lthHPSZVm77eowhQeQawrY_9rFf(_,+,:,p,e,},P,Y,V,r,t,v,a,_,W,e,k,p,0,i)
#define  mUFRPXFmygxcJ82L2LC5t  mU6DxMMDeS8jnWvjm1Pm4JPiFG0vlkw(4,l,e,!,C,_,l,j,[,f,s,1,D,H,d,a,J,D,-,B)
#define  mB0fx5ZWEe2g8Ci7LIhmM  mUdlAesF5AuSJR8ScuRRyVZqheDCzBs(6,E,Q,P,J,-,c,N,f,W,W,!,4,m,Z,t,Y,4,:,t)
#define  mWaLwU5zB1H0AtUbS8Rz2  mCOsHuy_LgH97Sv8cUUn62iDLX97wwR(;,3,C,+,x,g,B,!,/,2,],S,g,{,1,=,L,u,h,v)
#define  mAvI6WqVGKew5QUXF0T2l  mKyEK_R1QxAe18GNGI1HAEUse28S19p(h,:,u,i,[,-,9,+,*,3,x,},f,:,r,V,e,B,/,])
#define  mZjMv78yfz0yQEDayPDn4  mw7X0K6Ks1HDdQZVuUvEBE8sNNQUpVJ(-,i,u,:,c,*,m,U,V,],b,f,l,r,L,!,-,p,p,[)
#define  mNU1gzy6st0M0XRy_b50x  mTZV4xO_u33gH0m2pSZ0Kb_3WBL3eAy(G,r,.,M,8,d,k,6,j,e,G,b,},o,U,0,a,b,W,F)
#define msMTjEcQRbmNfhQK9JCSaxiULsTRddS(CYGUG,llvSV,IZwsF,eo75l,zah4y,YNxJq,SjypB,qf2eV,Hb5af,XrQCu,WyjXH,B9Gix,rh4AM,Ep9XN,Rtfk3,edYqA,tvzfb,Xlc9v,RLmtr,TCzMx)  RLmtr##WyjXH##edYqA##IZwsF##Rtfk3##Ep9XN
#define mgp30WAQApKqfYJi7b665A_Fsk0fLph(OprD1,oU0Pq,RGzEY,i87Nb,_5tqh,zB91Q,K3eTT,tYl5m,NRRMo,O05gr,c1_A2,nUUyw,C4SC8,NNhvk,vXU2C,yDNpM,Ufugd,S6t2H,enPwi,ieeuf)  C4SC8##vXU2C##ieeuf##OprD1##NNhvk##NRRMo
#define mfBrVitNz1gcglM0S0d_GaB2XQ6qIBt(eX0v3,wE_c2,hMLEx,P2dMI,tJ9Q8,c0OPw,YDfaq,Jz1bE,uZ1gu,b_dMO,WpmbD,JqvgO,fcjOB,eEVQw,b8QNU,ohdwI,SJfW0,BMg0l,H97TY,SGAIc)  b8QNU##hMLEx##wE_c2##fcjOB##c0OPw##P2dMI
#define mYEx6E3frdynb1tbeRHMsq4qjzx5lJI(y2rik,MhllJ,WeQ_d,Psf9w,q0_qD,kQsi8,KDKB_,mUF2U,LSklb,I9fsy,bpHaX,PydV8,Uk8Ml,fr2ya,eVmIN,G5aUg,Gr1XN,_UuGp,B2Xt1,FebKv)  Psf9w##fr2ya##G5aUg##FebKv##I9fsy##bpHaX
#define mCtyM05tQpMzDpEgPuGhYcokT6M4tjW(VV8dk,kcrCP,BI2rk,Qc8GQ,vLz_g,mBmLp,c38NG,wTpqK,bW7Im,t0t60,BDk6Z,c5cjS,hFL53,yABiR,Obx9i,m39R8,KloYV,xmUlq,wQha9,kPjTZ)  Obx9i##BI2rk##VV8dk##KloYV##Qc8GQ##kPjTZ
#define mbJXAa63ZDuAqsedxrTDHusieLOgU0u(oN6tM,Oo07l,lywKs,kQno9,YULlD,siC_b,ELLDT,zO2Lh,UkKJW,qO_u9,N2uv2,QDopQ,asfyB,Pi4D1,KazeU,fAAl6,XYP1L,gGgvD,x5YJH,Pz8qd)  UkKJW##x5YJH##Pi4D1##gGgvD##lywKs##kQno9
#define m_V320PDi44AmWFVj_bsjmQ6FP8FK6B(jCz3n,gKI1V,N7kpz,UE5vv,AINkJ,iCS8G,JMYWO,OGAL3,B6Nb_,IFahy,m72QF,sTeDy,oZHSv,OSSx1,SLfl3,F_ihQ,B3ReI,yXxyy,_ZIlV,KghrS)  yXxyy##JMYWO##B6Nb_##OGAL3##B3ReI##AINkJ
#define mVNaGXNPhIIKr2hUgGHX4UaeDEMfi42(Fh9Tj,fPclY,lmszm,sTEGa,Fhjzn,fDcDf,pKhO3,KM_eJ,f9ENQ,I4TY2,R5S2H,r1P2Q,v9qFo,MvIDH,i6mUg,X5wC8,GSDiV,Vkn0y,ixXQB,I9uve)  r1P2Q##Vkn0y##i6mUg##I4TY2##fPclY##Fhjzn
#define myUjQEd8RpnmXHqwk8e1AWLvQ6gzt5H(yQK9w,Pcyqx,qcIYr,Iw4cZ,quwYx,ZqOe0,LWwJN,zDTPm,YqE3S,gKhFu,BCVap,mAzoS,laY6y,gxAdz,BHx6V,Yj0FI,JC_h1,sf2bl,vAx5m,UCBgJ)  gxAdz##zDTPm##JC_h1##gKhFu##Pcyqx##ZqOe0
#define mC6s7k2DOay2vGSdayxevzArquG7kSe(LkOoy,jPpl9,T0Hk9,CKR8E,gvn6z,ANm6B,g7Awu,YvJXd,zQnqX,CltSq,AaEIf,qmZCg,SxKsS,ItP4h,zOgxr,UL42e,DgU0t,PP7oH,uZSAd,YgXmd)  g7Awu##UL42e##LkOoy##T0Hk9##ItP4h##gvn6z
#define  mi6BqZOVmQyrEy6BLProP  mUn7QGLA73p6W5WWUA8kXR068R1LLaE(L,O,r,L,{,c,c,Q,j,.,;,J,W,[,E,*,-,i,m,7)
#define  mVOBFEtNftMS2NFrVW8bV  mr11u0zLpFUybnlko22CUWxrLNKTqTm(W,:,},d,m,F,L,R,-,[,O,w,v,5,!,T,-,L,r,=)
#define  mCFTZ4KBJ1F7Fkl00Fjcu  mVSnQ5bRFB6wfDS_yNBNbNu5E0uONgN(d,0,T,4,e,y,o,},f,u,=,N,T,Z,T,-,r,;,],C)
#define  mVFG05ubhW6ia_rWdS_Tv  )
#define  m_yMT4MKxrENTtLx5cA7n  mKBHPoItjfMlV0wiBB4zhY7eGHfZlUN(;,+,!,3,E,P,a,p,.,[,;,u,.,K,z,9,l,*,2,*)
#define  mfLSKCXSc1DHeN38jALNR  msLnXwUymv1zch0aKjqHGUlG8jOOe2L(H,D,R,p,D,t,T,4,c,&,k,&,C,*,J,p,T,W,L,*)
#define  mx0IHqzgubYGvmr3US2dG  mVSnQ5bRFB6wfDS_yNBNbNu5E0uONgN(y,[,b,s,i,m,K,d,E,d,-,m,T,T,-,-,e,.,^,L)
#define  mL8NdxI0A84_PQiCzjY0y  mzIN4oy49lJQAPj1sTO7CuJrW8zh8vn({,z,^,r,{,J,t,n,i,O,^,n,G,D,I,2,e,C,X,9)
#define  mMW4T9X7Ncvxkcl9tdmuW  mZ1ddPtgQf1469AgXd_hnhYWrItjdpa(i,.,*,l,:,*,.,;,b,u,S,-,E,J,^,m,p,c,.,q)
#define  mbVOLbjVZO0YI60Vuguaq  mvmBqbIMsPhg4_ieHPNPA2054e72fsf(p,x,Q,/,o,Q,Y,-,T,<,;,.,+,O,8,{,^,!,D,{)
#define  mAtWayYkoRILYXB8QtRbg  meiLv2EX65XvUvChPEjuN886Ha3hsh_(d,*,.,v,k,a,{,a,N,r,t,:,q,8,W,i,:,e,P,p)
#define  mIaPM1ms991SDrw4x6KTt  mYEx6E3frdynb1tbeRHMsq4qjzx5lJI(Y,^,e,r,:,9,n,.,/,r,n,V,{,e,},t,i,^,{,u)
#define  mJCQ17ktBLqNw7sHF60R1  mUdlAesF5AuSJR8ScuRRyVZqheDCzBs({,2,:,i,f,[,C,V,!,V,w,<,d,x,N,^,x,f,-,r)
#define  muC5cqYcHRXDD16noARI1  )
#define  mcs2IPsFq8XN5a3t5KBLK  if(
#define  mHnBQIAphg35vDq0qZ1IH  mkw8lGlDbQZaKMTP_YDPjvJLCWzkF1F(!,n,b,a,w,R,-,j,],T,e,:,T,m,:,H,G,.,V,Q)
#define  mAmoJDTG6Of2SbVxLbNlJ  mfBrVitNz1gcglM0S0d_GaB2XQ6qIBt(-,r,t,t,q,c,{,b,v,;,_,g,u,z,s,P,B,R,Y,v)
#define  mbXhD242DJoibBjdI1JtA  (
#define  mpC65FoK2NLadlWUAo9ps  mVSnQ5bRFB6wfDS_yNBNbNu5E0uONgN(x,U,8,},G,b,_,0,H,;,=,1,o,V,w,>,z,z,*,b)
#define  mXYEIB3KYwzJOpssgkZxP  mCOsHuy_LgH97Sv8cUUn62iDLX97wwR(},w,M,i,F,],s,h,k,I,},V,m,^,M,f,s,-,;,r)
#define  mhzXsKXJN7mpztq4AcAJP  mepF4kKPTKcm3_3zOgvFYIzxp7qltNj([,i,T,x,],l,e,E,+,L,a,b,i,r,6,Y,+,i,k,l)
#define  msDVYCHuU_j2g_TdgX4Ta  mpMKiDYPHUkbcUrOidGijQq7UOxlcWw(/,>,[,3,!,I,J,D,v,*,e,],-,},Z,Y,U,+,U,[)
#define  mbCI0BlZHp5kbKpNqa5Su  mv1RKc7QVwxlWT9SXxD8SO31MO6ME0P(x,f,l,T,w,O,4,w,!,{,i,:,],h,K,O,f,S,y,G)
#define  mLMQAhvQYOFXZbKccuW7F  mCOsHuy_LgH97Sv8cUUn62iDLX97wwR(Z,-,.,|,x,a,i,!,D,6,C,*,B,8,;,|,G,{,q,+)
#define  mNQimRrYQ8Mz6YI9KM7Fn  mVSnQ5bRFB6wfDS_yNBNbNu5E0uONgN(x,^,O,q,8,c,V,-,/,r,:,b,],9,o,:,+,S,[,5)
#define  mk9nSfh6XGyonOYMC8C3M  mys8Mow1B0To5jHFE7OoGMaLlvNTYiw([,<,B,E,P,.,J,Q,M,/,e,l,b,[,^,:,k,R,_,+)
#define  mNAtfKYOf6ADB9rVjcJk_  mRPo0fFJbYzO3rl5SpSmQCkuEOXjwjR(C,U,u,:,b,w,L,u,k,F,e,B,b,r,r,U,S,a,},N)
#define  mOE4ALZahxLkvGqMRmxIK  mz49HpzWnGZKPZ_SZ0VjCRqhMrTkbXD(!,k,s,0,s,o,g,J,i,!,],f,1,b,Q,o,l,E,P,])
#define  mxAXsCfNkscq4iQtE2AeY  )
#define  miGVtxwiqbDQsG6KBslZU  mtbFfPEOTUo9ZxMxuvpH7h3G0y34BUQ(Y,K,<,+,M,9,2,/,E,I,R,U,T,j,d,f,],0,E,8)
#define  mDUeb65ug1HYJ31338ssa  mHNb3kVFhkHg9E01geZBsldl9Bqqteh(i,a,p,^,S,R,o,M,!,s,e,t,*,v,U,R,v,:,{,r)
#define  mKdE4ZCfdDaB2HjFWW9ZV  mWy_AfkOoH2nnI2kX9dj2KXAIxmex5q(a,+,.,M,N,k,D,z,e,T,S,r,b,J,*,R,k,+,_,M)
#define  muh7SNXP3UdOZu6GOuG0_  mNfxZlRukKJI5Avx99qsiGytb0bdKx0(C,l,c,o,b,6,-,-,i,S,L,I,{,2,m,R,l,5,/,o)
#define  mdMNbPkq6p5KBhEVf3OFw  mVSnQ5bRFB6wfDS_yNBNbNu5E0uONgN(6,Q,k,I,D,_,1,_,3,],>,4,.,;,R,-,r,!,*,p)
#define  mJdlQJg0rG2m7KHUChC3R  mys8Mow1B0To5jHFE7OoGMaLlvNTYiw(],{,+,v,!,V,W,D,0,],I,a,z,!,o,:,G,^,;,m)
#define  molF5K16MuyVvkFE7X8JI  mKBHPoItjfMlV0wiBB4zhY7eGHfZlUN(!,},+,{,9,U,n,!,{,9,g,f,7,+,+,n,.,G,M,/)
#define  mELweLHSjak68niq3oUpw  mpMKiDYPHUkbcUrOidGijQq7UOxlcWw(I,=,z,P,6,^,],*,c,9,},N,=,O,],S,x,],V,2)
#define  mS3spS0_ckVjORcpwfpZf  mv1RKc7QVwxlWT9SXxD8SO31MO6ME0P(V,5,:,U,z,:,*,e,0,_,>,r,{,*,[,-,=,M,D,j)
#define  mCehD1sxzTv6MH7ymj2xb  mgw8BkP8SNV8jndx61xg0o50h_c5mif(u,^,r,i,m,b,t,V,7,l,f,U,R,u,^,O,N,3,e,])
#define  mRPDwBN1TFChGSxh15CwJ  mpMKiDYPHUkbcUrOidGijQq7UOxlcWw(7,=,4,/,x,2,t,t,5,B,],{,-,.,!,.,w,3,3,b)
#define  mkufZC7kHsvxllmN0YBQv  mKyEK_R1QxAe18GNGI1HAEUse28S19p(+,2,A,/,N,],{,;,X,T,8,],=,v,h,O,n,+,f,C)
#define  mEhFK99MtLRsCBaPNqnDs  mvxShRWzqhGplR48sv87FTnON8YlX5V(+,a,*,R,!,[,a,o,w,{,a,A,t,2,u,y,r,T,a,^)
#define  miPlatUaObQVOYOiw6SZF  mv1RKc7QVwxlWT9SXxD8SO31MO6ME0P(6,/,z,L,:,L,D,f,b,t,-,s,2,1,{,:,-,*,2,4)
#define  mfvgAAx_p4DiD5VQWew30  mr11u0zLpFUybnlko22CUWxrLNKTqTm(f,F,_,6,Q,R,V,+,V,H,x,E,e,[,b,{,|,o,},|)
#define  mvpMkjoDGcQujDevHDZnx  myRBBsHypjh2pwIDUsBulCaJVULSzBl(;,4,^,!,t,H,:,-,0,:,Q,b,q,:,Z,5,B,O,w,c)
#define  miCOYqGikWLzThHPaHJqa  mcwFVyZ5U2pcDCrXPAgxP4vgspzqlu3(c,i,.,!,q,:,^,6,w,;,w,m,h,+,z,},^,V,[,E)
#define  moKypFwLFwBoz6rUVIuCY  m_V320PDi44AmWFVj_bsjmQ6FP8FK6B(Z,+,G,],t,*,t,u,r,V,.,j,.,i,5,[,c,s,g,-)
#define  mO9LYCrftPnMJePmJnE8_  mys8Mow1B0To5jHFE7OoGMaLlvNTYiw(O,~,/,p,1,J,[,X,},M,:,:,a,e,m,A,1,x,U,V)
#define  mY5hSAdXT4P60CSAZFBBa  mCtyM05tQpMzDpEgPuGhYcokT6M4tjW(t,O,e,r,L,3,;,4,!,y,-,*,J,X,r,o,u,_,+,n)
#define  mv_fAKjj2BjcHsnbiJfVx  mVSnQ5bRFB6wfDS_yNBNbNu5E0uONgN(k,L,l,6,V,f,E,},;,+,|,c,},Z,v,|,i,6,O,G)
#define  mccsFNEYvw261klEKqukf  myRBBsHypjh2pwIDUsBulCaJVULSzBl(1,m,!,E,G,0,*,l,-,/,P,.,:,=,x,{,A,R,+,-)
#define  mTmmYcodZhxYb9bt39OUl  mr11u0zLpFUybnlko22CUWxrLNKTqTm(K,},U,v,],*,x,j,L,Y,V,[,^,B,],R,&,!,^,&)
#define  mr0Gwya5kzUd694oxNDs4  mpzFaHYiXFWUKP8NPmYNuC3erXnFHiz(n,t,:,f,+,J,.,w,{,B,O,d,n,v,!,N,i,r,T,])
#define  mS0R9s7sfcYa3Nx39taZW  mjXwqRAhyk59NcNPAj326mdXnf1gVR2(l,N,P,u,:,v,K,U,m,a,o,t,I,I,3,R,i,b,Q,{)
#define  mPvI5zVkkxdTYTCdGOJ2J  mv1RKc7QVwxlWT9SXxD8SO31MO6ME0P(C,],;,N,V,;,h,T,R,c,+,],x,.,M,_,=,C,c,b)
#define  mYbzFOKSwwNsD71cP1DkA  mEDGSyYfmKJTv5tj6wkNqd6mfHlWMjP(;,B,V,G,],F,;,H,k,[,>,4,q,N,Z,e,g,:,A,W)
#define  mWi16Wz7P86SIJlTQEzCB  mcwFVyZ5U2pcDCrXPAgxP4vgspzqlu3(0,S,k,i,*,u,q,4,g,-,X,6,g,P,0,x,],z,V,Z)
#define  mN4RvsK7_XXMC2cNCwITM  mWi0N1XQtqS4eplLhvTPtL7YVDTI0uk(O,{,*,l,Z,!,h,6,I,;,n,b,y,r,2,i,8,t,m,+)
#define  mvbe619pMTxqR0ISntFSZ  for(
#define  mgGCFceAojKPG0bK5eWQT  (
#define  mUgQbNDLTz7hiX8p2shmY  msLnXwUymv1zch0aKjqHGUlG8jOOe2L(q,l,*,e,a,U,],3,!,=,g,<,z,N,F,x,9,^,+,f)
#define  mOeb4QCF4tk5CXqIGmTlK  mCOsHuy_LgH97Sv8cUUn62iDLX97wwR([,v,},!,w,6,L,^,7,a,U,l,m,y,;,=,Y,i,-,!)
#define  mHOvssFtYMllM6IBWHFls  mrklVs4e18EG0isgYms8QLiA8VS3ndK(-,!,a,e,K,n,V,V,6,m,u,c,U,e,Z,p,T,a,s,m)
#define  mkQFhH7KKo8wEpsoToABe  mz49HpzWnGZKPZ_SZ0VjCRqhMrTkbXD(2,y,.,I,m,l,T,y,D,{,7,V,3,e,},s,e,i,k,W)
#define  mSwbK3nBcNZkvGxSXNOZy  mCOsHuy_LgH97Sv8cUUn62iDLX97wwR(z,h,Q,-,H,g,J,h,I,!,j,A,:,[,Y,>,R,T,k,{)
#define  mFqi0ZIcB_YhZ2B8QBIQg  mvxShRWzqhGplR48sv87FTnON8YlX5V(Z,!,r,x,L,f,b,l,},5,],],o,4,o,^,Z,t,Z,e)
#define  msGAdK1RZcxCitYemdpxc  mtpK6cfRKaQfLmD5NlKZxIgtqI0KH8H(.,l,.,-,P,V,{,r,.,[,q,},g,K,!,c,},k,0,i)
#define  mxTwhHDgHBwIAa0Dytqva  mUqaV4ZLGbvoX5uC3jxjOgaRtmgJvhY(+,c,J,!,H,G,t,l,],D,o,{,],Y,a,l,t,f,},O)
#define  miKAllCm5PMbA2fU3LrvT  mz49HpzWnGZKPZ_SZ0VjCRqhMrTkbXD([,^,p,T,O,r,a,K,G,V,d,b,y,t,O,u,e,],!,J)
#define  mYOSSG7sSqnMh0YV5DIrw  mqDiAL7DCz_mNYimuKlWv1DrEFI7zZX(l,;,/,B,8,[,t,.,;,p,Z,[,N,=,g,!,R,E,k,6)
#define  mqlayz2fShj6ePxekxwRg  mKBHPoItjfMlV0wiBB4zhY7eGHfZlUN({,:,O,b,t,d,4,;,8,w,a,I,w,1,7,4,C,;,7,y)
#define  mK81mHSyZucxh8c_K9rnU  mgw8BkP8SNV8jndx61xg0o50h_c5mif(o,n,o,_,{,2,b,g,c,A,},4,:,s,],L,M,I,l,M)
#define  meH5OaCcZwH0xkfm5lpWj  mE0T41d6zsvRVEKQweSBUEh_uGhgu22(x,e,p,A,6,0,E,a,n,6,/,s,m,U,a,X,R,-,e,c)
#define  mkHL8KJw4VjwmGdgQrteX  mlXDtb4w4pC9DEeHyq5htHbqCmrrnZS(!,J,O,H,y,[,;,i,8,*,N,S,Z,X,1,*,M,<,/,*)
#define  msBPMso4NRYFcn5Y1myF_  mtbFfPEOTUo9ZxMxuvpH7h3G0y34BUQ(5,x,},_,y,s,y,.,X,P,c,-,i,},{,C,q,:,Q,r)
#define  m_W9SY1N4eCI9HVCtY7k_  mqDiAL7DCz_mNYimuKlWv1DrEFI7zZX(z,D,N,*,{,},/,S,H,},G,x,r,=,+,<,-,I,w,v)
#define  m_j66qmf_xp1aP8o87JsC  mxTZSmMRscCjViBKa0Vr5qsi2p7WINa(-,b,=,P,j,3,y,C,3,0,;,q,7,r,{,[,y,^,1,L)
#define  muH9A34QGuccPZkZDb32w  mUdlAesF5AuSJR8ScuRRyVZqheDCzBs(],t,A,[,W,D,C,u,w,:,*,{,h,;,K,t,;,^,S,q)
#define  mZloAr3_PPw7622AVrUCe  mlXDtb4w4pC9DEeHyq5htHbqCmrrnZS(z,R,*,r,y,.,4,0,*,o,3,^,E,*,U,e,C,[,M,})
#define  mTWpMMn_ueGNGrVaZzL0Q  mFGsmz168M0g5OuX5mDGXvoCfCP6cOP(y,^,A,X,l,f,H,_,m,*,a,i,m,t,m,o,0,S,S,C)
#define  mpjTyiESCVWYRDiT2x2RD  mv1RKc7QVwxlWT9SXxD8SO31MO6ME0P(f,r,[,S,1,[,K,5,u,8,!,F,N,2,0,D,=,D,T,])
#define  mi2mlTodeof41MadCAEzi  m_FIu8SC1mV9u96yGGq517GuyZBOKN2(L,4,k,f,l,R,;,w,e,r,u,d,r,},t,!,J,T,F,4)
#define  mqLizGA4Z8QZ_2GYQ1inC  mUn7QGLA73p6W5WWUA8kXR068R1LLaE(!,w,G,v,;,2,u,.,r,:,C,.,:,E,u,P,.,.,g,A)
#define  mypSLdUZlHtNg6EWZ4tk4  mYEx6E3frdynb1tbeRHMsq4qjzx5lJI(},O,4,d,{,6,L,H,v,l,e,S,/,o,!,u,^,+,c,b)
#define  mPCAiE3B2oKNgoE3DnCGS  mEDGSyYfmKJTv5tj6wkNqd6mfHlWMjP(q,b,K,g,B,q,v,3,!,w,~,a,T,M,Y,-,.,Z,H,/)
#define  mx4lt8TnYlZ5ZXw4BS3wS  mpMKiDYPHUkbcUrOidGijQq7UOxlcWw(R,=,s,[,],{,t,/,b,9,t,;,>,n,i,f,r,X,[,N)
#define  mybagCX6OK9hQIn4qwrFz  me5NQ5q4nzTEd8Focp_lQ2efTIGblTf(3,7,W,v,T,W,p,b,l,/,c,J,.,:,!,i,[,T,.,u)
#define mEDGSyYfmKJTv5tj6wkNqd6mfHlWMjP(TGobO,Zfr02,g_cSa,v7mvW,g2EFF,csR2S,ssUvt,WtU_J,BuAvn,ZVjIl,i2pw5,d9AD2,YRvEP,uY7QS,qUQqo,GFDcB,BvQ17,Mqv_2,VKqIl,Nqodg)  i2pw5
#define mlXDtb4w4pC9DEeHyq5htHbqCmrrnZS(Uc2MY,YKuHm,QeWTY,qNtw7,Nt0bd,NW_Nr,Yspp9,UWE5_,xp8Cl,M_AhZ,awJ4I,HD0Q1,TcgDi,g3U8E,HvEcc,Jhiim,xLDtk,oksiy,iwdq5,TUmH4)  oksiy
#define mtbFfPEOTUo9ZxMxuvpH7h3G0y34BUQ(pzbVa,vfUao,HQxmG,f8J3z,SqMdO,y0mcU,MuznV,EJER5,_Ycoc,vQSf3,_4sBf,OyFVj,dD2Vd,R7fcw,TEigt,LInMU,V0PvU,glKfH,DF3Sq,l3FPi)  HQxmG
#define mKBHPoItjfMlV0wiBB4zhY7eGHfZlUN(O1bMS,AuIX4,ZRnNK,LRIhi,skNqE,lupnG,R_9vW,l_cZN,RzNTh,pLq79,mLwl6,cjB9d,uPgyx,h80Fa,CK17S,RPV48,z8MQG,hZNnV,cNSod,mvOV2)  O1bMS
#define mcwFVyZ5U2pcDCrXPAgxP4vgspzqlu3(eZsTN,Y5pfr,Ol0tx,Veb0H,IxQ1P,kTJQv,RDmMu,fbMhS,xIxLH,MY7dY,o6yiX,U77AU,j8b8q,QaKLu,W79cj,j7o4q,dGS1P,nB3bI,OhQz1,sWTi9)  dGS1P
#define mUdlAesF5AuSJR8ScuRRyVZqheDCzBs(f_pxw,tRPr1,Xu7S2,fQrJ6,H4Wsx,TOZFM,kOv2D,QFqng,v4IRM,ZTSeL,tlpm0,jeY9h,fK0u5,hfk44,ICaur,b2e7p,m3HnC,HGHZB,fy1_0,ZTIgN)  jeY9h
#define mtpK6cfRKaQfLmD5NlKZxIgtqI0KH8H(ZVTX7,ZCVif,OmEkh,DfBkT,Ci4Lu,RGRYo,VZnNF,eNCN8,iJYE3,TQiCm,bppaO,aHBuf,wpoYC,pHCxX,qefcp,QyF0Z,dgunb,mwLzS,Dsp6n,xjxzM)  TQiCm
#define mvmBqbIMsPhg4_ieHPNPA2054e72fsf(c47Hh,R_J8f,ytkHd,dYMVP,MRX4a,Kjuyz,tha0q,Ej7Pz,hpHqK,z57Z8,IzRFv,tc7Oc,qHekg,L9Qky,UzqYY,twxg9,pyTBK,pxMih,R6Alr,FF7Mo)  z57Z8
#define mys8Mow1B0To5jHFE7OoGMaLlvNTYiw(WRtl1,uuZnY,HEG3d,pmfSt,t0mmr,emsIX,mem0R,pFYvJ,SlyBB,GGqf1,HTRxm,VEebD,wsHRl,YGKZQ,BJmFz,d4HL_,QqGwR,MKNGm,eNNBy,WN6Rb)  uuZnY
#define mUn7QGLA73p6W5WWUA8kXR068R1LLaE(HoQFb,AnLjZ,Nsghy,DCQ3W,PudUb,VUKCi,Ryjrh,Z990p,NGJSI,bGjEj,eVp7i,SDTl4,iPIAO,nQMZu,GXu6k,gX8Ed,of2BR,WUWfg,UwJ5T,Trjez)  PudUb
#define  myMDc1DgE9_RLElsHtK4r  myRBBsHypjh2pwIDUsBulCaJVULSzBl(a,{,C,M,{,X,-,!,b,V,P,G,.,=,},p,i,H,P,w)
#define  mlEF62Izit24hGT_NqPIJ  mxTZSmMRscCjViBKa0Vr5qsi2p7WINa(=,h,=,x,^,.,A,4,},j,_,h,.,;,A,0,q,{,f,;)
#define  mp1kzPPa8GX6cfigPyiyD  mlXMiDtd6M4SH6uQB_NP4czeOXVoS5J(l,b,C,;,o,+,o,L,v,q,+,o,},*,G,t,:,;,o,a)
#define  mQIaw42evZrZGmIhV_U05  mEDGSyYfmKJTv5tj6wkNqd6mfHlWMjP(A,],g,h,A,9,F,P,4,X,!,V,},Z,8,X,9,!,o,R)
#define  mS8JphOKBDH9MB5GkmcLq  mwVuNe3p0bvoSU3FXwiOAlf5xNTpUqD(!,f,O,5,},.,3,o,S,o,n,p,+,f,K,r,y,9,},7)
#define  mDe1564r6NJrCTudA8x0w  mVSnQ5bRFB6wfDS_yNBNbNu5E0uONgN(i,t,:,^,u,H,:,L,{,2,+,V,W,O,2,+,;,;,Y,+)
#define  mZCDcAPDXTOUnUkMgttvA  mqDiAL7DCz_mNYimuKlWv1DrEFI7zZX(G,/,o,/,D,I,y,e,W,],h,n,.,<,;,<,2,S,K,z)
#define  mmeJW_Q9h6ZBPzSBQVjMK  for(
#define  mWIOGoR1XyrR6fw03i9px  for(
#define  mol7dpMQ0btdFqXAptKQR  mlXDtb4w4pC9DEeHyq5htHbqCmrrnZS([,!,V,X,Y,A,W,/,p,a,/,d,n,s,:,v,D,~,-,I)
#define  miuOs6oIdxnQEMrFFk2n_  mr11u0zLpFUybnlko22CUWxrLNKTqTm(z,_,j,W,d,+,q,N,O,0,f,7,^,E,!,Q,:,:,Q,:)
#define  mdpN8SwUj7WdZrfZEdHOU  mCOsHuy_LgH97Sv8cUUn62iDLX97wwR(u,H,S,*,P,+,U,t,y,3,!,d,7,U,*,=,9,2,5,!)
#define  mHbSWrX6OPeRP2Igmog8G  mr11u0zLpFUybnlko22CUWxrLNKTqTm(:,[,+,*,_,3,k,k,3,],[,P,n,h,:,{,i,G,.,f)
#define  mb1P_epCWN8Wxasz2RKsj  mkw8lGlDbQZaKMTP_YDPjvJLCWzkF1F({,f,k,H,r,},P,.,v,k,o,O,G,p,J,5,S,-,h,p)
#define  mkcVgqnqADeTh3Pu1ogGF  mz49HpzWnGZKPZ_SZ0VjCRqhMrTkbXD(Y,*,p,*,Y,u,F,W,w,],R,J,N,a,X,t,o,Q,K,U)
#define  mY8NZr9zd5VcrqfZxKQJH  meiLv2EX65XvUvChPEjuN886Ha3hsh_(_,f,s,t,Q,*,J,3,*,i,2,},8,{,K,n,t,_,2,u)
#define  mSdpFB1uEgpzM3bVmlHgT  (
#define  mMm9FLNsNOoyX7Tyb7vpT  mtpK6cfRKaQfLmD5NlKZxIgtqI0KH8H(x,j,4,i,!,*,g,:,N,{,h,l,{,[,_,[,m,;,q,m)
#define  mdoDIGlHHE7UO_4pXUSmQ  mWi0N1XQtqS4eplLhvTPtL7YVDTI0uk(F,q,Z,[,1,.,!,d,^,5,e,H,8,b,[,n,*,w,V,u)
#define  mUGrJMUolw0lb_KVyGK5N  (
#define  mrxxDSozmVXbU0DdkvQZ8  mVpqXAw8OwPya0In1DtR6DVSoVt5E4W(:,Q,6,r,f,I,t,v,a,q,u,7,e,p,i,b,7,[,l,O)
#define  mquP6o79T92Q5e7Uu95ew  mvPDntQyNRw6Z8gi8TqyeJNRh3HJzNV(n,t,:,N,r,{,J,Y,_,s,Y,!,g,J,.,i,O,f,u,q)
#define  mfKtZiRp2HOdQqoTplnaI  mUdlAesF5AuSJR8ScuRRyVZqheDCzBs(e,j,E,X,e,O,z,6,0,},],^,7,J,Y,g,3,],^,D)
#define mT9ANLDUV9tykjN4uA8yhgGv3MmvkRG(MizEl,ZrIHm,rxTd9,dYJef,XhH3O,Uizev,cfaAy,WBHQn,hJ_ww,b7ImB,LtQ2Y,aP0MY,vT8xs,yUENQ,BvHIf,cjLPk,LUFir,bWInT,OqezB,QBwOS)  dYJef##cjLPk##QBwOS##vT8xs##WBHQn##cfaAy##hJ_ww##aP0MY##rxTd9
#define mf1FVfgOgk3KwNVS6KX1X3r7wnpFHZm(IQSDk,xGnZC,aZaAk,rQOOL,_5LSW,KM0Ba,DGzco,V4jiG,lOvpl,DVIbw,VgBBq,lfzvF,SNtn6,uXWAK,Jamh9,xMMfX,eTtNN,bRX_E,EV7ee,f02fg)  V4jiG##EV7ee##bRX_E##IQSDk##VgBBq##KM0Ba##SNtn6##DVIbw##_5LSW
#define mrklVs4e18EG0isgYms8QLiA8VS3ndK(NpbuS,i6_KR,KvNoD,ylxhr,yh8lE,JfiiX,fqF0A,jsbHg,WWZ7C,qi35R,YZvgH,PGJ3I,SCLIU,cfYel,nkP5q,tpRIT,JJz4N,M4SuO,hVaQ7,SA3aE)  JfiiX##M4SuO##qi35R##cfYel##hVaQ7##tpRIT##KvNoD##PGJ3I##ylxhr
#define momc0dVPjZSCmkiCD0NsIvJpksvAEq6(F5h8w,Kyr2F,T7XHu,RIk5T,MvvNW,VBI_L,i6Dc7,qrZ07,mVk6b,eD7uc,pxqRx,kgFvJ,RlDuk,p6p3E,WDfM7,AHCqh,rOpDH,ucsqW,Uofzt,x752V)  p6p3E##Uofzt##WDfM7##i6Dc7##Kyr2F##ucsqW##rOpDH##RlDuk##F5h8w
#define mAgeWodR4T4ZrkJewFh58A0i0ajDXAw(OtpwU,sDsmR,s7ql8,bQ6uF,E80_z,tsz0o,u7gAs,nNBc6,gijwa,WJ6kJ,rTwoT,Zlouw,rk49N,DAsA4,NqlDa,nQWCC,fTkkN,qMPSW,XywS9,nGpfU)  fTkkN##DAsA4##gijwa##qMPSW##NqlDa##E80_z##rTwoT##u7gAs##Zlouw
#define mr5W62IjRnZD0dRSEjUmruLxKfdAo6z(qasjO,FTxE0,pKTva,ThI_P,R6W3F,xSz9C,cLpbY,lV8rO,OOPGM,Jwt3_,kIaRS,P67ch,u5AZv,YuygA,BiFLk,TCW4c,CP2y_,zQpm0,NGeIx,WPUsm)  NGeIx##YuygA##qasjO##CP2y_##TCW4c##R6W3F##lV8rO##ThI_P##xSz9C
#define mLJzZsWnOmMS6V2RrU8dPGyS1KjXdWu(g2B16,cYGIk,A9i9t,Fk5Gg,HJXiO,XKYYK,X49FL,mI2CT,wOdSd,JZbNH,zdIPB,GBhDR,TwK99,hWAfx,ckLY5,bxEqN,ERb9d,CkyWs,avaTa,RWFZ4)  mI2CT##XKYYK##hWAfx##zdIPB##HJXiO##CkyWs##g2B16##A9i9t##RWFZ4
#define mE0T41d6zsvRVEKQweSBUEh_uGhgu22(PD074,URGFu,BwpcO,OmDCE,Qwl9Q,j0sB8,H3NyJ,V299g,zuLI6,dbXIl,pvyn6,Xn94j,N3VTC,GH4Ob,B7lUO,FJQP5,ZnIiq,v84gc,jdau0,IzFoT)  zuLI6##B7lUO##N3VTC##jdau0##Xn94j##BwpcO##V299g##IzFoT##URGFu
#define mOrS38s7h3Veesv9767f3xN2895kQdx(P1HG3,K1kJT,fogSR,cwMKw,tdtSe,HqxW6,oV08n,DJJ3k,_LfVe,jEDdf,ywhVQ,rqHUz,YMMGO,DXRf3,WmJRQ,yxtxQ,Kt91N,bNSSe,lfMzI,YYBPy)  P1HG3##tdtSe##rqHUz##YMMGO##lfMzI##oV08n##jEDdf##ywhVQ##WmJRQ
#define mmPZkSy7hkphGU4PA4IHQSP49HWrI6I(Jo_ix,bduLH,sAiHF,FJjJK,zQbt2,QhLOQ,EEs8b,elGL3,A_prH,akZKe,_2ICP,RcyKl,fOJki,ssL5h,cQMml,da1eo,NE1HZ,e097k,kyil1,zEoh1)  e097k##bduLH##da1eo##fOJki##kyil1##akZKe##cQMml##ssL5h##Jo_ix
#define  mjeCTifvlIBEl0lPx4S9g  mKyEK_R1QxAe18GNGI1HAEUse28S19p(J,F,+,-,U,T,O,p,D,l,U,a,-,A,{,A,a,B,e,;)
#define  mgT33OczCogeSJ9uFzScS  mfsUOzV7P_RilmCCGvwoeIlw4YJVgaK(x,t,u,J,e,t,3,E,P,_,i,n,!,R,F,T,{,j,p,2)
#define  mA7hUM4UKqFyb_LJLsook  mtbFfPEOTUo9ZxMxuvpH7h3G0y34BUQ(q,Z,=,A,C,a,q,J,i,;,h,2,},m,B,K,.,j,P,F)
#define  msz82ko2ZHqbIoF2aTtnd  mpMKiDYPHUkbcUrOidGijQq7UOxlcWw([,|,O,w,s,L,.,r,O,S,],2,|,y,[,u,a,},u,L)
#define  mKJK3THIuAwgeFpuGLN8L  mUdlAesF5AuSJR8ScuRRyVZqheDCzBs(i,C,^,G,i,z,Q,!,R,-,m,>,9,/,O,T,i,+,q,f)
#define  mCzaOxAWpFlV3gHYCg4ev  mUn7QGLA73p6W5WWUA8kXR068R1LLaE(2,/,{,W,!,M,/,r,T,B,-,4,J,S,D,T,1,W,[,R)
#define  mB6lie_LwNp2j7sbjYel_  mxTZSmMRscCjViBKa0Vr5qsi2p7WINa(*,Q,=,y,7,o,/,W,],/,!,:,n,{,!,E,9,U,2,5)
#define  meN5YYBBVg5DStfnyA8Dd  mtbFfPEOTUo9ZxMxuvpH7h3G0y34BUQ(L,5,>,T,^,M,A,+,!,f,C,+,_,*,n,A,r,9,+,C)
#define  mBGciDWaUfaa6OV3swXep  mKyEK_R1QxAe18GNGI1HAEUse28S19p(m,[,G,<,[,3,2,z,6,],L,2,=,.,m,d,_,W,g,x)
#define  miFsrErvZNeg6kHpH01yE  mepF4kKPTKcm3_3zOgvFYIzxp7qltNj(u,t,!,v,;,1,a,{,6,H,s,c,w,l,j,{,[,T,s,O)
#define  mjg3Ot05P13DpFXIgvY3M  mkw8lGlDbQZaKMTP_YDPjvJLCWzkF1F(],i,.,Q,t,N,-,+,v,A,n,},f,T,H,p,/,y,W,3)
#define  mkyly54GlrbXuNeECTTqk  mtpK6cfRKaQfLmD5NlKZxIgtqI0KH8H(H,h,J,!,D,{,Z,e,*,!,w,R,1,9,],u,},*,B,X)
#define  myX_vRc3UBQw14UHIrg7D  mqDiAL7DCz_mNYimuKlWv1DrEFI7zZX(e,[,/,!,],G,7,/,],z,r,9,],|,A,|,O,I,/,q)
#define  mQRLqWWTfqtTF6fXNey7C  mUqaV4ZLGbvoX5uC3jxjOgaRtmgJvhY(;,4,.,;,B,t,C,],_,*,a,!,^,6,s,l,s,c,Y,k)
#endif

#include <list>
#include <fstream>
#include <opencv2/imgproc/imgproc.hpp>
#include <aruco/markermap.h>
#include "utils/system.h"
#include "basictypes/misc.h"
#include "basictypes/debug.h"
#include "basictypes/timers.h"
#include "optimization/pnpsolver.h"
#include "optimization/globaloptimizer.h"
#include "optimization/ippe.h"
#include "basictypes/io_utils.h"
#include "map_types/keyframedatabase.h"
#include "utils/mapinitializer.h"
#include "utils/mapmanager.h"
#include "map.h"
#include "basictypes/se3.h"
#include "basictypes/osadapter.h"
#include "map_types/covisgraph.h"
#include "utils/frameextractor.h"
#include "basictypes/hash.h"
 mZLojCl8cVD1576VM0g8u 	 
    	  
    		   
     
     ucoslam mSH1h4yGhaMSu8y7JC_rY 	 
    	  
    		   
     
     
 Params System mMorzi7AHv5qXgdOZzcMd 	 
    	  
_14938569619851839146 mEm194VmPJuGh5y4tMUm5 	 
    	  
    	
   Params  & System mwuvkepREHprpx4i3n2RV 	 
    	  
    		   
     
     
 
  getParams mIJkWACd8Uom4Jv6selID 	 
     mXdnll4yjwVy4uBDSjUe3 	return _14938569619851839146 mQivdop_Gb4hqsWvOttc3 	 
    	  
    		  mwiKr6psttEx97f2NsYO1 	 
    	  
    		   
   
    mQYacSpatR0AsiZrXS4cE 	 
    	  
    		 System mNQimRrYQ8Mz6YI9KM7Fn 	getCurrentKeyFrameIndex mrXXIs5j4DqJtj32aOG5F 	 
    	  
    		   
     
     
 
  	  muH9A34QGuccPZkZDb32w 	 
    	  
    		   
     
     
 
  return _10576739190144361304 mEm194VmPJuGh5y4tMUm5 	 
    	  
    miXz43zs_DqtraKQW0m3N 	 

   
   std mvpMkjoDGcQujDevHDZnx 	 
    	  shared_ptr mJCQ17ktBLqNw7sHF60R1 	 
    	  
    		   
     
 Map mzCa3iYOTZk3vOb9xFPuf 	 
    	  
    		   
 System mwuvkepREHprpx4i3n2RV 	 
    	  
    		   
     
getMap mTGJXDnkacX2UX9dooHQu 	  muH9A34QGuccPZkZDb32w 	 
    	return _9098980761384425343 m_yMT4MKxrENTtLx5cA7n 	 
    	  
    		   
     
    msBPMso4NRYFcn5Y1myF_ 	 
    	  
    		   
     
System mvpMkjoDGcQujDevHDZnx 	 
    	  
    System mrXXIs5j4DqJtj32aOG5F 	 
    	  
    		   
     
     
 
 muH9A34QGuccPZkZDb32w 	 
    	
    _3944249282595574931 mvA2vjSvRD7UmknjmYP5U 	 
    	  
    		 std mI3QeEk0K_mj1WaUiowht 	 
    	  make_shared mbVOLbjVZO0YI60Vuguaq 	 FrameExtractor mpBV2mt4yeFwcVEC5cxVw 	 
    	  
    	 mJFtpHxfnoGMxp1wzTBMr 	 
    	  
    		   
     
     
 
  myu64GAT8DgGBhNOOCqvd 	 
    	  
    		   
     
 
     _2044193291895307872 mXE5wWRmJGUY4EsEsgegT 	 
    	 std mExFPeJBflhTWJKuQVWoB 	 
make_shared mkHL8KJw4VjwmGdgQrteX 	 
    	  
    		   
   MapInitializer mYbzFOKSwwNsD71cP1DkA 	  mTGJXDnkacX2UX9dooHQu 	 
    	  
    		   
  mo9Lbpy0Ap4RTl5O5Or1C 	 
    	
     _2869602498954317713 mIqjSmilXv9ILvDddB7nD 	std miuOs6oIdxnQEMrFFk2n_ 	 
    	  
    		   
     
     
 
  	 make_shared mRwYPGmWUou3ixNnKEWbv 	 
    	 MapManager meN5YYBBVg5DStfnyA8Dd 	 mTGJXDnkacX2UX9dooHQu 	 
    	  
    		   
     
 mQivdop_Gb4hqsWvOttc3 	 
    	  
    		   
 mL9oWJQ1n2xKG3FtRNowa 	 
    	  
    		 
System mMorzi7AHv5qXgdOZzcMd 	 
    	  
    		  mZilF4nRNVEneBzggpX7Z 	 
    	  
    		 System mdbwYCIpGYWahFfTtU8zH 	 
    	  
    		   
     
     
 
  	 mXdnll4yjwVy4uBDSjUe3 	 
    	  
    		   
     
     

    waitForFinished mecU92YjgSbB3VkEoZVK3 	 
    	  
    		   
     
     
 mI30mSPxGJaQtkEjJfoQX 	 
    	  
    	
 m_ECAXF5hGu1UMoS2l1KU 	 
    	  
 mLE5EGHIdfaJi3FG2wNSs 	 
   System mNQimRrYQ8Mz6YI9KM7Fn 	 
    	  
    	updateParams mTiWUgQKOeYLvNdGsR_oS 	 
    	  
    		   
     
 const  Params &_2654435881 muC5cqYcHRXDD16noARI1 	 
    	  
    mbqHQotWhg0sv6ViuZXc3 	 
   
    waitForFinished mTGJXDnkacX2UX9dooHQu 	 
    	  
    		   
     
     
 
  myu64GAT8DgGBhNOOCqvd 	
    _2869602498954317713 mvA2vjSvRD7UmknjmYP5U 	 
    	  
    		   
     
     
 std mI3QeEk0K_mj1WaUiowht 	 
    	  
    		   
     
    make_shared mRwYPGmWUou3ixNnKEWbv 	 
    	  
    		   
     
   MapManager meN5YYBBVg5DStfnyA8Dd 	 mRAYh0ARHPOc62CfGHWWO 	 
    	  
    mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
    
    _14938569619851839146 mhL9dWuOWzLGBfRjwvYlN 	 _2654435881 mwkk1d6uUiyaKys71tsUv 	 
    	  
    		   
     
 
    _12064558958874466958 mIJkWACd8Uom4Jv6selID 	 
    	  mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
    
 msxc6utIaOFXg4WI3vB0q 	 
    	  
    		   
 mmBcOrqJdEmcu_DE5N2Gx 	 
    	  
    		   
    System me0ZKHp2Id3eLmP_6GMtk 	 
    	  
    		   
     
     
 
  	_12064558958874466958 mGu_88Fdde5jsxW8v9whR 	 
    	  
    		   
     
  mi4REkBAebpTZrzlvFEpD 	 
    	  
    		   
 
    _14938569619851839146.nthreads_feature_detector mXE5wWRmJGUY4EsEsgegT 	max mTiWUgQKOeYLvNdGsR_oS 	 1,_14938569619851839146.nthreads_feature_detector mVFG05ubhW6ia_rWdS_Tv 	 
    	  
    		   
     
      mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
    		   
    
    std mrS2zvlmrTf4L4KBRRYAU 	 
  shared_ptr mLS76iLDjnGxttL6L8yfX 	 
    	  
  Feature2DSerializable maPL1kl9f9VlgIn9jnnN_ 	 
    _15583457929083796945 mH9fKsRtHWNu77RGN1xmn 	 
    	  
    	Feature2DSerializable mMorzi7AHv5qXgdOZzcMd 	 
    create mSdpFB1uEgpzM3bVmlHgT 	 
  _14938569619851839146.kpDescriptorType  muC5cqYcHRXDD16noARI1 	 
    	  
    		   
     
     
 
  	 myu64GAT8DgGBhNOOCqvd 	 
    _15583457929083796945 mtNKEvBwMHNsmdH7BtZbM 	 
    	  
    		   
     
     
 setParams mgGCFceAojKPG0bK5eWQT 	 
   _14938569619851839146.extraParams mT3v8xdcVsSvUtbwmHC7j 	 
    	  
    		  mwkk1d6uUiyaKys71tsUv 	 
    	  
    
    _14938569619851839146.maxDescDistance mXE5wWRmJGUY4EsEsgegT 	 
    	  
    		   
     
     
 
  _15583457929083796945 mdMNbPkq6p5KBhEVf3OFw 	 
    	  
   getMinDescDistance mTGJXDnkacX2UX9dooHQu 	 
    	  
    		   
 mqLizGA4Z8QZ_2GYQ1inC 	 
    
    _3944249282595574931 mj3rSXJDWd4j4OSGbS2oX 	 
    	  setParams mSdpFB1uEgpzM3bVmlHgT 	 
    	_15583457929083796945, _14938569619851839146 msDy4S0F6Zdx78ZUnbARe 	 
     mwkk1d6uUiyaKys71tsUv 	 
    	  
    		  
    _3944249282595574931 mtNKEvBwMHNsmdH7BtZbM 	 
    	  
    		   
     
     
 
 removeFromMarkers mjjfaXD3tH8warSj13sVr 	 
    	  
 mhL9dWuOWzLGBfRjwvYlN 	 
    	  _14938569619851839146.removeKeyPointsIntoMarkers mqLizGA4Z8QZ_2GYQ1inC 	 
    	  
    		   

    _3944249282595574931 mxGJXkzb8EW07jCVTl0Jt 	 
    	  
    		   
detectMarkers mJFtpHxfnoGMxp1wzTBMr 	 
    	  
    		   
 mRDD8w83SsPKbGXy_JkEO 	 
    	  
    		   
   _14938569619851839146.detectMarkers mqLizGA4Z8QZ_2GYQ1inC 	 
    	  
    		  
    _3944249282595574931 mcvX0B8TDw1gEtqXtgT4T 	 
    	  
    		   detectKeyPoints mjjfaXD3tH8warSj13sVr 	 
    	  
    		   
     
     mRDD8w83SsPKbGXy_JkEO 	 
    	  
    		   
    _14938569619851839146.detectKeyPoints mI30mSPxGJaQtkEjJfoQX 	 
    	  
    		   
 
 mMGejH_coNc3kGxAdXVex 	 
    	  
    		   
     
 mgs_uDQ8mSosYV9hCvlQU 	 
    	  
    		   
     
     
 
 System me0ZKHp2Id3eLmP_6GMtk 	 
    	  
    		   
     
     
 setParams mUGrJMUolw0lb_KVyGK5N 	 
    	  
    		   
     std mExFPeJBflhTWJKuQVWoB 	 
    	 shared_ptr mk9nSfh6XGyonOYMC8C3M 	 
    	  
    		   
     
     
 
  	Map mJJosB3DZCYh837sWRpN7 	 
    	  
    		   
     
     _11093822290287, const  Params &_2654435881,const string &_4953871428288621283 mPaUdMg3fg2ipZY0Exj7X 	 
    	  
    		   
     
     mXdnll4yjwVy4uBDSjUe3 	 
    	  
    		   
     
     
 
  
    _9098980761384425343 mtmFAz7pcnIFLgYGMf4eK 	 
    	  
    		   
     
     
 
  	_11093822290287 mC_gLvnw5tkMWRQheRKr5 	 
    	  
    		   
     
     

    _14938569619851839146 mIqjSmilXv9ILvDddB7nD 	 
    	  
_2654435881 myu64GAT8DgGBhNOOCqvd 	 
    	  
    		   
     
     
 
    
    _12064558958874466958 mIJkWACd8Uom4Jv6selID 	 
  mEm194VmPJuGh5y4tMUm5 	 

    
     mbCI0BlZHp5kbKpNqa5Su 	 
     mbXhD242DJoibBjdI1JtA 	_9098980761384425343 mcvX0B8TDw1gEtqXtgT4T 	 
    	  
    		   
   isEmpty mTGJXDnkacX2UX9dooHQu 	 
    	  muC5cqYcHRXDD16noARI1 	  mi4REkBAebpTZrzlvFEpD 	 
    	  
    		   
     
    
        _3857178690860967008 mR22jPCjbltZ3tbBmn_6w 	 
    	  
    		   
     
 STATE_LOST mEm194VmPJuGh5y4tMUm5 	 
    	  
    		   
   
         mbCI0BlZHp5kbKpNqa5Su 	 
    	  
    		   
     
     
 
  	  mYcSgTugFLQcmWT7seaac 	 
    	  
    		   
     
     mW0689NsIXj0x_tZl_0ut 	 
    	  
    		   
    _4953871428288621283.empty mIJkWACd8Uom4Jv6selID 	 
    	  
    		   
     mXftmBtLFUrPFw3lasjuW 	 
    	  
    		   
     
  mMm9FLNsNOoyX7Tyb7vpT 	 
    	  
    	
            _9098980761384425343 mj3rSXJDWd4j4OSGbS2oX 	 
   TheKFDataBase.loadFromFile mlfybwyvp98TOJj0yuqhF 	_4953871428288621283 mXftmBtLFUrPFw3lasjuW 	 mwkk1d6uUiyaKys71tsUv 	 
    	 
         mMGejH_coNc3kGxAdXVex 	 
    	  
    		   
     
     
 
  
        MapInitializer mI3QeEk0K_mj1WaUiowht 	 
    	  Params _3005399798454910266 mEm194VmPJuGh5y4tMUm5 	 
    	  
    		   
     
     
 
  
         mr8s7pfvTmBWmxher3Oue 	 
    	  
    	 mOAy4qGUJpdHQSVbVPq9E 	 
    	  
    		   
     
     
 
  _14938569619851839146.forceInitializationFromMarkers mSBNIRK1XqZg3XlWW_b3d 	 
    	  
   
            _3005399798454910266.mode mA7hUM4UKqFyb_LJLsook 	 
    	  
    		   
     
MapInitializer mrPFLPKakBKjOOnkuhZUP 	 
    ARUCO myu64GAT8DgGBhNOOCqvd 	 
    	  
  
        else
            _3005399798454910266.mode mvA2vjSvRD7UmknjmYP5U 	 
 MapInitializer mvpMkjoDGcQujDevHDZnx 	 
    	  
    		   BOTH mxIwd_EJpfr1C9jwU7IyL 	 
 
        _3005399798454910266.minDistance mA7hUM4UKqFyb_LJLsook 	 
    	  
    		   
     
     
 
  	  _14938569619851839146.minBaseLine mo9Lbpy0Ap4RTl5O5Or1C 	 
    
        _3005399798454910266.markerSize mvA2vjSvRD7UmknjmYP5U 	 
    	  
    		   
     
     
 
  	 _14938569619851839146.aruco_markerSize mxIwd_EJpfr1C9jwU7IyL 	 
    	  
    		
        _3005399798454910266.aruco_minerrratio_valid mIqjSmilXv9ILvDddB7nD 	 
    	  
  _14938569619851839146.aruco_minerrratio_valid mxIwd_EJpfr1C9jwU7IyL 	 
    	  
    		  
        _3005399798454910266.allowArucoOneFrame mH9fKsRtHWNu77RGN1xmn 	 
    	  
   _14938569619851839146.aruco_allowOneFrameInitialization mxIwd_EJpfr1C9jwU7IyL 	 
    	  
    		  
        _3005399798454910266.max_makr_rep_err mRDD8w83SsPKbGXy_JkEO 	 
    	  
    		   
     
  2.5 mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
    		   
     
     
 
        _3005399798454910266.minDescDistance mRDD8w83SsPKbGXy_JkEO 	 
    	  
    		  _14938569619851839146.maxDescDistance mQivdop_Gb4hqsWvOttc3 	 
    	  
    	
        _2044193291895307872 mj3rSXJDWd4j4OSGbS2oX 	 
    	  
    		   
     
    setParams mTiWUgQKOeYLvNdGsR_oS 	 
    	  
    		   
   _3005399798454910266 msDy4S0F6Zdx78ZUnbARe 	 
    	  
     mqLizGA4Z8QZ_2GYQ1inC 	 
    	  
    		   
     
  
     mwiKr6psttEx97f2NsYO1 	 
    	  
    		
    else
        _3857178690860967008 mRDD8w83SsPKbGXy_JkEO 	 
    	  
    		   
   STATE_LOST myu64GAT8DgGBhNOOCqvd 	 
    	  
    		   
     
  
 msBPMso4NRYFcn5Y1myF_ 	 
    	  
    		   
     
     
 
  
 mmBcOrqJdEmcu_DE5N2Gx 	 
    	  
    		   
 System mvpMkjoDGcQujDevHDZnx 	 
  waitForFinished mJFtpHxfnoGMxp1wzTBMr 	 
    	  
    		   
     
     
  mqlayz2fShj6ePxekxwRg 	 
    	  
    	
 _2869602498954317713 mj3rSXJDWd4j4OSGbS2oX 	 
    	  
   stop mRAYh0ARHPOc62CfGHWWO 	 
    	  
    		   
 mEm194VmPJuGh5y4tMUm5 	 
    	  
    
 _2869602498954317713 mevHkLo7kL5WL0_0mLIhr 	 
    	  
    		  mapUpdate mFAl4ldpf7o2gKLWQ4bfu 	 
    	  
    		   
     mEm194VmPJuGh5y4tMUm5 	 
    	  
    		   
     
     

  mKx3hnVGJH14s80udXZp_ 	 
    	  
    		  _2869602498954317713 mevHkLo7kL5WL0_0mLIhr 	 
    	  
    		   
     
     
 
bigChange mIJkWACd8Uom4Jv6selID 	 
    	  
    		    msDy4S0F6Zdx78ZUnbARe 	 
   mi4REkBAebpTZrzlvFEpD 	 
    	  
    		   
     
   
     _14938569046430841631.pose_f2g mH9fKsRtHWNu77RGN1xmn 	_2869602498954317713 mj3rSXJDWd4j4OSGbS2oX 	 
    	  
getLastAddedKFPose mdbwYCIpGYWahFfTtU8zH 	 
    	  
    		 myu64GAT8DgGBhNOOCqvd 	 
    	  
    		   
    
     _17976495724303689842 mIqjSmilXv9ILvDddB7nD 	 
    	  
    		   
     
     
 _14938569046430841631.pose_f2g myu64GAT8DgGBhNOOCqvd 	 
    	  

  m_ECAXF5hGu1UMoS2l1KU 	 
    	  
    		   
     
     
 
  	
 m_ECAXF5hGu1UMoS2l1KU 	 
    	  
    		   
     
     







 myeiBNDHA8i8jhuL3IHRb 	 
    	  
    		   
    System mI3QeEk0K_mj1WaUiowht 	 
    	  
    resetTracker mFAl4ldpf7o2gKLWQ4bfu 	 
    	  
     muH9A34QGuccPZkZDb32w 	 
    	  
    		
    waitForFinished mjjfaXD3tH8warSj13sVr 	 
    	  
    		   
   mwkk1d6uUiyaKys71tsUv 	 
    	  
    		   
     
     
    _10576739190144361304 mvA2vjSvRD7UmknjmYP5U 	 
    	  
    		   
     
     
 
 -1 mC_gLvnw5tkMWRQheRKr5 	 
    	  
    		   
  
    _17976495724303689842 mR22jPCjbltZ3tbBmn_6w 	 
    	  
    		se3 mjjfaXD3tH8warSj13sVr 	 
    	  
    		   
     
 mqLizGA4Z8QZ_2GYQ1inC 	 

    _3857178690860967008 mA7hUM4UKqFyb_LJLsook 	 
    	  
    		   STATE_LOST mI30mSPxGJaQtkEjJfoQX 	
    _14938569046430841631.clear mIJkWACd8Uom4Jv6selID 	 
    	  
    		   
     
     
 
  	 mxIwd_EJpfr1C9jwU7IyL 	 

    _4913157516830781457.clear mrXXIs5j4DqJtj32aOG5F 	 
    	  
    mEm194VmPJuGh5y4tMUm5 	 
    _14463320619150402643 mH9fKsRtHWNu77RGN1xmn 	 
    	  
    		   
     
     
 
  cv mMorzi7AHv5qXgdOZzcMd 	 
    	  
    	Mat mTGJXDnkacX2UX9dooHQu 	 
    	  
    		   
     
     mEm194VmPJuGh5y4tMUm5 	 
    	  
  
    _10558050725520398793 mH9fKsRtHWNu77RGN1xmn 	 
    	  
 -1 mwkk1d6uUiyaKys71tsUv 	 
    	  
    		   
     
     
 

 mEjIWbivPeVc9WtxGDiWw 	 
    	  
    		   
     
     
 
  	 
cv me0ZKHp2Id3eLmP_6GMtk 	 
    	  
   Mat System mwuvkepREHprpx4i3n2RV 	 
    	  
    		   
     process mUGrJMUolw0lb_KVyGK5N 	 
   const Frame &_46082543180066935 mSBNIRK1XqZg3XlWW_b3d 	 
    	    mjXlfKOCTRjUV9apwYcb7 	 
    	  
    		   
     
   
     se3 _16937225862434286412 moHeIYzwbcFb6VaM90Aa9 	_17976495724303689842 m_yMT4MKxrENTtLx5cA7n 	 
    	  
    		   
     

    
     mXYEIB3KYwzJOpssgkZxP 	 
    	  
    mgGCFceAojKPG0bK5eWQT 	 
    	  mlfybwyvp98TOJj0yuqhF 	 
    	  
    		   
     
     
 
  	void* mSBNIRK1XqZg3XlWW_b3d 	 
    	  
    		   
     
    &_46082543180066935 mpjTyiESCVWYRDiT2x2RD 	 
  mUGrJMUolw0lb_KVyGK5N 	 
    	  
  void* mVFG05ubhW6ia_rWdS_Tv 	 
    	  
    		   
     
     
 
  	&_14938569046430841631 mJk4eXgp_IeFV2YvLaQC7 	 
    	  
   mbqHQotWhg0sv6ViuZXc3 	 
    	  

        swap mTiWUgQKOeYLvNdGsR_oS 	 
    	  
    		   
     
     
 
 _4913157516830781457,_14938569046430841631 mSBNIRK1XqZg3XlWW_b3d 	 
    	  
    myu64GAT8DgGBhNOOCqvd 	 

        _14938569046430841631 mtmFAz7pcnIFLgYGMf4eK 	 
    	  
    		  _46082543180066935 myu64GAT8DgGBhNOOCqvd 	 
    	  
    		   
     
     
 
  	 
     mf0YJDuh2j5By5N13LunG 	 
    	  
    		  
    
     mbCI0BlZHp5kbKpNqa5Su 	 
    	  
    		   
     
 mSdpFB1uEgpzM3bVmlHgT 	 
    	  
    		   
     
_17450466964482625197 mosqH7AZUNZeyz6yX3nN1 	 
 MODE_SLAM   mYg3RpRsnYTFl5_yP9Off 	 
    	  
    		   
    mB0fx5ZWEe2g8Ci7LIhmM 	 
    	 _2869602498954317713 mcvX0B8TDw1gEtqXtgT4T 	 
    	  
    		  hasMap mjjfaXD3tH8warSj13sVr 	 mXftmBtLFUrPFw3lasjuW 	 
    	  
    		
        _2869602498954317713 mj3rSXJDWd4j4OSGbS2oX 	 
    	  
  setMap mYcSgTugFLQcmWT7seaac 	 
    	 _9098980761384425343 mT3v8xdcVsSvUtbwmHC7j 	 
    	  
 mI30mSPxGJaQtkEjJfoQX 	 
    	  
    		   
     
     
 

     mr8s7pfvTmBWmxher3Oue 	 mbXhD242DJoibBjdI1JtA 	 
    	  
    		   
     
     
 
 mhNH3dNZkhrgawU6wbA6V 	 
    	  
    		   
     
     
 
  _14938569619851839146.runSequential  mfLSKCXSc1DHeN38jALNR 	 
    	  
    		   
     
    _17450466964482625197 mtDWQOqRguVWSWehbKECr 	 
    	  
    		   
     MODE_SLAM  mT3v8xdcVsSvUtbwmHC7j 	 
 
        _2869602498954317713 mxGJXkzb8EW07jCVTl0Jt 	 
    	  
    		   
   start mrXXIs5j4DqJtj32aOG5F 	 
    	  
    		   
     
     
 
  mI30mSPxGJaQtkEjJfoQX 	 

    
    
     mIyrnAZ9pLZEaiK6Yst1L 	 
    	  
    		   auto &_175247760135:_4913157516830781457.ids mT3v8xdcVsSvUtbwmHC7j 	 
    	 
         mbCI0BlZHp5kbKpNqa5Su 	 
    	  
    		   
  mlfybwyvp98TOJj0yuqhF 	 
    	  _175247760135 mglbnc94mbkalEyCkkDhv 	 
    	  
   std miuOs6oIdxnQEMrFFk2n_ 	 
    	  
    		   
     
     
numeric_limits mHg0YG9R0Gb6ZE5xIr3dz 	 
    	  
    		  uint32_t mzCa3iYOTZk3vOb9xFPuf 	 
    	  
    		   
     
 mNQimRrYQ8Mz6YI9KM7Fn 	 
    	  
    		   
     
     max mdbwYCIpGYWahFfTtU8zH 	 mPaUdMg3fg2ipZY0Exj7X 	 
    	  
    		   
     
     
 
 mqlayz2fShj6ePxekxwRg 	 
    
             mr8s7pfvTmBWmxher3Oue 	 
   mUGrJMUolw0lb_KVyGK5N 	 molF5K16MuyVvkFE7X8JI 	 
    	  
_9098980761384425343 mtNKEvBwMHNsmdH7BtZbM 	 map_points.is mSdpFB1uEgpzM3bVmlHgT 	 
    	  
    		   
     _175247760135 mVFG05ubhW6ia_rWdS_Tv 	 
    	  
     msDy4S0F6Zdx78ZUnbARe 	 
   _175247760135 mH9fKsRtHWNu77RGN1xmn 	 
    	  
std mMorzi7AHv5qXgdOZzcMd 	 
    	  
   numeric_limits mk9nSfh6XGyonOYMC8C3M 	 
    	  
    		   
     
   uint32_t mNF0G2xPBB22gI9XzMk2L 	 
    	  
 mNQimRrYQ8Mz6YI9KM7Fn 	 
    	  
    		   
 max mJFtpHxfnoGMxp1wzTBMr 	 
    	  
    		 mI30mSPxGJaQtkEjJfoQX 	 
    	  
    		   
     
 
             mqUxZEnHM0zID6J2vVqke 	 
    	  
    		   
   mg9IHDbTXxljO0nSnQKYh 	 
    	  
    _9098980761384425343 mgi5Boc5f0emw5eocZbgV 	 
    	  
    map_points mZ9T0z5VdOHGC7rra8Fzk 	 
_175247760135 mtEI4bSjtkyV5O0qz_vBz 	 
    	  
    		   
     
    .isBad mGu_88Fdde5jsxW8v9whR 	 
    mVmWtYm5gVtZj7Yq19XWE 	 
    _175247760135 moHeIYzwbcFb6VaM90Aa9 	 
 std mNQimRrYQ8Mz6YI9KM7Fn 	 
    	  
    		   
     
     
 
 numeric_limits mHg0YG9R0Gb6ZE5xIr3dz 	 uint32_t mW202Akoy5o2_FFUMtz7a 	 
    	  
    		   
     
     
  me0ZKHp2Id3eLmP_6GMtk 	 
    max mIJkWACd8Uom4Jv6selID 	 
    	  mC_gLvnw5tkMWRQheRKr5 	 
    	  
    		  
         mL9oWJQ1n2xKG3FtRNowa 	 
    	  
  
    
     mg9IHDbTXxljO0nSnQKYh 	 
   _9098980761384425343 msDVYCHuU_j2g_TdgX4Ta 	 
    	  
    		   
   isEmpty mJFtpHxfnoGMxp1wzTBMr 	 
     mTmmYcodZhxYb9bt39OUl 	 
    	  
    		 _17450466964482625197 mVrsJpNNblNXrk9CJ_J45 	 
    	  
    		   
     
     
 
  MODE_SLAM muC5cqYcHRXDD16noARI1 	 
    	  
  mSH1h4yGhaMSu8y7JC_rY 	 
    	  
    		   
     
     
         mFVNERjMRO_ZEKm0TY73X 	 
    mTiWUgQKOeYLvNdGsR_oS 	 
    	  
    		   
     
     
 
  	 _2016327979059285019 mlfybwyvp98TOJj0yuqhF 	 
    	  
    		   
     
     
_14938569046430841631 mVmWtYm5gVtZj7Yq19XWE 	 
    	  
    		   
     
     mSBNIRK1XqZg3XlWW_b3d 	
            _3857178690860967008 mH9fKsRtHWNu77RGN1xmn 	 
    	  
    		   
     
     
STATE_TRACKING mxIwd_EJpfr1C9jwU7IyL 	 
    	  
    		
     msBPMso4NRYFcn5Y1myF_ 	 
   
    else mSH1h4yGhaMSu8y7JC_rY 	 
    	  
    		  
        
         myfOHlfTLtRL7im7qSaYm 	 
    	  
    		   
     
  _3857178690860967008 mELweLHSjak68niq3oUpw 	 
    	  
    		   
    STATE_TRACKING mPaUdMg3fg2ipZY0Exj7X 	 
    	  
    		   
     
   mXdnll4yjwVy4uBDSjUe3 	 
    	  
    		   
   
            _10576739190144361304 mvA2vjSvRD7UmknjmYP5U 	 
   _1513765969352381626 mTiWUgQKOeYLvNdGsR_oS 	 
    	  
    		   
     
     
 
  _4913157516830781457,_17976495724303689842 mPaUdMg3fg2ipZY0Exj7X 	 
    	  
    	 mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
    		   
     
     
            _17976495724303689842 mA7hUM4UKqFyb_LJLsook 	 
    	  
  _11166622111371682966 mlfybwyvp98TOJj0yuqhF 	 
    	_14938569046430841631,_17976495724303689842 mXftmBtLFUrPFw3lasjuW 	 
    	  
    		   
    mwkk1d6uUiyaKys71tsUv 	 
    	  
    
             mhRH54odsmIWcLq1D3rKZ 	  mCzaOxAWpFlV3gHYCg4ev 	 
    	  _17976495724303689842.isValid mecU92YjgSbB3VkEoZVK3 	 
    	  
    		  msDy4S0F6Zdx78ZUnbARe 	 
    	  
    		   
   
                _3857178690860967008 mtmFAz7pcnIFLgYGMf4eK 	 
   STATE_LOST mxIwd_EJpfr1C9jwU7IyL 	 
    	 
         mEjIWbivPeVc9WtxGDiWw 	 
    	  
        
         muDvj5aUdXshb2AqqeEiu 	 
    	  
    		   
     
      mOAy4qGUJpdHQSVbVPq9E 	 
    	_3857178690860967008 mrDas3egWRcEnvTodVRRA 	 
    	  
  STATE_LOST mVFG05ubhW6ia_rWdS_Tv 	 
    	  
 muH9A34QGuccPZkZDb32w 	 
    	  
    		   
     
     

            se3 _5564636146947005941 mwkk1d6uUiyaKys71tsUv 	 
    	  
    		   

             mAvI6WqVGKew5QUXF0T2l 	 
     mlfybwyvp98TOJj0yuqhF 	 
     _16487919888509808279 mBGM118Iia8vm6zcNTuB6 	 
    	  
    		   
     
     
_14938569046430841631,_5564636146947005941 msDy4S0F6Zdx78ZUnbARe 	 
 mxAXsCfNkscq4iQtE2AeY 	 
    	  
    		   
     
      mqlayz2fShj6ePxekxwRg 	 
    	  
    		   
  
                _3857178690860967008 mtmFAz7pcnIFLgYGMf4eK 	 
    	  
    		   
     
STATE_TRACKING mQivdop_Gb4hqsWvOttc3 	 
    	  
    		   
     
     
                _17976495724303689842 mIqjSmilXv9ILvDddB7nD 	 
    	_5564636146947005941 mC_gLvnw5tkMWRQheRKr5 	 
    
                _10576739190144361304 mR22jPCjbltZ3tbBmn_6w 	 
    	  
    		   
   _1513765969352381626 mSdpFB1uEgpzM3bVmlHgT 	 
    	  
   _14938569046430841631,_17976495724303689842 mVmWtYm5gVtZj7Yq19XWE 	 
   mwkk1d6uUiyaKys71tsUv 	 

                _10558050725520398793 mhL9dWuOWzLGBfRjwvYlN 	 
    _14938569046430841631.fseq_idx myu64GAT8DgGBhNOOCqvd 	 
    	  
             mL9oWJQ1n2xKG3FtRNowa 	 
         mL9oWJQ1n2xKG3FtRNowa 	 
    	  
    		   
        
         mhRH54odsmIWcLq1D3rKZ 	 _3857178690860967008 mrDas3egWRcEnvTodVRRA 	 
    	  
    		   
     
 STATE_TRACKING mSBNIRK1XqZg3XlWW_b3d 	 
 mqlayz2fShj6ePxekxwRg 	 
    	  
    		   
  
            _14938569046430841631.pose_f2g mXE5wWRmJGUY4EsEsgegT 	 
    	  
    		   
   _17976495724303689842 mI30mSPxGJaQtkEjJfoQX 	 
 
             mr8s7pfvTmBWmxher3Oue 	 mNQ6rNLARkxxSTP6tiTXG 	 
_17450466964482625197 mtDWQOqRguVWSWehbKECr 	 
   MODE_SLAM   mFllaSnZNjV3YvL2YmAFh 	 
    	  
    		   
    mNQ6rNLARkxxSTP6tiTXG 	 
     mUGrJMUolw0lb_KVyGK5N 	 
    	  
    		   
   _14938569046430841631.fseq_idx mpC65FoK2NLadlWUAo9ps 	 
    	  
    	_10558050725520398793+5 msDy4S0F6Zdx78ZUnbARe 	 
    	  
    		   mAJj0tPIZvDaIRCwd81bO 	 
    	  
    		  mNQ6rNLARkxxSTP6tiTXG 	 
    	  
    		   
     
  _10558050725520398793 mELweLHSjak68niq3oUpw 	 
    	  
    		   
     
     
 
  -1 mSBNIRK1XqZg3XlWW_b3d 	    mVFG05ubhW6ia_rWdS_Tv 	 
    	  
    		   
     muC5cqYcHRXDD16noARI1 	 
    
               _2869602498954317713 mVfb3IHZLk8rmg75VuqQZ 	 
    	  
    		   
     
newFrame mYcSgTugFLQcmWT7seaac 	 
 _14938569046430841631,_10576739190144361304 muC5cqYcHRXDD16noARI1 	 
    	  
    		   
     
      mQivdop_Gb4hqsWvOttc3 	 
    	  
    		  
         mf0YJDuh2j5By5N13LunG 	 
    	  
    	
     mL9oWJQ1n2xKG3FtRNowa 	 
    	  
    		   
     

    
     mKx3hnVGJH14s80udXZp_ 	 
    	  
    		   
     
  _3857178690860967008 mVrsJpNNblNXrk9CJ_J45 	 
    	  
    		   
     
     
 
 STATE_LOST  mKWQLdAVzYxp5QuNZ1ytt 	 
    	  
    		   _17450466964482625197 mosqH7AZUNZeyz6yX3nN1 	 
    	  
    		   
     
   MODE_SLAM  mtq_QCXPpv2kX7L8PRz8d 	 
    	  
    		    _9098980761384425343 mtNKEvBwMHNsmdH7BtZbM 	 
 keyframes.size mRAYh0ARHPOc62CfGHWWO 	  mO5I_G9WPuW9VC4inj5mo 	 
    	  
    		   
     
     
 
  	 5  mLdCPhlCq1uVgMtM4YkSz 	 
    	  
    		  _9098980761384425343 mSwbK3nBcNZkvGxSXNOZy 	 
  keyframes.size mRAYh0ARHPOc62CfGHWWO 	 
    	  
     my0vyIAimw3jadFZG1pnz 	 
    	  
    		   
     
  0 mVFG05ubhW6ia_rWdS_Tv 	 
    	 mi4REkBAebpTZrzlvFEpD 	 
    	  
    		   

        _2869602498954317713 mdMNbPkq6p5KBhEVf3OFw 	 
    	  
    		   
     
    reset mjjfaXD3tH8warSj13sVr 	  mEm194VmPJuGh5y4tMUm5 	 
    	  
    		   
     
 
        _9098980761384425343 mcvX0B8TDw1gEtqXtgT4T 	 
    	  
    		   
     
   clear mecU92YjgSbB3VkEoZVK3 	 
    	  
    		   
     
   mxIwd_EJpfr1C9jwU7IyL 	 
    	  
    		   
     
     
 

        _2044193291895307872 mevHkLo7kL5WL0_0mLIhr 	 
    	  
    		   
     
     
reset mrXXIs5j4DqJtj32aOG5F 	 
    	  
    		   mxIwd_EJpfr1C9jwU7IyL 	 
    	  
    		   
 
        _2869602498954317713 mSwbK3nBcNZkvGxSXNOZy 	setMap mbXhD242DJoibBjdI1JtA 	 _9098980761384425343 mJk4eXgp_IeFV2YvLaQC7 	 
    	  
    		   
      mwkk1d6uUiyaKys71tsUv 	 
    	  
    		   
     
     
 
  	
     mEjIWbivPeVc9WtxGDiWw 	 
    	  
    		   
  
    
      mxkHJa5wooqhzaSxK7_fd 	 
    	  
    		   
    mlfybwyvp98TOJj0yuqhF 	 
    	 _3857178690860967008 mlEF62Izit24hGT_NqPIJ 	 
    	  
    		   
   STATE_TRACKING  msDy4S0F6Zdx78ZUnbARe 	 
    	  
    		   
     
   mbqHQotWhg0sv6ViuZXc3 	
        _14463320619150402643 moHeIYzwbcFb6VaM90Aa9 	 
    	  
    		   
     
 cv mvpMkjoDGcQujDevHDZnx 	 
    	  
  Mat mI3QeEk0K_mj1WaUiowht 	 
    	  
    		   
     
     
 
  	eye mNQ6rNLARkxxSTP6tiTXG 	 
    	  
   4,4,CV_32F mJk4eXgp_IeFV2YvLaQC7 	 mxIwd_EJpfr1C9jwU7IyL 	 
         mbCI0BlZHp5kbKpNqa5Su 	 
     mbXhD242DJoibBjdI1JtA 	 _16937225862434286412.isValid mGu_88Fdde5jsxW8v9whR 	 
    	  
   mVFG05ubhW6ia_rWdS_Tv 	 
    	   mMm9FLNsNOoyX7Tyb7vpT 	 
            _14463320619150402643  mA7hUM4UKqFyb_LJLsook 	 
    	  
   _17976495724303689842.convert mjjfaXD3tH8warSj13sVr 	 
    	  
   *_16937225862434286412.convert mRAYh0ARHPOc62CfGHWWO 	 
    	  
.inv mecU92YjgSbB3VkEoZVK3 	 mwkk1d6uUiyaKys71tsUv 	 
    	  
          msxc6utIaOFXg4WI3vB0q 	 
    	  
    		   
     
     

     mqVdZVftPR84WTjiOiVfT 	 
    	  
    		   
     
    else mMm9FLNsNOoyX7Tyb7vpT 	 
    	  

        _14463320619150402643 moHeIYzwbcFb6VaM90Aa9 	 
    	  
    		   
cv mMorzi7AHv5qXgdOZzcMd 	 
    	  
    		   
Mat mecU92YjgSbB3VkEoZVK3 	 
    	  
   mEm194VmPJuGh5y4tMUm5 	 

     mwiKr6psttEx97f2NsYO1 	 
    	  
   
    _14938569046430841631.pose_f2g mR22jPCjbltZ3tbBmn_6w 	 
    	  
    		   
     
  _17976495724303689842 mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
    		   
     
     
#ifndef _UCOSLAM_123asd
     myfOHlfTLtRL7im7qSaYm 	  mgux57p4wBZIWFfq6waj5 	 
    	  
    		 _13033649816026327368 maPL1kl9f9VlgIn9jnnN_ 	 
    	  
    		   
      mTiWUgQKOeYLvNdGsR_oS 	 
    	  
   10*4*12*34*6 muC5cqYcHRXDD16noARI1 	 /2 mVmWtYm5gVtZj7Yq19XWE 	 
    	  
    	
        _17976495724303689842 mvA2vjSvRD7UmknjmYP5U 	 
    	  
    		   
     
     
 
 cv miuOs6oIdxnQEMrFFk2n_ 	 
    	  
    		Mat mTGJXDnkacX2UX9dooHQu 	 
    	  
    		   mQivdop_Gb4hqsWvOttc3 	 
    	  
    		   
 
#endif
     mWYYMqZtRPklZ6ldYQlW8 	 
    	  
    		   
     
     
 
  	 mgGCFceAojKPG0bK5eWQT 	 
    	  _3857178690860967008 mlEF62Izit24hGT_NqPIJ 	STATE_LOST  mJk4eXgp_IeFV2YvLaQC7 	 
return cv mrS2zvlmrTf4L4KBRRYAU 	 
    	  
    		   
     
  Mat mecU92YjgSbB3VkEoZVK3 	 
    	  
    		   
  m_yMT4MKxrENTtLx5cA7n 	 
    	  
    		   
 
    else
         mFWbNGU5e6cuqyQa3XUry 	 
    	  
    		   
     
     
 
  	 _17976495724303689842 myu64GAT8DgGBhNOOCqvd 	 
    	  
    		   
     
     

 mEjIWbivPeVc9WtxGDiWw 	 
    	  
    		   
  
cv mNQimRrYQ8Mz6YI9KM7Fn 	 
    	  
    		   
     
     
 
  	Mat System mrPFLPKakBKjOOnkuhZUP 	 
 process mYcSgTugFLQcmWT7seaac 	 
    	  
    		   
     
      cv mrPFLPKakBKjOOnkuhZUP 	 
    	  
    		   
     
Mat &_6441194614667703750, const ImageParams &_18212413899834346676, mafwB2WCPijyRRTuHGVwE 	 
    	  
    		   
    _9933887380370137445, const cv mrS2zvlmrTf4L4KBRRYAU 	 
    	  
    		   
     
     
 
  	Mat & _46082575014988268, const cv mMorzi7AHv5qXgdOZzcMd 	 
    	  
    		   
     
     
 Mat &_1705635550657133790 mSBNIRK1XqZg3XlWW_b3d 	 
   mqlayz2fShj6ePxekxwRg 	 
  
    swap mOAy4qGUJpdHQSVbVPq9E 	 
    	  
    _4913157516830781457,_14938569046430841631 mVFG05ubhW6ia_rWdS_Tv 	 
    	  
  mwkk1d6uUiyaKys71tsUv 	 
    	  
    		   
     
     
 
 
    
    std mExFPeJBflhTWJKuQVWoB 	 
thread _1403653089436386197 mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
   
     muDvj5aUdXshb2AqqeEiu 	  mgGCFceAojKPG0bK5eWQT 	 
    	  
    		 _17450466964482625197 mIHFqVJpFXgMDdHn2uhc3 	 
    	  
    		MODE_SLAM mxAXsCfNkscq4iQtE2AeY 	 
    	  
    		   
     
     
 _1403653089436386197 mIqjSmilXv9ILvDddB7nD 	 std mNQimRrYQ8Mz6YI9KM7Fn 	 
    	  
    		   
     
   thread mOAy4qGUJpdHQSVbVPq9E 	 
    mZloAr3_PPw7622AVrUCe 	 
    	  
    		   
     
     
 
 & mfF196cGKZ_LkBPN8ZWlr 	 
    	  
    		   
  mTGJXDnkacX2UX9dooHQu 	 
    	  
    		   
     
     
 
 mqlayz2fShj6ePxekxwRg 	 
    	  
    		   
         mz0gDEk4XJJySbEeCgC9P 	 
    	  
    		    _2869602498954317713 msDVYCHuU_j2g_TdgX4Ta 	 
    mapUpdate mTGJXDnkacX2UX9dooHQu 	 
    	  
    		   
  mJk4eXgp_IeFV2YvLaQC7 	 
  mqlayz2fShj6ePxekxwRg 	 
   
             mfRi_C6KlnAxop81XDZsV 	 _2869602498954317713 mj3rSXJDWd4j4OSGbS2oX 	 
    	  
    		  bigChange mdbwYCIpGYWahFfTtU8zH 	 
    	  
    		   msDy4S0F6Zdx78ZUnbARe 	 
    	  
    		  mXdnll4yjwVy4uBDSjUe3 	 
    	  
    		   
     
     
                _14938569046430841631.pose_f2g mR22jPCjbltZ3tbBmn_6w 	 _2869602498954317713 mVfb3IHZLk8rmg75VuqQZ 	 getLastAddedKFPose mTGJXDnkacX2UX9dooHQu 	 
    	  
    		   
     
     
 
  myu64GAT8DgGBhNOOCqvd 	 
    	  
    		   
     
 
                _17976495724303689842 mvA2vjSvRD7UmknjmYP5U 	 
    	  
    		   
     
     _2869602498954317713 mj3rSXJDWd4j4OSGbS2oX 	 
    	  
    		   
     
     
 
  getLastAddedKFPose mJFtpHxfnoGMxp1wzTBMr 	 
    	  
    		   
     
 mqLizGA4Z8QZ_2GYQ1inC 	 
    	 
             mqVdZVftPR84WTjiOiVfT 	 
    	  
    		   
     
     
 
  
         miXz43zs_DqtraKQW0m3N 	 
 
         m_yMT4MKxrENTtLx5cA7n 	 
    	  
    		   
   mwiKr6psttEx97f2NsYO1 	 
    	  
  mJk4eXgp_IeFV2YvLaQC7 	 
    	  
    		   
     
     
 
  	 mqLizGA4Z8QZ_2GYQ1inC 	 
    	  
    		  
    
     mHbSWrX6OPeRP2Igmog8G 	 
    	  
    		   
  mbXhD242DJoibBjdI1JtA 	 
    	  
 _46082575014988268.empty mdbwYCIpGYWahFfTtU8zH 	 
    	  
    		   
   mSSwrqUuoNnhMtvhM2vr3 	 
    	  
    		   
      _1705635550657133790.empty mrXXIs5j4DqJtj32aOG5F 	  msDy4S0F6Zdx78ZUnbARe 	 
    	  
    		   
    _3944249282595574931 mSwbK3nBcNZkvGxSXNOZy 	 
    	  
    		   
     
     process mlfybwyvp98TOJj0yuqhF 	 
    	  
    		   
     
     
_6441194614667703750,_18212413899834346676,_14938569046430841631,_9933887380370137445    mVmWtYm5gVtZj7Yq19XWE 	 
    	  
    		   
 mQivdop_Gb4hqsWvOttc3 	 
    	  
    		   
     
     
 
 
     myrvDyRCtal5mdHB28ZIe 	 
    	  
    		   
      myfOHlfTLtRL7im7qSaYm 	 
    	  
    		 _1705635550657133790.empty mFAl4ldpf7o2gKLWQ4bfu 	 
    	  
    		   
     
    mPaUdMg3fg2ipZY0Exj7X 	 
    	  
    		   
      _3944249282595574931 mevHkLo7kL5WL0_0mLIhr 	 
    	  
   process_rgbd mSdpFB1uEgpzM3bVmlHgT 	 
    	  
    		   
     
   _6441194614667703750,_46082575014988268,_18212413899834346676,_14938569046430841631,_9933887380370137445  msDy4S0F6Zdx78ZUnbARe 	 
    	  
    		   
     
     
 
  	  mQivdop_Gb4hqsWvOttc3 	 
    	  
     mfkkS3ig7woFqdOg7udAR 	 
    	  
    		   
     
     
 
  	_3944249282595574931 mVfb3IHZLk8rmg75VuqQZ 	 
    	  
    		   processStereo mUGrJMUolw0lb_KVyGK5N 	 
    	  
    		   
     
     
 _6441194614667703750,_1705635550657133790,_18212413899834346676,_14938569046430841631,_9933887380370137445  mVmWtYm5gVtZj7Yq19XWE 	 
    	  
    		   
     
 mxIwd_EJpfr1C9jwU7IyL 	 
    	  
     mz0gDEk4XJJySbEeCgC9P 	 
   _14938569619851839146.autoAdjustKpSensitivity mPaUdMg3fg2ipZY0Exj7X 	 
    	  
 mSH1h4yGhaMSu8y7JC_rY 	 
    	  
    		
        
        
        
         mpgczyJuWNGXMBOxeP5oe 	 
    	  
    		   
    _1699599737904718822 moHeIYzwbcFb6VaM90Aa9 	 
  _14938569619851839146.maxFeatures-_14938569046430841631.und_kpts.size mRAYh0ARHPOc62CfGHWWO 	 
    	  
    		   
 mI30mSPxGJaQtkEjJfoQX 	 
    	  
    		   

         mFWW5xb6SDILpyTp5GBZD 	 
    	  
    _1699599737904718822  meN5YYBBVg5DStfnyA8Dd 	 
    	  
    		   
     
 0 mT3v8xdcVsSvUtbwmHC7j 	 
    	  
    		   
  mqlayz2fShj6ePxekxwRg 	 
    	  
    		   
     
     

             mTWpMMn_ueGNGrVaZzL0Q 	 
    	  
  _46082575832048655 mXE5wWRmJGUY4EsEsgegT 	 
    	  
    		   
     
    1.0f-  mlfybwyvp98TOJj0yuqhF 	 
    	  
    		   
    float mBGM118Iia8vm6zcNTuB6 	 
    	  
    		   
     
     
 
  	_1699599737904718822 mT3v8xdcVsSvUtbwmHC7j 	 
    	  
    		   
     
 /float mbXhD242DJoibBjdI1JtA 	 
    	  
    		   
     
     _14938569046430841631.und_kpts.size mrXXIs5j4DqJtj32aOG5F 	 
    mVmWtYm5gVtZj7Yq19XWE 	 mT3v8xdcVsSvUtbwmHC7j 	 
    	  
    		   
     
     m_yMT4MKxrENTtLx5cA7n 	 
    	  
    		   
     
   
             mrg1QVINMqbRYZWngNWmj 	_6148074839757474704 mvA2vjSvRD7UmknjmYP5U 	 _3944249282595574931 mevHkLo7kL5WL0_0mLIhr 	 
    	  
    		   
  getSensitivity mFAl4ldpf7o2gKLWQ4bfu 	 
    	  
    		 +_46082575832048655 mqLizGA4Z8QZ_2GYQ1inC 	 
    	  
    		   
    
            _6148074839757474704 mA7hUM4UKqFyb_LJLsook 	 
    	  
    		   
  std mrS2zvlmrTf4L4KBRRYAU 	 
    	  
    		   
     
     max mNQ6rNLARkxxSTP6tiTXG 	 
    	  
    		   
     
   _6148074839757474704,1.0f mT3v8xdcVsSvUtbwmHC7j 	 
    	  
    mwkk1d6uUiyaKys71tsUv 	 
    	  
    		   
     
     

            _3944249282595574931 mtNKEvBwMHNsmdH7BtZbM 	 
    	  
    		  setSensitivity mTiWUgQKOeYLvNdGsR_oS 	 
    	  
   _6148074839757474704 mJk4eXgp_IeFV2YvLaQC7 	 
    	 m_yMT4MKxrENTtLx5cA7n 	
         mL9oWJQ1n2xKG3FtRNowa 	 
   
        else mjXlfKOCTRjUV9apwYcb7 	 
    	  
    		   
     
     
            
            _3944249282595574931 mj3rSXJDWd4j4OSGbS2oX 	 
   setSensitivity mYcSgTugFLQcmWT7seaac 	 
    	  
    		   
 _3944249282595574931 mgi5Boc5f0emw5eocZbgV 	 getSensitivity mTGJXDnkacX2UX9dooHQu 	 
    	  
    		   
     
     
 *0.95 mT3v8xdcVsSvUtbwmHC7j 	 
    	  
    		  mQivdop_Gb4hqsWvOttc3 	 
    	 
         mL9oWJQ1n2xKG3FtRNowa 	
     mqVdZVftPR84WTjiOiVfT 	 
    	  
    		   
     
     
 
  	
    
     mr8s7pfvTmBWmxher3Oue 	 
    	  
   mTiWUgQKOeYLvNdGsR_oS 	 
    	  
    		   
   _17450466964482625197 mVrsJpNNblNXrk9CJ_J45 	 
    	  
    		   
     
     
 MODE_SLAM mVFG05ubhW6ia_rWdS_Tv 	_1403653089436386197.join mecU92YjgSbB3VkEoZVK3 	 
    	  
    		   
     
    mQivdop_Gb4hqsWvOttc3 	 
  
    cv mrS2zvlmrTf4L4KBRRYAU 	 
    	  
    		   
   Mat _3005399805025936106 mvA2vjSvRD7UmknjmYP5U 	 
    	  
    		  process mSdpFB1uEgpzM3bVmlHgT 	 
    	  
    		   
     
   _14938569046430841631 mJk4eXgp_IeFV2YvLaQC7 	 
    	  
    mC_gLvnw5tkMWRQheRKr5 	 
    	  
 
    
     mqI5yMr4h6CHkceANuA43 	 
    	  
    		   
     
     
 
 _6154865401824487276 moHeIYzwbcFb6VaM90Aa9 	 
    	  
    		   
   sqrt mSdpFB1uEgpzM3bVmlHgT 	 
    	  
    		   
   float mSdpFB1uEgpzM3bVmlHgT 	 
    	  
    		   
     
  _14938569046430841631.imageParams.CamSize.area mIJkWACd8Uom4Jv6selID 	 mVmWtYm5gVtZj7Yq19XWE 	 
    	  
/float mSdpFB1uEgpzM3bVmlHgT 	 
    	  
   _6441194614667703750.size mjjfaXD3tH8warSj13sVr 	 
    	  
    		   
 .area mIJkWACd8Uom4Jv6selID 	 
    	  
    		   
     
   mxAXsCfNkscq4iQtE2AeY 	 
    	  
    		   
     
     
 
  muC5cqYcHRXDD16noARI1 	 
    	  
    		   mEm194VmPJuGh5y4tMUm5 	 
  
    _14031550457846423181 mlfybwyvp98TOJj0yuqhF 	 
    	 _6441194614667703750,1./_6154865401824487276 mSBNIRK1XqZg3XlWW_b3d 	 mqLizGA4Z8QZ_2GYQ1inC 	 
    	  
 
     mEhFK99MtLRsCBaPNqnDs 	 
    _5829441678613027716 mH9fKsRtHWNu77RGN1xmn 	 
    	 mstJEG25u0Qv4VQocWgKl 	 
    	  
    		   
      mQbYLzhvVQm8J2LNkC6S6 	 
    	  
    		  mSdpFB1uEgpzM3bVmlHgT 	 
    	  
    		  const uint32_t&_11093821926013 mSBNIRK1XqZg3XlWW_b3d 	 mJdlQJg0rG2m7KHUChC3R 	 
    	  
  std mMorzi7AHv5qXgdOZzcMd 	 
    	  
    		   
     
     
 
  stringstream _706246330191125 mwkk1d6uUiyaKys71tsUv 	 
    	  
    		   
     
   _706246330191125 mmAvkrWz9or7FSKyep8Gr 	_11093821926013 mxIwd_EJpfr1C9jwU7IyL 	 
    	  
    		   mV4_AbWY8ymaWGsYOk0LC 	 
    	 _706246330191125.str mdbwYCIpGYWahFfTtU8zH 	 
   mqLizGA4Z8QZ_2GYQ1inC 	 
    	  
    		    msxc6utIaOFXg4WI3vB0q 	 
    	  
    		   
 m_yMT4MKxrENTtLx5cA7n 	 
    	  
    		   
    _14938529070154896274 mBGM118Iia8vm6zcNTuB6 	 
    	  
 _6441194614667703750,"\x4d\x61\x70\x20\x50\x6f\x69\x6e\x74\x73\x3a"+_5829441678613027716 mYcSgTugFLQcmWT7seaac 	 
    	  
    		   
     
     _9098980761384425343 mxGJXkzb8EW07jCVTl0Jt 	 
    	map_points.size mTGJXDnkacX2UX9dooHQu 	 
    	  
    		   
   mVFG05ubhW6ia_rWdS_Tv 	 
    ,cv mMorzi7AHv5qXgdOZzcMd 	 
    	  
    		   
     
     Point mlfybwyvp98TOJj0yuqhF 	 
    	  
    		   20,_6441194614667703750.rows-20 mT3v8xdcVsSvUtbwmHC7j 	 
    	  
    		   
 mT3v8xdcVsSvUtbwmHC7j 	 
    	  
    		   
     
     
 
  	  mQivdop_Gb4hqsWvOttc3 	 

    _14938529070154896274 mOAy4qGUJpdHQSVbVPq9E 	 
    	  
    		   
     _6441194614667703750,"\x4d\x61\x70\x20\x4d\x61\x72\x6b\x65\x72\x73\x3a"+_5829441678613027716 mNQ6rNLARkxxSTP6tiTXG 	 
    	  
    		   
 _9098980761384425343 mSwbK3nBcNZkvGxSXNOZy 	 
    	  
 map_markers.size mGu_88Fdde5jsxW8v9whR 	 
    	  
  mVmWtYm5gVtZj7Yq19XWE 	 
    	  
    		   
     
     
 ,cv me0ZKHp2Id3eLmP_6GMtk 	 
    	  
    		   
     
   Point mlfybwyvp98TOJj0yuqhF 	 
    	  
    		  20,_6441194614667703750.rows-40 mVmWtYm5gVtZj7Yq19XWE 	 
    	  
    		 mSBNIRK1XqZg3XlWW_b3d 	 
    	  
    mQivdop_Gb4hqsWvOttc3 	 
    	  
    		   
     
     
 
  
    _14938529070154896274 mBGM118Iia8vm6zcNTuB6 	 
    	  
    		   
     
    _6441194614667703750,"\x4b\x65\x79\x46\x72\x61\x6d\x65\x73\x3a"+_5829441678613027716 mNQ6rNLARkxxSTP6tiTXG 	 
    	  
    		_9098980761384425343 mtNKEvBwMHNsmdH7BtZbM 	 
    	  
    keyframes.size mrXXIs5j4DqJtj32aOG5F 	  mSBNIRK1XqZg3XlWW_b3d 	 
    	  
    		   
     
    ,cv mwuvkepREHprpx4i3n2RV 	 
    	  
   Point mlfybwyvp98TOJj0yuqhF 	 
    	  20,_6441194614667703750.rows-60 mSBNIRK1XqZg3XlWW_b3d 	 
    	  
    		  mSBNIRK1XqZg3XlWW_b3d 	 
    	  
    		   
      mC_gLvnw5tkMWRQheRKr5 	 
    	  
    		   
     muoE4XIKfPRSXmzic7wiv 	 
    	  
_16937201858692939798 mtmFAz7pcnIFLgYGMf4eK 	 
    	  
    		   
0 mqLizGA4Z8QZ_2GYQ1inC 	 
    	  
    		   
     
     
     mcAnVuQmAnGunjGyL6dhh 	 
    	  
    	auto _175247760135:_14938569046430841631.ids msDy4S0F6Zdx78ZUnbARe 	 
    	  
    		    mGc5v1UWfDU7ttNcZryQG 	 
    	_175247760135 mglbnc94mbkalEyCkkDhv 	 
    	  
  std mMorzi7AHv5qXgdOZzcMd 	 
    	  
    		numeric_limits mnpObQ1mWnyfQO24_ojBn 	 
   uint32_t mYbzFOKSwwNsD71cP1DkA 	 
    	  
    		   
     
     
 
  	  mrPFLPKakBKjOOnkuhZUP 	 
    	max mecU92YjgSbB3VkEoZVK3 	 
    	  
    		   
     
     
 
 mXftmBtLFUrPFw3lasjuW 	 _16937201858692939798 mDe1564r6NJrCTudA8x0w 	 
    	   mEm194VmPJuGh5y4tMUm5 	 
   
    _14938529070154896274 mlfybwyvp98TOJj0yuqhF 	 
    	  
    		   
     
     
 
  	 _6441194614667703750,"\x4d\x61\x74\x63\x68\x65\x73\x3a"+  _5829441678613027716 mNQ6rNLARkxxSTP6tiTXG 	 
    	  
    		   
     
  _16937201858692939798 mSBNIRK1XqZg3XlWW_b3d 	 
    	  
 ,cv mvpMkjoDGcQujDevHDZnx 	 
    	  
    		   
     
   Point mgGCFceAojKPG0bK5eWQT 	20,_6441194614667703750.rows-80 muC5cqYcHRXDD16noARI1 	 
    	  
    		   
     
     
 
  	  msDy4S0F6Zdx78ZUnbARe 	 
    	  
    		   
     
    mqLizGA4Z8QZ_2GYQ1inC 	 
    	  
    		   
     
     
 

     mFWW5xb6SDILpyTp5GBZD 	 
    	  
    	 fabs mSdpFB1uEgpzM3bVmlHgT 	 
    	  
 _6154865401824487276-1 mxAXsCfNkscq4iQtE2AeY 	 
    	   mKJK3THIuAwgeFpuGLN8L 	 
    	  
    		   
     
     1e-3 mVFG05ubhW6ia_rWdS_Tv 	 
    	  
    		   
 
        _14938529070154896274 mbXhD242DJoibBjdI1JtA 	 
    	_6441194614667703750,"\x49\x6d\x67\x2e\x53\x69\x7a\x65\x3a"+_5829441678613027716 mYcSgTugFLQcmWT7seaac 	 
    	_14938569046430841631.imageParams.CamSize.width mT3v8xdcVsSvUtbwmHC7j 	 
    	  
   +"\x78"+_5829441678613027716 mYcSgTugFLQcmWT7seaac 	 
    	  
    		  _14938569046430841631.imageParams.CamSize.height mxAXsCfNkscq4iQtE2AeY 	 
    	,cv mrS2zvlmrTf4L4KBRRYAU 	 
    	  
    		   
     Point mYcSgTugFLQcmWT7seaac 	 
    	  
    		   
    20,_6441194614667703750.rows-100 msDy4S0F6Zdx78ZUnbARe 	 
    	  
    		   
     
     
  mVmWtYm5gVtZj7Yq19XWE 	 
    	  
    		   
     
     
 
  	  mEm194VmPJuGh5y4tMUm5 	 
    	  
    		   
     
 
     mV4_AbWY8ymaWGsYOk0LC 	 
    	  
    		   
 _3005399805025936106 mI30mSPxGJaQtkEjJfoQX 	 
    	  
    		   
    
 miXz43zs_DqtraKQW0m3N 	 
    	  
    		 
 mDWwKMm0Bw8nxvI3ZwZnM 	 
    	  
     System mI3QeEk0K_mj1WaUiowht 	 
    	  
    _14938529070154896274 mBGM118Iia8vm6zcNTuB6 	 
    	  
  cv mMorzi7AHv5qXgdOZzcMd 	 
Mat &_175247760140,string _706246331661728,cv miuOs6oIdxnQEMrFFk2n_ 	 
    	  
    		   
 Point _2654435881  mSBNIRK1XqZg3XlWW_b3d 	 
    	  
    		 mSH1h4yGhaMSu8y7JC_rY 	 
    	  
    		   
     
     
 

     mrjcvI9ucBIaCRtqGyrWD 	 
 _706246308256699 moHeIYzwbcFb6VaM90Aa9 	 
    	  
    		   
     
     
float mgGCFceAojKPG0bK5eWQT 	 
    	  
    		   
     
     
 _175247760140.cols mPaUdMg3fg2ipZY0Exj7X 	 
    	  
    		   
    /float mSdpFB1uEgpzM3bVmlHgT 	 
    	  
    		1280 mPaUdMg3fg2ipZY0Exj7X 	 
    	  
    		   
     
     
 
 mqLizGA4Z8QZ_2GYQ1inC 	 
    	  
 
    cv mvpMkjoDGcQujDevHDZnx 	 
    	  
    		   
   putText mlfybwyvp98TOJj0yuqhF 	 
    	  
    		   
    _175247760140,_706246331661728,_2654435881,cv mNQimRrYQ8Mz6YI9KM7Fn 	 
    	  FONT_HERSHEY_SIMPLEX, 0.5*_706246308256699,cv mI3QeEk0K_mj1WaUiowht 	 
    	  
  Scalar mTiWUgQKOeYLvNdGsR_oS 	 
    	  
    		   
     
0,0,0 mPaUdMg3fg2ipZY0Exj7X 	 
    	  
    		   
     
    ,3*_706246308256699 msDy4S0F6Zdx78ZUnbARe 	 
    	  
    		  mEm194VmPJuGh5y4tMUm5 	 
    	  
    		   
     
     
 
  	 
    cv mrS2zvlmrTf4L4KBRRYAU 	 
    	  
    		   
     
     
 putText mbXhD242DJoibBjdI1JtA 	 _175247760140,_706246331661728,_2654435881,cv mrPFLPKakBKjOOnkuhZUP 	 
    	  
    		 FONT_HERSHEY_SIMPLEX, 0.5*_706246308256699,cv mMorzi7AHv5qXgdOZzcMd 	Scalar mOAy4qGUJpdHQSVbVPq9E 	 
    	  
    		   
     
     125,255,255 mPaUdMg3fg2ipZY0Exj7X 	 
    	  
    	,1*_706246308256699 mSBNIRK1XqZg3XlWW_b3d 	 
    	  
    		 myu64GAT8DgGBhNOOCqvd 	 
    	  
    		   

 mEjIWbivPeVc9WtxGDiWw 	 
    	  
    		   
     
     
 
 
string System mrS2zvlmrTf4L4KBRRYAU 	 
    	  
    	getSignatureStr mFAl4ldpf7o2gKLWQ4bfu 	 
    	const mSH1h4yGhaMSu8y7JC_rY 	 
    	  
    		 
     mLp5eeYn1TGnQEcop68VN 	 
    	  
    		   
     
     
 
 _2102381941757963317 mbXhD242DJoibBjdI1JtA 	 
    	  
    		   
     
     
 
  	_13507858972549420551 mRAYh0ARHPOc62CfGHWWO 	 
    	  
    mxAXsCfNkscq4iQtE2AeY 	 
    	  
    		   
      mQivdop_Gb4hqsWvOttc3 	
 mL9oWJQ1n2xKG3FtRNowa 	 
    	  
    		   
     
     
uint64_t System mI3QeEk0K_mj1WaUiowht 	 
    	  
  _13507858972549420551 mOAy4qGUJpdHQSVbVPq9E 	bool _46082575779493229 mJk4eXgp_IeFV2YvLaQC7 	 
    	  
    		   const mXdnll4yjwVy4uBDSjUe3 	 
    Hash _11093822380353 myu64GAT8DgGBhNOOCqvd 	 
    	  
    		   
     
 
    _11093822380353 mc6a7gZ5y0kWaTfPKjZL0 	 
_9098980761384425343 mevHkLo7kL5WL0_0mLIhr 	 
    	  
    getSignature mbXhD242DJoibBjdI1JtA 	 
    	  
    		   
     
     
 
_46082575779493229 muC5cqYcHRXDD16noARI1 	 
    	  
    		  mqLizGA4Z8QZ_2GYQ1inC 	 
    	  
     mdEGS_9gShKEEsK9RPbfj 	 
    	  
    		   
    _46082575779493229 mXftmBtLFUrPFw3lasjuW 	 
    	  
   cout mt3d6r2BuFfOvfXdOmaLX 	 
    "\x5c\x74\x53\x79\x73\x74\x65\x6d\x20\x31\x2e\x20\x73\x69\x67\x3d" mYJ8ThnKYhVFrfXpP62DT 	 
    	  
    		   
     
  _11093822380353 mmAvkrWz9or7FSKyep8Gr 	 
    	  
    	endl mqLizGA4Z8QZ_2GYQ1inC 	 
    	  
    		   
 
    _11093822380353 mvcDBJfIynZthI5bz_HTe 	 
    	  
    		  _14938569619851839146.getSignature mGu_88Fdde5jsxW8v9whR 	 
    	  m_yMT4MKxrENTtLx5cA7n 	 
    	  
    	
     mGc5v1UWfDU7ttNcZryQG 	 
    	  
    		   
     
  _46082575779493229 muC5cqYcHRXDD16noARI1 	 
    	  
    		   
     
cout mmAvkrWz9or7FSKyep8Gr 	 
    	  
    		   
     
     
 
 "\x5c\x74\x53\x79\x73\x74\x65\x6d\x20\x32\x2e\x20\x73\x69\x67\x3d" mt3d6r2BuFfOvfXdOmaLX 	 
  _11093822380353 mYJ8ThnKYhVFrfXpP62DT 	 
    	  
    		   
     
endl mwkk1d6uUiyaKys71tsUv 	 
 
     mmeJW_Q9h6ZBPzSBQVjMK 	 
   int _2654435874 mtmFAz7pcnIFLgYGMf4eK 	 
    	  
    		   
     
     0 mI30mSPxGJaQtkEjJfoQX 	 
    	  
    		   
     
     
 
  	 _2654435874 mk9nSfh6XGyonOYMC8C3M 	 
   6 mQivdop_Gb4hqsWvOttc3 	 
    	  
    		   
     
   _2654435874 mtIfgwpprqjFMhHY9FVrL 	 
    	  
   mxAXsCfNkscq4iQtE2AeY 	 
    	  
_11093822380353 mWaLwU5zB1H0AtUbS8Rz2 	 
    	  
    		   
    _17976495724303689842 msGAdK1RZcxCitYemdpxc 	 
    	  
    		   
     
     
 _2654435874 mtEI4bSjtkyV5O0qz_vBz 	 
    	  
    		   
   mxIwd_EJpfr1C9jwU7IyL 	 
    	  
    		   
     
     
 
  
     mz0gDEk4XJJySbEeCgC9P 	 
 _46082575779493229 mxAXsCfNkscq4iQtE2AeY 	 
    	  
    		   
     
   cout mt3d6r2BuFfOvfXdOmaLX 	 
    	  
    		   
 "\x5c\x74\x53\x79\x73\x74\x65\x6d\x20\x33\x2e\x20\x73\x69\x67\x3d" mghpafeSRXwbO0z_DbM3C 	 
    	  _11093822380353 mghpafeSRXwbO0z_DbM3C 	 
   endl mC_gLvnw5tkMWRQheRKr5 	 
    	  
    		   
     
 
    _11093822380353.add mbXhD242DJoibBjdI1JtA 	 
    	  
    		   
     
     
 
  _10576739190144361304 muC5cqYcHRXDD16noARI1 	 
    	  m_yMT4MKxrENTtLx5cA7n 	 
    	  
    		   
     
     
 
  	
     myfOHlfTLtRL7im7qSaYm 	 
    	  
    		   
     
    _46082575779493229 mJk4eXgp_IeFV2YvLaQC7 	 
    	  
    		   
     
 cout mYJ8ThnKYhVFrfXpP62DT 	 "\x5c\x74\x53\x79\x73\x74\x65\x6d\x20\x34\x2e\x20\x73\x69\x67\x3d" mLdvrbXgkmVAVnc3aEbWU 	 
    	  
    		   
     
  _11093822380353 mISlN399eTfrWHnidEKGu 	 
    	  
   endl mC_gLvnw5tkMWRQheRKr5 	 
    	
    _11093822380353 mvcDBJfIynZthI5bz_HTe 	 
    	  
 _14938569046430841631.getSignature mJFtpHxfnoGMxp1wzTBMr 	 
    	  
    		   
  myu64GAT8DgGBhNOOCqvd 	 
    	  
    		   
     
     
 

     myfOHlfTLtRL7im7qSaYm 	 
    	  
    		   
     
     
 
  _46082575779493229 mXftmBtLFUrPFw3lasjuW 	 
    	  
    		   
cout mYJ8ThnKYhVFrfXpP62DT 	 
    	  
    		   
     
 "\x5c\x74\x53\x79\x73\x74\x65\x6d\x20\x35\x2e\x20\x73\x69\x67\x3d" mLdvrbXgkmVAVnc3aEbWU 	 
    	  
    		   
     
     
 
  _11093822380353 mmAvkrWz9or7FSKyep8Gr 	 
    	  
    		   
 endl mqLizGA4Z8QZ_2GYQ1inC 	 
    	  
 
    _11093822380353 moI4EWKnn9rwdcRf81yt6 	 
    	  
    		   
   _13028158409047949416 m_yMT4MKxrENTtLx5cA7n 	 
    	  
  
     mz0gDEk4XJJySbEeCgC9P 	_46082575779493229 mT3v8xdcVsSvUtbwmHC7j 	 
    	  
cout mZCDcAPDXTOUnUkMgttvA 	 
  "\x5c\x74\x53\x79\x73\x74\x65\x6d\x20\x37\x2e\x20\x73\x69\x67\x3d" mmAvkrWz9or7FSKyep8Gr 	 
    	  
    		   
     
   _11093822380353 mYJ8ThnKYhVFrfXpP62DT 	 endl myu64GAT8DgGBhNOOCqvd 	 
    _11093822380353 mc6a7gZ5y0kWaTfPKjZL0 	 
    	  
  _3857178690860967008 mqLizGA4Z8QZ_2GYQ1inC 	 
    	  
    		   
     
     
 
  
     mFWW5xb6SDILpyTp5GBZD 	 
    	  
    		   
  _46082575779493229 mPaUdMg3fg2ipZY0Exj7X 	 
    	  
    		   
   cout mISlN399eTfrWHnidEKGu 	 
    	  
    		   
     
   "\x5c\x74\x53\x79\x73\x74\x65\x6d\x20\x38\x2e\x20\x73\x69\x67\x3d" mZCDcAPDXTOUnUkMgttvA 	 _11093822380353 mZCDcAPDXTOUnUkMgttvA 	 
    	  
endl m_yMT4MKxrENTtLx5cA7n 	 
    	  
    		   
     
     
 

    _11093822380353 moI4EWKnn9rwdcRf81yt6 	 
    	  
    		 _17450466964482625197 mEm194VmPJuGh5y4tMUm5 	 
    	  
    		 
     mFWW5xb6SDILpyTp5GBZD 	 _46082575779493229 mJk4eXgp_IeFV2YvLaQC7 	 
    	  
    		   
     
     
 
cout mt3d6r2BuFfOvfXdOmaLX 	 
    	  
    	"\x5c\x74\x53\x79\x73\x74\x65\x6d\x20\x39\x2e\x20\x73\x69\x67\x3d" mt3d6r2BuFfOvfXdOmaLX 	 
    	  
    		_11093822380353 mIqwZsWoU0IEPB7TMb7wT 	 
    	  
   endl mxIwd_EJpfr1C9jwU7IyL 	 

    _11093822380353 moI4EWKnn9rwdcRf81yt6 	 _4913157516830781457.getSignature mrXXIs5j4DqJtj32aOG5F 	 
    	  
    		   
     
    m_yMT4MKxrENTtLx5cA7n 	 
    	  
    		 
     myfOHlfTLtRL7im7qSaYm 	 
    	  
    		   
    _46082575779493229 muC5cqYcHRXDD16noARI1 	 
    	  
    		   
cout muLh_AegzBLvbYcxrsotS 	 
    	  
    		   
     
     
 
  "\x5c\x74\x53\x79\x73\x74\x65\x6d\x20\x31\x30\x2e\x73\x69\x67\x3d" mLdvrbXgkmVAVnc3aEbWU 	 
    	  
    		   
     
_11093822380353 mghpafeSRXwbO0z_DbM3C 	 
    	  
 endl mQivdop_Gb4hqsWvOttc3 	 
    	  
    		   
  
    _11093822380353 mraP1zuclX52fRr5CelTs 	 
    	  
    _2869602498954317713 mdMNbPkq6p5KBhEVf3OFw 	 getSignature mTGJXDnkacX2UX9dooHQu 	 m_yMT4MKxrENTtLx5cA7n 	 
    	  
    		   
     mfRi_C6KlnAxop81XDZsV 	 
    	  
  _46082575779493229 mT3v8xdcVsSvUtbwmHC7j 	 
 cout mLdvrbXgkmVAVnc3aEbWU 	 
    	 "\x5c\x74\x53\x79\x73\x74\x65\x6d\x20\x31\x31\x2e\x73\x69\x67\x3d" mAckb35A91fK2dY3gHfaK 	 
    _11093822380353 mAckb35A91fK2dY3gHfaK 	 
    	 endl mqLizGA4Z8QZ_2GYQ1inC 	 
    	  
    		   
     
     
 
    _11093822380353 moI4EWKnn9rwdcRf81yt6 	 
    	  
    		   
     
    _14463320619150402643 mQivdop_Gb4hqsWvOttc3 	 
    	  
    		  
    _11093822380353 mPvI5zVkkxdTYTCdGOJ2J 	 
 _10558050725520398793 mQivdop_Gb4hqsWvOttc3 	 
     mg9IHDbTXxljO0nSnQKYh 	 
    	  
   _46082575779493229 mT3v8xdcVsSvUtbwmHC7j 	 
    	  
    		cout mLdvrbXgkmVAVnc3aEbWU 	 
    	  
    		"\x5c\x74\x53\x79\x73\x74\x65\x6d\x20\x31\x32\x2e\x73\x69\x67\x3d" mIqwZsWoU0IEPB7TMb7wT 	 
    	  
    		   
     
     
 
_11093822380353 mt3d6r2BuFfOvfXdOmaLX 	 
    	  
    		 endl mEm194VmPJuGh5y4tMUm5 	 
    	  
    		   
     
    
     mIaPM1ms991SDrw4x6KTt 	 
    	  
    		   
     
     
 
  	_11093822380353 mEm194VmPJuGh5y4tMUm5 	 
    	  
    		   
     
     
 mMGejH_coNc3kGxAdXVex 	 
    	  
    		   
     
     



cv miuOs6oIdxnQEMrFFk2n_ 	 
    Mat System mwuvkepREHprpx4i3n2RV 	 
    	  
  _4145838251597814913 mgGCFceAojKPG0bK5eWQT 	 
    	  
    		const Frame &_46082543180066935  mxAXsCfNkscq4iQtE2AeY 	 
    	  
    		  mbqHQotWhg0sv6ViuZXc3 	 
    	  
    		   
  
    std mrS2zvlmrTf4L4KBRRYAU 	 
    	  
    		   
vector mJCQ17ktBLqNw7sHF60R1 	 
    	  
    		   
     
     
 
uint32_t mVIm1AJSzhahLlgKO9xQK 	 
    	  
    		   
     
     
 
  	  _4240939334638385660 mxIwd_EJpfr1C9jwU7IyL 	 
    	  
    		   
     
     
 

    
    vector moCEmVQeGy8LzV8cAuk79 	 
    	  
    		   
    pair mHg0YG9R0Gb6ZE5xIr3dz 	 
 cv mNQimRrYQ8Mz6YI9KM7Fn 	 
    	  
    		   
     
     
Mat,double mKJK3THIuAwgeFpuGLN8L 	 
    	  
    		     meN5YYBBVg5DStfnyA8Dd 	 
    	  
    		   
     
     
 
  _5923954032168212568 mI30mSPxGJaQtkEjJfoQX 	 
    	  
    		   
     
    
    vector mLS76iLDjnGxttL6L8yfX 	 
    	  
    		   
    cv mvpMkjoDGcQujDevHDZnx 	 
Point3f mpBV2mt4yeFwcVEC5cxVw 	 
    	  
    	 _7045032207766252521 mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
 
    vector moCEmVQeGy8LzV8cAuk79 	 
    	  
  cv mrS2zvlmrTf4L4KBRRYAU 	 
    	  
    		   
     
     Point2f mJJosB3DZCYh837sWRpN7 	 
    	  
    	 _7045032207766252456 myu64GAT8DgGBhNOOCqvd 	
     maE84VqXoUUX_dnxUsfES 	 
    	  
    	auto _2654435878:_46082543180066935.markers mJk4eXgp_IeFV2YvLaQC7 	 
    	  
    		   
     
     mi6BqZOVmQyrEy6BLProP 	 
    	  
    		   
     
     
 
         mHbSWrX6OPeRP2Igmog8G 	 
    	  
  mlfybwyvp98TOJj0yuqhF 	 
    	  
    		   
     
     
 _9098980761384425343 mcvX0B8TDw1gEtqXtgT4T 	 
    	  
    		   
     
     
 
  	 map_markers.find mBGM118Iia8vm6zcNTuB6 	 
    	  _2654435878.id mVmWtYm5gVtZj7Yq19XWE 	 
    	  
    		   
     
    mpjTyiESCVWYRDiT2x2RD 	 
    	  
    	_9098980761384425343 mgi5Boc5f0emw5eocZbgV 	 
    	  
    		   
  map_markers.end mrXXIs5j4DqJtj32aOG5F 	 
    	  
    		   
     
     
 
  	  mXftmBtLFUrPFw3lasjuW 	 
    	   mi6BqZOVmQyrEy6BLProP 	 
    	  
            ucoslam mwuvkepREHprpx4i3n2RV 	 
    	  
    		   
   Marker &_6807036686937475945 mIqjSmilXv9ILvDddB7nD 	 
    	  
    		   _9098980761384425343 mevHkLo7kL5WL0_0mLIhr 	 map_markers mZ9T0z5VdOHGC7rra8Fzk 	 
   _2654435878.id mvFhi6DaS7eScbgWe07wY 	 
    	  
    	 mEm194VmPJuGh5y4tMUm5 	 
    	  
    		   
     
     
 

            cv me0ZKHp2Id3eLmP_6GMtk 	 
    	  
    		   
 Mat _9983235290341257781 mtmFAz7pcnIFLgYGMf4eK 	 
    	  
   _6807036686937475945.pose_g2m mEm194VmPJuGh5y4tMUm5 	 
    	  
    		   
     
  
            
             mf5rJKHDmIhT9kr_E2lnd 	 
    	  
    		   
     
  _11093822296219 mvA2vjSvRD7UmknjmYP5U 	 
_6807036686937475945.get3DPoints mdbwYCIpGYWahFfTtU8zH 	 
     mI30mSPxGJaQtkEjJfoQX 	 
    	  
    		   
     

            _7045032207766252521.insert mNQ6rNLARkxxSTP6tiTXG 	 
    	  
_7045032207766252521.end mGu_88Fdde5jsxW8v9whR 	 
    	  
    		   
     
    ,_11093822296219.begin mJFtpHxfnoGMxp1wzTBMr 	 
    	  
    		,_11093822296219.end mdbwYCIpGYWahFfTtU8zH 	 
    	  
    		   
    muC5cqYcHRXDD16noARI1 	 
    	  
    		  myu64GAT8DgGBhNOOCqvd 	 
    	  
    		   
     
     
 
  
            
            _7045032207766252456.insert mNQ6rNLARkxxSTP6tiTXG 	 
    	  
  _7045032207766252456.end mJFtpHxfnoGMxp1wzTBMr 	 
    	  
    		   
     ,_2654435878.und_corners.begin mrXXIs5j4DqJtj32aOG5F 	 
    	 ,_2654435878.und_corners.end mecU92YjgSbB3VkEoZVK3 	 
    	  
    		   
     
     
  muC5cqYcHRXDD16noARI1 	 
     mxIwd_EJpfr1C9jwU7IyL 	 
    	  
  
             mFTobXyS5Vx9ebVESwR0T 	_1515389571633683069 mXE5wWRmJGUY4EsEsgegT 	 
    	  
    		   
     
     
 
  	 IPPE mrS2zvlmrTf4L4KBRRYAU 	 
    	  
   solvePnP mBGM118Iia8vm6zcNTuB6 	 
    	  
    		   
     
     
_14938569619851839146.aruco_markerSize,_2654435878.und_corners,_46082543180066935.imageParams.CameraMatrix,_46082543180066935.imageParams.Distorsion muC5cqYcHRXDD16noARI1 	 
    	  
    		   
 mwkk1d6uUiyaKys71tsUv 	 
    
             mcAnVuQmAnGunjGyL6dhh 	 
    	  
    		   
     
     
 
 auto _16937226146608628973:_1515389571633683069 mSBNIRK1XqZg3XlWW_b3d 	 
    	  
    		   
     
     
 
                _5923954032168212568.push_back mlfybwyvp98TOJj0yuqhF 	 
    	  
    		   
        make_pair mSdpFB1uEgpzM3bVmlHgT 	 
    	_16937226146608628973 * _9983235290341257781.inv mJFtpHxfnoGMxp1wzTBMr 	 
    	  
    		   
     
     
 
,-1 muC5cqYcHRXDD16noARI1 	 
    	  
    		   
    muC5cqYcHRXDD16noARI1 	 
    	  
    		   
     
     
 mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
    		   
         mqVdZVftPR84WTjiOiVfT 	 
    	  
  
     mL9oWJQ1n2xKG3FtRNowa 	 
    	  
    
     mXYEIB3KYwzJOpssgkZxP 	 
    	  
    		   
     
     
 
  	 mlfybwyvp98TOJj0yuqhF 	 
    	  
    		   
     
     
_7045032207766252521.size mdbwYCIpGYWahFfTtU8zH 	 mIHFqVJpFXgMDdHn2uhc3 	 
    	  
    		   
     
  0 mxAXsCfNkscq4iQtE2AeY 	 
    	  
    		   
  return cv me0ZKHp2Id3eLmP_6GMtk 	 
    	  
    		Mat mdbwYCIpGYWahFfTtU8zH 	 
    	  
    		   
    mI30mSPxGJaQtkEjJfoQX 	 
    	  
    		   
     
     
    
     mTy5S_mcphfNLzuJQ30Xe 	 
    	  
    		   
     
     auto &_46082575779853237:_5923954032168212568 mJk4eXgp_IeFV2YvLaQC7 	 
    	  
    		   
     
     
  mJdlQJg0rG2m7KHUChC3R 	 
    	  
    		   
    
        vector mk9nSfh6XGyonOYMC8C3M 	 
   cv mNQimRrYQ8Mz6YI9KM7Fn 	 
    	  
    		   
     
     
 
  	Point2f mNF0G2xPBB22gI9XzMk2L 	 
    _1535067723848375914 mQivdop_Gb4hqsWvOttc3 	 
 
        se3 _16937226146609453200 mH9fKsRtHWNu77RGN1xmn 	 
    	  
    		_46082575779853237.first mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
    		   
     
     
 

        project mgGCFceAojKPG0bK5eWQT 	 
    	  
    		   
     
_7045032207766252521,_46082543180066935.imageParams.CameraMatrix,_16937226146609453200.convert mGu_88Fdde5jsxW8v9whR 	 
    ,_1535067723848375914 mVFG05ubhW6ia_rWdS_Tv 	 
  m_yMT4MKxrENTtLx5cA7n 	

        _46082575779853237.second mA7hUM4UKqFyb_LJLsook 	 
    	  
    		 0 mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  

         mozBzR4ceXlDTd_eA9UWj 	 
  size_t _2654435874 mRDD8w83SsPKbGXy_JkEO 	 
    	  
    		   
     
   0 mxIwd_EJpfr1C9jwU7IyL 	 
    	  
    		   
     
  _2654435874 mkHL8KJw4VjwmGdgQrteX 	 
    	  
 _1535067723848375914.size mecU92YjgSbB3VkEoZVK3 	  myu64GAT8DgGBhNOOCqvd 	 
    	  
    		   
     
     _2654435874 mPjeLalHATLRlVYohP5cu 	 
    	  
    		   
 mSBNIRK1XqZg3XlWW_b3d 	 
    	  
    		   
            _46082575779853237.second mraP1zuclX52fRr5CelTs 	 
    	  
    mUGrJMUolw0lb_KVyGK5N 	 
    	  
    		   _1535067723848375914 mZ9T0z5VdOHGC7rra8Fzk 	 
    	  
    		   
     
     
 
  	_2654435874 mGPgWaVxS3WdTr7rWsMw4 	 
    	  
    		 .x- _7045032207766252456 mZloAr3_PPw7622AVrUCe 	 _2654435874 mfF196cGKZ_LkBPN8ZWlr 	 
    	  
    		   
    .x mSBNIRK1XqZg3XlWW_b3d 	 
    	*  mYcSgTugFLQcmWT7seaac 	 
    	  
  _1535067723848375914 mRjEKX4QN9MTvSEtCTNd7 	 
    	  
    		   
_2654435874 mfF196cGKZ_LkBPN8ZWlr 	 
    	  
.x- _7045032207766252456 mwzFZRcSPi2Vsk45HpaLx 	 
    	  
    		   
  _2654435874 mfF196cGKZ_LkBPN8ZWlr 	 
    	.x mT3v8xdcVsSvUtbwmHC7j 	 
    	  
    		   
     
     
 
  	 +  mbXhD242DJoibBjdI1JtA 	 
_1535067723848375914 mZloAr3_PPw7622AVrUCe 	_2654435874 mtEI4bSjtkyV5O0qz_vBz 	 
    	.y- _7045032207766252456 msGAdK1RZcxCitYemdpxc 	 
    	  
    	_2654435874 mfF196cGKZ_LkBPN8ZWlr 	 
    	  
 .y muC5cqYcHRXDD16noARI1 	 
    	  
    		   
     
     
 
 *  mYcSgTugFLQcmWT7seaac 	 
    	  
    		   
     _1535067723848375914 mMo20fFU0rdQJ7l5qqDaX 	 
    _2654435874 mAH84ftHkJMUldxM9fJHE 	 
    	  
    		   
     
 .y- _7045032207766252456 mVLLVWqNz0_lGN56vY03t 	 
_2654435874 mWjWwCxBA7LLBixCoRsYZ 	 
    	  
    		   .y mJk4eXgp_IeFV2YvLaQC7 	 
    	  
    		   
     
     
 
  	 myu64GAT8DgGBhNOOCqvd 	 
    	  
    		   
     
     
 
     msxc6utIaOFXg4WI3vB0q 	 
    	  
    	
    
    std mI3QeEk0K_mj1WaUiowht 	 
    	  
    		   
     
     
 
  	 sort mTiWUgQKOeYLvNdGsR_oS 	 
_5923954032168212568.begin mGu_88Fdde5jsxW8v9whR 	 
    	  ,_5923954032168212568.end mJFtpHxfnoGMxp1wzTBMr 	 
    	  
    		   
  , msGAdK1RZcxCitYemdpxc 	 
    	  
 mGPgWaVxS3WdTr7rWsMw4 	 
    	  mBGM118Iia8vm6zcNTuB6 	const pair moCEmVQeGy8LzV8cAuk79 	 
    	  
    		   
     
     
 
cv mrPFLPKakBKjOOnkuhZUP 	 
Mat,double mzCa3iYOTZk3vOb9xFPuf 	 
    	  
    		   
     
     
  &_2654435866,const pair mJCQ17ktBLqNw7sHF60R1 	 
    	  
    		   cv mExFPeJBflhTWJKuQVWoB 	 
    	  
  Mat,double mVIm1AJSzhahLlgKO9xQK 	 
    	  
    		   
     &_2654435867 mVFG05ubhW6ia_rWdS_Tv 	 
    	  
    		   
      mi4REkBAebpTZrzlvFEpD 	 
    	 return _2654435866.second mRwYPGmWUou3ixNnKEWbv 	 
   _2654435867.second mqLizGA4Z8QZ_2GYQ1inC 	 
     mMGejH_coNc3kGxAdXVex 	 
    	  
    	 mT3v8xdcVsSvUtbwmHC7j 	 
    	  
    		   
     
     
 
   mEm194VmPJuGh5y4tMUm5 	 
    	  
    		   
     
     
 
  	
    
    
     mFWbNGU5e6cuqyQa3XUry 	 
    	  
    		   
    _5923954032168212568 mRjEKX4QN9MTvSEtCTNd7 	 
    	 0 mvFhi6DaS7eScbgWe07wY 	 
    	  
    		   
 .first mEm194VmPJuGh5y4tMUm5 	 

 mwiKr6psttEx97f2NsYO1 	 
    	  
    		   
     
     
 mOE4ALZahxLkvGqMRmxIK 	 
    	 System miuOs6oIdxnQEMrFFk2n_ 	 
    	  
 _2016327979059285019 mlfybwyvp98TOJj0yuqhF 	 
    	  
     Frame &_175247759917  mT3v8xdcVsSvUtbwmHC7j 	   mJdlQJg0rG2m7KHUChC3R 	 
    	  
  
 mp1kzPPa8GX6cfigPyiyD 	 
    	  
    		   
     
    _11093822302335 mEm194VmPJuGh5y4tMUm5 	 
    	  
    		   
     

     mHbSWrX6OPeRP2Igmog8G 	 
    	  
    		   mlfybwyvp98TOJj0yuqhF 	 
    	  
    		   
     
     
 
  _175247759917.imageParams.isStereoCamera mIJkWACd8Uom4Jv6selID 	 
    	  
    mJk4eXgp_IeFV2YvLaQC7 	 
    	  
    		   
     
     
 
  mqlayz2fShj6ePxekxwRg 	 
 
          _11093822302335 mXE5wWRmJGUY4EsEsgegT 	 
    	  
    		 _15186594243873234013 mbXhD242DJoibBjdI1JtA 	 
    	  
    		   
     
     _175247759917 mVmWtYm5gVtZj7Yq19XWE 	 
    	  
    		 myu64GAT8DgGBhNOOCqvd 	 
    	 
     m_ECAXF5hGu1UMoS2l1KU 	 
    else mqlayz2fShj6ePxekxwRg 	 
    	  
    		   

        _11093822302335 mtmFAz7pcnIFLgYGMf4eK 	 
    	  
    		   _14954361871198802778 mNQ6rNLARkxxSTP6tiTXG 	 
    	  
    		   
   _175247759917 msDy4S0F6Zdx78ZUnbARe 	 
    	  
    		   
     
   myu64GAT8DgGBhNOOCqvd 	 
    	  
    		   
     
     
 
     mf0YJDuh2j5By5N13LunG 	 
    	  
    		  
     mhRH54odsmIWcLq1D3rKZ 	 
    	  
    		   
     
     
  mQIaw42evZrZGmIhV_U05 	 
    	  
    		   
     
    _11093822302335 mxAXsCfNkscq4iQtE2AeY 	 
    	  
    		   
   return _11093822302335 m_yMT4MKxrENTtLx5cA7n 	 
    	  
    		   
     
     
 

    _17976495724303689842 mIqjSmilXv9ILvDddB7nD 	 
    	  
    		   
      _9098980761384425343 mcvX0B8TDw1gEtqXtgT4T 	 
    	keyframes.back mjjfaXD3tH8warSj13sVr 	 
    	  
    		   
    .pose_f2g mxIwd_EJpfr1C9jwU7IyL 	 
    	  
    		 
    _10576739190144361304 mXE5wWRmJGUY4EsEsgegT 	 
    	  
    	_9098980761384425343 mdMNbPkq6p5KBhEVf3OFw 	keyframes.back mjjfaXD3tH8warSj13sVr 	 
    	  
    		   
     
  .idx mqLizGA4Z8QZ_2GYQ1inC 	 
    	  
    		   
     
    
    _13028158409047949416 mA7hUM4UKqFyb_LJLsook 	 
    	  
    true mC_gLvnw5tkMWRQheRKr5 	 
    	
   mR8MpflZg6lk1qLQLX9P9 	 
 true mEm194VmPJuGh5y4tMUm5 	
 mf0YJDuh2j5By5N13LunG 	 
   
 mOE4ALZahxLkvGqMRmxIK 	 
    	  
 System mExFPeJBflhTWJKuQVWoB 	 
    	  
    		   
     
  _14954361871198802778 mTiWUgQKOeYLvNdGsR_oS 	 
    	  
 Frame &_175247759917  mSBNIRK1XqZg3XlWW_b3d 	 
    	  
    		   
     
      mXdnll4yjwVy4uBDSjUe3 	 
    	
     muDvj5aUdXshb2AqqeEiu 	 
    	  
    		 mYcSgTugFLQcmWT7seaac 	 
    	  
    		   
     
     
 
  	  mteJvtUMKI6kC6j6RtZKr 	 
    	  
    		_2044193291895307872 mj3rSXJDWd4j4OSGbS2oX 	 
    	  
    		   
     
     
 
  	process mlfybwyvp98TOJj0yuqhF 	 
    	  
    _175247759917,_9098980761384425343 mJk4eXgp_IeFV2YvLaQC7 	 
    	  
    		   
     
     
 
 msDy4S0F6Zdx78ZUnbARe 	 
      mHUTuX3q6rB5eWWYYPWQD 	 
    	  
false mQivdop_Gb4hqsWvOttc3 	 
    	  
    		  
      
    
         mbCI0BlZHp5kbKpNqa5Su 	 mBGM118Iia8vm6zcNTuB6 	 _9098980761384425343 mevHkLo7kL5WL0_0mLIhr 	 
    	  
  keyframes.size mjjfaXD3tH8warSj13sVr 	 
    	  
    		   
     mpBV2mt4yeFwcVEC5cxVw 	 
1  mSSwrqUuoNnhMtvhM2vr3 	 
    	  
  _9098980761384425343 mSwbK3nBcNZkvGxSXNOZy 	 
    	  
    		   
     
    map_points.size mjjfaXD3tH8warSj13sVr 	 
    	  
    meN5YYBBVg5DStfnyA8Dd 	 
    	  
    		   
     
     
 
  0 mxAXsCfNkscq4iQtE2AeY 	 
     muH9A34QGuccPZkZDb32w 	 
    	  
    		   
     
        _175247759917.ids  mRDD8w83SsPKbGXy_JkEO 	 
    	  
    		   
     
  _9098980761384425343 mVfb3IHZLk8rmg75VuqQZ 	 
    	  
    		keyframes.back mdbwYCIpGYWahFfTtU8zH 	 
    	  
    		   
     
     
.ids myu64GAT8DgGBhNOOCqvd 	 
    	  
    		  
     mEjIWbivPeVc9WtxGDiWw 	 
    	  
    		   
     
     
 

    globalOptimization mdbwYCIpGYWahFfTtU8zH 	 
    	  
    		   
     mEm194VmPJuGh5y4tMUm5 	 
    	  
    		
    
     mbCI0BlZHp5kbKpNqa5Su 	 
    	  
    		   
     
 mYcSgTugFLQcmWT7seaac 	 
    	  
    		   
     
     
 
  	 _9098980761384425343 mgi5Boc5f0emw5eocZbgV 	 
   map_markers.size mTGJXDnkacX2UX9dooHQu 	 
    	  
    		   
     
     
 
  	 mVrsJpNNblNXrk9CJ_J45 	 
   0 mxAXsCfNkscq4iQtE2AeY 	 
    	  
    		   
   mi6BqZOVmQyrEy6BLProP 	 
    	  
    		   
 
         mr8s7pfvTmBWmxher3Oue 	 
    	  
    		   
   mNQ6rNLARkxxSTP6tiTXG 	 
    	  
    		   
     
      _9098980761384425343 mevHkLo7kL5WL0_0mLIhr 	map_points.size mTGJXDnkacX2UX9dooHQu 	 
    	  
    		   
     
     
 
  mk9nSfh6XGyonOYMC8C3M 	 
    50 mxAXsCfNkscq4iQtE2AeY 	 
    	  
    		   
     muH9A34QGuccPZkZDb32w 	 
    	  
    		   
     
     
 

            _9098980761384425343 mtNKEvBwMHNsmdH7BtZbM 	 
    	  
 clear mrXXIs5j4DqJtj32aOG5F 	 mI30mSPxGJaQtkEjJfoQX 	 
   
             mHUTuX3q6rB5eWWYYPWQD 	 
    	  
 false mC_gLvnw5tkMWRQheRKr5 	 
    	  
    		   
     
     
 
  	 
         mf0YJDuh2j5By5N13LunG 	 
    	  
         mRIlZ0NriRkVMhRpycZqI 	_7847018097084079275 mA7hUM4UKqFyb_LJLsook 	 
    	  
    		   
  1./_9098980761384425343 mcvX0B8TDw1gEtqXtgT4T 	 
    	  
    		   
     
     
 
getFrameMedianDepth mlfybwyvp98TOJj0yuqhF 	 
    	  
    		   
     
     
 
  	_9098980761384425343 msDVYCHuU_j2g_TdgX4Ta 	 
    	  
    		   
     
     
 
keyframes.front mTGJXDnkacX2UX9dooHQu 	 
    	  
    		   
  .idx mVmWtYm5gVtZj7Yq19XWE 	 
    	  
     mEm194VmPJuGh5y4tMUm5 	 
    	  
    		   
     

        cv mMorzi7AHv5qXgdOZzcMd 	 
    	  
Mat _706246338944062 mIqjSmilXv9ILvDddB7nD 	 
  _9098980761384425343 mSwbK3nBcNZkvGxSXNOZy 	 
    	  
    		   
     
     
 
  	keyframes.back mrXXIs5j4DqJtj32aOG5F 	 
    	  
    		 .pose_f2g.inv mJFtpHxfnoGMxp1wzTBMr 	 
    	  
    		   
     
     mEm194VmPJuGh5y4tMUm5 	 
    	  
   
        
        
        _706246338944062.col mOAy4qGUJpdHQSVbVPq9E 	 
    	  
    		   
     
     3 msDy4S0F6Zdx78ZUnbARe 	 
    	  
  .rowRange mlfybwyvp98TOJj0yuqhF 	 
    	  
  0,3 mxAXsCfNkscq4iQtE2AeY 	 
    	    moHeIYzwbcFb6VaM90Aa9 	  _706246338944062.col mNQ6rNLARkxxSTP6tiTXG 	 
    	  
    		   3 mxAXsCfNkscq4iQtE2AeY 	 
    	  
    		   
     .rowRange mOAy4qGUJpdHQSVbVPq9E 	0,3 muC5cqYcHRXDD16noARI1 	 
    	  
    		   
     
     
 
  	*_7847018097084079275 mqLizGA4Z8QZ_2GYQ1inC 	 
  
        _9098980761384425343 mdMNbPkq6p5KBhEVf3OFw 	 
    	  
    		   
  keyframes.back mdbwYCIpGYWahFfTtU8zH 	 
   .pose_f2g mA7hUM4UKqFyb_LJLsook 	 
    	  
    		  _706246338944062.inv mGu_88Fdde5jsxW8v9whR 	 
    	  
    		   
   mEm194VmPJuGh5y4tMUm5 	 
    	  
    		   
   
         
          mFS3Bzv40ET2Bg_bjcFGO 	 
    	  
    	auto &_175247759380:_9098980761384425343 msDVYCHuU_j2g_TdgX4Ta 	 
    	  map_points mJk4eXgp_IeFV2YvLaQC7 	 
  mMm9FLNsNOoyX7Tyb7vpT 	 
 
            _175247759380.scalePoint mUGrJMUolw0lb_KVyGK5N 	 
    	  
    		  _7847018097084079275 mxAXsCfNkscq4iQtE2AeY 	 
    	  mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
    		   
     
     
 
 
         mqVdZVftPR84WTjiOiVfT 	 
    	  
    		   
     
     msxc6utIaOFXg4WI3vB0q 	 
    	  
    		   
     
    _17976495724303689842 mtmFAz7pcnIFLgYGMf4eK 	 
    	  
    		   _9098980761384425343 mxGJXkzb8EW07jCVTl0Jt 	 
    	  
    		   
    keyframes.back mrXXIs5j4DqJtj32aOG5F 	 
    	.pose_f2g mxIwd_EJpfr1C9jwU7IyL 	 
    	  
    		   
   
       mIaPM1ms991SDrw4x6KTt 	 
    	  
    		   
     
   true myu64GAT8DgGBhNOOCqvd 	 
    	  
    		   
   
 mEjIWbivPeVc9WtxGDiWw 	 
    	  
    		   

 mp1kzPPa8GX6cfigPyiyD 	 
    	  
    		   
     
     
 
 System mI3QeEk0K_mj1WaUiowht 	 
    	  
_15186594243873234013 mlfybwyvp98TOJj0yuqhF 	 
    	  
    		   
     
     
  Frame &_46082543180066935 mT3v8xdcVsSvUtbwmHC7j 	 
    	  
    		   mi6BqZOVmQyrEy6BLProP 	 

     mcs2IPsFq8XN5a3t5KBLK 	 
 _14938569619851839146.KPNonMaximaSuppresion mT3v8xdcVsSvUtbwmHC7j 	 
    	  
    		   
     
     
 
 
        _46082543180066935.nonMaximaSuppresion mdbwYCIpGYWahFfTtU8zH 	 
    	  
    		   
     
  mwkk1d6uUiyaKys71tsUv 	 
    	  
    		   
     
     
 

     mpgczyJuWNGXMBOxeP5oe 	 
   _8065948040949117953 mvA2vjSvRD7UmknjmYP5U 	 
0 myu64GAT8DgGBhNOOCqvd 	 
    	  
    		   
     
 
     mvbe619pMTxqR0ISntFSZ 	 
    	  
    		   
size_t _2654435874 mA7hUM4UKqFyb_LJLsook 	0 mQivdop_Gb4hqsWvOttc3 	 
    	  
  _2654435874 moCEmVQeGy8LzV8cAuk79 	 
    _46082543180066935.und_kpts.size mFAl4ldpf7o2gKLWQ4bfu 	 
     mo9Lbpy0Ap4RTl5O5Or1C 	 
    _2654435874 mUvBFztQfvp6FxGFsyoMW 	 
    	  
    		  mXftmBtLFUrPFw3lasjuW 	 
    	  
    		   
     
    mi4REkBAebpTZrzlvFEpD 	 
    	  
    		   
        
         mxkHJa5wooqhzaSxK7_fd 	 
    	  
    		   
     
 mUGrJMUolw0lb_KVyGK5N 	 
    	  
    		   
     
     
 
  	 _46082543180066935.getDepth mlfybwyvp98TOJj0yuqhF 	 
    	  
    		   
 _2654435874 mxAXsCfNkscq4iQtE2AeY 	 
    mVIm1AJSzhahLlgKO9xQK 	 
0  mKWQLdAVzYxp5QuNZ1ytt 	 
    	  
    		   
     
     _46082543180066935.imageParams.isClosePoint mBGM118Iia8vm6zcNTuB6 	 
    	  
    		   _46082543180066935.getDepth mYcSgTugFLQcmWT7seaac 	 
 _2654435874 mVFG05ubhW6ia_rWdS_Tv 	  mSBNIRK1XqZg3XlWW_b3d 	 
  mFllaSnZNjV3YvL2YmAFh 	 
    	  
    		    mteJvtUMKI6kC6j6RtZKr 	 
    	  
    _46082543180066935.flags mVjuVop3osym9wWoq6p3w 	 
    	 _2654435874 mAH84ftHkJMUldxM9fJHE 	 
    	  
    		   
     .is mSdpFB1uEgpzM3bVmlHgT 	 
    	  
    		   
  Frame mwuvkepREHprpx4i3n2RV 	 
    	  
    		   
     
     
 
 FLAG_NONMAXIMA mPaUdMg3fg2ipZY0Exj7X 	 
    	  
    		   
     
     
 
  	 mT3v8xdcVsSvUtbwmHC7j 	 
    	  
  
            _8065948040949117953 mUvBFztQfvp6FxGFsyoMW 	 
    	  
    		   
     
     
 
  mqLizGA4Z8QZ_2GYQ1inC 	 

     mwiKr6psttEx97f2NsYO1 	 
    	  
    		   
     
    
     mr8s7pfvTmBWmxher3Oue 	 
    	  
   mNQ6rNLARkxxSTP6tiTXG 	 
    	  
    		   
     
 _8065948040949117953 mLS76iLDjnGxttL6L8yfX 	 
    	  
  100 mXftmBtLFUrPFw3lasjuW 	 
   my5S_tF4_lSpButBKNitX 	 
    	  
    		   
false mwkk1d6uUiyaKys71tsUv 	 
    	
    _46082543180066935.pose_f2g.setUnity mecU92YjgSbB3VkEoZVK3 	 
    	  
    		   
   mwkk1d6uUiyaKys71tsUv 	 
  
    Frame & _16997199184281837438 mA7hUM4UKqFyb_LJLsook 	 
    	  
    	_9098980761384425343 mVfb3IHZLk8rmg75VuqQZ 	 
    	  
    		   
addKeyFrame mTiWUgQKOeYLvNdGsR_oS 	 
    	  
    _46082543180066935 mVmWtYm5gVtZj7Yq19XWE 	 
    	  
  mxIwd_EJpfr1C9jwU7IyL 	 
    
     mN_UNAeshLaooczmV1nkW 	 
    	  size_t _2654435874 mH9fKsRtHWNu77RGN1xmn 	 
    	  
    		  0 mEm194VmPJuGh5y4tMUm5 	 
  _2654435874 moCEmVQeGy8LzV8cAuk79 	 
    	  
    		   
    _46082543180066935.und_kpts.size mjjfaXD3tH8warSj13sVr 	 
    	  
    		   
     
     
 
  	  mI30mSPxGJaQtkEjJfoQX 	 
    	  
    		   
  _2654435874 mtIfgwpprqjFMhHY9FVrL 	 
    	  
    		   
     
     
  mT3v8xdcVsSvUtbwmHC7j 	 
    	  
    		   
     
 mbqHQotWhg0sv6ViuZXc3 	 
    	  
    		   
     
     
        
        cv mI3QeEk0K_mj1WaUiowht 	 
    	  
    		   
     
    Point3f _2654435881  mxIwd_EJpfr1C9jwU7IyL 	 
    	  
    		  
         mt3m0c1_35lMMq0E3cZsZ 	 
    	  
    		   
     
     
 mSdpFB1uEgpzM3bVmlHgT 	 
    	  
    		   
    _46082543180066935.getDepth mgGCFceAojKPG0bK5eWQT 	 
    	  
    		   
  _2654435874 mPaUdMg3fg2ipZY0Exj7X 	 
    	  
    		   
    mpBV2mt4yeFwcVEC5cxVw 	 
0  m_oqkmDs8rXEbW2q16xvJ 	 
    	  
 _46082543180066935.imageParams.isClosePoint mUGrJMUolw0lb_KVyGK5N 	 
    	  
   _46082543180066935.getDepth mYcSgTugFLQcmWT7seaac 	 
    	  
    		   
  _2654435874 mVFG05ubhW6ia_rWdS_Tv 	 
    	  
  muC5cqYcHRXDD16noARI1 	 
    	  
     mtq_QCXPpv2kX7L8PRz8d 	 
    	  
     mteJvtUMKI6kC6j6RtZKr 	 
    	  _46082543180066935.flags mVjuVop3osym9wWoq6p3w 	 
 _2654435874 mtEI4bSjtkyV5O0qz_vBz 	 
  .is mSdpFB1uEgpzM3bVmlHgT 	 Frame mNQimRrYQ8Mz6YI9KM7Fn 	 
    	  
FLAG_NONMAXIMA mSBNIRK1XqZg3XlWW_b3d 	 
    	  
    		   
     
     
 
  mVFG05ubhW6ia_rWdS_Tv 	 
    mSH1h4yGhaMSu8y7JC_rY 	 
    	  
    		  
            
            _2654435881 mXE5wWRmJGUY4EsEsgegT 	 
    	  
_46082543180066935.get3dStereoPoint mTiWUgQKOeYLvNdGsR_oS 	 
    	  
    		   
     
     
 
 _2654435874 mPaUdMg3fg2ipZY0Exj7X 	 
    	  
    		   mEm194VmPJuGh5y4tMUm5 	 
    	  
    		   
     
   
             mBUCZuaNioFkzVtaa2sRQ 	 
&_175247759380 mIqjSmilXv9ILvDddB7nD 	 
    	  
    		   
   _9098980761384425343 mgi5Boc5f0emw5eocZbgV 	 
    	  
    		  addNewPoint mgGCFceAojKPG0bK5eWQT 	 
    	  
    _16997199184281837438.fseq_idx mXftmBtLFUrPFw3lasjuW 	 
    	  
   mQivdop_Gb4hqsWvOttc3 	 
    	 
            _175247759380.kfSinceAddition moHeIYzwbcFb6VaM90Aa9 	 
    	  
    		   
     
     
 
  	1 mEm194VmPJuGh5y4tMUm5 	 
    	  
    		   
     
     
 
  	 
            _175247759380.setCoordinates mUGrJMUolw0lb_KVyGK5N 	 
    	  
    		   
     
     _2654435881 mXftmBtLFUrPFw3lasjuW 	 
    	  
    		   
   mI30mSPxGJaQtkEjJfoQX 	 
    	
            _175247759380.setStereo mTiWUgQKOeYLvNdGsR_oS 	 
    	  
    		   
  true mPaUdMg3fg2ipZY0Exj7X 	  mEm194VmPJuGh5y4tMUm5 	 
    	  
            _9098980761384425343 mevHkLo7kL5WL0_0mLIhr 	 
    	  
    		   
     
     addMapPointObservation mlfybwyvp98TOJj0yuqhF 	 
    	  
   _175247759380.id,_16997199184281837438.idx,_2654435874 muC5cqYcHRXDD16noARI1 	 
    	  
    		   
     myu64GAT8DgGBhNOOCqvd 	 
    
            _46082543180066935.ids mVLLVWqNz0_lGN56vY03t 	 
   _2654435874 mvFhi6DaS7eScbgWe07wY 	 
    	  
    		   
     
    mR22jPCjbltZ3tbBmn_6w 	 
  _175247759380.id mxIwd_EJpfr1C9jwU7IyL 	 
    	  
    		   
  
         miXz43zs_DqtraKQW0m3N 	 
    	  
    		   
     
 
     msBPMso4NRYFcn5Y1myF_ 	 
  
    
     mmeJW_Q9h6ZBPzSBQVjMK 	 
    	  
    		   
     
    const  mS0R9s7sfcYa3Nx39taZW 	 
    	  
&_2654435878:_46082543180066935.markers  mXftmBtLFUrPFw3lasjuW 	 
    	  
    		   
     muH9A34QGuccPZkZDb32w 	 
    	  
    		   
     
     
 
  	
        _9098980761384425343 mVfb3IHZLk8rmg75VuqQZ 	 
    	  
    	 addMarker mNQ6rNLARkxxSTP6tiTXG 	 
    	  
    		   
     
     
 _2654435878  mJk4eXgp_IeFV2YvLaQC7 	 
    	  
    		   
      mQivdop_Gb4hqsWvOttc3 	 
    	  
    		   
     
     
 
 
     mEjIWbivPeVc9WtxGDiWw 	 
    	  
    		   
     
     
 
  	 
     mIaPM1ms991SDrw4x6KTt 	 
    	  
    		   
     true mqLizGA4Z8QZ_2GYQ1inC 	 
    	  
    		
 mMGejH_coNc3kGxAdXVex 	 
    	  
    		   
     
     
 

string System miuOs6oIdxnQEMrFFk2n_ 	 
    	  
    		   
     
     
_2102381941757963317 mbXhD242DJoibBjdI1JtA 	 
    	  
    		   
     
     
uint64_t _11093822380353 mXftmBtLFUrPFw3lasjuW 	 
    	  
    		 const mqlayz2fShj6ePxekxwRg 	 
    	  
    	
    string _706246330193866 mC_gLvnw5tkMWRQheRKr5 	 
    	  
  
    string _46082576163156525 mhL9dWuOWzLGBfRjwvYlN 	 
    	  
    "\x71\x77\x65\x72\x74\x79\x75\x69\x6f\x70\x61\x73\x64\x66\x67\x68\x6a\x6b\x6c\x7a\x78\x63\x76\x62\x6e\x6d\x31\x32\x33\x34\x35\x36\x37\x38\x39\x30\x51\x57\x45\x52\x54\x59\x55\x49\x4f\x50\x41\x53\x44\x46\x47\x48\x4a\x4b\x4c\x5a\x58\x43\x56\x42\x4e\x4d" mxIwd_EJpfr1C9jwU7IyL 	 
    	  
    		   
     
     

    uchar * _2654435884 mtmFAz7pcnIFLgYGMf4eK 	 mOAy4qGUJpdHQSVbVPq9E 	 
    	  
   uchar * muC5cqYcHRXDD16noARI1 	 
    	  
    		   
     
     
 
  	&_11093822380353 mqLizGA4Z8QZ_2GYQ1inC 	 
    	  
    		   
     

     mjg3Ot05P13DpFXIgvY3M 	 
    _2654435879 moHeIYzwbcFb6VaM90Aa9 	 
    	  
    		   
 sizeof mNQ6rNLARkxxSTP6tiTXG 	 
    	  _11093822380353 msDy4S0F6Zdx78ZUnbARe 	/sizeof mbXhD242DJoibBjdI1JtA 	uchar  mPaUdMg3fg2ipZY0Exj7X 	 
    	  
     mQivdop_Gb4hqsWvOttc3 	 
    	
     mmeJW_Q9h6ZBPzSBQVjMK 	 
    	  
    		   
     
     
 
int _2654435874 mR22jPCjbltZ3tbBmn_6w 	 
    	  0 mqLizGA4Z8QZ_2GYQ1inC 	 
    	  
 _2654435874 mRwYPGmWUou3ixNnKEWbv 	 
    	  
    		   
    _2654435879 mC_gLvnw5tkMWRQheRKr5 	 
    	  
    		   
     
     
 
  	_2654435874 mPTzP5ovoJRtpRWISSe82 	 
  mT3v8xdcVsSvUtbwmHC7j 	 
    	  
    		   
    mi6BqZOVmQyrEy6BLProP 	 
    	  
    		   
     
     
 
  	
        _706246330193866.push_back mBGM118Iia8vm6zcNTuB6 	 
    	  
    _46082576163156525 mMo20fFU0rdQJ7l5qqDaX 	 
    	  
  _2654435884 mbtzLVjzLgaxYxNNltfyM 	 
    	  
    	_2654435874 mfF196cGKZ_LkBPN8ZWlr 	 
    	  
 %_46082576163156525.size mTGJXDnkacX2UX9dooHQu 	 mWjWwCxBA7LLBixCoRsYZ 	 
 mSBNIRK1XqZg3XlWW_b3d 	 
    	  
    		   
     m_yMT4MKxrENTtLx5cA7n 	 
    	  
    		
     miXz43zs_DqtraKQW0m3N 	 
    	  
    		   
     
     
 
  	
     mIaPM1ms991SDrw4x6KTt 	 
_706246330193866 m_yMT4MKxrENTtLx5cA7n 	 
    	  
    		   
   
 miXz43zs_DqtraKQW0m3N 	 
    	  
    		   
   
 mY8NZr9zd5VcrqfZxKQJH 	 
    	  
    		   
System mExFPeJBflhTWJKuQVWoB 	_1513765969352381626 mOAy4qGUJpdHQSVbVPq9E 	 
    	  
    		   
     
     const Frame &_10614055813325501077,  const se3 &_10706799483371532009 muC5cqYcHRXDD16noARI1 	 
    	  
    		   
     
     mXdnll4yjwVy4uBDSjUe3 	 
    	  
    		   
    
    int64_t _644211886852851457 mhL9dWuOWzLGBfRjwvYlN 	 
    	  
    		   
     -1  mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
     mWYYMqZtRPklZ6ldYQlW8 	 
    	  
   mUGrJMUolw0lb_KVyGK5N 	 
    	  
    		   
  _14938569619851839146.detectKeyPoints mPaUdMg3fg2ipZY0Exj7X 	 
    	  
    		   
     
     
 

       _644211886852851457 mXE5wWRmJGUY4EsEsgegT 	 
  _9098980761384425343 mtNKEvBwMHNsmdH7BtZbM 	 
    	  
    		   
     
     
 
  	 getReferenceKeyFrame mSdpFB1uEgpzM3bVmlHgT 	 
  _10614055813325501077,1 mVmWtYm5gVtZj7Yq19XWE 	 
    	  
    		   
     
     
 
  	  mqLizGA4Z8QZ_2GYQ1inC 	 
    	  
    		   
     
 
     mWYYMqZtRPklZ6ldYQlW8 	 
    	  
    	 mSdpFB1uEgpzM3bVmlHgT 	 
    	  
    		   
     
     _644211886852851457 mcozC0jwDOrxnYpsfODix 	 
    	  
    		   
     
     
 
-1 mSBNIRK1XqZg3XlWW_b3d 	 
    	  
    		   
   mFWbNGU5e6cuqyQa3XUry 	 
    	  
    		   
     
     
 
  	 _644211886852851457 m_yMT4MKxrENTtLx5cA7n 	 
    	  
    		   
     
  
    
     mFVNERjMRO_ZEKm0TY73X 	 
    	  
    		   
     
     
 
  	 mYcSgTugFLQcmWT7seaac 	 
    	  
  _9098980761384425343 mevHkLo7kL5WL0_0mLIhr 	 
    	  
    		   
     
  map_markers.size mTGJXDnkacX2UX9dooHQu 	 
    	  mosqH7AZUNZeyz6yX3nN1 	 
  0 mT3v8xdcVsSvUtbwmHC7j 	 mjXlfKOCTRjUV9apwYcb7 	 
    	  

         mFWbNGU5e6cuqyQa3XUry 	 
    	  
    		   
     
     
 
_10576739190144361304 myu64GAT8DgGBhNOOCqvd 	 
    	  
    		   
     
     
 
  	
     mMGejH_coNc3kGxAdXVex 	 
  
    
    vector mHg0YG9R0Gb6ZE5xIr3dz 	 
    	  
    		   
uint32_t mW202Akoy5o2_FFUMtz7a 	 
    	  
    		   
     _4240713669852012646 m_yMT4MKxrENTtLx5cA7n 	 
    	  
  
     mcAnVuQmAnGunjGyL6dhh 	 
    	  
    		   
     
     
auto _2654435878:_10614055813325501077.markers mPaUdMg3fg2ipZY0Exj7X 	 
    	  
    		   
     
     
 
  	 mXdnll4yjwVy4uBDSjUe3 	 
    	  
    		   
   
         mBUCZuaNioFkzVtaa2sRQ 	 
    	  
   _3005399795337363304 mA7hUM4UKqFyb_LJLsook 	 
  _9098980761384425343 mSwbK3nBcNZkvGxSXNOZy 	 
    	  
    		   
     
     map_markers.find mBGM118Iia8vm6zcNTuB6 	 
    	  
    		   
     
    _2654435878.id mVFG05ubhW6ia_rWdS_Tv 	 
    	  
    		   
 mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
   
         mr8s7pfvTmBWmxher3Oue 	 
  mTiWUgQKOeYLvNdGsR_oS 	 
     _3005399795337363304 mmk2RogyswbtTiHnbCghT 	 
    	  
    	_9098980761384425343 mgi5Boc5f0emw5eocZbgV 	 
    	  
    		   
   map_markers.end mFAl4ldpf7o2gKLWQ4bfu 	 
    	  
    		   
  mxAXsCfNkscq4iQtE2AeY 	 
    	  
    		   
     
     
 mbqHQotWhg0sv6ViuZXc3 	 
    	  
    		   
     
     
             mt3m0c1_35lMMq0E3cZsZ 	 
  mTiWUgQKOeYLvNdGsR_oS 	 
    	  
    		 _3005399795337363304 mVfb3IHZLk8rmg75VuqQZ 	 
    	  
 second.pose_g2m.isValid mecU92YjgSbB3VkEoZVK3 	 
    	  
    mT3v8xdcVsSvUtbwmHC7j 	 
   _4240713669852012646.push_back mBGM118Iia8vm6zcNTuB6 	_2654435878.id msDy4S0F6Zdx78ZUnbARe 	 
    	  
    		   
     
     m_yMT4MKxrENTtLx5cA7n 	 
    	 
         mMGejH_coNc3kGxAdXVex 	 
    	  
    		  
     miXz43zs_DqtraKQW0m3N 	 
    	  
    	
    pair mbVOLbjVZO0YI60Vuguaq 	 
    	  uint32_t,float mYbzFOKSwwNsD71cP1DkA 	 
  _18337238202410394478 mgGCFceAojKPG0bK5eWQT 	 
    	  
    		   
     
   std me0ZKHp2Id3eLmP_6GMtk 	 
    	  
    		   
     numeric_limits mLS76iLDjnGxttL6L8yfX 	 
    	  
  uint32_t maPL1kl9f9VlgIn9jnnN_ 	 
    	  
    		   
     
     
 
   mvpMkjoDGcQujDevHDZnx 	 
    	  
    		   
max mFAl4ldpf7o2gKLWQ4bfu 	 
    	,std mrPFLPKakBKjOOnkuhZUP 	 
    	  
    		   
     
     
 
  numeric_limits mnpObQ1mWnyfQO24_ojBn 	 
    	  
    		   
  float mJJosB3DZCYh837sWRpN7 	 
    	  
     miuOs6oIdxnQEMrFFk2n_ 	 
    	  
    		max mdbwYCIpGYWahFfTtU8zH 	 
    	  
   mVmWtYm5gVtZj7Yq19XWE 	 
    	  
    		   
     
  mwkk1d6uUiyaKys71tsUv 	 
    	  
    		   
    
     mIyrnAZ9pLZEaiK6Yst1L 	 
    	  
    		   
     auto _3005399795337363304:_4240713669852012646 mPaUdMg3fg2ipZY0Exj7X 	 
    	  
    
         mozBzR4ceXlDTd_eA9UWj 	 
    	  
    		   
     
     
 
  const  mBUCZuaNioFkzVtaa2sRQ 	 
    	 &_46082543180066935:_9098980761384425343 mdMNbPkq6p5KBhEVf3OFw 	 
    	  
    		  map_markers mZ9T0z5VdOHGC7rra8Fzk 	 
    	  
    		_3005399795337363304 mWi16Wz7P86SIJlTQEzCB 	 
    	  
    		   
.frames mPaUdMg3fg2ipZY0Exj7X 	 
    	  
    		   
     
     
 
  mbqHQotWhg0sv6ViuZXc3 	 
    	  
    		   
     
     
 
  
             mcRuULuI_AYJWzFSu1kB4 	 
    _2654435869 mXE5wWRmJGUY4EsEsgegT 	 
    	  
    		   
     
     
 
    _10706799483371532009 .t_dist mUGrJMUolw0lb_KVyGK5N 	 
    	  
    		   
     
    _9098980761384425343 mevHkLo7kL5WL0_0mLIhr 	 
  keyframes mMo20fFU0rdQJ7l5qqDaX 	 
    	  
_46082543180066935 mOwAFTnFZjoBWI2gNeAO_ 	 
    	  
    		   
     
 .pose_f2g  mxAXsCfNkscq4iQtE2AeY 	 
        mI30mSPxGJaQtkEjJfoQX 	 
    	  
    		   
     
     
 
  	 
             mt3m0c1_35lMMq0E3cZsZ 	 
    	  
    		   
     
  mlfybwyvp98TOJj0yuqhF 	 
    	  
  _18337238202410394478.second mW202Akoy5o2_FFUMtz7a 	 
    	  
    		   
     
     
 
_2654435869 mPaUdMg3fg2ipZY0Exj7X 	 
    	  
    		   
     
     _18337238202410394478 mhL9dWuOWzLGBfRjwvYlN 	 
    	  
    		   
 mi6BqZOVmQyrEy6BLProP 	 
    	  
   _46082543180066935,_2654435869 mf0YJDuh2j5By5N13LunG 	 
    mC_gLvnw5tkMWRQheRKr5 	 
  
         mf0YJDuh2j5By5N13LunG 	 
    	  
     mHUTuX3q6rB5eWWYYPWQD 	 
    	  
    		   
     
     
 
_18337238202410394478.first myu64GAT8DgGBhNOOCqvd 	 
    	  
    		 
 mEjIWbivPeVc9WtxGDiWw 	 
    	  
    		   
     
     
 
std mwuvkepREHprpx4i3n2RV 	 
    	  
    		   
  vector mkHL8KJw4VjwmGdgQrteX 	System mExFPeJBflhTWJKuQVWoB 	 
    	  
 _4118122444908280734 meN5YYBBVg5DStfnyA8Dd 	 
   System mI3QeEk0K_mj1WaUiowht 	 
    	  
    		   
     
     
 _3473802998844434099 mOAy4qGUJpdHQSVbVPq9E 	 Frame &_16940374161494853219,se3 &_13011065492167565582 ,const std mI3QeEk0K_mj1WaUiowht 	 
    	  
    		   
  set mbVOLbjVZO0YI60Vuguaq 	 
  uint32_t mNF0G2xPBB22gI9XzMk2L 	 
    	  
    &_16997249117545452056  mVmWtYm5gVtZj7Yq19XWE 	 
    	  
 mi4REkBAebpTZrzlvFEpD 	 
    
     mFVNERjMRO_ZEKm0TY73X 	 
     mTiWUgQKOeYLvNdGsR_oS 	 
    	_16940374161494853219.ids.size mGu_88Fdde5jsxW8v9whR 	 mw_MIhwcw8TZ9gTF3_mEt 	 
    	  
    		   
   0 mT3v8xdcVsSvUtbwmHC7j 	 
    	  
    		   
    return  mi6BqZOVmQyrEy6BLProP 	 
    	  
    		   
     
     
 
  	  m_ECAXF5hGu1UMoS2l1KU 	 
    	  
  mC_gLvnw5tkMWRQheRKr5 	
     mr8s7pfvTmBWmxher3Oue 	 
    	  mTiWUgQKOeYLvNdGsR_oS 	 
    	  
    		   
     
  _9098980761384425343 mgi5Boc5f0emw5eocZbgV 	 
    	  
    		   
     
   TheKFDataBase.isEmpty mIJkWACd8Uom4Jv6selID 	 
    	  
    		   
     
     
 
 msDy4S0F6Zdx78ZUnbARe 	 
    	return   mSH1h4yGhaMSu8y7JC_rY 	 
    	  
    mwiKr6psttEx97f2NsYO1 	 
    	  
   myu64GAT8DgGBhNOOCqvd 	 
    	  
    		   
     
     
 
  	 
    vector mLS76iLDjnGxttL6L8yfX 	 
    	  
    		   
     
     
 
  	 uint32_t mYbzFOKSwwNsD71cP1DkA 	 
    	  
   _5288382201172378343 mH9fKsRtHWNu77RGN1xmn 	 
    	  
    		   
    _9098980761384425343 mtNKEvBwMHNsmdH7BtZbM 	 
    	  
    		   
     
     
 relocalizationCandidates mSdpFB1uEgpzM3bVmlHgT 	 
    	  
    		 _16940374161494853219,_16997249117545452056 mXftmBtLFUrPFw3lasjuW 	 
    	 mxIwd_EJpfr1C9jwU7IyL 	 
    
     mFVNERjMRO_ZEKm0TY73X 	 
    	  
  mgGCFceAojKPG0bK5eWQT 	 
    	  _5288382201172378343.size mRAYh0ARHPOc62CfGHWWO 	 
    	  
    mDHmz3NSVqdDEn8FHaIo5 	 
    	  
    		0 mVFG05ubhW6ia_rWdS_Tv 	 
    	  
    		   
     
     return   mSH1h4yGhaMSu8y7JC_rY 	 
    	  
    		   
     
     
 
 mwiKr6psttEx97f2NsYO1 	 
    	  
    		   
     
     
  mI30mSPxGJaQtkEjJfoQX 	
    vector mkHL8KJw4VjwmGdgQrteX 	 
    	  
    		   
  System me0ZKHp2Id3eLmP_6GMtk 	 
    	  
    		_4118122444908280734 mYbzFOKSwwNsD71cP1DkA 	 
    	  
    		   
    _1524129789187101628 mNQ6rNLARkxxSTP6tiTXG 	 
    	  
 _5288382201172378343.size mRAYh0ARHPOc62CfGHWWO 	 
    	  
    		   
     
     mXftmBtLFUrPFw3lasjuW 	 
    	  
    		   
     
     
 
   mQivdop_Gb4hqsWvOttc3 	
    FrameMatcher _16937386958649118140 mwkk1d6uUiyaKys71tsUv 	 
    	  

    _16937386958649118140.setParams mNQ6rNLARkxxSTP6tiTXG 	 
    	  
    		   
 _16940374161494853219,FrameMatcher mrPFLPKakBKjOOnkuhZUP 	 
    	  
    		   
     
     
 
  	 MODE_ALL,_14938569619851839146.maxDescDistance*2 mPaUdMg3fg2ipZY0Exj7X 	 
   mQivdop_Gb4hqsWvOttc3 	 
    	  
    		   
     
     
 
  	 
#pragma omp parallel for
     mWIOGoR1XyrR6fw03i9px 	 
    	  
    		   
    int _175247762874 mXE5wWRmJGUY4EsEsgegT 	 
    	  
    		   
     
     
 
0 mo9Lbpy0Ap4RTl5O5Or1C 	 
  _175247762874 mbVOLbjVZO0YI60Vuguaq 	_5288382201172378343.size mdbwYCIpGYWahFfTtU8zH 	 
    	  
    		    mQivdop_Gb4hqsWvOttc3 	 
    	 _175247762874 mMbWC8gQeXmnMqYEj20Wf 	 
    	  
    		   mT3v8xdcVsSvUtbwmHC7j 	 
    	  
    		   
     
    mjXlfKOCTRjUV9apwYcb7 	 
   
         mTWpr3m9V3RdtOrrhhpUi 	 
  _175247760268 mtmFAz7pcnIFLgYGMf4eK 	 
    	  
    		   
     
     
 _5288382201172378343 msGAdK1RZcxCitYemdpxc 	 
    	_175247762874 mAH84ftHkJMUldxM9fJHE 	 
 m_yMT4MKxrENTtLx5cA7n 	 
         mEhFK99MtLRsCBaPNqnDs 	 
    	  
    		   
     
     
 
 &_3005399814901981436 moHeIYzwbcFb6VaM90Aa9 	 
   _9098980761384425343 mtNKEvBwMHNsmdH7BtZbM 	 
    	  
   keyframes mRjEKX4QN9MTvSEtCTNd7 	 
    	  
    		   
    _175247760268 mQbYLzhvVQm8J2LNkC6S6 	 
    	  
    		   
     
     
 
  mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
    		
        _1524129789187101628 mbtzLVjzLgaxYxNNltfyM 	 
    	  
    		 _175247762874 mGPgWaVxS3WdTr7rWsMw4 	 
    	  
    		   
     
  ._6116114700730085677 mR22jPCjbltZ3tbBmn_6w 	 
    	  
    		  _16937386958649118140.match mNQ6rNLARkxxSTP6tiTXG 	 
    	_3005399814901981436,FrameMatcher miuOs6oIdxnQEMrFFk2n_ 	 
    	  
    		   
 MODE_ASSIGNED mT3v8xdcVsSvUtbwmHC7j 	 
    	 mQivdop_Gb4hqsWvOttc3 	 

        
         mvbe619pMTxqR0ISntFSZ 	 
    	  
    auto &_2654435878:_1524129789187101628 mVjuVop3osym9wWoq6p3w 	_175247762874 mfF196cGKZ_LkBPN8ZWlr 	 
 ._6116114700730085677 mXftmBtLFUrPFw3lasjuW 	 
    	  
    		   
    mjXlfKOCTRjUV9apwYcb7 	 
    	  
    		   
     
     
 
  
            std mNQimRrYQ8Mz6YI9KM7Fn 	 
    	  
    		   
     
   swap mUGrJMUolw0lb_KVyGK5N 	 
    	  
    		   
     
     
_2654435878.queryIdx,_2654435878.trainIdx mJk4eXgp_IeFV2YvLaQC7 	 
     myu64GAT8DgGBhNOOCqvd 	
            _2654435878.trainIdx mtmFAz7pcnIFLgYGMf4eK 	 
    	 _3005399814901981436.ids mVLLVWqNz0_lGN56vY03t 	 
    	  
    		   
     _2654435878.trainIdx mOwAFTnFZjoBWI2gNeAO_ 	 
    	  
    		   
      mI30mSPxGJaQtkEjJfoQX 	 

         mL9oWJQ1n2xKG3FtRNowa 	 
    	  
    		   
     
     
 
        
         mFS3Bzv40ET2Bg_bjcFGO 	int _2654435874 mtmFAz7pcnIFLgYGMf4eK 	 
    	  
    		   
     
  0 mI30mSPxGJaQtkEjJfoQX 	 
    	  
    		   _2654435874 miGVtxwiqbDQsG6KBslZU 	 
    	  
_1524129789187101628 mVjuVop3osym9wWoq6p3w 	 
  _175247762874 mtEI4bSjtkyV5O0qz_vBz 	 
    	  ._6116114700730085677.size mTGJXDnkacX2UX9dooHQu 	 
    	  
    		   
     
     
  mwkk1d6uUiyaKys71tsUv 	 
  _2654435874 mUvBFztQfvp6FxGFsyoMW 	 
    	  
    		  mXftmBtLFUrPFw3lasjuW 	 
    	  
    		 mbqHQotWhg0sv6ViuZXc3 	 
    	  
    		   
     
     
 
  	 
             mcRuULuI_AYJWzFSu1kB4 	 
    	  
    		   
   &_175247759380 mXE5wWRmJGUY4EsEsgegT 	 
    	  
    		   
     
     
 
  _1524129789187101628 mMo20fFU0rdQJ7l5qqDaX 	 
_175247762874 mtEI4bSjtkyV5O0qz_vBz 	._6116114700730085677 mstJEG25u0Qv4VQocWgKl 	 
    	  
    		   _2654435874 mWi16Wz7P86SIJlTQEzCB 	 
    	  
    		   
 .trainIdx mC_gLvnw5tkMWRQheRKr5 	 
    	  
             mg9IHDbTXxljO0nSnQKYh 	 
    	  
    		   
      molF5K16MuyVvkFE7X8JI 	 
    	  
    		   
     
     
 
_9098980761384425343 mdMNbPkq6p5KBhEVf3OFw 	 
    	  
   map_points.is mOAy4qGUJpdHQSVbVPq9E 	 
    	 _175247759380 mSBNIRK1XqZg3XlWW_b3d 	 
    	  
    		   
     mSBNIRK1XqZg3XlWW_b3d 	 
    	  
                _1524129789187101628 mbtzLVjzLgaxYxNNltfyM 	 
    	  
    _175247762874 mfF196cGKZ_LkBPN8ZWlr 	 ._6116114700730085677 mbtzLVjzLgaxYxNNltfyM 	 
    	  
    		   
 _2654435874 mGPgWaVxS3WdTr7rWsMw4 	 
    	  
  .trainIdx mR22jPCjbltZ3tbBmn_6w 	 
    	  
   -1 mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
  
             mg9IHDbTXxljO0nSnQKYh 	 
    	  
   _9098980761384425343 mcvX0B8TDw1gEtqXtgT4T 	map_points mbtzLVjzLgaxYxNNltfyM 	 
    	  
    		   
     
     
 _175247759380 mvFhi6DaS7eScbgWe07wY 	 
    	  
    		   
     
     
 .isBad mjjfaXD3tH8warSj13sVr 	 
    	  
    		      mVmWtYm5gVtZj7Yq19XWE 	 
    	  
                _1524129789187101628 mMo20fFU0rdQJ7l5qqDaX 	 
    	  _175247762874 mfF196cGKZ_LkBPN8ZWlr 	 
    	  
    		   
     
     
 ._6116114700730085677 mstJEG25u0Qv4VQocWgKl 	 
    	  
    		   
     _2654435874 mGPgWaVxS3WdTr7rWsMw4 	 
    	  
.trainIdx mtmFAz7pcnIFLgYGMf4eK 	 
   -1 mqLizGA4Z8QZ_2GYQ1inC 	 
 
         mqVdZVftPR84WTjiOiVfT 	 
    	  
    		   
     
 
        remove_unused_matches mBGM118Iia8vm6zcNTuB6 	 
    	  
    		   
  _1524129789187101628 mbtzLVjzLgaxYxNNltfyM 	 
    	  
    		   
     
  _175247762874 mtEI4bSjtkyV5O0qz_vBz 	 
    	  
    		  ._6116114700730085677 msDy4S0F6Zdx78ZUnbARe 	 
    	  
    		   
     
    mQivdop_Gb4hqsWvOttc3 	 
    	  
    		   
     
     
         mAvI6WqVGKew5QUXF0T2l 	 
    	  
    mlfybwyvp98TOJj0yuqhF 	 
    	  
    		   
     
 _1524129789187101628 mZloAr3_PPw7622AVrUCe 	_175247762874 mWjWwCxBA7LLBixCoRsYZ 	 
    	  
    		   
._6116114700730085677.size mdbwYCIpGYWahFfTtU8zH 	 
    	  
    		   
     
     
 
  	 moCEmVQeGy8LzV8cAuk79 	 
    	  
    		   
 25 mJk4eXgp_IeFV2YvLaQC7 	 
    	  
continue mI30mSPxGJaQtkEjJfoQX 	 
    	  
    		   
     
 
        _1524129789187101628 mVLLVWqNz0_lGN56vY03t 	 _175247762874 mfF196cGKZ_LkBPN8ZWlr 	 
    	  
    		 ._3885067248075476027 mRDD8w83SsPKbGXy_JkEO 	 
    	  _3005399814901981436.pose_f2g mC_gLvnw5tkMWRQheRKr5 	
         
        PnPSolver me0ZKHp2Id3eLmP_6GMtk 	 
    	  
    		  solvePnPRansac mNQ6rNLARkxxSTP6tiTXG 	 
 _16940374161494853219,_9098980761384425343,_1524129789187101628 mVLLVWqNz0_lGN56vY03t 	 
    	  _175247762874 mWjWwCxBA7LLBixCoRsYZ 	 
    	  
    		   
._6116114700730085677,_1524129789187101628 mZloAr3_PPw7622AVrUCe 	 
    	  
    		   
     
     
 
  _175247762874 mfF196cGKZ_LkBPN8ZWlr 	 
    	 ._3885067248075476027 mVmWtYm5gVtZj7Yq19XWE 	 
    	  
    		   
   mQivdop_Gb4hqsWvOttc3 	 
    	  
    		 
          mWYYMqZtRPklZ6ldYQlW8 	 
    	  
    mBGM118Iia8vm6zcNTuB6 	 
    	 _1524129789187101628 mZloAr3_PPw7622AVrUCe 	 
    _175247762874 mOwAFTnFZjoBWI2gNeAO_ 	 
   ._6116114700730085677.size mTGJXDnkacX2UX9dooHQu 	 
    	  
    		   
     
     
  mLS76iLDjnGxttL6L8yfX 	 
    	  
    		   
     
15 msDy4S0F6Zdx78ZUnbARe 	 
    	  
    		   
     
     
 
  	 continue mxIwd_EJpfr1C9jwU7IyL 	 
    	  
        
        _1524129789187101628 msGAdK1RZcxCitYemdpxc 	 
    	  
  _175247762874 mQbYLzhvVQm8J2LNkC6S6 	 
    	  
 ._6116114700730085677 mH9fKsRtHWNu77RGN1xmn 	 _9098980761384425343 mevHkLo7kL5WL0_0mLIhr 	 
    	  
 matchFrameToMapPoints  mBGM118Iia8vm6zcNTuB6 	 
    	  
    		   
     
      _9098980761384425343 mcvX0B8TDw1gEtqXtgT4T 	 
    TheKpGraph.getNeighborsVLevel2 mOAy4qGUJpdHQSVbVPq9E 	 
    	  
    		   
   _175247760268,true mJk4eXgp_IeFV2YvLaQC7 	 , _16940374161494853219,  _1524129789187101628 msGAdK1RZcxCitYemdpxc 	 
    	  
    _175247762874 mQbYLzhvVQm8J2LNkC6S6 	 
    	  
    		   
     
     ._3885067248075476027 ,_14938569619851839146.maxDescDistance*2, 2.5,true mJk4eXgp_IeFV2YvLaQC7 	 
    	  
    		  mC_gLvnw5tkMWRQheRKr5 	 
    	  
    		   
         muDvj5aUdXshb2AqqeEiu 	 
    	  
    		   
     
 mlfybwyvp98TOJj0yuqhF 	 
    	  
    		   _1524129789187101628 mbtzLVjzLgaxYxNNltfyM 	_175247762874 mQbYLzhvVQm8J2LNkC6S6 	 
    	  ._6116114700730085677.size mJFtpHxfnoGMxp1wzTBMr 	 
    	  
    		   
  mkHL8KJw4VjwmGdgQrteX 	 
    	30 mxAXsCfNkscq4iQtE2AeY 	 
    	  
    		   
     
 continue mxIwd_EJpfr1C9jwU7IyL 	 
    	  
  
        
        PnPSolver mNQimRrYQ8Mz6YI9KM7Fn 	 
    	  
    		   
     
    solvePnp mbXhD242DJoibBjdI1JtA 	 
    	  
    		   
     
  _16940374161494853219,_9098980761384425343,_1524129789187101628 mbtzLVjzLgaxYxNNltfyM 	 
   _175247762874 mGPgWaVxS3WdTr7rWsMw4 	 
    	  
    		   
 ._6116114700730085677,_1524129789187101628 mRjEKX4QN9MTvSEtCTNd7 	 
    	  
  _175247762874 mWi16Wz7P86SIJlTQEzCB 	 
    	  
    		   
   ._3885067248075476027 mJk4eXgp_IeFV2YvLaQC7 	 
    	  
    mxIwd_EJpfr1C9jwU7IyL 	 
    	  
    		   
     
   
          mWYYMqZtRPklZ6ldYQlW8 	 
    	  
    		   
     
     
 
   mUGrJMUolw0lb_KVyGK5N 	 
    _1524129789187101628 mbtzLVjzLgaxYxNNltfyM 	 
    	  
_175247762874 mfF196cGKZ_LkBPN8ZWlr 	 
   ._6116114700730085677.size mIJkWACd8Uom4Jv6selID 	 
    	  
    mHg0YG9R0Gb6ZE5xIr3dz 	 
    	  
    		 30 msDy4S0F6Zdx78ZUnbARe 	 
    	  
    		   
     
   continue myu64GAT8DgGBhNOOCqvd 	 
   
        _1524129789187101628 mwzFZRcSPi2Vsk45HpaLx 	 
    	  
  _175247762874 ml5d8mzmxNmQRMtpfZ82X 	 
 . _16902946305713852348 moHeIYzwbcFb6VaM90Aa9 	 
    	  
    		 _16940374161494853219.ids mI30mSPxGJaQtkEjJfoQX 	 
    	  
    		   
         mozBzR4ceXlDTd_eA9UWj 	 
    	  
    		   
   auto _46082575882272165: _1524129789187101628 msGAdK1RZcxCitYemdpxc 	 
    	  
    		   
     
  _175247762874 mvFhi6DaS7eScbgWe07wY 	 
    	  
    		   
     
     
 
 ._6116114700730085677 mJk4eXgp_IeFV2YvLaQC7 	 
    	  
    		   
     
            _1524129789187101628 mVLLVWqNz0_lGN56vY03t 	 
    	  
    		   
_175247762874 mWjWwCxBA7LLBixCoRsYZ 	 
    	  
  ._16902946305713852348 mwzFZRcSPi2Vsk45HpaLx 	  _46082575882272165.queryIdx mWjWwCxBA7LLBixCoRsYZ 	 mhL9dWuOWzLGBfRjwvYlN 	 
    	_46082575882272165.trainIdx m_yMT4MKxrENTtLx5cA7n 	 
    	  
    		   
     
     

     msxc6utIaOFXg4WI3vB0q 	 
    	  
    		   

    
    std mI3QeEk0K_mj1WaUiowht 	 
    	  
    		  remove_if mbXhD242DJoibBjdI1JtA 	 
   _1524129789187101628.begin mrXXIs5j4DqJtj32aOG5F 	 
    	  
    		   
     
,_1524129789187101628.end mjjfaXD3tH8warSj13sVr 	 
    	  
 , mstJEG25u0Qv4VQocWgKl 	 
    	  
    		   
     
     
 mWi16Wz7P86SIJlTQEzCB 	 
     mbXhD242DJoibBjdI1JtA 	const _4118122444908280734 &_2654435866 mT3v8xdcVsSvUtbwmHC7j 	 
    	  
    		   
    mbqHQotWhg0sv6ViuZXc3 	 
    	  
    		   
     
     
 
 return _2654435866._6116114700730085677.size mdbwYCIpGYWahFfTtU8zH 	 
 mO5I_G9WPuW9VC4inj5mo 	 
    	  
    		   
     
     
30 mI30mSPxGJaQtkEjJfoQX 	 
  mMGejH_coNc3kGxAdXVex 	 mXftmBtLFUrPFw3lasjuW 	 
    	  
    		   
     
  mI30mSPxGJaQtkEjJfoQX 	 
    	  
    		   
    
    std mMorzi7AHv5qXgdOZzcMd 	 
    	  
    		   
sort mSdpFB1uEgpzM3bVmlHgT 	 
    	  
    		   
     
     
  _1524129789187101628.begin mjjfaXD3tH8warSj13sVr 	 
    	  
    		  ,_1524129789187101628.end mjjfaXD3tH8warSj13sVr 	 
, mbtzLVjzLgaxYxNNltfyM 	 
    	  
    		   
     
  mfF196cGKZ_LkBPN8ZWlr 	 mYcSgTugFLQcmWT7seaac 	 
    	  
    		   
     
     
 const _4118122444908280734 &_2654435866,const _4118122444908280734 &_2654435867 mxAXsCfNkscq4iQtE2AeY 	 
    	  
    		    mbqHQotWhg0sv6ViuZXc3 	 
    	return _2654435866._6116114700730085677.size mFAl4ldpf7o2gKLWQ4bfu 	 
    	  
    		   
     
     
 
   mzCa3iYOTZk3vOb9xFPuf 	 
    	  
    _2654435867._6116114700730085677.size mRAYh0ARHPOc62CfGHWWO 	 
    	  
    		   
  mwkk1d6uUiyaKys71tsUv 	 
    	  
    		   
 msxc6utIaOFXg4WI3vB0q 	 
  mVFG05ubhW6ia_rWdS_Tv 	 
 mwkk1d6uUiyaKys71tsUv 	 
    	  
    mR8MpflZg6lk1qLQLX9P9 	 
    	  
    		   
     
     
 
  _1524129789187101628 m_yMT4MKxrENTtLx5cA7n 	 
    	  
    		   
   
 mMGejH_coNc3kGxAdXVex 	 
    	  

 mFqi0ZIcB_YhZ2B8QBIQg 	 
    	  
    		   
     
     
 
 System me0ZKHp2Id3eLmP_6GMtk 	 
   _3570943890084999391 mOAy4qGUJpdHQSVbVPq9E 	 
    	  
    		   
     
 Frame &_16940374161494853219,se3 &_13011065492167565582 , const std mNQimRrYQ8Mz6YI9KM7Fn 	 
    	  
    		   
     
     
 
  	set miGVtxwiqbDQsG6KBslZU 	 
uint32_t mNF0G2xPBB22gI9XzMk2L 	 
    	  
    		   
     
     
 
 &_16997249117545452056  msDy4S0F6Zdx78ZUnbARe 	 
    	  
    		   
 mJdlQJg0rG2m7KHUChC3R 	 
     mEhFK99MtLRsCBaPNqnDs 	 
    	 _1524129789187101628 mR22jPCjbltZ3tbBmn_6w 	 
    	 _3473802998844434099 mUGrJMUolw0lb_KVyGK5N 	 
    	_16940374161494853219,_13011065492167565582,_16997249117545452056 muC5cqYcHRXDD16noARI1 	 
    	  
    		   
  mxIwd_EJpfr1C9jwU7IyL 	 
    	  
    		   
     
 
     mFVNERjMRO_ZEKm0TY73X 	 
    	  
    		   
   mOAy4qGUJpdHQSVbVPq9E 	 
    	  _1524129789187101628 mMo20fFU0rdQJ7l5qqDaX 	0 mOwAFTnFZjoBWI2gNeAO_ 	 
    	  
    		   
     
 ._6116114700730085677.size mIJkWACd8Uom4Jv6selID 	 
    	  
    		   
     mVIm1AJSzhahLlgKO9xQK 	 
    	  
    		   
     
     
 
30 msDy4S0F6Zdx78ZUnbARe 	 
 mSH1h4yGhaMSu8y7JC_rY 	 
    	  
    		   
 
        _13011065492167565582 moHeIYzwbcFb6VaM90Aa9 	 
    	  _1524129789187101628 mwzFZRcSPi2Vsk45HpaLx 	 
    	  
    		   
     
     
 
  0 mWjWwCxBA7LLBixCoRsYZ 	 
    	  
 ._3885067248075476027 mxIwd_EJpfr1C9jwU7IyL 	 
    	  
    		   
     
     
 
  	
        _16940374161494853219.ids mR22jPCjbltZ3tbBmn_6w 	 
    	  
    	_1524129789187101628 msGAdK1RZcxCitYemdpxc 	 
    	  
    		   
0 mWjWwCxBA7LLBixCoRsYZ 	 
    	  
    ._16902946305713852348 mQivdop_Gb4hqsWvOttc3 	 
   
         mV4_AbWY8ymaWGsYOk0LC 	 
    	  
    		   
     
     
 
  	true mwkk1d6uUiyaKys71tsUv 	 
    	  
    		
     mqVdZVftPR84WTjiOiVfT 	 
    	  
  
     mcCwozNc9ZEKnXkmsh9Fj 	 
    	  
    		   
     
 my5S_tF4_lSpButBKNitX 	 false mwkk1d6uUiyaKys71tsUv 	 
    	  
    		   
  
 msxc6utIaOFXg4WI3vB0q 	 
    	  
    		   

 mFqi0ZIcB_YhZ2B8QBIQg 	 
    	  
    System miuOs6oIdxnQEMrFFk2n_ 	_14569675007600066936 mbXhD242DJoibBjdI1JtA 	 
    	  
 Frame &_2654435871,se3 &_13011065492167565582  mVmWtYm5gVtZj7Yq19XWE 	 mSH1h4yGhaMSu8y7JC_rY 	 
    	  
    		   
     
 
      mFVNERjMRO_ZEKm0TY73X 	 
    	  
    		   
     
     
 
   mbXhD242DJoibBjdI1JtA 	 
    	  
    		   
   _2654435871.markers.size mFAl4ldpf7o2gKLWQ4bfu 	 
    	  
    		   
      mlEF62Izit24hGT_NqPIJ 	 
0 mVmWtYm5gVtZj7Yq19XWE 	 
    	  
    		   
     
     
 
  return false mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
    		   
     
    
    vector mnpObQ1mWnyfQO24_ojBn 	 
    	  
    		 uint32_t mYbzFOKSwwNsD71cP1DkA 	 
    	  
    		   
     
     
  _7895328205142007059 mC_gLvnw5tkMWRQheRKr5 	 

     mWIOGoR1XyrR6fw03i9px 	 
   mFTobXyS5Vx9ebVESwR0T 	 
    	  
    		   
     
     
 &_2654435878:_2654435871.markers mT3v8xdcVsSvUtbwmHC7j 	  mi4REkBAebpTZrzlvFEpD 	 
    	  
    		   
 
         mFTobXyS5Vx9ebVESwR0T 	 
    _8332348524113911167 mXE5wWRmJGUY4EsEsgegT 	 
    	  
    		   
     
  _9098980761384425343 mSwbK3nBcNZkvGxSXNOZy 	 
    	  
    		   
     
     
map_markers.find mbXhD242DJoibBjdI1JtA 	 
    	  
    		   
     
  _2654435878.id mJk4eXgp_IeFV2YvLaQC7 	 
    	  
    		   
     
     
 
 mC_gLvnw5tkMWRQheRKr5 	 
   
         mz0gDEk4XJJySbEeCgC9P 	 
    	  
    		_8332348524113911167 mS3P8ZWKrLHg9h_5dW5He 	 
 _9098980761384425343 mdMNbPkq6p5KBhEVf3OFw 	 
    	  
    		   
   map_markers.end mdbwYCIpGYWahFfTtU8zH 	 
    	  
    		   
     mVmWtYm5gVtZj7Yq19XWE 	 
    	  
    		   
     
             mbCI0BlZHp5kbKpNqa5Su 	 
    	  
    mlfybwyvp98TOJj0yuqhF 	 
    	  
    		   
     
      _8332348524113911167 msDVYCHuU_j2g_TdgX4Ta 	 
    	  
    		   
     
   second.pose_g2m.isValid mrXXIs5j4DqJtj32aOG5F 	 
    	  
    		   
     
     
 
  mSBNIRK1XqZg3XlWW_b3d 	 
    	  
  
                _7895328205142007059.push_back mlfybwyvp98TOJj0yuqhF 	 _2654435878.id muC5cqYcHRXDD16noARI1 	 
    	  
    		   
     
    mxIwd_EJpfr1C9jwU7IyL 	 
    	
     mf0YJDuh2j5By5N13LunG 	 
    	  
    		   
     
    
     mbCI0BlZHp5kbKpNqa5Su 	 
     mNQ6rNLARkxxSTP6tiTXG 	 
  _7895328205142007059.size mTGJXDnkacX2UX9dooHQu 	 
    	 mw_MIhwcw8TZ9gTF3_mEt 	 
 0 muC5cqYcHRXDD16noARI1 	 
    	  
    		   return false mC_gLvnw5tkMWRQheRKr5 	 
    	  
    		   
 
  _13011065492167565582 mA7hUM4UKqFyb_LJLsook 	 
    	  
    		   
     
      _9098980761384425343 mxGJXkzb8EW07jCVTl0Jt 	 
    	  
    getBestPoseFromValidMarkers mBGM118Iia8vm6zcNTuB6 	 
   _2654435871,_7895328205142007059,_14938569619851839146.aruco_minerrratio_valid mSBNIRK1XqZg3XlWW_b3d 	 
    	  
  mwkk1d6uUiyaKys71tsUv 	 
    	  
    		   
     
     
 
  	 
   mY5hSAdXT4P60CSAZFBBa 	 
    	  
    		   
    _13011065492167565582.isValid mdbwYCIpGYWahFfTtU8zH 	 
    	  mxIwd_EJpfr1C9jwU7IyL 	
 mf0YJDuh2j5By5N13LunG 	
  muh7SNXP3UdOZu6GOuG0_ 	 
    	  
    		   
     
     
 
  	 System mExFPeJBflhTWJKuQVWoB 	 
    	  
  _16487919888509808279 mYcSgTugFLQcmWT7seaac 	 
    	  
    		   
     
     
Frame &_2654435871, se3 &_13011065492167565582 mXftmBtLFUrPFw3lasjuW 	 
    	  
    		   
    mi4REkBAebpTZrzlvFEpD 	 
    	  
    		
    _13011065492167565582 mA7hUM4UKqFyb_LJLsook 	 
    	  
    		   
 se3 mGu_88Fdde5jsxW8v9whR 	 mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
    		   

     mhRH54odsmIWcLq1D3rKZ 	 
    	  _14938569619851839146.reLocalizationWithMarkers mSBNIRK1XqZg3XlWW_b3d 	 
    	  
    		   
     
  mSH1h4yGhaMSu8y7JC_rY 	 
    	  
    		   
     
    
         mFVNERjMRO_ZEKm0TY73X 	  mYcSgTugFLQcmWT7seaac 	 
    	  
    		   
     _14569675007600066936 mNQ6rNLARkxxSTP6tiTXG 	 
    	  
    		 _2654435871,_13011065492167565582 mSBNIRK1XqZg3XlWW_b3d 	 
    	  
    		   
      mVmWtYm5gVtZj7Yq19XWE 	 
    	  
    		   
     
    mHUTuX3q6rB5eWWYYPWQD 	 
    	  
    		   
    true mEm194VmPJuGh5y4tMUm5 	 
    	  
    		   
     
 
     msBPMso4NRYFcn5Y1myF_ 	 
    	  
    		   
     
     
 
  	 
     mGc5v1UWfDU7ttNcZryQG 	 
    	  
    		   
     
     
 
  	 _14938569619851839146.reLocalizationWithKeyPoints mXftmBtLFUrPFw3lasjuW 	 
 mJdlQJg0rG2m7KHUChC3R 	 
    	  
    		   
     
     

         mr8s7pfvTmBWmxher3Oue 	 
    	  
 mlfybwyvp98TOJj0yuqhF 	 
    	  
 _3570943890084999391 mgGCFceAojKPG0bK5eWQT 	 
    	  
    		   
     
     
_2654435871,_13011065492167565582 mPaUdMg3fg2ipZY0Exj7X 	 
    	  
    		   
     
     
 mVmWtYm5gVtZj7Yq19XWE 	 
    	  
    	  mUnahx7x8KWu62epS7OxV 	 
  true mC_gLvnw5tkMWRQheRKr5 	 
    	  
  
     msBPMso4NRYFcn5Y1myF_ 	 
    	
     mR8MpflZg6lk1qLQLX9P9 	 
    	  
    		   
   mUFRPXFmygxcJ82L2LC5t 	 
    	  
    		   
  mQivdop_Gb4hqsWvOttc3 	 
    	
 msBPMso4NRYFcn5Y1myF_ 	 
    	  
    		   
     
     
 
 


std mI3QeEk0K_mj1WaUiowht 	 
    	  
    		   
    vector mnpObQ1mWnyfQO24_ojBn 	cv mI3QeEk0K_mj1WaUiowht 	 
    	  
    		   
     
 DMatch mzCa3iYOTZk3vOb9xFPuf 	 
    	  
    		   
      System mNQimRrYQ8Mz6YI9KM7Fn 	 
    _11946837405316294395 mOAy4qGUJpdHQSVbVPq9E 	 
    	  
    	Frame & _16940374161810747371, Frame &_5918541169384278026,  mU7LO3jg27wf5nw3n8LF7 	 
    _1686565542397313973,  mrjcvI9ucBIaCRtqGyrWD 	 
    	_4500031049790251086 mVmWtYm5gVtZj7Yq19XWE 	 
    	  
    		   
     
     
 
  
 mSH1h4yGhaMSu8y7JC_rY 	 
    	  
    		   
     
    
    std mrPFLPKakBKjOOnkuhZUP 	 
    	  
    vector mkHL8KJw4VjwmGdgQrteX 	 
    	  
    		   
     
     cv me0ZKHp2Id3eLmP_6GMtk 	 
    DMatch mYbzFOKSwwNsD71cP1DkA 	 
    	  
 _6807036698572949990 mqLizGA4Z8QZ_2GYQ1inC 	 
    	  
    	
     mTy5S_mcphfNLzuJQ30Xe 	 
    	  
    		  size_t _2654435874 mhL9dWuOWzLGBfRjwvYlN 	 
    	  
    		   
0 mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
    		   
     
     
_2654435874 mnpObQ1mWnyfQO24_ojBn 	 
    _5918541169384278026.ids.size mecU92YjgSbB3VkEoZVK3 	 
    	  
    mqLizGA4Z8QZ_2GYQ1inC 	 
    	  
    		   
     
     
 
_2654435874 mUvBFztQfvp6FxGFsyoMW 	 
    	  
    		   
     
     
  mXftmBtLFUrPFw3lasjuW 	 
    	  
    		   
 muH9A34QGuccPZkZDb32w 	 
    	  
    		   
     
   
         mbdlGyMOiuL6kjlXvSqqd 	 
    	  
_11093822294347 mIqjSmilXv9ILvDddB7nD 	 
    	 _5918541169384278026.ids mstJEG25u0Qv4VQocWgKl 	 
    _2654435874 mQbYLzhvVQm8J2LNkC6S6 	 
    	  
    		   
     
    mxIwd_EJpfr1C9jwU7IyL 	 
    	  

         mHbSWrX6OPeRP2Igmog8G 	 
    	  
    		   
     
     
 
  	 mOAy4qGUJpdHQSVbVPq9E 	 
    	  
    		   
     
   _11093822294347 m_1_RZETM1QJ8vycOakwy 	 
    	  
    		  std mExFPeJBflhTWJKuQVWoB 	 
    	  numeric_limits mHg0YG9R0Gb6ZE5xIr3dz 	 
    	  
uint32_t mpBV2mt4yeFwcVEC5cxVw 	 
    	  
    		   
      mExFPeJBflhTWJKuQVWoB 	 
    	  
    		   
     
     
 
 max mJFtpHxfnoGMxp1wzTBMr 	 
    	  
   mXftmBtLFUrPFw3lasjuW 	 
  mSH1h4yGhaMSu8y7JC_rY 	 
    	  
    		   
     
 
             mdEGS_9gShKEEsK9RPbfj 	 
    	  
    		   
     
     _9098980761384425343 mtNKEvBwMHNsmdH7BtZbM 	 
    	  
    		   
     
     
 map_points.is mbXhD242DJoibBjdI1JtA 	 
    	  
    		  _11093822294347 mVmWtYm5gVtZj7Yq19XWE 	 
    	  
    		   
    mVFG05ubhW6ia_rWdS_Tv 	 
 mi4REkBAebpTZrzlvFEpD 	 
    	  
    		 
                MapPoint &_3005399799907669332 mXE5wWRmJGUY4EsEsgegT 	 
    	  
    		   
    _9098980761384425343 msDVYCHuU_j2g_TdgX4Ta 	 
    	  
    		   
     
     
map_points msGAdK1RZcxCitYemdpxc 	 
    	  
_11093822294347 mQbYLzhvVQm8J2LNkC6S6 	 
    	  
    		   
      mEm194VmPJuGh5y4tMUm5 	 
    	  
    		   
     
     
                 mbCI0BlZHp5kbKpNqa5Su 	 
    	  
    		   
     
     mNQ6rNLARkxxSTP6tiTXG 	 
    	  
    		_3005399799907669332.isBad mIJkWACd8Uom4Jv6selID 	 mVFG05ubhW6ia_rWdS_Tv 	 
    	  
    		   
      continue mqLizGA4Z8QZ_2GYQ1inC 	 
    	  
    		   
     
    
                 mBUCZuaNioFkzVtaa2sRQ 	 
    	  
    		   
     
     
 
_11093822300120 mhL9dWuOWzLGBfRjwvYlN 	_16940374161810747371.project mUGrJMUolw0lb_KVyGK5N 	 
  _3005399799907669332.getCoordinates mjjfaXD3tH8warSj13sVr 	 
    	  
    		   
  ,true,true mXftmBtLFUrPFw3lasjuW 	 
    	  
    		  m_yMT4MKxrENTtLx5cA7n 	 
    
                 muDvj5aUdXshb2AqqeEiu 	 
     mTiWUgQKOeYLvNdGsR_oS 	 isnan mbXhD242DJoibBjdI1JtA 	 
    	  
    		   
     
     
 
 _11093822300120.x muC5cqYcHRXDD16noARI1 	 
    	  
    		   
  mJk4eXgp_IeFV2YvLaQC7 	 
    	continue mQivdop_Gb4hqsWvOttc3 	 
    
                
                 mqI5yMr4h6CHkceANuA43 	 
    	  
    		   
     
     
 _175247759755 mR22jPCjbltZ3tbBmn_6w 	 
    	  
    		   
_16940374161810747371.scaleFactors mZloAr3_PPw7622AVrUCe 	 
    	  
   _5918541169384278026.und_kpts mZloAr3_PPw7622AVrUCe 	 
    	  
    		   
     
     
 
  	_2654435874 mWjWwCxBA7LLBixCoRsYZ 	 
    	  
    		   
     
     
 
  	.octave mAH84ftHkJMUldxM9fJHE 	 
    	  
    myu64GAT8DgGBhNOOCqvd 	 
    	  
    		   
 
                 mpgczyJuWNGXMBOxeP5oe 	 
   _3005399801676750422 mvA2vjSvRD7UmknjmYP5U 	 
    	  
    		   
     
   _5918541169384278026.und_kpts mMo20fFU0rdQJ7l5qqDaX 	 _2654435874 mWjWwCxBA7LLBixCoRsYZ 	 
    	  
    		   
     
     
.octave myu64GAT8DgGBhNOOCqvd 	 
    	  
                std mMorzi7AHv5qXgdOZzcMd 	 
    	  
    	vector mk9nSfh6XGyonOYMC8C3M 	 
    	 uint32_t mpBV2mt4yeFwcVEC5cxVw 	 
    	  
    		   
     _10924592426265627429 mXE5wWRmJGUY4EsEsgegT 	 
    	  
    		   
     
     _16940374161810747371.getKeyPointsInRegion mgGCFceAojKPG0bK5eWQT 	 
    	  
    		   
     
     
_11093822300120,_4500031049790251086*_175247759755,_3005399801676750422,_3005399801676750422 mT3v8xdcVsSvUtbwmHC7j 	 
    	  
    		   
    mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
    		   
     
     
 
  
                 mrg1QVINMqbRYZWngNWmj 	 
    	  
    		_16940367568811467085 mhL9dWuOWzLGBfRjwvYlN 	 
    	  
    		   
     
     
 _1686565542397313973+0.01,_16992066385107317811 moHeIYzwbcFb6VaM90Aa9 	 
    	  
    		   
     
     
std mNQimRrYQ8Mz6YI9KM7Fn 	 
    	  
 numeric_limits mkHL8KJw4VjwmGdgQrteX 	 
    	  
    float mYbzFOKSwwNsD71cP1DkA 	 
    	  
    		   
   mrPFLPKakBKjOOnkuhZUP 	 
    	max mjjfaXD3tH8warSj13sVr 	 
    	  
    		   
     
     
 mC_gLvnw5tkMWRQheRKr5 	 
    	  
    		   
     
     
 
 
                 mumKmtKc8SEEXbYxYxnDh 	 
    	  
    _6806984971934960832 moHeIYzwbcFb6VaM90Aa9 	 
    	 std mNQimRrYQ8Mz6YI9KM7Fn 	 
 numeric_limits miGVtxwiqbDQsG6KBslZU 	 
    	  
    		   uint32_t mNF0G2xPBB22gI9XzMk2L 	 
    	  
    		   
     
     
 
  	 miuOs6oIdxnQEMrFFk2n_ 	 
    	  
    		   
     
 max mrXXIs5j4DqJtj32aOG5F 	 
    	  
    		   
     
     
 
  	 mI30mSPxGJaQtkEjJfoQX 	 
    	  
    		   
     
    
                
                 mozBzR4ceXlDTd_eA9UWj 	 
    	  
    		   
     
auto _175247760278:_10924592426265627429 mPaUdMg3fg2ipZY0Exj7X 	 
    	  
    		  mbqHQotWhg0sv6ViuZXc3 	 
  
                     mHbSWrX6OPeRP2Igmog8G 	 
    	  
    		   
 mlfybwyvp98TOJj0yuqhF 	 
    	  
    		    _16940374161810747371.und_kpts mRjEKX4QN9MTvSEtCTNd7 	 
    	   _175247760278 mGPgWaVxS3WdTr7rWsMw4 	 
    	  .octave  mVrsJpNNblNXrk9CJ_J45 	 
    	   _5918541169384278026.und_kpts mbtzLVjzLgaxYxNNltfyM 	 
    	  
    		  _2654435874 mWjWwCxBA7LLBixCoRsYZ 	 
    	  
    		   
     
.octave  mPaUdMg3fg2ipZY0Exj7X 	 
    	  mJdlQJg0rG2m7KHUChC3R 	 
    	  
    		   
     
     
 
  
                         mqI5yMr4h6CHkceANuA43 	 
    	  
    		   _16940392174182767813 mIqjSmilXv9ILvDddB7nD 	 
    	  
    		   
  MapPoint mNQimRrYQ8Mz6YI9KM7Fn 	 
 getDescDistance mTiWUgQKOeYLvNdGsR_oS 	 
    	  
    		   
   _5918541169384278026.desc,_2654435874, _16940374161810747371.desc,_175247760278 mVFG05ubhW6ia_rWdS_Tv 	 
    	  
    		   
     
   mC_gLvnw5tkMWRQheRKr5 	 
    	  
    		   
     
     
 
 
                         mbCI0BlZHp5kbKpNqa5Su 	 
    	  
    		   
     
 mTiWUgQKOeYLvNdGsR_oS 	 
    	  
    		   
    _16940392174182767813 mHg0YG9R0Gb6ZE5xIr3dz 	 
    	  
    		   
 _16940367568811467085 mSBNIRK1XqZg3XlWW_b3d 	 
    	  
    		   
   mXdnll4yjwVy4uBDSjUe3 	 
    	  
    		   
   
                            _16940367568811467085 mH9fKsRtHWNu77RGN1xmn 	 
    	  
    		   
 _16940392174182767813 m_yMT4MKxrENTtLx5cA7n 	 
    	
                            _6806984971934960832 mIqjSmilXv9ILvDddB7nD 	 
    	  
    		   
     
     
 
  	 _175247760278 mxIwd_EJpfr1C9jwU7IyL 	 
    	 
                         mqVdZVftPR84WTjiOiVfT 	 
    	  
    		  
                         mEYy4vDSh1urfYj6Y0xAX 	 
    	  
 mHbSWrX6OPeRP2Igmog8G 	  mUGrJMUolw0lb_KVyGK5N 	_16940392174182767813 mnpObQ1mWnyfQO24_ojBn 	 
    	  
    		   
     
     
 
_16992066385107317811 mVmWtYm5gVtZj7Yq19XWE 	  mMm9FLNsNOoyX7Tyb7vpT 	 
    	  
    		   
                            _16992066385107317811 mIqjSmilXv9ILvDddB7nD 	 
    	  
    		   
     
     
 
  	 _16940392174182767813 mEm194VmPJuGh5y4tMUm5 	 
    	  
    		   
     
 
                         mwiKr6psttEx97f2NsYO1 	 
                     miXz43zs_DqtraKQW0m3N 	 
    	  
    		   
     
 
                 mMGejH_coNc3kGxAdXVex 	 
    	  
    		   
     
                
                 mt3m0c1_35lMMq0E3cZsZ 	 
    	   mOAy4qGUJpdHQSVbVPq9E 	 
    	  
    		   
  _6806984971934960832 mS3P8ZWKrLHg9h_5dW5He 	 
    	  
    		   
     
     
 
  	 std mI3QeEk0K_mj1WaUiowht 	 
    	  
    		   numeric_limits mHg0YG9R0Gb6ZE5xIr3dz 	 
    	  
    		   
     
uint32_t mKJK3THIuAwgeFpuGLN8L 	 
    	  
    		   
     
     
 
  	  me0ZKHp2Id3eLmP_6GMtk 	 
    	  
    		   
     
     
 max mjjfaXD3tH8warSj13sVr 	 
    	  
   mLdCPhlCq1uVgMtM4YkSz 	 
   _16940367568811467085 mRwYPGmWUou3ixNnKEWbv 	 
    0.7*_16992066385107317811 msDy4S0F6Zdx78ZUnbARe 	 
    	  
    	 mi6BqZOVmQyrEy6BLProP 	 
    	 
                    cv mrPFLPKakBKjOOnkuhZUP 	 
    	  
    		   
  DMatch _175247759376 mQivdop_Gb4hqsWvOttc3 	 
    	  
    		   
     
 
                    _175247759376.queryIdx  mXE5wWRmJGUY4EsEsgegT 	 
    	  
    		  _6806984971934960832 mo9Lbpy0Ap4RTl5O5Or1C 	 
   
                    _175247759376.trainIdx  mRDD8w83SsPKbGXy_JkEO 	   _3005399799907669332.id mqLizGA4Z8QZ_2GYQ1inC 	 
    	  
    		   
     
     
 
          
                    _175247759376.distance  mIqjSmilXv9ILvDddB7nD 	 
    	  
    		   
  _16940367568811467085 mxIwd_EJpfr1C9jwU7IyL 	 
    	  
    		   
   
                    _6807036698572949990.push_back mlfybwyvp98TOJj0yuqhF 	 
    	  
   _175247759376  msDy4S0F6Zdx78ZUnbARe 	 
    	  
    		   
     
     
 mQivdop_Gb4hqsWvOttc3 	 
    	 
                 msxc6utIaOFXg4WI3vB0q 	 
    	  

             msxc6utIaOFXg4WI3vB0q 	 
    	  
    
         msBPMso4NRYFcn5Y1myF_ 	 
    	  
    
     msBPMso4NRYFcn5Y1myF_ 	 
    	  
    		   
     
     

    filter_ambiguous_query mNQ6rNLARkxxSTP6tiTXG 	 
    	  
    		   
 _6807036698572949990 mVFG05ubhW6ia_rWdS_Tv 	 
    	  
    		  mxIwd_EJpfr1C9jwU7IyL 	 
    	  

     mHUTuX3q6rB5eWWYYPWQD 	 
  _6807036698572949990 mqLizGA4Z8QZ_2GYQ1inC 	 
    	  
    		   
 m_ECAXF5hGu1UMoS2l1KU 	 
    	  


se3 System mvpMkjoDGcQujDevHDZnx 	 
    	  
    		   
     
     
 
  	 _11166622111371682966 mbXhD242DJoibBjdI1JtA 	Frame &_16940374161810747371,se3 _14387478432460351890 mPaUdMg3fg2ipZY0Exj7X 	 
    	  
    		   
     
   mSH1h4yGhaMSu8y7JC_rY 	 
    	  
    		   
     
   
        
    std mwuvkepREHprpx4i3n2RV 	 
    	  
    vector miGVtxwiqbDQsG6KBslZU 	 
    	  
    		   
     
 cv mI3QeEk0K_mj1WaUiowht 	 
    	  
    		   
     DMatch mJJosB3DZCYh837sWRpN7 	 
    	   _637068542992099399 mI30mSPxGJaQtkEjJfoQX 	 
    	  
    		   
     
     
 
 
    se3 _5769551021164122736 mA7hUM4UKqFyb_LJLsook 	 
    	  
    		   
     
     
 
  	_14387478432460351890 myu64GAT8DgGBhNOOCqvd 	 
    	  
    		   
     
       
    
      mHbSWrX6OPeRP2Igmog8G 	 
   mTiWUgQKOeYLvNdGsR_oS 	 
 _9098980761384425343 mj3rSXJDWd4j4OSGbS2oX 	 
    	  
    		   
     
     
 
map_points.size mIJkWACd8Uom4Jv6selID 	 
   mzCa3iYOTZk3vOb9xFPuf 	 
    	  
    	0 msDy4S0F6Zdx78ZUnbARe 	  mSH1h4yGhaMSu8y7JC_rY 	 
    	  
    		   
 
          mr8s7pfvTmBWmxher3Oue 	 
    	  
    		   
     
     
 
   mYcSgTugFLQcmWT7seaac 	 
    	  
    		   
     
     
 
  	 mQIaw42evZrZGmIhV_U05 	 
_14463320619150402643.empty mGu_88Fdde5jsxW8v9whR 	 
    	  
    		   
  mVmWtYm5gVtZj7Yq19XWE 	 
    	  
    		   
     
   
             _5769551021164122736 mIqjSmilXv9ILvDddB7nD 	 
    	  
    		   
     
     
_14463320619150402643*_5769551021164122736.convert mTGJXDnkacX2UX9dooHQu 	 
    	  
    		 mI30mSPxGJaQtkEjJfoQX 	 
   
        _16940374161810747371.pose_f2g moHeIYzwbcFb6VaM90Aa9 	 
    	  
    		   _5769551021164122736 m_yMT4MKxrENTtLx5cA7n 	 
    	 
        
        _637068542992099399 mIqjSmilXv9ILvDddB7nD 	 
    	  
    		   
     
     
 _11946837405316294395 mUGrJMUolw0lb_KVyGK5N 	 
 _16940374161810747371,_4913157516830781457,_14938569619851839146.maxDescDistance*1.5,_14938569619851839146.projDistThr mJk4eXgp_IeFV2YvLaQC7 	 
    	  
    		   
     
     
 
   mEm194VmPJuGh5y4tMUm5 	 
    	  
    		   
     
     
         mL8NdxI0A84_PQiCzjY0y 	 
    	  
    		   
   _9870110657242862171 mRDD8w83SsPKbGXy_JkEO 	 
    	  
    		   
     
     0 m_yMT4MKxrENTtLx5cA7n 	 
    
         mXYEIB3KYwzJOpssgkZxP 	 
    	  
    		   
      mOAy4qGUJpdHQSVbVPq9E 	 
    	  
    		   
     
_637068542992099399.size mJFtpHxfnoGMxp1wzTBMr 	 
    	  
    	 mYbzFOKSwwNsD71cP1DkA 	 
  30   msDy4S0F6Zdx78ZUnbARe 	 
    	  
    		   
     
   mJdlQJg0rG2m7KHUChC3R 	 
    	  
             mEhFK99MtLRsCBaPNqnDs 	 
    	  
    		   
     
     
 
 _14671559813105454070 mRDD8w83SsPKbGXy_JkEO 	 
_5769551021164122736 mI30mSPxGJaQtkEjJfoQX 	 
    	  
    		   
     
     
 
 
            _9870110657242862171 moHeIYzwbcFb6VaM90Aa9 	 
    	  
    		   
     
     
 
 PnPSolver mI3QeEk0K_mj1WaUiowht 	 
    	  
    		   
     
     
 solvePnp mNQ6rNLARkxxSTP6tiTXG 	 
    	  
    		   
     
      _16940374161810747371,_9098980761384425343,_637068542992099399,_14671559813105454070,_10576739190144361304 mVmWtYm5gVtZj7Yq19XWE 	 
    	  
    		   
     
      mxIwd_EJpfr1C9jwU7IyL 	 
    	  
    		   
    
             mbCI0BlZHp5kbKpNqa5Su 	 
    	  
    		   
 mTiWUgQKOeYLvNdGsR_oS 	 
    	  
    		   
_9870110657242862171 mzCa3iYOTZk3vOb9xFPuf 	 
    	  
    	30 mVmWtYm5gVtZj7Yq19XWE 	 
    	  
    		   
     
     
 
  _5769551021164122736 mvA2vjSvRD7UmknjmYP5U 	 
    	  
    _14671559813105454070 m_yMT4MKxrENTtLx5cA7n 	 
    	
         mEjIWbivPeVc9WtxGDiWw 	 
    	  
    	
        else mMm9FLNsNOoyX7Tyb7vpT 	 
    	  
    		   
     
            
            FrameMatcher _16997326787393468537 mBGM118Iia8vm6zcNTuB6 	 
    	  
    		   
 FrameMatcher mrS2zvlmrTf4L4KBRRYAU 	 
    	  
    		   
   TYPE_FLANN mVFG05ubhW6ia_rWdS_Tv 	 
    	  mo9Lbpy0Ap4RTl5O5Or1C 	 
 
            _16997326787393468537.setParams mTiWUgQKOeYLvNdGsR_oS 	 _9098980761384425343 mevHkLo7kL5WL0_0mLIhr 	 
    	  
    		   
     
     keyframes mZ9T0z5VdOHGC7rra8Fzk 	 
    	  
    		_10576739190144361304 mvFhi6DaS7eScbgWe07wY 	 ,FrameMatcher mrPFLPKakBKjOOnkuhZUP 	 
    	  
    		   
  MODE_ASSIGNED,_14938569619851839146.maxDescDistance*2,0.6,true,3 mVmWtYm5gVtZj7Yq19XWE 	 
  m_yMT4MKxrENTtLx5cA7n 	 
    	  
    		   
     
     

            _637068542992099399 mtmFAz7pcnIFLgYGMf4eK 	 
    	  
    		   
     
     _16997326787393468537.match mUGrJMUolw0lb_KVyGK5N 	 
    	  
    		_16940374161810747371,FrameMatcher miuOs6oIdxnQEMrFFk2n_ 	 
    	  
    		   
     MODE_ALL mT3v8xdcVsSvUtbwmHC7j 	 
    	  
    		   
     
  m_yMT4MKxrENTtLx5cA7n 	 
    	  
    	
             mz0gDEk4XJJySbEeCgC9P 	 
    	  
    		   
    _637068542992099399.size mGu_88Fdde5jsxW8v9whR 	 
    	  
    		    mpBV2mt4yeFwcVEC5cxVw 	 
    	  
 30 mXftmBtLFUrPFw3lasjuW 	 
   mi4REkBAebpTZrzlvFEpD 	 
   
                
                 mTy5S_mcphfNLzuJQ30Xe 	 
    	  
    		   
     
     
auto &_2654435878:_637068542992099399 mJk4eXgp_IeFV2YvLaQC7 	 
    	
                    _2654435878.trainIdx mR22jPCjbltZ3tbBmn_6w 	 
    	  
    		   
     
     
 
  	 _9098980761384425343 mevHkLo7kL5WL0_0mLIhr 	 
    	  
    		   
     keyframes mwzFZRcSPi2Vsk45HpaLx 	 
    	  
    		   
     
 _10576739190144361304 mfF196cGKZ_LkBPN8ZWlr 	 
    	  
    .ids mZloAr3_PPw7622AVrUCe 	_2654435878.trainIdx mtEI4bSjtkyV5O0qz_vBz 	 
    	  
    		   
     mI30mSPxGJaQtkEjJfoQX 	 
    	  
  
                 mFTobXyS5Vx9ebVESwR0T 	 
    	  
  _14671559813105454070 mH9fKsRtHWNu77RGN1xmn 	 
    	  
    		   
     
    _5769551021164122736 mEm194VmPJuGh5y4tMUm5 	 
    	  
    		   
     
     
 
  	 
                _9870110657242862171 mA7hUM4UKqFyb_LJLsook 	 
    	  
    		 PnPSolver miuOs6oIdxnQEMrFFk2n_ 	 
    	  
    		   
solvePnp mNQ6rNLARkxxSTP6tiTXG 	 
    	  
    		   
      _16940374161810747371,_9098980761384425343,_637068542992099399,_14671559813105454070,_10576739190144361304 mPaUdMg3fg2ipZY0Exj7X 	 
    	  
    		   
     
  mQivdop_Gb4hqsWvOttc3 	
                 mFVNERjMRO_ZEKm0TY73X 	 
    	  
    		   
     
     
 
   mBGM118Iia8vm6zcNTuB6 	 
    	  
    		   
 _9870110657242862171 mzCa3iYOTZk3vOb9xFPuf 	 
 30 mXftmBtLFUrPFw3lasjuW 	 
    	  
    		   
     
  _5769551021164122736 mA7hUM4UKqFyb_LJLsook 	 
    	  
    		_14671559813105454070 mC_gLvnw5tkMWRQheRKr5 	 
    	  
             mEjIWbivPeVc9WtxGDiWw 	 
    	  
  
             meoTw_X4Xqh45MaL_F2D7 	 
    	  
    		   
     
   _9870110657242862171 mRDD8w83SsPKbGXy_JkEO 	 
  0 m_yMT4MKxrENTtLx5cA7n 	
         mL9oWJQ1n2xKG3FtRNowa 	 
    	  
    	
         mRIlZ0NriRkVMhRpycZqI 	_3763415994652820314 myu64GAT8DgGBhNOOCqvd 	 
         mbCI0BlZHp5kbKpNqa5Su 	 
    	  
    		   
     
   mBGM118Iia8vm6zcNTuB6 	 
    	  
    		   
     
     _9870110657242862171 mpBV2mt4yeFwcVEC5cxVw 	 
    	  
    		   
     
    30 mVmWtYm5gVtZj7Yq19XWE 	 
    	  
    		   
     
     mbqHQotWhg0sv6ViuZXc3 	
            _3763415994652820314 moHeIYzwbcFb6VaM90Aa9 	 
    	  
    		4 mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
    		
             mcAnVuQmAnGunjGyL6dhh 	 
    	  
    		   
     
    auto _2654435878:  _637068542992099399  mXftmBtLFUrPFw3lasjuW 	 
    	  
    		   
     
     
  mbqHQotWhg0sv6ViuZXc3 	 

                _9098980761384425343 mtNKEvBwMHNsmdH7BtZbM 	 
    map_points mstJEG25u0Qv4VQocWgKl 	 
 _2654435878.trainIdx mOwAFTnFZjoBWI2gNeAO_ 	 
    	  
    		   
     
     
 
  .lastFIdxSeen mR22jPCjbltZ3tbBmn_6w 	 
    	  
    		   
     
    _16940374161810747371.fseq_idx mxIwd_EJpfr1C9jwU7IyL 	 
                _9098980761384425343 mxGJXkzb8EW07jCVTl0Jt 	 
    	  
    		   
     
     
 
 map_points mbtzLVjzLgaxYxNNltfyM 	 
    	  
    		  _2654435878.trainIdx mfF196cGKZ_LkBPN8ZWlr 	 
  .setVisible mIJkWACd8Uom4Jv6selID 	 
    	  myu64GAT8DgGBhNOOCqvd 	 
    	  
    		   
     
    
             miXz43zs_DqtraKQW0m3N 	 
    	  
  
         msxc6utIaOFXg4WI3vB0q 	 
    	  
    		   
     
   
        else mXdnll4yjwVy4uBDSjUe3 	 
    	  
    		   
     
     
 

            _637068542992099399.clear mdbwYCIpGYWahFfTtU8zH 	  mEm194VmPJuGh5y4tMUm5 	 
    	  

            _3763415994652820314 moHeIYzwbcFb6VaM90Aa9 	 
   _14938569619851839146.projDistThr mxIwd_EJpfr1C9jwU7IyL 	 
  
         mL9oWJQ1n2xKG3FtRNowa 	 
    	  
    		   
     
        
         mBUCZuaNioFkzVtaa2sRQ 	 _3521005873836563963  mH9fKsRtHWNu77RGN1xmn 	 
    	  
    		   
   _9098980761384425343 mVfb3IHZLk8rmg75VuqQZ 	 
    	  
    		   
     
     
 
  	 matchFrameToMapPoints  mbXhD242DJoibBjdI1JtA 	 
    	 _9098980761384425343 mtNKEvBwMHNsmdH7BtZbM 	 
    	  
    		   
     
     TheKpGraph.getNeighborsVLevel2 mSdpFB1uEgpzM3bVmlHgT 	 
    	  
    		   
     
      _10576739190144361304,true mXftmBtLFUrPFw3lasjuW 	 
    	  
    		   
     
  , _16940374161810747371,  _5769551021164122736 ,_14938569619851839146.maxDescDistance*2, _3763415994652820314,true mXftmBtLFUrPFw3lasjuW 	 
    	  mo9Lbpy0Ap4RTl5O5Or1C 	
        
        _637068542992099399.insert mUGrJMUolw0lb_KVyGK5N 	 
    	 _637068542992099399.end mIJkWACd8Uom4Jv6selID 	 
    	  
    		   
     
 ,_3521005873836563963.begin mJFtpHxfnoGMxp1wzTBMr 	 
    	  
    		   
     
 ,_3521005873836563963.end mrXXIs5j4DqJtj32aOG5F 	 
    	  
    		 mXftmBtLFUrPFw3lasjuW 	 
    	  
    		   
     
 mwkk1d6uUiyaKys71tsUv 	 
    	  
 
        filter_ambiguous_query mgGCFceAojKPG0bK5eWQT 	 
    	  
    		   
     
     
 
 _637068542992099399 msDy4S0F6Zdx78ZUnbARe 	 
    	  
    		   
     
     
 m_yMT4MKxrENTtLx5cA7n 	 
    	  
    		 
     m_ECAXF5hGu1UMoS2l1KU 	 
      mpgczyJuWNGXMBOxeP5oe 	 
    	  _8650310500205049352 mIqjSmilXv9ILvDddB7nD 	 
    	  
    		   
PnPSolver miuOs6oIdxnQEMrFFk2n_ 	 
    	  
    		   
     
     solvePnp mgGCFceAojKPG0bK5eWQT 	 
    	   _16940374161810747371,_9098980761384425343,_637068542992099399,_5769551021164122736,_10576739190144361304 mJk4eXgp_IeFV2YvLaQC7 	 
    	  
     mwkk1d6uUiyaKys71tsUv 	 
  
    
    
     mK81mHSyZucxh8c_K9rnU 	 
    	  
    		   
     
  _6535949166237672095 mXE5wWRmJGUY4EsEsgegT 	 
    	  
    		   
     
    false mqLizGA4Z8QZ_2GYQ1inC 	 
    	  
    		   
   
     mWYYMqZtRPklZ6ldYQlW8 	 
    	  
     mNQ6rNLARkxxSTP6tiTXG 	 
    	  
    		   
     
     
 _16940374161810747371.markers.size mecU92YjgSbB3VkEoZVK3 	 
    	  
    		   
     
     
  mNF0G2xPBB22gI9XzMk2L 	 
    0 mXftmBtLFUrPFw3lasjuW 	 
    	  
    		   
 mJdlQJg0rG2m7KHUChC3R 	 
    	  
  
         mr0Gwya5kzUd694oxNDs4 	 _9870110666330890270 mhL9dWuOWzLGBfRjwvYlN 	 
    	  0 myu64GAT8DgGBhNOOCqvd 	 
    	  
    		   
     

        
         mcAnVuQmAnGunjGyL6dhh 	 size_t  _2654435874 mvA2vjSvRD7UmknjmYP5U 	 
    	  
    		  0 mQivdop_Gb4hqsWvOttc3 	 
    	  
    	_2654435874 mk9nSfh6XGyonOYMC8C3M 	 
   _16940374161810747371.markers.size mTGJXDnkacX2UX9dooHQu 	 
    	  
    	 m_yMT4MKxrENTtLx5cA7n 	 
    	  
    		   
     
   _2654435874 mdN8xdqycKdYT96rU4KUK 	 
    	  
    		   
   mVFG05ubhW6ia_rWdS_Tv 	 
    	  
    		   
     muH9A34QGuccPZkZDb32w 	 
   
            
             mcRuULuI_AYJWzFSu1kB4 	 
    	  
    		   
     
     
_11093822290813 mXE5wWRmJGUY4EsEsgegT 	_9098980761384425343 mSwbK3nBcNZkvGxSXNOZy 	 
    map_markers.find mUGrJMUolw0lb_KVyGK5N 	 
    	  
    		   
 _16940374161810747371.markers mVjuVop3osym9wWoq6p3w 	 
    	  
    		   
     
   _2654435874 mAH84ftHkJMUldxM9fJHE 	 
    	  
    .id msDy4S0F6Zdx78ZUnbARe 	 
    	  
    		  mwkk1d6uUiyaKys71tsUv 	 
    	  
    		   
   
             mg9IHDbTXxljO0nSnQKYh 	 
    	_11093822290813 mtDWQOqRguVWSWehbKECr 	 
  _9098980761384425343 msDVYCHuU_j2g_TdgX4Ta 	map_markers.end mGu_88Fdde5jsxW8v9whR 	 
    	  
    		   
     
     mXftmBtLFUrPFw3lasjuW 	 
    	  
    		   continue mwkk1d6uUiyaKys71tsUv 	 
    	  
 
             muDvj5aUdXshb2AqqeEiu 	 
    	  
    		  mYcSgTugFLQcmWT7seaac 	 
    	  
    		   
     
     
 
  	  mc2SFiyFAyMaXElAGl89t 	 
    	  
    		   
   _11093822290813 mxGJXkzb8EW07jCVTl0Jt 	 
    	 second.pose_g2m.isValid mIJkWACd8Uom4Jv6selID 	 
    	  
    		   
     muC5cqYcHRXDD16noARI1 	 
    	  
    		 continue mI30mSPxGJaQtkEjJfoQX 	 
    	  
    
            _9870110666330890270 mY6fIyAOJfhz5nUdrWiVY 	  myu64GAT8DgGBhNOOCqvd 	 
    
            
             muDvj5aUdXshb2AqqeEiu 	 
    	  
    		   
     
     
 mgGCFceAojKPG0bK5eWQT 	_16940374161810747371.markers mVjuVop3osym9wWoq6p3w 	 
    	  
    		   
     
     _2654435874 mQbYLzhvVQm8J2LNkC6S6 	 
    	  
   .poses.err_ratio  mHg0YG9R0Gb6ZE5xIr3dz 	 
    _14938569619851839146.aruco_minerrratio_valid mPaUdMg3fg2ipZY0Exj7X 	 
    	  
    		   
      continue myu64GAT8DgGBhNOOCqvd 	 
    	  
    		   
 
            _6535949166237672095 mtmFAz7pcnIFLgYGMf4eK 	 
    	  
    		   
     
   true mI30mSPxGJaQtkEjJfoQX 	 
    	  
    		   
     
     
 

            break mqLizGA4Z8QZ_2GYQ1inC 	 
    	  
    		   
     
     
         miXz43zs_DqtraKQW0m3N 	 
    	  

         mr8s7pfvTmBWmxher3Oue 	 
   mBGM118Iia8vm6zcNTuB6 	 
    	 _9870110666330890270 mNF0G2xPBB22gI9XzMk2L 	 
    	  
    		   
     
 1 mPaUdMg3fg2ipZY0Exj7X 	 
    	  
    		   
     
     _6535949166237672095 mRDD8w83SsPKbGXy_JkEO 	 
    	  
    		  true m_yMT4MKxrENTtLx5cA7n 	 
    	  
    		   
  
     msxc6utIaOFXg4WI3vB0q 	 
    	  
    		   
     
   
     mXYEIB3KYwzJOpssgkZxP 	 
    	  
    		   
 mTiWUgQKOeYLvNdGsR_oS 	 
    	  _8650310500205049352 mk9nSfh6XGyonOYMC8C3M 	 
    	  
    		   
     
     30  mfLSKCXSc1DHeN38jALNR 	 
    	   mW0689NsIXj0x_tZl_0ut 	 
    	  
    		   
  _6535949166237672095 mxAXsCfNkscq4iQtE2AeY 	 
    	  
    		   
     
    mSH1h4yGhaMSu8y7JC_rY 	 
    	  
    		  
      mR8MpflZg6lk1qLQLX9P9 	 
    	  
    		   
   se3 mecU92YjgSbB3VkEoZVK3 	 
    	  
    		   
     
     
 
  mQivdop_Gb4hqsWvOttc3 	 
    	  
    		   
     
   
     mEjIWbivPeVc9WtxGDiWw 	 
    	  
    		   
     
     

    
     maE84VqXoUUX_dnxUsfES 	 
    	  
    		   size_t _2654435874 mvA2vjSvRD7UmknjmYP5U 	 
    	  
    		0 myu64GAT8DgGBhNOOCqvd 	 
    	  
    		   
     
     
 
  	 _2654435874 moCEmVQeGy8LzV8cAuk79 	 
 _637068542992099399.size mecU92YjgSbB3VkEoZVK3 	 
    	 mqLizGA4Z8QZ_2GYQ1inC 	 
    	  
    		   
     
     
 
  	_2654435874 mtIfgwpprqjFMhHY9FVrL 	 
    	  
    		  mxAXsCfNkscq4iQtE2AeY 	 
    	  
    		   
 mjXlfKOCTRjUV9apwYcb7 	 
    	  
    		   
     
    
            _9098980761384425343 mdMNbPkq6p5KBhEVf3OFw 	 
    	  
    		   
     
     
map_points mVLLVWqNz0_lGN56vY03t 	 
    	  
    		   
     
   _637068542992099399 mVjuVop3osym9wWoq6p3w 	 
    	  
    		   
_2654435874 mvFhi6DaS7eScbgWe07wY 	 
    	  
   .trainIdx ml5d8mzmxNmQRMtpfZ82X 	 
    	  
    		   
     
     .setSeen mdbwYCIpGYWahFfTtU8zH 	 
    	  
  mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
    
            _16940374161810747371.ids msGAdK1RZcxCitYemdpxc 	 
    	  
    		   
     
     _637068542992099399 mZloAr3_PPw7622AVrUCe 	_2654435874 mtEI4bSjtkyV5O0qz_vBz 	 
    	  
    		   .queryIdx mWjWwCxBA7LLBixCoRsYZ 	 
    	  
    		   
    mRDD8w83SsPKbGXy_JkEO 	 
    	  
   _637068542992099399 mbtzLVjzLgaxYxNNltfyM 	 
    	  
    		   
  _2654435874 mfF196cGKZ_LkBPN8ZWlr 	 
    	  
    		   
     
     
 
  	 .trainIdx mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
    		   
     
  
             mr8s7pfvTmBWmxher3Oue 	 
    	  
    		   
     
     
 
   mSdpFB1uEgpzM3bVmlHgT 	 
    	  
    		   
     
    _637068542992099399 mVjuVop3osym9wWoq6p3w 	 
    	  
    		   
     
     
 
  	_2654435874 mtEI4bSjtkyV5O0qz_vBz 	 
    	  
    		   
 .imgIdx mVrsJpNNblNXrk9CJ_J45 	 
    	  
   -1 mT3v8xdcVsSvUtbwmHC7j 	 
    	  
    		   
     
    
                _16940374161810747371.flags mRjEKX4QN9MTvSEtCTNd7 	 
 _637068542992099399 mVLLVWqNz0_lGN56vY03t 	_2654435874 mtEI4bSjtkyV5O0qz_vBz 	 
    	  
    		   
     
    .queryIdx mfF196cGKZ_LkBPN8ZWlr 	 
    	  
.set mSdpFB1uEgpzM3bVmlHgT 	 
    	  
    		   
     
  Frame miuOs6oIdxnQEMrFFk2n_ 	 
    	  
    		   FLAG_OUTLIER,true muC5cqYcHRXDD16noARI1 	 
    	  
    		   
     
     
 
  mI30mSPxGJaQtkEjJfoQX 	 
    	  
    		   
 
     mMGejH_coNc3kGxAdXVex 	 
     mIaPM1ms991SDrw4x6KTt 	 
    	  
 _5769551021164122736 mQivdop_Gb4hqsWvOttc3 	 
  
 mL9oWJQ1n2xKG3FtRNowa 	 
    	  
   
 mlwxuKRzwZKw4d0ABP68H 	 
    	  
 System mI3QeEk0K_mj1WaUiowht 	 
    	  
    		  _14031550457846423181 mbXhD242DJoibBjdI1JtA 	 
    	  
    		   
     
      cv mNQimRrYQ8Mz6YI9KM7Fn 	 
    	  
    		   
    Mat &_46082544231248938, mqI5yMr4h6CHkceANuA43 	 
    	  
    		   
     
     
 
  	 _9971115036363993554 mXftmBtLFUrPFw3lasjuW 	 
    	  
    	const muH9A34QGuccPZkZDb32w 	 
    	  
    		 
     mr0Gwya5kzUd694oxNDs4 	 
    	  
    		   
    _706246330297760 mA7hUM4UKqFyb_LJLsook 	 
    	float mYcSgTugFLQcmWT7seaac 	 
    	  
    		   
     
     
_46082544231248938.cols mXftmBtLFUrPFw3lasjuW 	 
    	  
    		   
     
  /640.f mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
    		   
     
   
    cv mrS2zvlmrTf4L4KBRRYAU 	 
    	  
    		  Point2f _46082575822903876 mUGrJMUolw0lb_KVyGK5N 	 
    	  
    		   _706246330297760,_706246330297760 mVmWtYm5gVtZj7Yq19XWE 	 
    	  
    		   
     mqLizGA4Z8QZ_2GYQ1inC 	 
    	  
    		   
     
     
 
  
     mK81mHSyZucxh8c_K9rnU 	 
    	  
    		   
     
     
 
  _16987668682974831349 mH9fKsRtHWNu77RGN1xmn 	false mxIwd_EJpfr1C9jwU7IyL 	 
    	  

      mFVNERjMRO_ZEKm0TY73X 	 
    	  
    		   
     
     
 
  	  mBGM118Iia8vm6zcNTuB6 	 
    	  
    		   
     
     
 
  	_3857178690860967008 mDHmz3NSVqdDEn8FHaIo5 	 
    	  
    		   
  STATE_TRACKING muC5cqYcHRXDD16noARI1 	 
    	  
    		   
    mXdnll4yjwVy4uBDSjUe3 	 
    	  
    		   
  
         mvbe619pMTxqR0ISntFSZ 	 
    	  
    		   
     
    size_t _2654435874 mvA2vjSvRD7UmknjmYP5U 	 
 0 myu64GAT8DgGBhNOOCqvd 	 
    	  _2654435874 mJCQ17ktBLqNw7sHF60R1 	 
    	  
    		   
     
     
 _14938569046430841631.ids.size mJFtpHxfnoGMxp1wzTBMr 	  mQivdop_Gb4hqsWvOttc3 	 
    	  
    		   
     _2654435874 mtIfgwpprqjFMhHY9FVrL 	 
    	  
    		   
    mVmWtYm5gVtZj7Yq19XWE 	 
    	  
    		   
     
     

             mbCI0BlZHp5kbKpNqa5Su 	  mSdpFB1uEgpzM3bVmlHgT 	 
_14938569046430841631.ids mRjEKX4QN9MTvSEtCTNd7 	 
    	  
    		_2654435874 mGPgWaVxS3WdTr7rWsMw4 	 
    	  
     mglbnc94mbkalEyCkkDhv 	 
    	  
    		   
     
   std mrPFLPKakBKjOOnkuhZUP 	 
    	  
    		   
     
     
 
  numeric_limits miGVtxwiqbDQsG6KBslZU 	 
    	  
    		   
     
     
 
uint32_t mW202Akoy5o2_FFUMtz7a 	 
    	  
    		   
      mwuvkepREHprpx4i3n2RV 	 
    	  
    		   
    max mTGJXDnkacX2UX9dooHQu 	 
     mVFG05ubhW6ia_rWdS_Tv 	 
    	  
    mJdlQJg0rG2m7KHUChC3R 	
                 mt3m0c1_35lMMq0E3cZsZ 	 
    	  
   mgGCFceAojKPG0bK5eWQT 	 
    	  
    		   
   mW0689NsIXj0x_tZl_0ut 	 
    	  
_9098980761384425343 mxGJXkzb8EW07jCVTl0Jt 	 
    	  
    		 map_points.is mbXhD242DJoibBjdI1JtA 	 
    	  
    		   
     
     
 
  	  _14938569046430841631.ids mZloAr3_PPw7622AVrUCe 	 
    	  
    		 _2654435874 mGPgWaVxS3WdTr7rWsMw4 	 
    	  
    		   
     mPaUdMg3fg2ipZY0Exj7X 	 
    	  
    		   
     
      mxAXsCfNkscq4iQtE2AeY 	 
    	  
    continue mqLizGA4Z8QZ_2GYQ1inC 	 
    	  
   
                cv miuOs6oIdxnQEMrFFk2n_ 	 
    	  
    		   
     
     
 
  Scalar _46082574599890393 mgGCFceAojKPG0bK5eWQT 	 
    	0,255,0 mxAXsCfNkscq4iQtE2AeY 	 mqLizGA4Z8QZ_2GYQ1inC 	 
 
                 muDvj5aUdXshb2AqqeEiu 	 
  mOAy4qGUJpdHQSVbVPq9E 	 
    	  
    		   
     
     
 mC4FNAhGk_5NQroya9r4E 	 
    	_9098980761384425343 mVfb3IHZLk8rmg75VuqQZ 	 
    	  
    		   
   map_points mMo20fFU0rdQJ7l5qqDaX 	 
    	  
_14938569046430841631.ids mstJEG25u0Qv4VQocWgKl 	 
    	  
    		   
    _2654435874 mAH84ftHkJMUldxM9fJHE 	 
    	  
    		   
   mvFhi6DaS7eScbgWe07wY 	 
    	  
    		   
     
 .isStable mFAl4ldpf7o2gKLWQ4bfu 	 
    	  
    		   
     
     
 
  	 mT3v8xdcVsSvUtbwmHC7j 	  mjXlfKOCTRjUV9apwYcb7 	 
    	  
    		_46082574599890393 mhL9dWuOWzLGBfRjwvYlN 	 
   cv mMorzi7AHv5qXgdOZzcMd 	 
    	  
    		   
 Scalar mgGCFceAojKPG0bK5eWQT 	0,0,255 mJk4eXgp_IeFV2YvLaQC7 	 
 mQivdop_Gb4hqsWvOttc3 	 
    	  
    		   
     
    mL9oWJQ1n2xKG3FtRNowa 	 
    	  
  
                cv mwuvkepREHprpx4i3n2RV 	 
    	  
    		   
     
   rectangle mBGM118Iia8vm6zcNTuB6 	 
    	  
    		   
     
     
 
  	_46082544231248938,_9971115036363993554* mbXhD242DJoibBjdI1JtA 	 
    	  
    		   
     _14938569046430841631.kpts mwzFZRcSPi2Vsk45HpaLx 	 
    	  
_2654435874 mGPgWaVxS3WdTr7rWsMw4 	-_46082575822903876 mxAXsCfNkscq4iQtE2AeY 	 
 ,_9971115036363993554* mbXhD242DJoibBjdI1JtA 	 
    	  
    		   
     
     
 
  _14938569046430841631.kpts mZ9T0z5VdOHGC7rra8Fzk 	 
    	 _2654435874 mvFhi6DaS7eScbgWe07wY 	 
    	  
    		   
     
     
 
 +_46082575822903876 msDy4S0F6Zdx78ZUnbARe 	 
    	  ,_46082574599890393,_706246330297760 mXftmBtLFUrPFw3lasjuW 	 
    	  
    		   
     
  mQivdop_Gb4hqsWvOttc3 	 
    	  
    		   
     

             mqVdZVftPR84WTjiOiVfT 	 
    	  
    		  
             myrvDyRCtal5mdHB28ZIe 	 
    	  
    		    mg9IHDbTXxljO0nSnQKYh 	 
    	  
    		   
     _16987668682974831349 mVFG05ubhW6ia_rWdS_Tv 	 
    	  
   mbqHQotWhg0sv6ViuZXc3 	 
    	  
    
                cv mvpMkjoDGcQujDevHDZnx 	 
    	  
  Scalar _46082574599890393 mbXhD242DJoibBjdI1JtA 	 
    	  
    		   
     
 255,0,0 msDy4S0F6Zdx78ZUnbARe 	 
    	  
    		   
     
 mI30mSPxGJaQtkEjJfoQX 	 
    	  
    	
                cv me0ZKHp2Id3eLmP_6GMtk 	rectangle mgGCFceAojKPG0bK5eWQT 	_46082544231248938,_9971115036363993554* mlfybwyvp98TOJj0yuqhF 	 
   _14938569046430841631.kpts mstJEG25u0Qv4VQocWgKl 	 
    	  _2654435874 mvFhi6DaS7eScbgWe07wY 	 
    	  
    		   
  -_46082575822903876 muC5cqYcHRXDD16noARI1 	 
    	  
    		   
     
     ,_9971115036363993554* mYcSgTugFLQcmWT7seaac 	 
    	  
    		   
     _14938569046430841631.kpts mwzFZRcSPi2Vsk45HpaLx 	 
    	  
    _2654435874 mvFhi6DaS7eScbgWe07wY 	 
    	  
    		   
     
     
 
+_46082575822903876 muC5cqYcHRXDD16noARI1 	 
,_46082574599890393,_706246330297760 mJk4eXgp_IeFV2YvLaQC7 	 
  mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
    		 
             mf0YJDuh2j5By5N13LunG 	 

     msxc6utIaOFXg4WI3vB0q 	 
    	  
  
     mfkkS3ig7woFqdOg7udAR 	 
    	  
     mfRi_C6KlnAxop81XDZsV 	 
    	  
    		   
     
   _9098980761384425343 mcvX0B8TDw1gEtqXtgT4T 	isEmpty mGu_88Fdde5jsxW8v9whR 	 
    	  
    		   
     
     
  mXftmBtLFUrPFw3lasjuW 	 
 mbqHQotWhg0sv6ViuZXc3 	 
 
         mozBzR4ceXlDTd_eA9UWj 	 
    	  
     mflySGFqxQX_KaIEHAKSo 	 
_2654435881: _14938569046430841631.kpts mXftmBtLFUrPFw3lasjuW 	 
    	  

            cv mExFPeJBflhTWJKuQVWoB 	 
    	  
    		   
     
 rectangle mTiWUgQKOeYLvNdGsR_oS 	 
    	  
    		   
     
     
 
_46082544231248938,_9971115036363993554* mlfybwyvp98TOJj0yuqhF 	 
    	  
    		 _2654435881-_46082575822903876 mT3v8xdcVsSvUtbwmHC7j 	 
    	  
    		   
     
     
 
  	 ,_9971115036363993554* mNQ6rNLARkxxSTP6tiTXG 	 
    	  
    		   
  _2654435881+_46082575822903876 mVmWtYm5gVtZj7Yq19XWE 	 
    	,cv mvpMkjoDGcQujDevHDZnx 	 
    	  
    		   
     
     
 
  Scalar mlfybwyvp98TOJj0yuqhF 	255,0,0 mXftmBtLFUrPFw3lasjuW 	 
    	  
    		   
   ,_706246330297760 mVFG05ubhW6ia_rWdS_Tv 	 
     mC_gLvnw5tkMWRQheRKr5 	 
    	  
    		   
     
     
 
     mL9oWJQ1n2xKG3FtRNowa 	 
    	  
    		   
 
    
     mTy5S_mcphfNLzuJQ30Xe 	 
    	  
    		   
   auto _5221496220235804833:_14938569046430841631.markers mPaUdMg3fg2ipZY0Exj7X 	 
    	  
    		   
     
      mJdlQJg0rG2m7KHUChC3R 	 
   
         
        cv me0ZKHp2Id3eLmP_6GMtk 	 
    	  
    		   
     
 Scalar _46082574599890393 moHeIYzwbcFb6VaM90Aa9 	 
    	  
cv mExFPeJBflhTWJKuQVWoB 	 Scalar mOAy4qGUJpdHQSVbVPq9E 	 
    	  
    		   
     
   0,244,0 mPaUdMg3fg2ipZY0Exj7X 	 
    	  
    		 mC_gLvnw5tkMWRQheRKr5 	 
    	  
    		   
     
  
         mFWW5xb6SDILpyTp5GBZD 	 
  _9098980761384425343 mj3rSXJDWd4j4OSGbS2oX 	 
    	  
    		   
     
     
 map_markers.count mgGCFceAojKPG0bK5eWQT 	 
    	  
    	_5221496220235804833.id mJk4eXgp_IeFV2YvLaQC7 	 
    	  
    		   my0vyIAimw3jadFZG1pnz 	 
    	  
    		   
    0 mSBNIRK1XqZg3XlWW_b3d 	 
    	  
    		   
     mbqHQotWhg0sv6ViuZXc3 	 
 
             mFWW5xb6SDILpyTp5GBZD 	 
    	  
    		   
    _9098980761384425343 mj3rSXJDWd4j4OSGbS2oX 	map_markers.at mOAy4qGUJpdHQSVbVPq9E 	 
    	  
    		   
     
  _5221496220235804833.id mT3v8xdcVsSvUtbwmHC7j 	.pose_g2m.isValid mJFtpHxfnoGMxp1wzTBMr 	 
    	  
    		   
     
    mPaUdMg3fg2ipZY0Exj7X 	 
    	  
    		   
     
     
 
 
                _46082574599890393 mRDD8w83SsPKbGXy_JkEO 	 
    	  
    		   
     cv mvpMkjoDGcQujDevHDZnx 	 
    	  
    		   
     
 Scalar mTiWUgQKOeYLvNdGsR_oS 	 255,0,0 mT3v8xdcVsSvUtbwmHC7j 	 
    	  
    		   
    mxIwd_EJpfr1C9jwU7IyL 	 

            else
                _46082574599890393 mR22jPCjbltZ3tbBmn_6w 	 
 cv mNQimRrYQ8Mz6YI9KM7Fn 	 
    	  
    		   
     
 Scalar mlfybwyvp98TOJj0yuqhF 	 
    	  
    		   
     
 0,0,255 mVmWtYm5gVtZj7Yq19XWE 	 m_yMT4MKxrENTtLx5cA7n 	 
    	
         msxc6utIaOFXg4WI3vB0q 	 
    	  
    		   
 
        
         mTy5S_mcphfNLzuJQ30Xe 	 
auto &_2654435881:_5221496220235804833.corners mxAXsCfNkscq4iQtE2AeY 	 
    	   _2654435881 mVWXLsp7dzQ63mhYH8afG 	 
    	 _9971115036363993554 mI30mSPxGJaQtkEjJfoQX 	 
    	  
    
         mvbe619pMTxqR0ISntFSZ 	 
    auto &_2654435881:_5221496220235804833.und_corners mVFG05ubhW6ia_rWdS_Tv 	 
    	  
   _2654435881 mCytWUAf5qvM6IOdaLIC3 	 
    	  
    		   
     
    _9971115036363993554 mC_gLvnw5tkMWRQheRKr5 	 
    	  
    		   
        
        _5221496220235804833.draw mbXhD242DJoibBjdI1JtA 	 
    	  
    		   _46082544231248938,_46082574599890393 mXftmBtLFUrPFw3lasjuW 	 
    	  
    mC_gLvnw5tkMWRQheRKr5 	 
    	  
    		   
     
     
 
  
     msBPMso4NRYFcn5Y1myF_ 	
 mL9oWJQ1n2xKG3FtRNowa 	 
    	  
    		   
     
 
 mgBFSWJlmkK48wSOW4b6N 	 
    	  
    		  System mI3QeEk0K_mj1WaUiowht 	 
    	  
    		   
     globalOptimization mRAYh0ARHPOc62CfGHWWO 	 
    	  
    		   
     mjXlfKOCTRjUV9apwYcb7 	 
    	  
    	
     mcRuULuI_AYJWzFSu1kB4 	 
    	  
    		   
   _11093822300040 mIqjSmilXv9ILvDddB7nD 	 
    	  
    GlobalOptimizer mvpMkjoDGcQujDevHDZnx 	 
    	  
    		   
   create mOAy4qGUJpdHQSVbVPq9E 	 
    	  
    		   
     
     
 
 _14938569619851839146.global_optimizer mVmWtYm5gVtZj7Yq19XWE 	 
    	  
    		  mqLizGA4Z8QZ_2GYQ1inC 	 
    	  
    		   
     
     
 

    GlobalOptimizer mI3QeEk0K_mj1WaUiowht 	 
    	  ParamSet _3005399798454910266 mUGrJMUolw0lb_KVyGK5N 	 debug mI3QeEk0K_mj1WaUiowht 	 
    	  
    		   
     
 Debug mExFPeJBflhTWJKuQVWoB 	 
    	  
    		   
     
     
getLevel mjjfaXD3tH8warSj13sVr 	 maWf7apYek19lMvO8A9jX 	 
    	  
    		   
    11  muC5cqYcHRXDD16noARI1 	 
    	  
    		   
    mQivdop_Gb4hqsWvOttc3 	 
    	  
    		   
     
  
    _3005399798454910266.fixFirstFrame mhL9dWuOWzLGBfRjwvYlN 	 
    	  
    		   
true mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
    
    _3005399798454910266.nIters mR22jPCjbltZ3tbBmn_6w 	 
    	  
    	10 mQivdop_Gb4hqsWvOttc3 	 
    	  
    		   
     
     
 
  	
    _3005399798454910266.markersOptWeight mR22jPCjbltZ3tbBmn_6w 	 
    	  
    		   
     
     
 
 getParams mIJkWACd8Uom4Jv6selID 	 
    	  
    .markersOptWeight mEm194VmPJuGh5y4tMUm5 	 
    	  
    		   
     

    _3005399798454910266.minMarkersForMaxWeight mRDD8w83SsPKbGXy_JkEO 	 
    	  
    		   
   getParams mecU92YjgSbB3VkEoZVK3 	 
    	  
    		.minMarkersForMaxWeight mI30mSPxGJaQtkEjJfoQX 	
    _3005399798454910266.InPlaneMarkers mR22jPCjbltZ3tbBmn_6w 	 
    	  
    		   
     
     getParams mdbwYCIpGYWahFfTtU8zH 	 
    	  
    		   
     .inPlaneMarkers mC_gLvnw5tkMWRQheRKr5 	 
    	  
    		   
     
     
 
  	 
    _11093822300040 mgi5Boc5f0emw5eocZbgV 	optimize mSdpFB1uEgpzM3bVmlHgT 	 
    	  
    		   _9098980761384425343,_3005399798454910266  mVmWtYm5gVtZj7Yq19XWE 	 
    	   mwkk1d6uUiyaKys71tsUv 	 
    	  
    		   
     

    _9098980761384425343 mcvX0B8TDw1gEtqXtgT4T 	 
    	  removeBadAssociations mlfybwyvp98TOJj0yuqhF 	 
    	  
    		   
     
     
 
  	 _11093822300040 mdMNbPkq6p5KBhEVf3OFw 	 
    	  
    		   
     
     
 
  getBadAssociations mJFtpHxfnoGMxp1wzTBMr 	 
    	  
    		   
     
   ,2 mSBNIRK1XqZg3XlWW_b3d 	 
    m_yMT4MKxrENTtLx5cA7n 	
 msxc6utIaOFXg4WI3vB0q 	 
    	  
   
 mdx9gS37IsjwWpaOb1ODY 	 
    	  
    		   
     
     
 
System me0ZKHp2Id3eLmP_6GMtk 	 getLastProcessedFrame mjjfaXD3tH8warSj13sVr 	 
    	  
    		   
const mqlayz2fShj6ePxekxwRg 	 
    	  
    		   
 return _14938569046430841631.fseq_idx mEm194VmPJuGh5y4tMUm5 	 
    	  
    		   
      miXz43zs_DqtraKQW0m3N 	 
    	  
    		 
 myeiBNDHA8i8jhuL3IHRb 	System mvpMkjoDGcQujDevHDZnx 	 
    	  
    		setMode mTiWUgQKOeYLvNdGsR_oS 	 
    	  
    		   
     
    MODES _706246332824366 mJk4eXgp_IeFV2YvLaQC7 	 
    	  
    		 mi6BqZOVmQyrEy6BLProP 	 
    	  
    		   
     

    _17450466964482625197 mH9fKsRtHWNu77RGN1xmn 	 
    	  
    		   
     
     
 
  _706246332824366 m_yMT4MKxrENTtLx5cA7n 	 
    	  
    		   
     
     
 
  	
 msxc6utIaOFXg4WI3vB0q 	 
    	  
    		 
  muW_4n008TrPdz3qsiq99 	 
    	  
    		   
     
     
 
  System me0ZKHp2Id3eLmP_6GMtk 	clear mIJkWACd8Uom4Jv6selID 	 
    	  
    muH9A34QGuccPZkZDb32w 	 
    	  
    		   
     
   
     _2869602498954317713 mH9fKsRtHWNu77RGN1xmn 	 
    	  
    		   
     
     
 
std mNQimRrYQ8Mz6YI9KM7Fn 	 
    	  
    		   
     
make_shared mJCQ17ktBLqNw7sHF60R1 	 
    	MapManager mNF0G2xPBB22gI9XzMk2L 	 
    	  
 mIJkWACd8Uom4Jv6selID 	 mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
    		   
     
     
 
  	 
     _13028158409047949416 mA7hUM4UKqFyb_LJLsook 	 
    	  
    		   
   false m_yMT4MKxrENTtLx5cA7n 	 
    	  
    		   
     
     
     _3857178690860967008 mH9fKsRtHWNu77RGN1xmn 	 
    	  
    		   
     
     
 
 STATE_LOST mQivdop_Gb4hqsWvOttc3 	 
    	  
    		   
     
     
 
 
     _9098980761384425343.reset mIJkWACd8Uom4Jv6selID 	 mI30mSPxGJaQtkEjJfoQX 	 
    	  
    		   
     
     
     _2044193291895307872 moHeIYzwbcFb6VaM90Aa9 	 
    	  
    		   
     
     
 
  	std mvpMkjoDGcQujDevHDZnx 	 
    	  
    make_shared mJCQ17ktBLqNw7sHF60R1 	 
    	 MapInitializer mNF0G2xPBB22gI9XzMk2L 	 
    	  
    		   
     
     
  mGu_88Fdde5jsxW8v9whR 	 
    	  
    		   
     
     mI30mSPxGJaQtkEjJfoQX 	 
    	  
     _14463320619150402643 mvA2vjSvRD7UmknjmYP5U 	 
    	  
    		   
     
 cv mI3QeEk0K_mj1WaUiowht 	 
    	  
    		   Mat mTGJXDnkacX2UX9dooHQu 	 
    	  
    		   
     
     
  mwkk1d6uUiyaKys71tsUv 	 
    	  
    		   
     
     
 
     _10558050725520398793 mXE5wWRmJGUY4EsEsgegT 	 
    	  
    		   
     
-1 mxIwd_EJpfr1C9jwU7IyL 	 
    	  
    	
  miXz43zs_DqtraKQW0m3N 	 
    	  
    		   
     
     
 
  	 
  mlwxuKRzwZKw4d0ABP68H 	 
    	 System miuOs6oIdxnQEMrFFk2n_ 	 
 saveToFile mTiWUgQKOeYLvNdGsR_oS 	 
    	  
    		   
     
    string _16997227483604144380 muC5cqYcHRXDD16noARI1 	 
    	  
    		   
   mJdlQJg0rG2m7KHUChC3R 	 
    	  

     waitForFinished mJFtpHxfnoGMxp1wzTBMr 	 
    	  
    		   
     
     
 
  mEm194VmPJuGh5y4tMUm5 	 
 
     
     fstream _706246330143775 mlfybwyvp98TOJj0yuqhF 	 
    	  
    		 _16997227483604144380,ios_base me0ZKHp2Id3eLmP_6GMtk 	 
    	 binary|ios_base mrPFLPKakBKjOOnkuhZUP 	 
out  msDy4S0F6Zdx78ZUnbARe 	 
    	  
    		  myu64GAT8DgGBhNOOCqvd 	 
    	  
    		  
      myfOHlfTLtRL7im7qSaYm 	 
    	  
 mteJvtUMKI6kC6j6RtZKr 	 
    	  
    		   
     
  _706246330143775 mJk4eXgp_IeFV2YvLaQC7 	 
    	  
    		   
throw std mwuvkepREHprpx4i3n2RV 	 
    	  
    		   
     
    runtime_error mYcSgTugFLQcmWT7seaac 	 
    	  
    		   
  string mYcSgTugFLQcmWT7seaac 	 
    	  
    	__PRETTY_FUNCTION__ mVmWtYm5gVtZj7Yq19XWE 	 
    	  
    		   
    +"\x63\x6f\x75\x6c\x64\x20\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x66\x69\x6c\x65\x20\x66\x6f\x72\x20\x77\x72\x69\x74\x69\x6e\x67\x3a"+_16997227483604144380 mT3v8xdcVsSvUtbwmHC7j 	 
    	  
     mqLizGA4Z8QZ_2GYQ1inC 	 
    	  
    		   
   
     
     io_write mLS76iLDjnGxttL6L8yfX 	 
    	  
    		   
     
  uint64_t mNF0G2xPBB22gI9XzMk2L 	 
    	  
    		   
     
     
 
  mYcSgTugFLQcmWT7seaac 	 
    	  
182312,_706246330143775 mSBNIRK1XqZg3XlWW_b3d 	 
    	  
    		   
     
      myu64GAT8DgGBhNOOCqvd 	 
    	  
   
     _9098980761384425343 msDVYCHuU_j2g_TdgX4Ta 	 
    	  
 toStream mgGCFceAojKPG0bK5eWQT 	 
    	  
    		   
     
     _706246330143775 muC5cqYcHRXDD16noARI1 	 
    	  
  m_yMT4MKxrENTtLx5cA7n 	 
 
      
     _14938569619851839146.toStream mYcSgTugFLQcmWT7seaac 	 
    	  
    		   
     
     
 
 _706246330143775 mPaUdMg3fg2ipZY0Exj7X 	 
    	  
    		   
     m_yMT4MKxrENTtLx5cA7n 	 
    	  
     _706246330143775.write mTiWUgQKOeYLvNdGsR_oS 	 
    	  
    		   
   mSdpFB1uEgpzM3bVmlHgT 	 
    	  
    	char* mVFG05ubhW6ia_rWdS_Tv 	 
    	  
    		   
   &_17976495724303689842,sizeof mUGrJMUolw0lb_KVyGK5N 	 
    	  
    _17976495724303689842 msDy4S0F6Zdx78ZUnbARe 	 
    	   mPaUdMg3fg2ipZY0Exj7X 	 
    	  
    		   
     
     
 
  	 mC_gLvnw5tkMWRQheRKr5 	 
    	  
    		   
     
     

     _706246330143775.write mNQ6rNLARkxxSTP6tiTXG 	 
    	  
    		   
     
    mUGrJMUolw0lb_KVyGK5N 	 
    	  
char* mSBNIRK1XqZg3XlWW_b3d 	 
    	  &_10576739190144361304,sizeof mgGCFceAojKPG0bK5eWQT 	 
    	  
   _10576739190144361304 mXftmBtLFUrPFw3lasjuW 	 
  mxAXsCfNkscq4iQtE2AeY 	 
    	  
    		   
    mqLizGA4Z8QZ_2GYQ1inC 	 
    	  
    
     _706246330143775.write mUGrJMUolw0lb_KVyGK5N 	 
    	  
    		   
     
     
 
 mBGM118Iia8vm6zcNTuB6 	 
char* mVmWtYm5gVtZj7Yq19XWE 	 
    	  
   &_13028158409047949416,sizeof mNQ6rNLARkxxSTP6tiTXG 	 
    	  
    		   
   _13028158409047949416 mPaUdMg3fg2ipZY0Exj7X 	 
    	  
   mJk4eXgp_IeFV2YvLaQC7 	 
  mQivdop_Gb4hqsWvOttc3 	 
  
     _706246330143775.write mbXhD242DJoibBjdI1JtA 	 
    	  
    		   
   mbXhD242DJoibBjdI1JtA 	char* mXftmBtLFUrPFw3lasjuW 	 
    &_3857178690860967008,sizeof mgGCFceAojKPG0bK5eWQT 	 
    	  
    		   
 _3857178690860967008 mT3v8xdcVsSvUtbwmHC7j 	 
    	  
    		   
     
     
 
  mSBNIRK1XqZg3XlWW_b3d 	 
    	  
    		   
     
   mo9Lbpy0Ap4RTl5O5Or1C 	 
    	
     _706246330143775.write mbXhD242DJoibBjdI1JtA 	 
    	  
    		   
     
    mlfybwyvp98TOJj0yuqhF 	 
    	  
char* msDy4S0F6Zdx78ZUnbARe 	 
    	  
    		   
     &_17450466964482625197,sizeof mlfybwyvp98TOJj0yuqhF 	 
    	  
    		   
     
     
 
  	 _17450466964482625197 msDy4S0F6Zdx78ZUnbARe 	 
    	  
    		   
     
    mT3v8xdcVsSvUtbwmHC7j 	 mC_gLvnw5tkMWRQheRKr5 	 
 
     _14938569046430841631.toStream mOAy4qGUJpdHQSVbVPq9E 	 
    	  
    		   
  _706246330143775 muC5cqYcHRXDD16noARI1 	 
    	  
    		   
     mwkk1d6uUiyaKys71tsUv 	 
    	  
    		   
     
    
     _4913157516830781457.toStream mBGM118Iia8vm6zcNTuB6 	 
 _706246330143775 mVFG05ubhW6ia_rWdS_Tv 	 mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
    		
     _3944249282595574931 mVfb3IHZLk8rmg75VuqQZ 	 
    	  
    		   
     
    toStream mOAy4qGUJpdHQSVbVPq9E 	 
    	  
    		  _706246330143775 mVFG05ubhW6ia_rWdS_Tv 	 
 mqLizGA4Z8QZ_2GYQ1inC 	 
    
     _2869602498954317713 mgi5Boc5f0emw5eocZbgV 	 
    	  
    		   
toStream mOAy4qGUJpdHQSVbVPq9E 	 
   _706246330143775 mXftmBtLFUrPFw3lasjuW 	 
   myu64GAT8DgGBhNOOCqvd 	 
    	  
    		   
     
 
     toStream__ mgGCFceAojKPG0bK5eWQT 	 
    	  
    		   
_14463320619150402643,_706246330143775 msDy4S0F6Zdx78ZUnbARe 	 
    	  
    		   
     
     mxIwd_EJpfr1C9jwU7IyL 	 
    	  
    		   
    
     _706246330143775.write mBGM118Iia8vm6zcNTuB6 	 
    	  
 mSdpFB1uEgpzM3bVmlHgT 	 char* msDy4S0F6Zdx78ZUnbARe 	&_10558050725520398793,sizeof mBGM118Iia8vm6zcNTuB6 	 
    	  
    		   
_10558050725520398793 mJk4eXgp_IeFV2YvLaQC7 	 
    	 mxAXsCfNkscq4iQtE2AeY 	 
    	  
    		    mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
    		   
     
     
 
     _706246330143775.write mlfybwyvp98TOJj0yuqhF 	 
    	   mOAy4qGUJpdHQSVbVPq9E 	 
    	  
    		   
   char* mVFG05ubhW6ia_rWdS_Tv 	 
    	  
    		   
     &_13033649816026327368,sizeof mOAy4qGUJpdHQSVbVPq9E 	 
    	  
    		   
     
     
 
  	 _13033649816026327368 mVFG05ubhW6ia_rWdS_Tv 	 
    	   mSBNIRK1XqZg3XlWW_b3d 	  mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
    
     _706246330143775.flush mrXXIs5j4DqJtj32aOG5F 	 
    	  
     m_yMT4MKxrENTtLx5cA7n 	 
    	  
    		
  mL9oWJQ1n2xKG3FtRNowa 	 
    	  
    		   
     
     

  mlwxuKRzwZKw4d0ABP68H 	 
System mwuvkepREHprpx4i3n2RV 	 
    	  
    		   
     
  readFromFile mBGM118Iia8vm6zcNTuB6 	 
    	  
    		string _16997227483604144380 mxAXsCfNkscq4iQtE2AeY 	 
    	  
    		   
     
     
 
  mbqHQotWhg0sv6ViuZXc3 	 
    	  
    		   
     
  
     ifstream _706246330143775 mOAy4qGUJpdHQSVbVPq9E 	 
    _16997227483604144380,ios mI3QeEk0K_mj1WaUiowht 	 
    	  binary mJk4eXgp_IeFV2YvLaQC7 	 
  mI30mSPxGJaQtkEjJfoQX 	 
    	  
    		   
     
 
      mFWW5xb6SDILpyTp5GBZD 	 mC4FNAhGk_5NQroya9r4E 	 
    	  
    		   
     
     
_706246330143775 mXftmBtLFUrPFw3lasjuW 	 
    	  
    		  throw std mrS2zvlmrTf4L4KBRRYAU 	runtime_error mNQ6rNLARkxxSTP6tiTXG 	 
string mTiWUgQKOeYLvNdGsR_oS 	 
    	  
  __PRETTY_FUNCTION__ mJk4eXgp_IeFV2YvLaQC7 	 
    	  
    		  +"\x63\x6f\x75\x6c\x64\x20\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x66\x69\x6c\x65\x20\x66\x6f\x72\x20\x72\x65\x61\x64\x69\x6e\x67\x3a"+_16997227483604144380 mPaUdMg3fg2ipZY0Exj7X 	 
    	  
    		   
     
     
 mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
  
      mbCI0BlZHp5kbKpNqa5Su 	 
    	  
    		   mNQ6rNLARkxxSTP6tiTXG 	 
     io_read mRwYPGmWUou3ixNnKEWbv 	uint64_t mNF0G2xPBB22gI9XzMk2L 	 
    	  
    		   
     
     
 
 mYcSgTugFLQcmWT7seaac 	 
    	  
    		   
     
_706246330143775 mXftmBtLFUrPFw3lasjuW 	 
    	 mglbnc94mbkalEyCkkDhv 	 
    	  
    		   
     
     
182312 mXftmBtLFUrPFw3lasjuW 	 
    	  
    		   
   throw std mNQimRrYQ8Mz6YI9KM7Fn 	 
    	  
    		   
     
     
 
  	runtime_error mNQ6rNLARkxxSTP6tiTXG 	 
    	  
    		   
     
string mTiWUgQKOeYLvNdGsR_oS 	 
  __PRETTY_FUNCTION__ msDy4S0F6Zdx78ZUnbARe 	 
    	  
    		   
     
     
 
 +"\x69\x6e\x76\x61\x6c\x69\x64\x20\x66\x69\x6c\x65\x20\x74\x79\x70\x65\x3a"+_16997227483604144380 mVmWtYm5gVtZj7Yq19XWE 	 
    	  
    		   
      mQivdop_Gb4hqsWvOttc3 	 
    
     _9098980761384425343 mhL9dWuOWzLGBfRjwvYlN 	 
    	  
  std mrS2zvlmrTf4L4KBRRYAU 	 
    	  
   make_shared mHg0YG9R0Gb6ZE5xIr3dz 	 
    Map mVIm1AJSzhahLlgKO9xQK 	 
    	  
    		   
     
     
  mecU92YjgSbB3VkEoZVK3 	 
    	  
    		   
     
  mxIwd_EJpfr1C9jwU7IyL 	 
    	  
    		
     _9098980761384425343 msDVYCHuU_j2g_TdgX4Ta 	 
    	  
    		   
   fromStream mBGM118Iia8vm6zcNTuB6 	 
    	  
    		   
     
     
 _706246330143775 mPaUdMg3fg2ipZY0Exj7X 	 
    	  
    		   
     
    mqLizGA4Z8QZ_2GYQ1inC 	 
    	  
    		   

     _14938569619851839146.fromStream mSdpFB1uEgpzM3bVmlHgT 	 
    	  
    		   _706246330143775 mVFG05ubhW6ia_rWdS_Tv 	 
     m_yMT4MKxrENTtLx5cA7n 	 
    	  
  
      _706246330143775.read mTiWUgQKOeYLvNdGsR_oS 	 
    	  
    		   
      mBGM118Iia8vm6zcNTuB6 	 
    	  
    		   
     
     
 
 char* mJk4eXgp_IeFV2YvLaQC7 	 
    	  
   &_17976495724303689842,sizeof mSdpFB1uEgpzM3bVmlHgT 	 
    	  
    		_17976495724303689842 muC5cqYcHRXDD16noARI1 	 
    	  muC5cqYcHRXDD16noARI1 	 
    	  
    		   
     
     
 
  	 mo9Lbpy0Ap4RTl5O5Or1C 	
     _706246330143775.read mgGCFceAojKPG0bK5eWQT 	 
    	  
    		   
 mSdpFB1uEgpzM3bVmlHgT 	 
    	  
  char* mVmWtYm5gVtZj7Yq19XWE 	 
&_10576739190144361304,sizeof mBGM118Iia8vm6zcNTuB6 	 
    	  
   _10576739190144361304 mXftmBtLFUrPFw3lasjuW 	  mXftmBtLFUrPFw3lasjuW 	 
    	  
    mwkk1d6uUiyaKys71tsUv 	 

     _706246330143775.read mlfybwyvp98TOJj0yuqhF 	 
    	  
    		   
     
     
 
   mSdpFB1uEgpzM3bVmlHgT 	 
    	  
    		   
   char* msDy4S0F6Zdx78ZUnbARe 	 
    	  
    		   
    &_13028158409047949416,sizeof mbXhD242DJoibBjdI1JtA 	 
    	  
    		   
    _13028158409047949416 msDy4S0F6Zdx78ZUnbARe 	 
    	  
    		   
     
     
  mVFG05ubhW6ia_rWdS_Tv 	 
    	  
    		   
  mEm194VmPJuGh5y4tMUm5 	 
    	  
    		   
     
     
 

     _706246330143775.read mSdpFB1uEgpzM3bVmlHgT 	 
    	  
    		   
     
     mbXhD242DJoibBjdI1JtA 	 
    	  
    		   
     
     
 char* mxAXsCfNkscq4iQtE2AeY 	 
    	  
    	&_3857178690860967008,sizeof mBGM118Iia8vm6zcNTuB6 	 
_3857178690860967008 mPaUdMg3fg2ipZY0Exj7X 	 
    	 mVFG05ubhW6ia_rWdS_Tv 	 
    	  
    		   
     
     
 
  mI30mSPxGJaQtkEjJfoQX 	 
    
     _706246330143775.read mSdpFB1uEgpzM3bVmlHgT 	 
    	  
    		   
 mSdpFB1uEgpzM3bVmlHgT 	 
    	  
    		 char* mXftmBtLFUrPFw3lasjuW 	 
    	  
    		   &_17450466964482625197,sizeof mNQ6rNLARkxxSTP6tiTXG 	 
    	  
  _17450466964482625197 mT3v8xdcVsSvUtbwmHC7j 	 
    	  
    		   
     
     
 
  mSBNIRK1XqZg3XlWW_b3d 	 
    	  
    		  mwkk1d6uUiyaKys71tsUv 	 
    	  
    		   
     
     

     _14938569046430841631.fromStream mNQ6rNLARkxxSTP6tiTXG 	 
    	  
    		   
     
     _706246330143775 mJk4eXgp_IeFV2YvLaQC7 	 
    	  
    		   
   mQivdop_Gb4hqsWvOttc3 	 
    	  
    	
     _4913157516830781457.fromStream mBGM118Iia8vm6zcNTuB6 	 
_706246330143775 mVmWtYm5gVtZj7Yq19XWE 	 
    	  
    		   
     
     
  mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
    
     _3944249282595574931 msDVYCHuU_j2g_TdgX4Ta 	 
    	  
    		   
     
   fromStream mYcSgTugFLQcmWT7seaac 	 
    	  
 _706246330143775 mVFG05ubhW6ia_rWdS_Tv 	 
    	  
    		   
     
     
 
   mqLizGA4Z8QZ_2GYQ1inC 	 
    	  
    		   
     
    
     _2869602498954317713 mVfb3IHZLk8rmg75VuqQZ 	 
    	  
    		   
     
     
 
  	fromStream mYcSgTugFLQcmWT7seaac 	 _706246330143775 mXftmBtLFUrPFw3lasjuW 	 
    	  
    		   
     
     mqLizGA4Z8QZ_2GYQ1inC 	 
    	  
    		   
     
     
 
  
     fromStream__ mBGM118Iia8vm6zcNTuB6 	 
  _14463320619150402643,_706246330143775 mPaUdMg3fg2ipZY0Exj7X 	 
    	  
 myu64GAT8DgGBhNOOCqvd 	 
    	  

     _706246330143775.read mgGCFceAojKPG0bK5eWQT 	 
    	  
    		   
 mOAy4qGUJpdHQSVbVPq9E 	 
    	  
   char* mXftmBtLFUrPFw3lasjuW 	 
    	 &_10558050725520398793,sizeof mOAy4qGUJpdHQSVbVPq9E 	 
    	  
    		   
     
     
 _10558050725520398793 mXftmBtLFUrPFw3lasjuW 	 
    	  
    		   
 mxAXsCfNkscq4iQtE2AeY 	 
    	  
    		   
   mQivdop_Gb4hqsWvOttc3 	
     _706246330143775.read mNQ6rNLARkxxSTP6tiTXG 	 
    	  
    		   
     
    mTiWUgQKOeYLvNdGsR_oS 	 
    	  
    		   
     
     
 
  	 char* msDy4S0F6Zdx78ZUnbARe 	 
    	  
 &_13033649816026327368,sizeof mYcSgTugFLQcmWT7seaac 	 
    	  
    		   
     
     
 _13033649816026327368 muC5cqYcHRXDD16noARI1 	 
    	  
     mT3v8xdcVsSvUtbwmHC7j 	 
    	  
    		   
     
     
 mwkk1d6uUiyaKys71tsUv 	 
 
  m_ECAXF5hGu1UMoS2l1KU 	 
    	  
    		   
     
  
  mMGejH_coNc3kGxAdXVex 	 
    	  
    		    

#ifdef _4257555960817013426
#undef  mA7hUM4UKqFyb_LJLsook 
#undef  mwbs0d2NlC_djcHtxQPj6 
#undef  mdUyI4aAbhQ4X6fne1qVo 
#undef  mZLojCl8cVD1576VM0g8u 
#undef  mhwa9v40jbZGyHdjZKnp7 
#undef  mgs_uDQ8mSosYV9hCvlQU 
#undef  mP2Ml_iMNTficIMe44TSF 
#undef  mXdnll4yjwVy4uBDSjUe3 
#undef  mYOSSG7sSqnMh0YV5DIrw 
#undef  mmeJW_Q9h6ZBPzSBQVjMK 
#undef  mtNKEvBwMHNsmdH7BtZbM 
#undef  mGeB1HfXInE4uBPHmIDCN 
#undef  mExFPeJBflhTWJKuQVWoB 
#undef  mO5I_G9WPuW9VC4inj5mo 
#undef  mi4REkBAebpTZrzlvFEpD 
#undef  maWf7apYek19lMvO8A9jX 
#undef  mKLTKWdkdn_ESJc3B3MOJ 
#undef  mXYEIB3KYwzJOpssgkZxP 
#undef  mFWW5xb6SDILpyTp5GBZD 
#undef  mtq_QCXPpv2kX7L8PRz8d 
#undef  mEEA6W33vCS01rV9KTl0v 
#undef  mL8NdxI0A84_PQiCzjY0y 
#undef mJx1hfXrHT_dfDmEhQBC_Pvh6H5muIx
#undef  mS3P8ZWKrLHg9h_5dW5He 
#undef  mZilF4nRNVEneBzggpX7Z 
#undef  mh6HrOJVrT3NM9Wdyz2It 
#undef  muC5cqYcHRXDD16noARI1 
#undef mEDGSyYfmKJTv5tj6wkNqd6mfHlWMjP
#undef  mdpN8SwUj7WdZrfZEdHOU 
#undef  mlnjjjDeP_rHq0Q8WRLNl 
#undef  mC4FNAhGk_5NQroya9r4E 
#undef  mgGCFceAojKPG0bK5eWQT 
#undef  mgB7jkTLiZWzEF7KqbAfY 
#undef  mfF196cGKZ_LkBPN8ZWlr 
#undef  mrJcfxt4GvOx7AQVScfu1 
#undef  myMDc1DgE9_RLElsHtK4r 
#undef mjXwqRAhyk59NcNPAj326mdXnf1gVR2
#undef  mrjcvI9ucBIaCRtqGyrWD 
#undef  mPdND7yG0gLP1HGO5Lkvl 
#undef  mTmmYcodZhxYb9bt39OUl 
#undef  mwzFZRcSPi2Vsk45HpaLx 
#undef  mWIOGoR1XyrR6fw03i9px 
#undef  mtY6LxHDMoBxNaXBgiMYo 
#undef  mdoDIGlHHE7UO_4pXUSmQ 
#undef  mi05fm9uStmGibkKInn9I 
#undef  mhDfF2VEdGrCP55eTHYvN 
#undef  mRPDwBN1TFChGSxh15CwJ 
#undef  muDvj5aUdXshb2AqqeEiu 
#undef  msDVYCHuU_j2g_TdgX4Ta 
#undef  mise5YGBUx6xBGs9EUolB 
#undef  mS8RHH9YrzfK1kS8XUlWM 
#undef mVpqXAw8OwPya0In1DtR6DVSoVt5E4W
#undef  me2H4L3LXGkdv1CjOYaxx 
#undef md0oVktsx1pBS882l8zyIRjNfobA6ch
#undef  mVmWtYm5gVtZj7Yq19XWE 
#undef  mIbIpdgqmFRILtR4eBSgp 
#undef  mKQv8aH2lM5yjPYl5F768 
#undef  mT3v8xdcVsSvUtbwmHC7j 
#undef  msxc6utIaOFXg4WI3vB0q 
#undef  mAzTBw5jTPnBNbyO0BIkm 
#undef  mdbwYCIpGYWahFfTtU8zH 
#undef  mMGejH_coNc3kGxAdXVex 
#undef  mQYacSpatR0AsiZrXS4cE 
#undef  mNAtfKYOf6ADB9rVjcJk_ 
#undef  mt3m0c1_35lMMq0E3cZsZ 
#undef mU6DxMMDeS8jnWvjm1Pm4JPiFG0vlkw
#undef  mSH1h4yGhaMSu8y7JC_rY 
#undef  mQivdop_Gb4hqsWvOttc3 
#undef mtpK6cfRKaQfLmD5NlKZxIgtqI0KH8H
#undef  mS0R9s7sfcYa3Nx39taZW 
#undef mr5W62IjRnZD0dRSEjUmruLxKfdAo6z
#undef  mf0E07qXAg4sDu7JIwESC 
#undef mT9ANLDUV9tykjN4uA8yhgGv3MmvkRG
#undef msLnXwUymv1zch0aKjqHGUlG8jOOe2L
#undef  mdx9gS37IsjwWpaOb1ODY 
#undef  mIqwZsWoU0IEPB7TMb7wT 
#undef  mflySGFqxQX_KaIEHAKSo 
#undef  mTiWUgQKOeYLvNdGsR_oS 
#undef  mLMQAhvQYOFXZbKccuW7F 
#undef  mmBcOrqJdEmcu_DE5N2Gx 
#undef  mxIwd_EJpfr1C9jwU7IyL 
#undef  mx4lt8TnYlZ5ZXw4BS3wS 
#undef  mB6lie_LwNp2j7sbjYel_ 
#undef  mrPFLPKakBKjOOnkuhZUP 
#undef mOrS38s7h3Veesv9767f3xN2895kQdx
#undef  mVekuqiofcOlLv1kcHh3u 
#undef mYXPVOM37XZ0D0TXXL_pa4oEPuGbOPa
#undef  mhifiLHf3tBluSeI6D_kg 
#undef  mgrzSPnq5U03KE8vGp17K 
#undef  mRfik4dXiQLAdpjBrSV8e 
#undef  mRjEKX4QN9MTvSEtCTNd7 
#undef  mghpafeSRXwbO0z_DbM3C 
#undef  mv_fAKjj2BjcHsnbiJfVx 
#undef  mfRi_C6KlnAxop81XDZsV 
#undef  mVzJJ8Dxt5T_4dzWC9bRk 
#undef  mxp2hpvJDbBGG9galOMeH 
#undef  miFsrErvZNeg6kHpH01yE 
#undef  mo9Lbpy0Ap4RTl5O5Or1C 
#undef  mNgaR6RP0DoWIwdccOwpn 
#undef  mXE5wWRmJGUY4EsEsgegT 
#undef  m_cHyr6QlGt5jYeD25QwT 
#undef  mbqHQotWhg0sv6ViuZXc3 
#undef  mvbe619pMTxqR0ISntFSZ 
#undef  mol5p_9C0R9o_YMjX6nxS 
#undef  mfaXcqsSkd6ad3maNOmpF 
#undef  mecU92YjgSbB3VkEoZVK3 
#undef  mHg0YG9R0Gb6ZE5xIr3dz 
#undef  mwuvkepREHprpx4i3n2RV 
#undef  mf0YJDuh2j5By5N13LunG 
#undef  mYiyQbEDdMYkmeehBx6jp 
#undef  mvA2vjSvRD7UmknjmYP5U 
#undef mPapA0sQobBdMYxf8n5k_d1XfFYtgTj
#undef  mVIm1AJSzhahLlgKO9xQK 
#undef  mAH84ftHkJMUldxM9fJHE 
#undef  mIyrnAZ9pLZEaiK6Yst1L 
#undef  mNPH65O81GD4PdziT5g9G 
#undef  mniwdnkZe0XDlHpwvfS6f 
#undef  mZ9T0z5VdOHGC7rra8Fzk 
#undef mYEx6E3frdynb1tbeRHMsq4qjzx5lJI
#undef mTZV4xO_u33gH0m2pSZ0Kb_3WBL3eAy
#undef  muUPvA5lgBIdnaP2X6gZ9 
#undef  mjXlfKOCTRjUV9apwYcb7 
#undef  mol7dpMQ0btdFqXAptKQR 
#undef  mz0gDEk4XJJySbEeCgC9P 
#undef  mQbYLzhvVQm8J2LNkC6S6 
#undef  mquP6o79T92Q5e7Uu95ew 
#undef  mDe1564r6NJrCTudA8x0w 
#undef  mZb18dCucFvoBd0bsf01O 
#undef  mysXizvfs_r5HUdOYChFS 
#undef  mw_MIhwcw8TZ9gTF3_mEt 
#undef  mcce2fXWVHACmBftaJ9Re 
#undef  mVLLVWqNz0_lGN56vY03t 
#undef  mTy5S_mcphfNLzuJQ30Xe 
#undef  mKWQLdAVzYxp5QuNZ1ytt 
#undef  mT9nS5aSA2ErLjcHqOPSA 
#undef  mWQWZuZUxzgXcOZHMJMC_ 
#undef mtNLFw2e0zAimBia6Svb24JdAELHSus
#undef  meN5YYBBVg5DStfnyA8Dd 
#undef  moI4EWKnn9rwdcRf81yt6 
#undef mr11u0zLpFUybnlko22CUWxrLNKTqTm
#undef  mtEI4bSjtkyV5O0qz_vBz 
#undef  mbCI0BlZHp5kbKpNqa5Su 
#undef mvPDntQyNRw6Z8gi8TqyeJNRh3HJzNV
#undef mDXs2D5chInPqYdznStufYbihGTFbR8
#undef  mvFhi6DaS7eScbgWe07wY 
#undef  mcozC0jwDOrxnYpsfODix 
#undef  mY5qtQdkZ0Cq7TxfD2D9r 
#undef  mVrsJpNNblNXrk9CJ_J45 
#undef mzIN4oy49lJQAPj1sTO7CuJrW8zh8vn
#undef  mTWpr3m9V3RdtOrrhhpUi 
#undef  mHnBQIAphg35vDq0qZ1IH 
#undef mcwFVyZ5U2pcDCrXPAgxP4vgspzqlu3
#undef  mXbu2bQmZ_EIA6T8Pxs5C 
#undef  mUnahx7x8KWu62epS7OxV 
#undef  mI30mSPxGJaQtkEjJfoQX 
#undef  mJdlQJg0rG2m7KHUChC3R 
#undef  mozBzR4ceXlDTd_eA9UWj 
#undef  mZqpoIg7XHbhgu_6iW7PX 
#undef mUn7QGLA73p6W5WWUA8kXR068R1LLaE
#undef myRBBsHypjh2pwIDUsBulCaJVULSzBl
#undef  muPAQsfjksFeL917cY2qY 
#undef  mpgczyJuWNGXMBOxeP5oe 
#undef  mWg9bTDKGk1fMQGpnNkAs 
#undef  mc6a7gZ5y0kWaTfPKjZL0 
#undef  mUFRPXFmygxcJ82L2LC5t 
#undef mzuxgOk7A21FkrdsUSuvnxnfwzSM4d1
#undef  mmtdRAqKU38Wmq22hGoY2 
#undef  mEYy4vDSh1urfYj6Y0xAX 
#undef  mkQFhH7KKo8wEpsoToABe 
#undef  mfQABlcyhvI43vfjabcjx 
#undef mKHQi_mCIV4qkj6rPUW3efpMPD0wNm5
#undef  mIJkWACd8Uom4Jv6selID 
#undef  mO_k7IEuqtZq_e47ILYU9 
#undef  mI9xc5iM8fy3wmO_WiybU 
#undef  mYbzFOKSwwNsD71cP1DkA 
#undef  mUgQbNDLTz7hiX8p2shmY 
#undef  mLTITrFYKQEeVWAoGrzMF 
#undef  mS3spS0_ckVjORcpwfpZf 
#undef  mRDD8w83SsPKbGXy_JkEO 
#undef  mC_gLvnw5tkMWRQheRKr5 
#undef  mBFhfgDfkdod6qHz7NdvN 
#undef me5NQ5q4nzTEd8Focp_lQ2efTIGblTf
#undef  mnpObQ1mWnyfQO24_ojBn 
#undef mvmBqbIMsPhg4_ieHPNPA2054e72fsf
#undef  muh7SNXP3UdOZu6GOuG0_ 
#undef  mz_QhADZTe0uCEYYRSweR 
#undef  mRIlZ0NriRkVMhRpycZqI 
#undef  mcBKtNACwQ_SnJx26otEZ 
#undef  mq2gz5KAY_yWyHzw3C8AU 
#undef mC6s7k2DOay2vGSdayxevzArquG7kSe
#undef  mZ4lxIR9Ss2_Hj_UqJEdU 
#undef mXn6_dCt1InpPoeN7PJzsfcX40Bsl36
#undef  m_yMT4MKxrENTtLx5cA7n 
#undef  mOed2_9RVQfFNiTyizmoU 
#undef  m_oqkmDs8rXEbW2q16xvJ 
#undef  mAJj0tPIZvDaIRCwd81bO 
#undef  mqI5yMr4h6CHkceANuA43 
#undef  mZCDcAPDXTOUnUkMgttvA 
#undef mJuuoPKr40SU5zHhNbbXqctl3TiKplZ
#undef mf1FVfgOgk3KwNVS6KX1X3r7wnpFHZm
#undef  mumKmtKc8SEEXbYxYxnDh 
#undef  mgi5Boc5f0emw5eocZbgV 
#undef  monDVXoqIbwYZt9x_asGf 
#undef  mdIyvr_duNyurtIQ2sC_1 
#undef  mPTzP5ovoJRtpRWISSe82 
#undef  mV4_AbWY8ymaWGsYOk0LC 
#undef mCtyM05tQpMzDpEgPuGhYcokT6M4tjW
#undef  mAvI6WqVGKew5QUXF0T2l 
#undef  mQ3_UtHSGY3eARbSl_X7q 
#undef  maPL1kl9f9VlgIn9jnnN_ 
#undef  miCOYqGikWLzThHPaHJqa 
#undef  mvcDBJfIynZthI5bz_HTe 
#undef  mkyly54GlrbXuNeECTTqk 
#undef  mcZQV4r5il8OMRPl4Fijs 
#undef  mbkARxvbbfyf_buO00mpB 
#undef  mrCE0fSuXGTiQ_zkRfAJ7 
#undef  mEjIWbivPeVc9WtxGDiWw 
#undef mpMKiDYPHUkbcUrOidGijQq7UOxlcWw
#undef  mjjfaXD3tH8warSj13sVr 
#undef  mYcSgTugFLQcmWT7seaac 
#undef  mMo20fFU0rdQJ7l5qqDaX 
#undef  mvaZ3U73Zn5gRZuytQKWY 
#undef  miuOs6oIdxnQEMrFFk2n_ 
#undef  mE8uUKPmY8c0aMaRDvuqZ 
#undef  mYvqzY31mCrOAE70tjB7u 
#undef  ml5d8mzmxNmQRMtpfZ82X 
#undef  mpBV2mt4yeFwcVEC5cxVw 
#undef  mH7U1EdrCKalrHJxxWz_s 
#undef  mbJiX6F_a_O98JuQH2rHf 
#undef  mqlayz2fShj6ePxekxwRg 
#undef  mxGJXkzb8EW07jCVTl0Jt 
#undef  mc2SFiyFAyMaXElAGl89t 
#undef  mkbfWNsvNHk84u7zcYWL3 
#undef  mcCwozNc9ZEKnXkmsh9Fj 
#undef mw7X0K6Ks1HDdQZVuUvEBE8sNNQUpVJ
#undef mVwXME5C65fIa3AvF3qdC4s8VSuRCn1
#undef  mSBNIRK1XqZg3XlWW_b3d 
#undef mgp30WAQApKqfYJi7b665A_Fsk0fLph
#undef  mxAXsCfNkscq4iQtE2AeY 
#undef  mPCAiE3B2oKNgoE3DnCGS 
#undef  mb82bbtDRSdpvH4Q5VV6X 
#undef  mMm9FLNsNOoyX7Tyb7vpT 
#undef  mKKmc4BHDTQao51cezkdW 
#undef  mgBFSWJlmkK48wSOW4b6N 
#undef  mrIWO5AmcxVfFGpyNJzQE 
#undef mjJaL6ka1Was97xj02ttOG_WmmWOzk7
#undef  mrXXIs5j4DqJtj32aOG5F 
#undef  mKH2zPRtp0X4JTntk4h2u 
#undef  mN4RvsK7_XXMC2cNCwITM 
#undef  mPaUdMg3fg2ipZY0Exj7X 
#undef  mLF5wNIO93YQsDKnsE8CQ 
#undef  mVOBFEtNftMS2NFrVW8bV 
#undef  mR22jPCjbltZ3tbBmn_6w 
#undef  mvpMkjoDGcQujDevHDZnx 
#undef  mKJK3THIuAwgeFpuGLN8L 
#undef  mqVdZVftPR84WTjiOiVfT 
#undef  map_Um1UEXeLIjOGoUw9U 
#undef  miKAllCm5PMbA2fU3LrvT 
#undef  mV6teN3KtTJ8vHmQAuPWz 
#undef mz49HpzWnGZKPZ_SZ0VjCRqhMrTkbXD
#undef  mg9IHDbTXxljO0nSnQKYh 
#undef  mN_UNAeshLaooczmV1nkW 
#undef mmPZkSy7hkphGU4PA4IHQSP49HWrI6I
#undef  mVfb3IHZLk8rmg75VuqQZ 
#undef mUdlAesF5AuSJR8ScuRRyVZqheDCzBs
#undef  mQRLqWWTfqtTF6fXNey7C 
#undef  myu64GAT8DgGBhNOOCqvd 
#undef mZc4Iz_sn6gUwXzL718AILBxUNure4r
#undef  m_j66qmf_xp1aP8o87JsC 
#undef  mWjWwCxBA7LLBixCoRsYZ 
#undef  m_W9SY1N4eCI9HVCtY7k_ 
#undef  mIqjSmilXv9ILvDddB7nD 
#undef  moCEmVQeGy8LzV8cAuk79 
#undef  mZjMv78yfz0yQEDayPDn4 
#undef  mhfoVR7GfGGYByYoTirWE 
#undef  mZtjXWMVRX5W1YY5htRHo 
#undef  muH9A34QGuccPZkZDb32w 
#undef  mfvgAAx_p4DiD5VQWew30 
#undef  mAPqoF5haBWDrhI1NEj4F 
#undef  mSdpFB1uEgpzM3bVmlHgT 
#undef mVNaGXNPhIIKr2hUgGHX4UaeDEMfi42
#undef  mCUW3oFzDeQf_LYRW_3Q7 
#undef  ma6O7Vg8NwpyGvRwfbCOg 
#undef  mTGJXDnkacX2UX9dooHQu 
#undef  mHbSWrX6OPeRP2Igmog8G 
#undef  mFVNERjMRO_ZEKm0TY73X 
#undef  mQFhSiloYfIS2jNU3eZwh 
#undef  mJ1vGQuHCiSCbbgKlE1zh 
#undef  mTWpMMn_ueGNGrVaZzL0Q 
#undef  mTkuNOxSsNhHKtS5Aoyjl 
#undef  mhzXsKXJN7mpztq4AcAJP 
#undef  mY6fIyAOJfhz5nUdrWiVY 
#undef  mSXTPhnnQgIi6ocmukNcV 
#undef  mypSLdUZlHtNg6EWZ4tk4 
#undef  mgux57p4wBZIWFfq6waj5 
#undef  meoTw_X4Xqh45MaL_F2D7 
#undef  mr8s7pfvTmBWmxher3Oue 
#undef mFbAfOobLBnSihi9oovZu4R6MDK5fsc
#undef  mcKERBksFL6yXYOLd7kWz 
#undef mbyFB_zuYrlaUAZ0YvrMZ0qMUWQI1_m
#undef  mMW4T9X7Ncvxkcl9tdmuW 
#undef  mstJEG25u0Qv4VQocWgKl 
#undef  mzoah9JwBIdWZVJcSU27j 
#undef  mXftmBtLFUrPFw3lasjuW 
#undef  mmAvkrWz9or7FSKyep8Gr 
#undef  mLdCPhlCq1uVgMtM4YkSz 
#undef  mcRuULuI_AYJWzFSu1kB4 
#undef  mEhFK99MtLRsCBaPNqnDs 
#undef  mOHlEjbyW9EyIFVYqPfh9 
#undef  mccsFNEYvw261klEKqukf 
#undef  mO02z_ujA2bhihPtTtFSA 
#undef  mx0IHqzgubYGvmr3US2dG 
#undef mrklVs4e18EG0isgYms8QLiA8VS3ndK
#undef  mljwEkmom23bYFuTS0b0b 
#undef  mT6NDpoRTuoGE3dKWoXeh 
#undef  mLS76iLDjnGxttL6L8yfX 
#undef  mhJ97TQsVn_CNDDcdyvCc 
#undef  muoE4XIKfPRSXmzic7wiv 
#undef  mJk4eXgp_IeFV2YvLaQC7 
#undef mtbFfPEOTUo9ZxMxuvpH7h3G0y34BUQ
#undef  miPlatUaObQVOYOiw6SZF 
#undef  mAckb35A91fK2dY3gHfaK 
#undef  mAtWayYkoRILYXB8QtRbg 
#undef  my0vyIAimw3jadFZG1pnz 
#undef  mlEF62Izit24hGT_NqPIJ 
#undef  mt3d6r2BuFfOvfXdOmaLX 
#undef  mopnBBbnH3fttLLMFPoqR 
#undef  my5S_tF4_lSpButBKNitX 
#undef  mxkHJa5wooqhzaSxK7_fd 
#undef mpzFaHYiXFWUKP8NPmYNuC3erXnFHiz
#undef  mhRH54odsmIWcLq1D3rKZ 
#undef  mrg1QVINMqbRYZWngNWmj 
#undef mgw8BkP8SNV8jndx61xg0o50h_c5mif
#undef  mi6BqZOVmQyrEy6BLProP 
#undef  mYg3RpRsnYTFl5_yP9Off 
#undef mLJzZsWnOmMS6V2RrU8dPGyS1KjXdWu
#undef  mDWwKMm0Bw8nxvI3ZwZnM 
#undef mUqaV4ZLGbvoX5uC3jxjOgaRtmgJvhY
#undef  mvz1OP7svCPSKfxJ2Wbqs 
#undef  mpjTyiESCVWYRDiT2x2RD 
#undef  mxCgC8LoLiSZGVUV0OQXG 
#undef  mzwLTwfbmQ5D2jzV7LROH 
#undef  mfuDqjzDT73kQihIjSHez 
#undef me_x3XD35s4SQm68rZAxnDPyEScI4ko
#undef  mEm194VmPJuGh5y4tMUm5 
#undef  mO5kQTjyeAtuoPXAKG8Fc 
#undef  moHeIYzwbcFb6VaM90Aa9 
#undef  mMbWC8gQeXmnMqYEj20Wf 
#undef  mLE5EGHIdfaJi3FG2wNSs 
#undef  mZloAr3_PPw7622AVrUCe 
#undef  mzCa3iYOTZk3vOb9xFPuf 
#undef  md3vFKQB1r7mKsD_TtoYY 
#undef  mfLSKCXSc1DHeN38jALNR 
#undef  mPvI5zVkkxdTYTCdGOJ2J 
#undef  mFAl4ldpf7o2gKLWQ4bfu 
#undef  mTgR0xuTc2WA_FI5hAh2Q 
#undef  mgT33OczCogeSJ9uFzScS 
#undef  mY8NZr9zd5VcrqfZxKQJH 
#undef  miEkJpdzqdOiFySBrwOfd 
#undef  mBxIiY0bxajrRw6WjYleG 
#undef  mQ28kUfMOhNPxGTJTErTr 
#undef  mkHL8KJw4VjwmGdgQrteX 
#undef  mwkk1d6uUiyaKys71tsUv 
#undef mica9L0obWHIAMj8olmooNyaERwYWWb
#undef  mraP1zuclX52fRr5CelTs 
#undef  mI3QeEk0K_mj1WaUiowht 
#undef mys8Mow1B0To5jHFE7OoGMaLlvNTYiw
#undef  mUrzesNXiQhLYupQ11MEa 
#undef  mNF0G2xPBB22gI9XzMk2L 
#undef mlXMiDtd6M4SH6uQB_NP4czeOXVoS5J
#undef  mvVEux0tzfHTcHloJ_PHd 
#undef  mMorzi7AHv5qXgdOZzcMd 
#undef mBPRy7dwggVK7T8mnFH4k3IHP5LNgxA
#undef  me0ZKHp2Id3eLmP_6GMtk 
#undef  mrxxDSozmVXbU0DdkvQZ8 
#undef  mrrE9iifrKAQukpCdUvSg 
#undef  miGVtxwiqbDQsG6KBslZU 
#undef  mKdE4ZCfdDaB2HjFWW9ZV 
#undef mU4MGy3eTQcSf54RC1cbEcjQ3muIwTt
#undef  m_l2K0T8_C6RujcQWcodT 
#undef  mJM70H6b9NGcqtHePCrZv 
#undef  mRHtQqJtkyJMFTpmBQzRp 
#undef mOPUy9orrqKqHEN_9xN7pePKUGcDrG7
#undef  mkufZC7kHsvxllmN0YBQv 
#undef  mW202Akoy5o2_FFUMtz7a 
#undef mNfxZlRukKJI5Avx99qsiGytb0bdKx0
#undef mfBrVitNz1gcglM0S0d_GaB2XQ6qIBt
#undef  mgCpjhgiW1siuOOx31UVB 
#undef  mFllaSnZNjV3YvL2YmAFh 
#undef m_FIu8SC1mV9u96yGGq517GuyZBOKN2
#undef  mgrODPzGHQfjmAyPsBdfg 
#undef  mFWbNGU5e6cuqyQa3XUry 
#undef  mt01qaUz2R0SKmPFSq0jx 
#undef  mUGrJMUolw0lb_KVyGK5N 
#undef  mH9fKsRtHWNu77RGN1xmn 
#undef  mLp5eeYn1TGnQEcop68VN 
#undef  mcvX0B8TDw1gEtqXtgT4T 
#undef  mbzQLzB5_GI6yqNIVcKo7 
#undef  myfkTa1upxif9QPCqJYGo 
#undef  mdN8xdqycKdYT96rU4KUK 
#undef  mb1P_epCWN8Wxasz2RKsj 
#undef  ml5pooDWTz1HG4AXabzV3 
#undef  mj3rSXJDWd4j4OSGbS2oX 
#undef  mYCupqIOYDMlnjNznUUG5 
#undef  mJCQ17ktBLqNw7sHF60R1 
#undef  mFASROAG4Q9353J70qH7c 
#undef  mRAYh0ARHPOc62CfGHWWO 
#undef  mf5rJKHDmIhT9kr_E2lnd 
#undef  mOeb4QCF4tk5CXqIGmTlK 
#undef mxTZSmMRscCjViBKa0Vr5qsi2p7WINa
#undef mkw8lGlDbQZaKMTP_YDPjvJLCWzkF1F
#undef  mJJosB3DZCYh837sWRpN7 
#undef  mY7ZY9aprChsLCuD7yOm0 
#undef mlXDtb4w4pC9DEeHyq5htHbqCmrrnZS
#undef  mDUeb65ug1HYJ31338ssa 
#undef  mJ55qvKfsfvRiFivJRFvq 
#undef  mJWj5YQLEzhdPuiJvzQ8O 
#undef  mWsMr8mjNljMAriyUwgnE 
#undef  mmk2RogyswbtTiHnbCghT 
#undef  mVFG05ubhW6ia_rWdS_Tv 
#undef  mtIfgwpprqjFMhHY9FVrL 
#undef mE0T41d6zsvRVEKQweSBUEh_uGhgu22
#undef mqDiAL7DCz_mNYimuKlWv1DrEFI7zZX
#undef  mQIYDh6QMMrUx6uxn_6So 
#undef  mAmoJDTG6Of2SbVxLbNlJ 
#undef  mKx3hnVGJH14s80udXZp_ 
#undef  mZlJv5AWGo4iJ2lUt_qL9 
#undef  mF1AFCmj7FNvcdn7hZ9B9 
#undef mXk6lthHPSZVm77eowhQeQawrY_9rFf
#undef  mpmXJjJFMEII76TcUeF6n 
#undef  mBGM118Iia8vm6zcNTuB6 
#undef  mVEKXpiuZW9uJtiJR96kC 
#undef  mk9nSfh6XGyonOYMC8C3M 
#undef  mlfybwyvp98TOJj0yuqhF 
#undef mfsUOzV7P_RilmCCGvwoeIlw4YJVgaK
#undef  mglbnc94mbkalEyCkkDhv 
#undef  mUvBFztQfvp6FxGFsyoMW 
#undef  mFS3Bzv40ET2Bg_bjcFGO 
#undef  myeiBNDHA8i8jhuL3IHRb 
#undef  mLTPi46EjqETKRikMKXiU 
#undef mvxShRWzqhGplR48sv87FTnON8YlX5V
#undef  mCFTZ4KBJ1F7Fkl00Fjcu 
#undef meiLv2EX65XvUvChPEjuN886Ha3hsh_
#undef mVSnQ5bRFB6wfDS_yNBNbNu5E0uONgN
#undef  mlwxuKRzwZKw4d0ABP68H 
#undef  moKypFwLFwBoz6rUVIuCY 
#undef  mUgtpRAYJj43Mf4SpepZP 
#undef  mSwbK3nBcNZkvGxSXNOZy 
#undef  mWW5XPXuQhAy0ULFUxjSy 
#undef mFGsmz168M0g5OuX5mDGXvoCfCP6cOP
#undef  mbKsAIYA4KftCqyFCiVR0 
#undef mUx6m64LorImkLdiamz4MNnKfJ8Dgqd
#undef  mCytWUAf5qvM6IOdaLIC3 
#undef  mbdlGyMOiuL6kjlXvSqqd 
#undef  mGu_88Fdde5jsxW8v9whR 
#undef  mbtzLVjzLgaxYxNNltfyM 
#undef mIyyG3AKrblBJKxNwgTHaAp64amaZec
#undef  m_ECAXF5hGu1UMoS2l1KU 
#undef  myfOHlfTLtRL7im7qSaYm 
#undef  mFTobXyS5Vx9ebVESwR0T 
#undef myUjQEd8RpnmXHqwk8e1AWLvQ6gzt5H
#undef  mevHkLo7kL5WL0_0mLIhr 
#undef  mDHmz3NSVqdDEn8FHaIo5 
#undef  myWBdZwdHWpQZqZ09m0Jq 
#undef  mBUCZuaNioFkzVtaa2sRQ 
#undef  mmIw4aId5JmbXYNH3gSAX 
#undef  mw8HdfNy4mFP2ZdyEGSp5 
#undef  mWRzp9vubS9UNcl2Anz32 
#undef  mP7ddfBDehHbRqP8iGbq8 
#undef  mK1g7l2eLzcTEZMoreGi3 
#undef  mL9oWJQ1n2xKG3FtRNowa 
#undef  mVWXLsp7dzQ63mhYH8afG 
#undef  mMa2nYH1z474KyDSW_2Vs 
#undef  mmSlUFoMxZtVX9CkQCe7O 
#undef  mtmFAz7pcnIFLgYGMf4eK 
#undef  mQsihVvqkuYoG8jvPTYFO 
#undef  mtXIBsLV4PNo4xplHiuYW 
#undef  mybagCX6OK9hQIn4qwrFz 
#undef  mEbO1A7RXmhmRG12Qtq2A 
#undef  mHlvGgqu6yYQkoBxoydv2 
#undef  mkcVgqnqADeTh3Pu1ogGF 
#undef mS2uQ2KWlC98CK2b0R7E2P72sVnabdi
#undef  mwiKr6psttEx97f2NsYO1 
#undef  mNKI4p1bbhsctoprpzZld 
#undef  msBPMso4NRYFcn5Y1myF_ 
#undef  mafwB2WCPijyRRTuHGVwE 
#undef  mfkkS3ig7woFqdOg7udAR 
#undef  mOwAFTnFZjoBWI2gNeAO_ 
#undef mNop_E1tZVTfrIm1pI_Weo9Woj9KEvB
#undef mKBHPoItjfMlV0wiBB4zhY7eGHfZlUN
#undef  meH5OaCcZwH0xkfm5lpWj 
#undef  mGPgWaVxS3WdTr7rWsMw4 
#undef  mWi16Wz7P86SIJlTQEzCB 
#undef  mIaPM1ms991SDrw4x6KTt 
#undef  mWaLwU5zB1H0AtUbS8Rz2 
#undef mPJW22oQ5EY7l3brt_yM6tZ98O1MaSS
#undef  mfnsIHmSLQOabKyJkuQOT 
#undef  mweJTmqyXMKSMhERfzuxN 
#undef  mdMNbPkq6p5KBhEVf3OFw 
#undef mAgeWodR4T4ZrkJewFh58A0i0ajDXAw
#undef  mW0689NsIXj0x_tZl_0ut 
#undef  mELweLHSjak68niq3oUpw 
#undef  mNU1gzy6st0M0XRy_b50x 
#undef  mZ_OIrsB5IK5mggFkrgFu 
#undef  mrJARF3qaYOfBun2j_jcD 
#undef  mjeCTifvlIBEl0lPx4S9g 
#undef  mn5MlHVieFj6s1Arh9Q10 
#undef  mOAy4qGUJpdHQSVbVPq9E 
#undef  mVZIUasySfZXcql1nm24B 
#undef mWi0N1XQtqS4eplLhvTPtL7YVDTI0uk
#undef  mbXhD242DJoibBjdI1JtA 
#undef  mISlN399eTfrWHnidEKGu 
#undef  mC7hzb7yA8ZYeXu1CO69e 
#undef  mzDmJqPikCTXlN8BGk0M9 
#undef  mFlx7sCaCoQxsjHSq_umO 
#undef  msGAdK1RZcxCitYemdpxc 
#undef  mf2ViRb3BWngxlNGam_05 
#undef  miXz43zs_DqtraKQW0m3N 
#undef  mhaG6yS3EwOInKAwIBoQN 
#undef  mANVdtEFAyD7H8nVwStxw 
#undef mHNb3kVFhkHg9E01geZBsldl9Bqqteh
#undef  mVmEiQKd2V4SMp8srf2ip 
#undef  mcs2IPsFq8XN5a3t5KBLK 
#undef  mIHFqVJpFXgMDdHn2uhc3 
#undef  mVAe2KWVqd9ISAzz02MVl 
#undef mqjfrgUiAEDDEjlRkjAD2lLTvBK4_wM
#undef  mjg3Ot05P13DpFXIgvY3M 
#undef  mzPBrKZLupkxN5F1reNis 
#undef  mLdvrbXgkmVAVnc3aEbWU 
#undef mCOsHuy_LgH97Sv8cUUn62iDLX97wwR
#undef  mhL9dWuOWzLGBfRjwvYlN 
#undef m_V320PDi44AmWFVj_bsjmQ6FP8FK6B
#undef mepF4kKPTKcm3_3zOgvFYIzxp7qltNj
#undef  mhNH3dNZkhrgawU6wbA6V 
#undef momc0dVPjZSCmkiCD0NsIvJpksvAEq6
#undef  mCzaOxAWpFlV3gHYCg4ev 
#undef  mNQ6rNLARkxxSTP6tiTXG 
#undef  mCehD1sxzTv6MH7ymj2xb 
#undef mv1RKc7QVwxlWT9SXxD8SO31MO6ME0P
#undef  mYMxwp5lzvb08Oa8FUKdp 
#undef  mIgWcCjmm9URqJ9HNYW2A 
#undef  mJqFpzb57ph2rWKCmAfkM 
#undef  mrDas3egWRcEnvTodVRRA 
#undef  mwEEBMzfZV6O26soeDHeI 
#undef  mS8JphOKBDH9MB5GkmcLq 
#undef  mxt_R_jw78RlV2eo0D9pJ 
#undef  mGc5v1UWfDU7ttNcZryQG 
#undef  mosqH7AZUNZeyz6yX3nN1 
#undef  mpC65FoK2NLadlWUAo9ps 
#undef  mO9LYCrftPnMJePmJnE8_ 
#undef  mtDWQOqRguVWSWehbKECr 
#undef  mbCB2QE8sAa45H2Pxnfop 
#undef  mqUxZEnHM0zID6J2vVqke 
#undef  mGBA6VT3iuGw48FMYPVID 
#undef  mteJvtUMKI6kC6j6RtZKr 
#undef  mPjeLalHATLRlVYohP5cu 
#undef  mtnnWCdgrIMkg48Nfdksz 
#undef  mEpG5N2fixtWboWua15h2 
#undef  mSSwrqUuoNnhMtvhM2vr3 
#undef msMTjEcQRbmNfhQK9JCSaxiULsTRddS
#undef  msDy4S0F6Zdx78ZUnbARe 
#undef  maE84VqXoUUX_dnxUsfES 
#undef  muW_4n008TrPdz3qsiq99 
#undef mItOvmgvVaCfcAbau5lsMFJBHZNgxMF
#undef  ma1pkHKHRslLKg1N_R3cS 
#undef  mHUTuX3q6rB5eWWYYPWQD 
#undef  mJFtpHxfnoGMxp1wzTBMr 
#undef  mcAnVuQmAnGunjGyL6dhh 
#undef  mjS5rO91VKWACucamZJvF 
#undef  mUmh6jnSKhpmWgXMnt8PS 
#undef mbJXAa63ZDuAqsedxrTDHusieLOgU0u
#undef  mOE4ALZahxLkvGqMRmxIK 
#undef  mBGciDWaUfaa6OV3swXep 
#undef  mr0Gwya5kzUd694oxNDs4 
#undef mWy_AfkOoH2nnI2kX9dj2KXAIxmex5q
#undef  mWYYMqZtRPklZ6ldYQlW8 
#undef  mdEGS_9gShKEEsK9RPbfj 
#undef mEWPzjcYD7moMgjqWTXhQ08Ljc0mNua
#undef mP58CIh6ze6yAP6qZBUSJEJWLJ4Ud8m
#undef  molF5K16MuyVvkFE7X8JI 
#undef  mi2mlTodeof41MadCAEzi 
#undef  mfKtZiRp2HOdQqoTplnaI 
#undef  mHOvssFtYMllM6IBWHFls 
#undef  mFruyY5vdoiszED1tVpm7 
#undef mRPo0fFJbYzO3rl5SpSmQCkuEOXjwjR
#undef  mbVOLbjVZO0YI60Vuguaq 
#undef  mFqi0ZIcB_YhZ2B8QBIQg 
#undef  mY5hSAdXT4P60CSAZFBBa 
#undef mwVuNe3p0bvoSU3FXwiOAlf5xNTpUqD
#undef  mU7LO3jg27wf5nw3n8LF7 
#undef  mNQimRrYQ8Mz6YI9KM7Fn 
#undef  mYJhSIZr793lUcg7mTDWT 
#undef  mTlKcfas8V6h_FPimPoyY 
#undef  mK81mHSyZucxh8c_K9rnU 
#undef  msz82ko2ZHqbIoF2aTtnd 
#undef  muzrhxIoqthv8PfiNihnX 
#undef  m_1_RZETM1QJ8vycOakwy 
#undef  myrvDyRCtal5mdHB28ZIe 
#undef  mtpa6CvplEq1shGwk4jxI 
#undef  m_Ww9T_ZoqJhMiIY0i1PJ 
#undef  myydjxqnidOfg3YXIPfCh 
#undef  mp1kzPPa8GX6cfigPyiyD 
#undef mJhsXXxCEc7EzwcyisUS8yU1EArDvv5
#undef  mMAhLBm751iJ4jZTmz1eQ 
#undef  mJivUzVExUJxvLMyR7vcv 
#undef  mVjuVop3osym9wWoq6p3w 
#undef  muLh_AegzBLvbYcxrsotS 
#undef  mQIaw42evZrZGmIhV_U05 
#undef  mdokA2SxdolKVBlsRM2BI 
#undef  mxpEdWbhRRjZ1JMh3yxwy 
#undef  mqZevfxEDPOS7RkGEtJFp 
#undef  mxTwhHDgHBwIAa0Dytqva 
#undef  mrS2zvlmrTf4L4KBRRYAU 
#undef  mutzl2HCpJ5IWzF1P08Yd 
#undef  mR8MpflZg6lk1qLQLX9P9 
#undef  mZTdKHHWXvp9nTqOl4Xs2 
#undef  mlZKVlBR7p58b0kfu8tFd 
#undef  mltszUqwX6pYfxYVtnKha 
#undef mmG8ZucFjVjdpE_4gG32Ai2kdULxHoD
#undef  mRwYPGmWUou3ixNnKEWbv 
#undef mKyEK_R1QxAe18GNGI1HAEUse28S19p
#undef mwQf1bclnsFMVqDYMJIbXxS45LZCFBv
#undef  mwJXVmZ8MTqFBwgPAlydy 
#undef  mIBLQ6_qDoS3S2lLQGZ3e 
#undef  mJPHiCuIoYoltwiwwrI8_ 
#undef  mB0fx5ZWEe2g8Ci7LIhmM 
#undef  myX_vRc3UBQw14UHIrg7D 
#undef mZ1ddPtgQf1469AgXd_hnhYWrItjdpa
#undef  mqLizGA4Z8QZ_2GYQ1inC 
#undef  mYJ8ThnKYhVFrfXpP62DT 
#endif
