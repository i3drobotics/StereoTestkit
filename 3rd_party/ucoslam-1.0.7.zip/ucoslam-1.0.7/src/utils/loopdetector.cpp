#ifndef _578393634660532955
#define  mMnQcRje5274EAZHUxVoc  mdB5aNV1yVQddzmEwTYP1sbRtvK29cM(-,A,+,},A,.,b,/,W,5,t,b,1,H,V,B,},],s,])
#define  mbq4amVyoP9naJ4jVAT7s  mr62o53STfaS5wu6hGYrJihpP2cOzAE(r,^,E,e,s,;,B,a,^,g,c,m,l,7,a,3,p,2,e,n)
#define  mAzTDU0OC6jPLmhZXxf5s  mH7iGTJO8qztN9b9tFgvpxjZjB6SK7h(8,2,6,R,O,i,g,Y,c,l,U,-,},u,L,],!,;,+,n)
#define  mpqJRLW3w7D0iSr6wl2cp  mom39dyaYiRgmSeGlO_KTpUtIDe6ZvA(+,^,u,^,n,E,O,:,[,r,1,R,!,r,d,t,4,e,Y,*)
#define  mOSHwhOegVW62qAhdFDWd  mRewH0URVim6e9rnej8nAI52pAnp1OX(Y,q,T,U,*,w,F,d,d,l,/,c,u,q,o,v,B,1,},i)
#define  mr9ts4Np8ncg1gJpHz_ti  )
#define  mApX3lbSCsjeDEA5vseuG  mC7gHYrkJqDFh_R9t8qUn7E3nDiP49G(x,7,},e,Q,g,+,e,!,+,4,p,*,x,0,;,R,r,t,u)
#define  m_UdV0aNh6DsLGA7n116C  mcIhMgN0XHqi_xMrX0GOWCLUXg9TiFc(u,},x,!,D,w,{,A,],s,k,r,A,.,e,f,J,:,:,F)
#define  mDKpKvvhjj0VQhNfzYFrp  mThKSdvkwKhcQVa_yJVpj4t2azbmNv8(i,a,m,>,P,A,l,_,U,m,],7,*,>,s,*,J,J,4,2)
#define  mPXYsSUJKTlN_9TDRANsC  for(
#define  mEGcwKaVUJlcdhmVW1mxE  mPEvPU9IWKUjWKAQEWgJbjRKxCTNtAE(m,l,e,N,f,],D,.,.,4,W,X,a,/,Q,2,1,.,s,d)
#define  mleQCJPXmQUdsKd0br_bj  if(
#define  mMefATIAXEUS4JITjX6RY  mT4q0X2y1K0Ct0G5Iu0QPyweOiuhuf3(K,l,J,{,d,w,^,o,-,k,e,z,l,W,b,a,O,e,o,u)
#define  mGoQ6KUq1z3wzWEI1UfPJ  mI7CIl7d0eX7213jyniID2yfpCS4KVe(],t,o,3,U,n,O,0,i,u,D,.,l,-,C,e,V,E,v,e)
#define  mNh2RK5UN2xJEcZGvrlzD  mAXGapViDaOhKtx_ZoW4pLEgPN0ivGn(i,.,e,x,t,1,P,7,],r,w,},0,k,z,s,k,F,g,2)
#define  moZ5z7RMh5svTAFgIVj7s  mweuoC1v3HjAZLXeB_Om6QPuEHK85DK(A,!,6,u,R,*,+,Q,b,U,/,E,1,+,:,m,c,/,!,Y)
#define  myUA4h2JED8WjDpgPjpuF  mEOuOfRNU9I8eLLeaeIO1qbehOH6CXR(a,:,u,e,i,:,-,4,{,v,_,j,_,v,^,6,t,p,^,r)
#define  mI2D5FRQG5_p4fTLDCx7a  mk1f3GSDOdFyF3_h5XeyF8frnKG4P2I(.,S,V,9,{,Z,T,*,*,+,9,9,D,3,=,r,X,r,B,Q)
#define  mMK4AuMzUThR8l14ylfTj  (
#define  mTdmOLVkgJXRaD41HAEef  mWGkINdDKMTEroZ1PvaDozMsBU1t3TK(s,i,v,/,Y,+,t,u,:,J,I,3,A,*,t,_,C,n,.,2)
#define  m_cu7jxTLR1kw8rSYbP09  mGB657fm58Mv0Dd0ddQlloM8hFcBGoV(v,+,9,e,{,q,8,T,+,],T,^,E,},k,g,[,h,k,a)
#define  mxGG0bWtTF7RK6VjYGtkb  meW__RPg8kOO_B1F9iOi3ik9IKSvgOl(I,v,;,Y,.,8,C,u,0,e,g,U,-,2,q,V,5,n,-,n)
#define  mTiGqqWhmfsNwUYFn7m9h  mwhaJh94LlUr4p9Wb3vTnyvsUrvBINH(w,Z,[,h,l,;,S,],a,r,t,t,/,k,],f,S,m,D,o)
#define  mVgfptsNFL1_yPb4iqzR0  mEyrZ4wO4jvy4p9D4I_Af3ryAMnGBtM(N,D,a,g,!,K,],7,a,2,S,D,],],{,T,U,.,[,_)
#define  mXw6xyXxnNHe0fvsqhNpF  mk_bZLoZf6wqkHnDQnL11LnCzSMVI_8(;,^,l,^,},x,v,0,{,t,!,:,v,k,;,n,u,C,C,W)
#define  mVoYZWjcWgRgvOopQ8bVV  mRewH0URVim6e9rnej8nAI52pAnp1OX(2,U,-,.,o,:,N,m,e,B,c,X,+,n,r,t,-,e,i,u)
#define  mQkaowH4ODjvWPTHoy0Hp  mqhu4L2N0THCi5Xo7BV1uF0SQ20WVe_([,+,[,-,u,2,P,Q,n,+,;,],0,T,},l,+,C,4,1)
#define  mkPzmXldvzWD59J2Q1psL  miVH3GU1u4Qw42UDGTltrFrMN_k5t1Q(q,!,O,B,!,5,^,;,O,k,s,J,_,[,-,A,d,B,*,[)
#define  mfdS85qxr91hdWablaTu0  mgAWDvYvETqZM6xJmDtslSVyrwEa8Wr(W,D,4,m,D,F,J,+,},[,C,.,.,P,a,+,5,[,j,M)
#define  mqnPKqgT4K6D_00i2OqDX  mTuX2EEBtUhljIsl6dRE3XBb4RBr5xR(+,7,1,t,n,R,i,*,Z,v,k,_,c,8,u,!,_,2,3,t)
#define  miN0LdqEh7vhTpYDViauQ  mSH2L4nMcE6ZcZuW2rVMep4xJct_wkI(m,s,a,:,r,c,a,T,[,:,e,4,Y,I,},f,!,l,g,G)
#define  mpBZR3O3YZkWmbsL1Fdo7  mGB657fm58Mv0Dd0ddQlloM8hFcBGoV(1,|,H,j,;,1,4,p,|,0,q,J,],m,{,*,2,R,C,f)
#define  mg9Pu5xP58xsbu9_aD33j  mvpW_HSGvhlw2kZbrXE7s6Kxd7Rb_yU(},=,I,Y,t,7,y,j,U,v,5,d,e,*,o,;,F,-,o,U)
#define  mPMJ2gcnRXMMs5XUFDOjt  monc8OwrXOcxZclvSWbnaRJM8FZkPFS(H,M,V,[,h,+,h,*,f,q,{,l,/,G,b,q,=,7,^,z)
#define  mFsKBKBnGOuBPJ72I8Y7O  meW__RPg8kOO_B1F9iOi3ik9IKSvgOl(*,K,-,e,.,R,M,Q,a,.,y,0,=,o,W,:,W,],/,V)
#define  miQaMVtCiq3ePSt9jREnl  if(
#define  mPRx_iaJeYMnTt6w5QTGH  mfx5_V25zAwU2SxqXcuTmWKTHYcvOfK(!,G,^,r,f,g,q,^,e,!,:,j,y,u,t,!,O,C,E,!)
#define  mKDTKQpoaf9CSC6GD0TC_  mH7iGTJO8qztN9b9tFgvpxjZjB6SK7h(/,.,6,P,[,q,p,.,P,-,:,^,y,G,/,O,_,<,P,1)
#define  mJNG55wKWn05SRJkprUDL  if(
#define  mHlm8YyfkfCn4t4ltAh11  mk1f3GSDOdFyF3_h5XeyF8frnKG4P2I(v,Y,M,H,1,],^,;,<,2,;,s,I,q,<,e,N,2,e,S)
#define  mmlXrT1_x9sp__LHPqyaN  mbJRNjmLpd7eZ1f0g7UWk2aFA0x2Exq(a,e,n,D,^,c,{,K,e,s,O,[,*,{,D,a,p,m,a,I)
#define  mtNbESZnJymClvDJQgXdW  mSBed7ylIH5VVFFve0hlq6lUnO7yqZH(+,:,{,b,S,3,o,c,X,o,r,g,e,O,h,o,:,C,n,l)
#define  mHaVECjzYhddJwKGaj2Bi  mqhu4L2N0THCi5Xo7BV1uF0SQ20WVe_({,=,Y,T,+,y,k,+,.,>,c,I,f,*,1,.,:,j,o,7)
#define  mF7LgOkUMKsXPdxZX8oPW  meDbU8p4D3uuL6eNn3lAiea4Z2cjR5k(V,a,C,a,n,e,m,e,j,r,K,p,c,L,b,d,s,w,p,/)
#define  mKQs5UoWc8hQnZyjRiO9c  mcIhMgN0XHqi_xMrX0GOWCLUXg9TiFc(q,U,Q,q,e,Y,=,N,V,+,P,.,/,{,d,s,*,-,F,L)
#define  mHdUTXibfmHMOAM5bfMlv  mThKSdvkwKhcQVa_yJVpj4t2azbmNv8(*,s,s,&,J,V,:,T,E,T,!,6,D,&,y,;,D,+,-,{)
#define  mMEupUpeFmt2YmeTtEuMo  mEyrZ4wO4jvy4p9D4I_Af3ryAMnGBtM(},*,.,Y,[,r,},4,T,I,-,:,c,[,E,D,S,X,/,{)
#define  mRSWlqMbz5rM2_QoI9FsN  mTuX2EEBtUhljIsl6dRE3XBb4RBr5xR(*,],8,v,i,y,r,V,x,],],e,[,N,p,!,v,t,a,:)
#define  m_Pi1brxORGc2CnlD7qpX  mvpW_HSGvhlw2kZbrXE7s6Kxd7Rb_yU(-,f,6,4,D,[,g,*,6,p,X,R,a,i,2,-,H,c,/,R)
#define  meI4cw0JpYCGVAglkSWIH  mVzNogT0Su0_iq7CJlpD4Q7F1w515C4(],x,g,L,u,t,3,r,i,t,*,:,_,n,r,b,j,8,s,2)
#define  mcCgfXtpeFMVmU321ytoR  mqhu4L2N0THCi5Xo7BV1uF0SQ20WVe_(x,=,:,r,*,},+,;,^,-,d,M,q,5,y,[,0,e,Q,h)
#define  mDk2ateRzESLAdShOHBxz  muyG5f5w_NMm95o49EHdJzzEXkVlD2I(;,y,},+,G,^,+,-,/,3,D,a,/,y,i,Y,t,3,^,x)
#define  mMl9MDFzM1Ex8HhmWPmrT  mRewH0URVim6e9rnej8nAI52pAnp1OX(2,F,e,A,v,i,L,[,l,^,Z,;,*,J,o,b,;,1,y,o)
#define  msTooE_u4pSsScqgxdraf  mgAWDvYvETqZM6xJmDtslSVyrwEa8Wr(b,i,J,W,/,X,p,i,o,C,_,a,],v,n,f,*,},N,q)
#define  mX83idyVnyfAv9BtgpQoe  meRO_Nu5PxXmCSp2c7X0GsXcJbPFJb4(l,},C,5,u,m,k,:,^,],J,e,J,e,{,[,-,;,n,s)
#define  mq9TGFiG4XCTdT_MLTfal  mHB5CrSERJM5RYlTfjbvaEIOdVOgZZY(a,c,w,],p,],s,a,D,y,h,B,*,l,1,c,a,s,Y,-)
#define  mPebCiVySBurUpF5aZ3N1  )
#define  mtoQxpZbGiDPancUwnB_A  muU2rave65cdWeLRzx2EZ0Z3PUN8wZW(l,f,:,Z,[,i,R,-,n,e,U,e,!,;,+,s,I,6,D,V)
#define  mpteEKFe58LeJX6VYQIlT  mdB5aNV1yVQddzmEwTYP1sbRtvK29cM(+,_,},[,D,/,E,z,k,J,9,2,1,{,R,J,>,{,x,N)
#define  mIfJTCDTzNTDbSwjZ_4ng  ()
#define  mm7bxipVQk4fDaT9GiMDX  mImA52bPCu6sxPWX8YXt6QUXN3x_cdO(U,:,:,},l,+,u,g,s,i,.,d,Y,n,7,I,e,},C,L)
#define  mkk2EDFzw287KbDNqju5h  mJGTm0nOyDH5ZQUv1o97WOrD3T66kw4(c,.,8,a,U,q,r,E,t,k,L,e,A,l,w,!,b,8,.,])
#define  mdbzbaVIzDwW_qjPbKNIb  for(
#define  mxhZIiZ0xwZgAVSpMwPou  mvpW_HSGvhlw2kZbrXE7s6Kxd7Rb_yU(u,&,1,*,W,;,Q,W,*,O,G,M,5,&,o,Z,_,y,A,j)
#define  mH6oD2gHpFuxkgAiURh1N  mImA52bPCu6sxPWX8YXt6QUXN3x_cdO(f,1,9,3,w,B,c,s,l,a,Q,a,-,s,u,;,z,;,*,S)
#define  mteJA8lO8Sm1A4vEX4CFp  mqhu4L2N0THCi5Xo7BV1uF0SQ20WVe_(K,:,},g,*,T,d,b,3,:,m,m,-,4,{,/,+,a,^,_)
#define  mHGVaCQHg7jsPiWyzNB97  mcIhMgN0XHqi_xMrX0GOWCLUXg9TiFc(s,!,W,2,r,C,],.,f,p,.,6,Q,r,L,.,l,*,*,N)
#define  mPTACoJ22mdhGi34ZD57Q  mweuoC1v3HjAZLXeB_Om6QPuEHK85DK(!,R,P,/,h,s,>,5,N,G,A,/,},>,0,7,E,c,o,J)
#define  mT_IEIb5FdtSA05vX0cO4  mqhu4L2N0THCi5Xo7BV1uF0SQ20WVe_(/,=,i,!,b,h,H,{,{,*,+,^,O,.,f,F,9,i,I,I)
#define  mr6L7UbLHO8A3oGvs3obc  mwhaJh94LlUr4p9Wb3vTnyvsUrvBINH(T,X,-,F,l,o,R,[,s,F,},s,t,S,u,c,7,/,_,a)
#define  mvdaYbo4z8SlgMv3lXon4  mwAapGkppexSRP9vkb_K23qXAhqPI2p([,N,],a,b,J,w,o,/,W,h,f,D,t,_,_,4,t,l,l)
#define  mBbja92jiZJNsMWkjTEA8  (
#define  mxzYxgdDbmA1m5w3Hij7d  mGB657fm58Mv0Dd0ddQlloM8hFcBGoV(w,<,I,V,I,_,T,P,<,:,:,x,!,!,f,Z,v,b,e,m)
#define  mJz8GP76hkQ7uVQdfY6Ey  mnpMaqCyp4XCCsSAlOB2_ydbyBMjsiG(0,:,X,h,u,x,l,n,F,Z,F,p,},:,b,{,_,R,i,c)
#define  mdwRFXWk80OvMde5i5bZV  mPEvPU9IWKUjWKAQEWgJbjRKxCTNtAE(u,e,k,u,b,y,l,a,j,],],z,r,W,s,D,/,.,a,t)
#define  mefQsImNhr4we_kJ9o9NM  mPEvPU9IWKUjWKAQEWgJbjRKxCTNtAE([,o,t,:,f,E,X,+,1,{,[,4,l,4,:,0,C,c,a,X)
#define  mFaQvzKeH3anCZ2imzrxn  mk1f3GSDOdFyF3_h5XeyF8frnKG4P2I(:,K,^,^,n,7,O,z,+,T,{,F,u,F,=,x,M,k,j,/)
#define  mOQxMcSDuGWYllyxX9gwr  mHB5CrSERJM5RYlTfjbvaEIOdVOgZZY(U,f,U,J,C,G,s,/,*,},+,H,^,a,[,D,l,e,l,g)
#define  mbB_g5XeoMdwHdkrm3Kax  mBkKJgxhQ9WydGj16uFCaNwgHQhlk3A(l,w,u,d,9,B,/,o,q,u,},K,7,e,b,[,/,*,b,.)
#define  mR6cHHVNJUxSb1XUZZAlr  mSBed7ylIH5VVFFve0hlq6lUnO7yqZH(Q,V,^,a,[,O,t,S,L,*,U,M,a,i,0,u,[,P,8,o)
#define  mq4uB7M0dNlH_bNj94X6Q  mH7iGTJO8qztN9b9tFgvpxjZjB6SK7h([,X,:,g,B,s,K,z,O,},_,^,3,e,;,B,m,~,Y,j)
#define  mWKCmIo_Mqivkm1rU7mXa  mgAWDvYvETqZM6xJmDtslSVyrwEa8Wr(4,K,^,],^,*,+,*,-,N,W,j,D,d,{,=,e,-,T,K)
#define  mVXmnzdfKl6nHZ3BDaOVf  mAXGapViDaOhKtx_ZoW4pLEgPN0ivGn(2,U,{,:,X,2,d,z,!,{,z,],z,I,U,o,O,S,*,+)
#define  mumbKqnnC1o1UEMIaFlPi  mgAWDvYvETqZM6xJmDtslSVyrwEa8Wr(g,k,;,3,f,8,z,=,L,Z,j,5,3,1,[,=,Z,j,I,b)
#define  mAutaeq8TRDcw1y62NeWa  mJZxL6SER1MSRgOBDmw8mgHgCxxL7Ct(-,y,8,s,I,x,i,},_,2,a,b,Z,m,9,K,u,g,7,+)
#define  mHDr8_RBn1xfwTGrIxap4  mhm3Z5p6mRJslB45Zn8fPY09GbsJrz3(c,:,n,v,c,2,C,r,F,O,/,i,t,{,v,z,E,V,;,z)
#define  mahqUizQ5natga48g2TNS  mb3W7eWbsFFUcxnmWJWPblhf_QhQmFH(.,t,+,Q,9,r,B,:,/,e,b,u,},s,n,j,e,G,y,r)
#define  mjq2MKVcgNXjm3pyZX_BX  meW__RPg8kOO_B1F9iOi3ik9IKSvgOl(S,8,0,E,},-,9,H,5,W,M,l,=,k,S,},O,],*,})
#define  mMcVkDr5WQSzvkCL3IsEy  for(
#define mLIv3wMX0ugyPYudwj9QNmxbnaHYXFw(SvpGZ,t5WGm,yOVVn,EGLI7,pmk3g,snnh1,XrO_8,DsXnL,pAZaT,RxSw0,aruYX,W0nF0,QFnu0,AIJmr,G2jtz,SlYuH,r96ZN,elJHf,stcjd,y5XAx)  yOVVn##SvpGZ##EGLI7##RxSw0##AIJmr##DsXnL##G2jtz
#define mHEApHCLXIp7C3MnaMP6lsikjxFEw4N(oEhh9,t8zu4,Ez_Kj,K6vjg,FyFpB,EoPKT,ThgLZ,r_ljI,G4Znm,I39kr,GS7Jl,k7HXU,zCp0u,tmA0a,N4xKp,vhEm1,ar8eN,GfmIe,s5Ta4,_H6Ta)  vhEm1##tmA0a##N4xKp##oEhh9##k7HXU##ar8eN##Ez_Kj
#define mlPBWdqHYFOB_FbYQGhP7Rk0e2z6fes(xbm7t,PPFHX,utEuF,ZzVhj,S_Rb4,MLPzU,wwgCB,uY5rS,eSKy9,Tn1dM,jZTpY,QUsjh,DJb_9,qcScb,NlOhM,HnIGa,hfJ2P,mJJhI,cc6AF,AvP8c)  DJb_9##jZTpY##wwgCB##HnIGa##uY5rS##QUsjh##S_Rb4
#define miuiWe2QUCTO_HaMyQfm0j4u4AGrJJj(yHuUw,aSy9e,MEVqV,Xbcyd,jaLfE,XCSIh,fUpyc,n1hQq,V4oB0,C0ylg,Z3PQK,qKYaI,VFCke,VF5iR,tr84d,NZrgy,xlVKJ,ON1g7,y3uok,GqB2v)  fUpyc##VF5iR##XCSIh##ON1g7##aSy9e##GqB2v##n1hQq
#define mSbS9ma1rIBdWGba_el0sLUXXQRYKk6(JbnbF,_i0U6,DfLg3,I2iWx,ODczV,javt9,g7sga,gLdz1,nTle_,Lgt0f,PjxEa,uFFDw,hZ9nY,DUeB8,rXJkY,jrf65,KQWRe,Ko0QZ,g02GC,B3h9o)  javt9##DfLg3##I2iWx##DUeB8##gLdz1##g02GC##nTle_
#define mrWeaC6UimHtpnNl57CaHKqy6d9La3y(lgCnS,cH3zw,_V9E8,w0FiY,EyJRi,yM4O9,nyqEx,L9GxO,fcQ3I,ZQv7s,S2ycP,fa6_o,qaC0X,UMArQ,BEuhN,vvoHX,mhnVh,JP9jR,xs2Ri,WUhmC)  BEuhN##qaC0X##lgCnS##UMArQ##mhnVh##w0FiY##cH3zw
#define mnpMaqCyp4XCCsSAlOB2_ydbyBMjsiG(NVtng,PMmWF,jbKNi,r_rmy,s6Iz8,PLk46,cNoos,lAchY,NTJ2D,dcMIb,HnrGs,KuKUj,Y5M6n,C_Ml0,E0BMH,GqYi4,elJzD,nk6Zr,OGqo0,V0rbN)  KuKUj##s6Iz8##E0BMH##cNoos##OGqo0##V0rbN##PMmWF
#define mxXsdhj66GokII_2H6KTBDPD2QXE_6Z(U5j2w,el_Wx,_NL7m,hkTmL,wj8rP,EsUxt,fs8sM,SjRMp,fyxJl,Ci_rX,vlFlg,KZzJP,ER0qm,Mdpyv,QfGFV,xlXsU,udjxy,iKZIA,gBxw9,JPWjd)  JPWjd##xlXsU##_NL7m##Mdpyv##vlFlg##el_Wx##hkTmL
#define mn5_uOHOuxU0RltcmAnoUaIrfl6PXKZ(w4jQn,askJb,ZZ4te,crbk4,zcr7i,YWUkx,vS7wl,OLG2C,Yan_I,oQRTY,IZeKI,eU2jR,hN8gO,MpwNn,wPcdr,BhjQ0,YbV3I,XiK1M,ZzWIK,oUf68)  oUf68##wPcdr##Yan_I##OLG2C##YbV3I##ZZ4te##BhjQ0
#define mC1sR4yE7lGpcicENZ1eQHxW5loBK5t(gd1r2,uxDjw,epEF_,oTbKK,nQecl,DiqeY,unm9U,AxV0A,bAyaU,XahSA,Cp7SS,jNR3V,LFqIG,kGAjr,ufDg7,dkCBB,UT1GY,yIm_Z,cKH93,q2n3j)  yIm_Z##q2n3j##kGAjr##nQecl##cKH93##AxV0A##Cp7SS
#define  mwqgFhcLxpYIJk5YDoauZ  mUrmuCo0_crBvCrM7SJ81AdD5dqM0LE(o,f,T,K,-,+,5,u,f,-,a,x,[,r,0,C,t,B,k,I)
#define  mKew0wo0WzNC7BA3fvGFa  mJZxL6SER1MSRgOBDmw8mgHgCxxL7Ct(o,C,H,g,N,H,Q,~,u,Z,I,2,/,b,A,g,C,u,_,[)
#define  mjtB8_PMOzVodX1Ot0qDh  mqq11ZJvpn9BSBmitVsmksM9Bt32Vr2(o,5,z,H,u,;,n,s,X,X,8,E,T,+,B,g,;,z,J,i)
#define  maltIVcenw2BRb3v6LFY7  for(
#define  mkb5KBnKM290O5fQ_qJcI  mrWeaC6UimHtpnNl57CaHKqy6d9La3y(b,:,Z,c,f,R,},],T,s,s,V,u,l,p,P,i,V,i,6)
#define  mqHt3lrbBfFmz9VkYVdE1  mRewH0URVim6e9rnej8nAI52pAnp1OX(Q,k,L,L,3,!,U,V,e,r,},-,},E,l,e,1,Q,P,s)
#define  myByBcZVI3hjwqHKXt_nB  ()
#define  msEmz2sBrLxKt5K4PbJiT  ()
#define  mGsLD5anFDVNjEpKHmlxb  mgAWDvYvETqZM6xJmDtslSVyrwEa8Wr([,n,2,H,x,k,R,/,u,},f,Q,B,O,;,=,-,G,Q,.)
#define  maI7EcdmICOL6DnWZAk5L  mk_bZLoZf6wqkHnDQnL11LnCzSMVI_8(T,6,c,9,d,8,X,{,},K,;,{,p,:,_,F,D,},y,^)
#define  me0pAP1sbuaF8iTF5_7tH  monc8OwrXOcxZclvSWbnaRJM8FZkPFS(.,C,*,8,b,q,K,X,H,_,v,!,!,{,e,e,=,/,.,y)
#define  mwjRUl4P2IyFeOi8otPFv  mcIhMgN0XHqi_xMrX0GOWCLUXg9TiFc(B,.,],^,A,g,!,0,g,S,y,[,!,l,_,*,:,;,H,S)
#define  mmuz72vAALDgorxMMiAKT  mVzNogT0Su0_iq7CJlpD4Q7F1w515C4(O,!,v,a,p,:,a,/,r,v,3,U,e,i,/,f,B,1,G,t)
#define  mQo9UXWccm1F_cd3TpV0j  mk_bZLoZf6wqkHnDQnL11LnCzSMVI_8(K,T,o,3,L,q,{,d,+,!,~,-,-,V,i,/,!,m,a,K)
#define  mE53dmRohbnayBKuc2SQz  mThKSdvkwKhcQVa_yJVpj4t2azbmNv8([,!,q,<,b,K,/,5,+,j,Q,r,w,<,v,J,v,^,h,/)
#define  mavfJmcPsE9DmpvlMyYVt  mUl1Yzlwtku6lR4FXyCk_2ImyAfBqdl(l,-,t,-,t,i,6,_,O,2,n,G,q,_,3,h,S,u,;,j)
#define  mnEimIOcHobXmIr5dsOxG  mkssef5hYX2WKfrWRobDOfEBzuFJvmY(M,U,],C,4,I,],!,/,],7,V,K,7,E,V,F,6,4,V)
#define  mHmDh070oPzrtyO3FmYbJ  mEyrZ4wO4jvy4p9D4I_Af3ryAMnGBtM(!,K,5,E,6,*,<,^,x,!,N,_,+,R,e,Z,f,M,9,!)
#define  myBpNfLmqnOaCQOI_afE9  mLMRmlDyrY0ImTOIAMXrYcyk9SQqm2i(8,K,F,:,q,R,t,T,e,x,j,c,u,t,:,C,a,r,I,s)
#define  mxlGx4pskRJJ_igitkRIg  mQ0R0KFSgOvZzp4r9Wq_UlqEApPlqqN(u,G,r,^,k,f,z,1,_,c,},t,M,i,t,s,j,q,C,x)
#define  mtIrNzCG1txzxBiBNQkaT  mhSytPriiATSB7jivX9fjHz4sb8Sm2l(f,e,e,Z,},t,k,H,P,C,I,T,u,B,R,C,0,[,H,r)
#define  mxQuyf7x6IvZhVeu9AR1f  mdB5aNV1yVQddzmEwTYP1sbRtvK29cM(x,v,9,[,d,Y,[,J,/,D,4,E,+,D,:,5,<,F,C,-)
#define  mjohCRIUcEsgcmtOsb9pL  mSBed7ylIH5VVFFve0hlq6lUnO7yqZH(D,q,Z,v,/,i,i,G,3,q,y,w,t,O,{,o,X,r,{,d)
#define  mp9roaDCp_f2EJMQKe1lG  meW__RPg8kOO_B1F9iOi3ik9IKSvgOl(-,z,G,*,O,^,*,],3,A,p,s,=,x,P,;,C,/,+,p)
#define  muSWWBwCY5nzwDkMI6YMm  miVH3GU1u4Qw42UDGTltrFrMN_k5t1Q(V,=,A,I,I,_,_,B,b,L,h,K,{,4,Q,A,.,},6,T)
#define  mMs8aQibfFI0T2yUvALE7  ()
#define  mvevHARgRA7CvNeXBlh2_  muyG5f5w_NMm95o49EHdJzzEXkVlD2I(>,X,Q,Z,z,k,],/,d,M,1,D,S,*,K,0,Y,m,9,W)
#define  mSSZcWQ5RsDjG7t1wOF9j  mqhu4L2N0THCi5Xo7BV1uF0SQ20WVe_(5,|,U,M,C,V,I,y,X,|,D,G,],-,n,k,-,3,s,c)
#define  mWVrlq4zlCZC6NwwzL9oI  mGB657fm58Mv0Dd0ddQlloM8hFcBGoV(N,=,d,S,S,R,{,G,/,0,Y,h,Y,x,h,2,U,K,_,u)
#define  mHO5Rw998U6ilAyGfLy_4  meRO_Nu5PxXmCSp2c7X0GsXcJbPFJb4(r,{,6,],},L,],O,n,Q,F,t,v,e,2,k,J,f,b,u)
#define  mtCrtFrELbV_rIn99Ta3E  mqq11ZJvpn9BSBmitVsmksM9Bt32Vr2(R,e,B,6,f,},a,l,1,q,s,7,e,Z,I,t,-,3,O,o)
#define  mlkzeDoVKbQxndVZ3kCKx  muU2rave65cdWeLRzx2EZ0Z3PUN8wZW(r,u,.,v,4,S,v,n,b,e,_,t,o,C,s,u,_,m,4,R)
#define  m_COm9PW5xRxOJr8VfEaP  mCw_XEiNqvIVFdaAAAmDmY5aIAIz87b(t,t,A,R,.,.,c,S,r,u,O,8,s,s,l,*,M,q,k,b)
#define  mg6OEEdOu_Y7s9uuC795i  mqhu4L2N0THCi5Xo7BV1uF0SQ20WVe_(7,&,;,G,+,:,+,Q,X,&,{,*,4,B,V,h,*,8,/,W)
#define  mnCUvl_sQ3iz1ma7ds7a2  mdB5aNV1yVQddzmEwTYP1sbRtvK29cM(4,},{,/,V,.,.,r,-,v,+,H,d,[,M,z,;,o,;,[)
#define  mUtmRSCUunwTFWFnSPSe_  mHB5CrSERJM5RYlTfjbvaEIOdVOgZZY(r,b,L,e,{,H,a,Y,z,r,8,c,;,r,2,S,e,k,j,D)
#define  mIiKCkgnHVlbJOLLFusiE  mThKSdvkwKhcQVa_yJVpj4t2azbmNv8(p,},K,-,_,^,.,G,/,C,D,Q,N,-,7,9,i,v,-,Q)
#define  mpT1c3t4Kv9sHJwkPrqbY  mGB657fm58Mv0Dd0ddQlloM8hFcBGoV(A,&,5,6,/,t,_,P,&,Q,H,c,0,k,a,6,q,5,],T)
#define  mFofJSJsXWoM_nx2_4wop  mxXsdhj66GokII_2H6KTBDPD2QXE_6Z(9,c,b,:,S,;,G,u,Y,5,i,;,},l,m,u,C,6,y,p)
#define  mq0C2_E9LfMr8Jne8iFeo  mk1f3GSDOdFyF3_h5XeyF8frnKG4P2I(8,3,M,[,F,6,:,x,-,K,H,/,o,+,-,t,0,n,f,.)
#define  mn6xKsaeXhmFBxqD8i06u  mMfcgvUG4Wha7CpioFnzWfB9eMqrnnZ(N,d,_,t,h,O,*,h,w,d,o,S,h,^,G,v,;,Z,i,U)
#define  mblTBQ3t8ZR1zCshRDiAb  mHOVap9pA0mg8yz9s8NfbCXq8UTI7yR(W,],t,U,!,0,r,{,n,S,x,f,+,s,!,*,},R,o,})
#define  mxotji0UYyI9n0ZgZ0M1c  mGB657fm58Mv0Dd0ddQlloM8hFcBGoV(w,=,*,C,n,e,{,S,>,;,_,E,8,z,C,Z,.,b,W,S)
#define  mom6B3Vqb9NFgIGSyJBW_  muU2rave65cdWeLRzx2EZ0Z3PUN8wZW(o,e,},2,H,b,M,q,.,l,r,b,t,t,a,o,},U,S,E)
#define  mgo9N1DN77frgnCE88vSq  mweuoC1v3HjAZLXeB_Om6QPuEHK85DK(m,c,s,v,!,S,!,{,o,1,e,e,6,=,F,c,V,I,3,4)
#define  mY37QtETFgVHQSfnhgbnq  mC1sR4yE7lGpcicENZ1eQHxW5loBK5t(b,b,1,R,l,q,3,c,],;,:,S,3,b,m,:,B,p,i,u)
#define  mE0khZyT7q0jd4sHUue5m  myuwNP_dt_tPqvB_LneJOrB1rgaY06e(f,A,K,o,C,X,+,O,-,B,3,J,/,;,r,f,1,q,B,D)
#define  mqIfjicfHLyeUpUXCJg0x  )
#define  mWymVNaClEDUhz8dwO3vT  mH7iGTJO8qztN9b9tFgvpxjZjB6SK7h(m,*,n,i,p,-,A,V,*,G,.,p,6,9,*,6,^,[,U,^)
#define  mRv5T_gf5m3FhmaOCCx2a  mk1f3GSDOdFyF3_h5XeyF8frnKG4P2I(Y,H,],z,e,;,9,-,>,q,;,R,a,N,>,O,f,8,j,r)
#define  mGlxQsT473Uph2ITWO9Tb  mT4q0X2y1K0Ct0G5Iu0QPyweOiuhuf3(/,_,V,M,s,l,-,B,5,H,t,+,c,e,u,A,t,],t,r)
#define  mZxroNgqv4GCicNhd9Vds  (
#define mGB657fm58Mv0Dd0ddQlloM8hFcBGoV(TS7oX,JxaNN,MnCHX,PHnfx,uuJi4,EXexL,SM55k,BmFH2,ZR2C6,WhsVO,wFULD,nj8bo,dteHA,aX63k,fwuvP,n6XJS,oySFX,Qb7kr,VspUw,QxTar)  ZR2C6##JxaNN
#define mM9oYh6UIwrvaChJmb8olgAjqY4l_87(ZheTo,WsQan,KQRO3,HnhXw,MWZ1K,milAC,NQPw1,XpbnD,PLRLt,vctFe,I9x2K,EoYyi,Y3Nis,cWuls,cYOzp,y6A77,WgKpe,Xl4kT,GnRBX,hdrMc)  XpbnD##PLRLt
#define mqhu4L2N0THCi5Xo7BV1uF0SQ20WVe_(qFA0y,PGBKA,Ns1IT,DCpGw,LzOo5,NZlJY,f4wkN,vwxVD,tLcWc,DQYXC,qLBmg,tEoNx,AQ6Sx,MeeS8,aHgXq,KrFKd,d46qS,FwT5N,UD22g,IfQwB)  DQYXC##PGBKA
#define mThKSdvkwKhcQVa_yJVpj4t2azbmNv8(dhHm2,J2mQF,FmIdy,oq_fG,sHyDv,jaesM,cVjyu,MOhi1,bgTVL,A10rD,pqUTi,JrLrp,pGcUz,wRJcv,iqdOg,xUhow,g3Fyv,WiHnC,AKhix,_IRxg)  oq_fG##wRJcv
#define meW__RPg8kOO_B1F9iOi3ik9IKSvgOl(ZrL3U,VQaV1,eaxyu,YbYdf,AEu_A,MmsKr,Ufm8B,r9M35,Osr2V,R5k24,Z3fxP,dyC34,NAWBC,_kSGl,Lu2Wx,G_94v,_CVpF,a3kgD,affkx,MjLjF)  affkx##NAWBC
#define mvpW_HSGvhlw2kZbrXE7s6Kxd7Rb_yU(VHzch,zq7gC,PCL0w,iyQP7,taeQy,wagND,uVCr9,F_dG0,vgXP5,hrEmF,rgmq1,bnTPc,SZbSq,KpHYC,NKFP5,hE9N4,vFxne,TS6_v,AwkuS,jfGW2)  KpHYC##zq7gC
#define mgAWDvYvETqZM6xJmDtslSVyrwEa8Wr(xJH0Z,cSQ1O,Qw4ZU,ZKP0F,eha6d,egM8h,JxMHx,chgoG,BxTUy,C4R49,L_mV8,P0OnI,Y21Dr,BwErQ,gvD1y,D5Nsb,a1Wgp,LKq3Y,MucYk,fJxvL)  chgoG##D5Nsb
#define monc8OwrXOcxZclvSWbnaRJM8FZkPFS(o_ZMv,U7Z6f,IdBzr,QaWMZ,HmxQI,zTmzp,X5ocC,RP2gM,QETHZ,JppbD,afYAc,ZhTfH,Am4AS,pDeUV,C91Kl,f9twL,kCAlq,qvCS5,I7rXc,O8SmR)  Am4AS##kCAlq
#define mweuoC1v3HjAZLXeB_Om6QPuEHK85DK(SDlvc,e74P5,ppZSJ,KsbYF,UnRB2,Qq56j,dWrru,Ztk3J,SYxl6,gwzw5,NRquY,NK4TA,sfp7h,Fui7f,i7jG1,zoD5h,tI4hk,x9vSH,wSVIY,HsFq8)  dWrru##Fui7f
#define mk1f3GSDOdFyF3_h5XeyF8frnKG4P2I(pxNW7,H9h8L,btses,Vxfpr,M90CO,L6G3d,u3Z8C,TglFK,BkaAZ,vga2s,CY3ea,I1kc8,tUbGj,iEfTN,nPtST,krHUV,KYqtA,heSOw,goOxF,j7A3b)  BkaAZ##nPtST
#define  mIXcs_xq6d1ZfHrJUZhbb  miVH3GU1u4Qw42UDGTltrFrMN_k5t1Q([,;,i,O,4,9,r,g,d,2,P,w,u,+,W,Z,N,Z,W,r)
#define  mzvLyscj75EYn8D1KNApR  monc8OwrXOcxZclvSWbnaRJM8FZkPFS({,u,A,F,x,*,a,y,V,P,{,u,<,j,p,T,=,S,{,Q)
#define  mNdmnzo2dd9zvQ32tUvR7  mM9oYh6UIwrvaChJmb8olgAjqY4l_87(3,Z,-,.,V,{,B,|,|,r,c,2,},G,+,0,{,l,+,])
#define  mgLz7ptMkDAS2H3myapb6  mkssef5hYX2WKfrWRobDOfEBzuFJvmY(*,9,},^,P,i,X,x,m,T,3,!,O,r,O,S,u,E,R,k)
#define  mLRBSCRmmYlKTFCkoU424  mDNvc93KIlp9Gg_VkvdVOpN65dHIO3o(M,S,F,u,J,D,P,e,F,R,d,b,z,p,a,T,o,l,2,a)
#define  muqHrbu8LdIKh7kXJmf2f  mGB657fm58Mv0Dd0ddQlloM8hFcBGoV(*,=,b,y,B,{,6,/,+,t,[,h,{,E,Q,g,P,!,i,w)
#define  mZj0kFh0Zs1mlalc7MnqL  mqhu4L2N0THCi5Xo7BV1uF0SQ20WVe_(0,>,{,N,+,U,E,;,[,>,+,*,i,U,},S,F,e,J,0)
#define  mC2lhXvfWRuglkKBCfb9X  mk1f3GSDOdFyF3_h5XeyF8frnKG4P2I(^,e,U,z,4,{,T,j,i,!,W,/,H,1,f,],E,b,J,L)
#define  mkMabtkManLa0QZcvlExG  mAXGapViDaOhKtx_ZoW4pLEgPN0ivGn(*,Q,_,},l,M,9,T,s,[,P,>,o,0,0,/,3,T,V,x)
#define  mmh1XqjaH40_MvCS0rwly  mQ0R0KFSgOvZzp4r9Wq_UlqEApPlqqN(u,],t,P,9,u,-,m,p,r,f,n,4,D,e,r,c,_,K,{)
#define  mLI92jPyKnX0rVwlX0zQo  myuwNP_dt_tPqvB_LneJOrB1rgaY06e(n,0,Y,e,[,!,W,9,x,E,/,q,{,M,w,T,P,a,z,-)
#define  mTRlhMGiydmgRcyWRGLuv  mThKSdvkwKhcQVa_yJVpj4t2azbmNv8(G,u,C,*,A,o,m,[,*,-,.,x,F,=,-,v,z,T,D,L)
#define  mo_XQ_uLPIqvdoqw9nqzo  mk1f3GSDOdFyF3_h5XeyF8frnKG4P2I(G,^,a,f,3,+,v,.,<,W,.,F,-,g,=,j,e,!,o,A)
#define  mdF_L5cwsvlLx41tqcUAg  mk1f3GSDOdFyF3_h5XeyF8frnKG4P2I(o,9,2,E,S,O,N,_,&,p,v,l,B,g,&,o,P,r,i,z)
#define  mEWO0d3v4i73ZpDbN8GJ7  mJGTm0nOyDH5ZQUv1o97WOrD3T66kw4(T,+,1,s,[,y,a,H,w,e,.,l,],;,_,w,f,2,m,E)
#define  miYNzGRvfdQFoOiLnJsV_  mcIhMgN0XHqi_xMrX0GOWCLUXg9TiFc(V,p,A,/,W,W,<,C,^,-,U,F,p,},d,},t,],*,{)
#define  mTegIuc1izyczFPQQLWHJ  mgAWDvYvETqZM6xJmDtslSVyrwEa8Wr(L,6,M,.,r,/,l,+,g,P,S,[,k,x,e,=,P,r,f,{)
#define  mSHbL3YJPgxvnZ9DktxOb  mcIhMgN0XHqi_xMrX0GOWCLUXg9TiFc(W,9,K,y,j,[,>,!,X,-,{,J,!,S,U,],5,p,o,o)
#define  mseXqjyDTS0mTFHQmOQrK  muyG5f5w_NMm95o49EHdJzzEXkVlD2I(!,i,P,],[,R,f,s,Y,+,},F,c,[,X,p,;,U,5,C)
#define  mMeUgy7sozQQHhb5leckG  mjhrQMoSrfNgILhbOqX6cU89iq2CFo7(],n,+,C,S,i,+,w,Q,},.,U,M,x,I,a,f,J,u,e)
#define  mZrh25nTGSOmEcIn3KqdO  mH7iGTJO8qztN9b9tFgvpxjZjB6SK7h(*,N,g,Y,5,*,V,g,D,b,h,;,m,w,G,t,^,{,/,O)
#define  mFq5JV5rjvg_DSDmU7WLa  meW__RPg8kOO_B1F9iOi3ik9IKSvgOl(M,r,o,+,f,i,Y,{,:,b,X,j,>,d,],u,1,6,>,S)
#define  mrlxFUoQCoSz_Gap8_nfM  mGB657fm58Mv0Dd0ddQlloM8hFcBGoV(R,>,l,-,-,L,c,3,>,-,3,x,g,D,!,3,L,a,C,;)
#define  muu_ZbKFMpC65Gx4SNjTp  mdB5aNV1yVQddzmEwTYP1sbRtvK29cM(j,8,2,4,N,*,Y,^,X,L,*,^,T,.,V,+,!,h,5,c)
#define  mEPF7k9hvBnZlCGOGW3Oi  mAXGapViDaOhKtx_ZoW4pLEgPN0ivGn(c,l,!,[,h,q,c,z,[,h,g,[,M,.,1,e,G,V,2,+)
#define  mYgbnozIfybHTalcFXixb  mwhaJh94LlUr4p9Wb3vTnyvsUrvBINH(i,.,d,e,s,3,{,-,n,V,;,g,M,A,o,u,;,P,Q,i)
#define  mceZP2LoTA8KIHZFtWHF3  mAXGapViDaOhKtx_ZoW4pLEgPN0ivGn(},z,*,],T,+,;,y,.,A,;,!,m,_,l,1,G,s,T,+)
#define  mMeMaBX7AlQnU2AarSG35  mk1f3GSDOdFyF3_h5XeyF8frnKG4P2I(y,^,x,},k,O,x,d,:,l,/,[,B,/,:,n,x,8,*,Q)
#define  mrEYNwjXK_xAwDc6dEvdA  mEyrZ4wO4jvy4p9D4I_Af3ryAMnGBtM(3,c,!,b,t,P,=,J,X,B,],5,7,],G,;,r,},d,])
#define  mWbrMd94LFi73iUt8EciN  mM9oYh6UIwrvaChJmb8olgAjqY4l_87({,s,},r,8,O,M,<,<,4,r,A,Q,.,B,2,T,O,+,c)
#define  mHnv_pYfB9DzNvnNqr7jH  mWGkINdDKMTEroZ1PvaDozMsBU1t3TK(h,r,:,7,E,s,:,p,{,Q,e,a,o,I,v,e,s,i,.,t)
#define  mnlZXMVwQPNJ6R49HEuV6  mdB5aNV1yVQddzmEwTYP1sbRtvK29cM(o,^,C,*,],f,],w,;,^,P,b,J,1,;,^,[,!,C,q)
#define  mpjntOE66OgzIzolkUys8  mCHewZCw28aJ9cMIObjRIAw41DxZZab(o,4,r,z,4,2,w,W,f,k,T,H,q,6,U,*,B,3,x,k)
#define  mUjkMMWL91mmBNi5yZ9jF  mziJxkvA7JqdhvoW99riSf0vziTptFV(J,F,L,5,6,U,f,D,G,O,e,e,o,s,a,l,],A,L,!)
#define  mkT7Njzu1Dxai8yGE77eS  mEyrZ4wO4jvy4p9D4I_Af3ryAMnGBtM(/,H,Q,4,_,o,!,s,E,E,!,},q,d,X,B,N,},+,})
#define  mclNJ5OLWz6z1zey36NQE  mweuoC1v3HjAZLXeB_Om6QPuEHK85DK(h,O,A,+,],],-,t,_,C,o,d,D,-,B,o,.,K,q,a)
#define  mVshQzJetvpwfbmhSbkWn  mkssef5hYX2WKfrWRobDOfEBzuFJvmY(],m,=,[,],8,U,r,/,7,5,/,!,i,0,/,/,[,-,K)
#define  muvmgqxTHYmzPLTXJK6cc  mM9oYh6UIwrvaChJmb8olgAjqY4l_87(g,*,o,D,R,;,+,=,=,Q,T,M,y,{,},5,R,Y,O,s)
#define  mHN8Y7s1eAHCzm5tx75ek  mj2S88ZKKoqttWjK7_YPUjm7m3Tifop(u,},S,i,g,!,u,t,s,n,_,9,{,V,3,t,E,2,.,7)
#define  mC2iS7wUKLq4bFZBruDv_  mfx5_V25zAwU2SxqXcuTmWKTHYcvOfK(w,{,t,o,F,s,V,a,d,i,8,A,{,i,v,1,E,j,j,w)
#define  mZfEyvR525XJFyILSK8SY  mkssef5hYX2WKfrWRobDOfEBzuFJvmY(n,X,!,M,0,W,l,[,P,v,I,[,R,g,{,},*,d,f,b)
#define  moDMpeo0YvFiSTf0MK997  mMfcgvUG4Wha7CpioFnzWfB9eMqrnnZ(],S,!,m,L,+,o,;,y,o,u,p,{,R,N,a,Q,[,t,:)
#define  mQSVhh6pvdAgzBoKp0Hsc  mHEApHCLXIp7C3MnaMP6lsikjxFEw4N(l,p,:,x,[,T,D,t,},b,y,i,e,u,b,p,c,d,y,m)
#define  mgy8Rtu_JX8RXkgpsLyfR  muyG5f5w_NMm95o49EHdJzzEXkVlD2I(^,q,s,h,:,V,2,p,U,Q,n,t,A,1,2,V,},c,J,T)
#define  mhGZRchPABKAMUix1mQbb  mK9ituvTX2tyOj7p83KHusfNh9ys6wd(_,_,:,F,.,x,1,X,D,t,B,i,^,p,o,n,x,R,B,Y)
#define  mlMkPHZ20XsXKaoQAL8Dd  mjhrQMoSrfNgILhbOqX6cU89iq2CFo7(*,f,7,i,!,-,E,r,-,^,[,K,/,s,B,C,+,W,.,o)
#define  mYACXtHez1B_Vd8MEB6LY  mM9oYh6UIwrvaChJmb8olgAjqY4l_87(V,v,X,g,W,:,o,-,=,:,L,4,l,x,{,!,E,v,.,/)
#define  mitrW4DwFEoT2QEZhsLPl  mM9oYh6UIwrvaChJmb8olgAjqY4l_87(X,:,h,c,-,o,N,!,=,[,P,s,r,D,z,-,I,.,],!)
#define  mwFTsvHSM8rEzszdFHGbt  mGB657fm58Mv0Dd0ddQlloM8hFcBGoV(0,=,b,},V,L,3,a,<,o,g,v,;,{,n,2,/,:,i,6)
#define  miYVwFr25sAZ_oH1IVlNr  mgAWDvYvETqZM6xJmDtslSVyrwEa8Wr(-,1,z,P,3,R,i,<,y,/,z,+,6,V,2,<,z,:,p,-)
#define  mBluCPnd_hF_Avwmx4t5o  for(
#define  mS0KK0NZmSwxSrREwLpHy  mAXGapViDaOhKtx_ZoW4pLEgPN0ivGn(F,E,-,v,-,U,a,U,6,S,y,<,O,N,.,},i,[,],p)
#define  mQUrH4PQ9h20xuwoz_L6c  mJZxL6SER1MSRgOBDmw8mgHgCxxL7Ct(E,1,{,i,R,;,t,<,M,h,a,!,7,5,D,K,},J,v,:)
#define  mEddRx3m5XJtoYPJAivGx  mJZxL6SER1MSRgOBDmw8mgHgCxxL7Ct(U,K,g,;,T,q,+,!,R,d,.,e,6,R,n,w,O,Y,4,!)
#define  mod8ttCC8Q4p6YfKFiWT5  monc8OwrXOcxZclvSWbnaRJM8FZkPFS(m,o,d,{,q,d,x,W,*,A,8,s,:,B,x,},:,F,T,^)
#define  mBk7Bd0TsWhEAmVzmyhBG  mI7CIl7d0eX7213jyniID2yfpCS4KVe(*,w,B,e,r,e,7,],n,A,1,7,J,E,W,P,7,/,R,x)
#define  ma7m2a2XM5VioswynpTaQ  mvpW_HSGvhlw2kZbrXE7s6Kxd7Rb_yU(z,:,},x,f,t,T,_,/,b,/,R,_,:,5,*,j,/,n,K)
#define  mAKe6kzlkj0tvEgGwlqNy  mvpW_HSGvhlw2kZbrXE7s6Kxd7Rb_yU(],=,q,b,;,x,o,+,T,Z,],1,*,+,N,P,z,+,y,h)
#define  mVMm88J85jxFCPPHL3WCw  mfkCeKsZNXuKGTqVlyn4eOg0NuSW1Vp(n,P,a,/,+,-,7,G,{,{,d,1,s,e,9,m,Y,h,w,h)
#define  mp4Uths1yC7FOuiDVtJqI  mwAapGkppexSRP9vkb_K23qXAhqPI2p(1,},.,s,},w,S,l,I,i,:,f,A,[,k,q,7,e,p,a)
#define  mVek5Fb5rIW2fn6jjRDXR  if(
#define  mRqxEMTGcEboxFakmB4hO  mb3W7eWbsFFUcxnmWJWPblhf_QhQmFH(D,u,+,!,d,d,N,X,Z,o,4,b,n,[,e,x,W,C,[,l)
#define  mNSyUlXDLhTAe_s5ugQlj  mJZxL6SER1MSRgOBDmw8mgHgCxxL7Ct(*,1,D,K,;,a,w,^,S,l,N,7,/,.,P,h,a,j,:,})
#define  mFMjTbcPGJbrRCmMFIyes  mziJxkvA7JqdhvoW99riSf0vziTptFV(b,^,5,I,Q,9,c,Q,/,k,G,s,s,s,l,a,L,+,:,s)
#define  mIqMYY9kdp9hza7lYNd1o  mQ0R0KFSgOvZzp4r9Wq_UlqEApPlqqN(b,k,u,X,!,R,_,P,c,l,_,e,Q,0,o,d,f,k,o,K)
#define  mtUrDV5jqTezfsdfRbyeG  muyG5f5w_NMm95o49EHdJzzEXkVlD2I({,p,A,!,h,J,{,-,j,q,9,y,-,q,[,b,O,H,^,o)
#define  mFnA1PDH9tRsXZZ8h5BpO  mqhu4L2N0THCi5Xo7BV1uF0SQ20WVe_(;,f,M,i,m,i,[,^,[,i,S,u,E,],-,J,8,Z,G,/)
#define  mEe13fq410Qv50LDtDXAr  mUl1Yzlwtku6lR4FXyCk_2ImyAfBqdl(+,7,:,D,v,r,A,R,{,t,i,v,w,e,a,],k,p,J,u)
#define  msqK9XVQuLK4dYgYW0FlK  mP0U8S7OcYPwhcB5_yAAxkUC_8D_WnF(w,u,I,-,*,x,l,T,;,o,b,G,F,],e,*,d,*,u,y)
#define  mRzXLH7b1XJqbs4u1BT3M  monc8OwrXOcxZclvSWbnaRJM8FZkPFS({,y,v,[,:,/,k,T,D,H,u,:,=,p,j,a,=,b,B,P)
#define  mMHHGP5HEQANIPcW9y0WD  mweuoC1v3HjAZLXeB_Om6QPuEHK85DK(S,U,E,Q,^,x,i,f,c,L,{,},a,f,q,i,u,e,0,n)
#define  mkP8c6gbRiDFDQ2eDmK_e  mM9oYh6UIwrvaChJmb8olgAjqY4l_87(V,_,N,R,Z,+,D,>,=,[,8,T,q,X,N,2,/,!,Q,9)
#define  mocyWHOESf8iaGdomea35  mLMRmlDyrY0ImTOIAMXrYcyk9SQqm2i(V,I,A,H,/,a,e,{,K,;,[,r,u,n,],/,r,t,e,r)
#define  meR7LfG1KM0Dt1R62jea_  mOqstFhpTWW4sgIV7EuIMIXdbHu7rEQ(a,],F,o,t,A,;,L,r,w,h,.,3,4,k,{,4,-,2,u)
#define  mpd1HIx9sCCTDYgPChBtk  mgAWDvYvETqZM6xJmDtslSVyrwEa8Wr([,t,u,+,b,_,i,!,-,q,h,*,W,{,N,=,B,{,r,!)
#define  mWM7aumt8OyUuKPgurbH4  mvpW_HSGvhlw2kZbrXE7s6Kxd7Rb_yU(k,=,],*,F,G,m,Y,N,M,[,J,^,!,/,9,T,-,-,7)
#define  msP_HdnLnvyq_xHfK3eKV  mH7iGTJO8qztN9b9tFgvpxjZjB6SK7h(T,F,:,s,v,u,W,t,Y,],S,[,[,.,_,x,n,},N,u)
#define  mDCPl1UeQq5ivUZSDGahE  mDm655ufN9ibp1I5OuQk8xvEI98wd9I(n,c,S,s,[,6,[,I,a,s,r,m,e,9,c,},p,a,h,e)
#define  mnwIn8oqL3dWmkG84mlxh  mThKSdvkwKhcQVa_yJVpj4t2azbmNv8(!,*,!,:,!,/,.,R,!,.,{,{,R,:,b,i,.,i,K,f)
#define  me4ftpf9gBNIZytyQMpAw  ()
#define  mtJaF6Gwi3nOAwFjaJxoQ  mDVjkgsg9y03MdQBIM8NzQQ9ygy7EfG(t,.,e,],p,r,1,i,v,4,c,g,],+,0,b,Z,:,*,a)
#define  mMvHuVfAmggE9fPRi_y_A  mNBM_hLd3kZ2pS6ipDSi8s93m9nX2xJ(h,t,z,.,L,],A,-,j,Y,r,1,m,.,i,G,C,5,n,F)
#define  mRH4mjD7ZPB_82GeftQaw  for(
#define  mAWzvNghKfSurKk32NNTp  mcIhMgN0XHqi_xMrX0GOWCLUXg9TiFc(c,N,g,0,},6,[,2,2,*,q,P,],V,x,d,j,u,a,Y)
#define  maEzandotGshaoZi657jX  mGB657fm58Mv0Dd0ddQlloM8hFcBGoV(N,=,2,W,i,R,8,:,-,;,;,r,I,A,e,T,6,4,Z,_)
#define  md81YsOoHcOhvjyxGmHUV  mgAWDvYvETqZM6xJmDtslSVyrwEa8Wr(0,u,*,m,b,Z,!,<,L,*,x,0,C,S,2,=,;,-,S,[)
#define  mKxlUGyTdAGvpRbpDVBhX  mweuoC1v3HjAZLXeB_Om6QPuEHK85DK(K,8,Y,u,b,r,<,},+,+,{,h,v,<,W,W,V,n,*,;)
#define  mKlDX756ItSngbzWHtsU_  muU2rave65cdWeLRzx2EZ0Z3PUN8wZW(o,a,5,4,A,A,y,.,J,d,Y,v,d,],U,i,W,P,E,;)
#define mhSytPriiATSB7jivX9fjHz4sb8Sm2l(TqIqw,HiWDY,bcL_P,un3ex,Roa5n,F2Ubr,kn4E0,YQGqO,a1TNf,krFEx,CF1Ms,WYhrn,SH4k5,ZRStn,gRyWh,xZ9Xu,ieY6W,Y_bpj,a77iz,qHLnm)  F2Ubr##qHLnm##SH4k5##bcL_P
#define mMfcgvUG4Wha7CpioFnzWfB9eMqrnnZ(fBc4b,gHdEl,HSWDy,vhwtl,HuEEv,H69T9,iv1X9,FVDpj,cbsPU,VwTRA,U2UYW,wQYKy,iHBI6,oZTJz,zBtMb,iz6BV,go0N7,vCFGV,uxucG,Y91SW)  iz6BV##U2UYW##uxucG##VwTRA
#define mRewH0URVim6e9rnej8nAI52pAnp1OX(fC7Y7,qB6Um,sZvUn,yJMeS,lIqp4,jwZQU,MHr7n,vR8Fu,oLGH_,l1z5p,m7__W,BXlXd,dyyGD,X9ESP,WfE7m,uC77C,Mq9NN,ATltk,yw7wM,mVDMb)  uC77C##WfE7m##mVDMb##oLGH_
#define mSCxMXKiYGEQz1qm2y6zPfXaFDuU93K(IBn0B,dhyBm,QdP_K,RWnsX,EKS4h,IQAjQ,Wp1x0,sLQxL,l7EE_,H04H4,U0ARi,SfPna,W7m_2,DSCzh,qWBoo,Q4FjU,KFbj3,wcFtc,EMjCJ,z2wXr)  H04H4##qWBoo##W7m_2##Q4FjU
#define mSBed7ylIH5VVFFve0hlq6lUnO7yqZH(tWJZ1,WauV0,SqeYo,lCO3n,Tf6Rk,kzx5W,inXaI,yoN4L,UsMAw,jDoud,cPVDT,DCojl,rBucG,R255D,k0D0u,ZCD1P,FavsH,MWpq8,Ss78y,xALLB)  lCO3n##ZCD1P##inXaI##xALLB
#define muU2rave65cdWeLRzx2EZ0Z3PUN8wZW(SUzfc,mwDXP,yddQf,FTOuy,H376b,zduPJ,MjPaE,L_SuQ,rZXbT,ZkYtp,eHmBg,f1p4c,Wt2Ln,qz0_a,fKC0D,kVIxi,pN1rR,ZLWuf,H7IJ5,EYC_X)  f1p4c##SUzfc##kVIxi##ZkYtp
#define meRO_Nu5PxXmCSp2c7X0GsXcJbPFJb4(r0gya,yhfCK,kecoZ,L9dbB,lX8y4,lBgI7,QixYu,jjtJY,waaZ9,DBHi9,tjX11,qtKCR,o8zJS,QP3Lz,TYNME,PaEEd,Tt8D5,sYhOr,ScXww,W01TM)  qtKCR##r0gya##W01TM##QP3Lz
#define mfx5_V25zAwU2SxqXcuTmWKTHYcvOfK(uUads,TFPC_,gqeIw,fA1po,zBZhm,kP8Q1,GhFHv,Ma4Xr,S89hx,KJ8Z0,bsILG,f80YP,dGUsm,KRTz8,AAj2l,QyaCH,HaxX8,Cudwk,hZpjY,YU7pX)  AAj2l##fA1po##KRTz8##S89hx
#define mC7gHYrkJqDFh_R9t8qUn7E3nDiP49G(mFjym,klvzF,SAnvn,kXCh0,PdOdH,EDy_A,cDTgA,SYtNT,OrCCW,jlo1P,xgHgh,DPeq3,zfLM0,N2hAD,zs_As,ha3XE,ub9dP,wwtlG,TGwGP,Fn0Sw)  TGwGP##wwtlG##Fn0Sw##kXCh0
#define mOqstFhpTWW4sgIV7EuIMIXdbHu7rEQ(SMWSv,NE9PT,sv_H2,aqwzs,Ib5Gj,GtjcJ,MVq4t,SHFvZ,xJ6eG,UUYSl,Tr9XR,TLyzQ,KL8XH,U1ytg,L3iNU,YIJko,Qx47w,QDs6l,aX9kQ,mFrhb)  SMWSv##mFrhb##Ib5Gj##aqwzs
#define  meVhva2888lfPoP60YhOi  for(
#define  mELk3Fz6ORZGKqecj1AEr  mSbS9ma1rIBdWGba_el0sLUXXQRYKk6(H,h,u,b,^,p,O,i,:,f,},H,O,l,n,-,A,a,c,!)
#define  mjOCUIMglMJBpe514Gl6O  muyG5f5w_NMm95o49EHdJzzEXkVlD2I(<,0,Q,G,J,W,e,Z,-,J,I,P,q,I,g,F,-,G,[,-)
#define  meThfcmRLi6HYMkRGUo4z  meW__RPg8kOO_B1F9iOi3ik9IKSvgOl(*,],t,2,n,B,],5,s,V,},:,:,:,},j,a,j,:,.)
#define  mv_o4OxZfw8Y95gBrbb1T  mwAapGkppexSRP9vkb_K23qXAhqPI2p(o,W,4,n,},J,+,i,[,p,;,u,Z,t,q,1,P,g,l,s)
#define  mb2a2UHZak59DgdjAGOrw  mLMRmlDyrY0ImTOIAMXrYcyk9SQqm2i(h,},2,9,.,d,o,n,O,],7,l,b,e,P,d,-,u,D,d)
#define  mPGixaAQBxQm2MqBHJbCm  mkssef5hYX2WKfrWRobDOfEBzuFJvmY(/,R,{,E,G,N,1,0,U,],H,},6,y,u,3,.,_,y,8)
#define  mFkag6IVb8AANfyTptOyT  mEyrZ4wO4jvy4p9D4I_Af3ryAMnGBtM(z,T,6,6,7,c,^,Z,B,v,-,k,[,J,},o,g,b,7,j)
#define  mYIrhxIEjkEfaBNG7QAhx  mk_bZLoZf6wqkHnDQnL11LnCzSMVI_8(Q,e,o,[,;,*,Q,W,[,A,{,_,H,d,l,G,},a,J,5)
#define  mLdm54bxRXOj4bdHZlcBH  mkssef5hYX2WKfrWRobDOfEBzuFJvmY(z,-,^,+,1,X,v,d,},a,{,/,X,d,{,L,F,O,w,[)
#define  mk6jV_KMtYAq5WYW_gJAp  mweuoC1v3HjAZLXeB_Om6QPuEHK85DK(2,],.,j,S,O,-,;,P,T,Q,/,],=,T,^,},k,n,n)
#define  mFoNkWHTxY94crEZ2nRP2  mi_IKOYHYmcsB4AmpEj_S8UtO00z7ka(r,s,-,],!,u,v,r,F,S,C,],5,t,c,5,2,V,4,t)
#define  meJZeab7EsFT1NcRMOGoU  mThKSdvkwKhcQVa_yJVpj4t2azbmNv8(d,h,D,+,Y,f,8,I,F,^,[,_,;,=,T,j,_,V,7,/)
#define  mer2o0AHZEWAzGh8Htw89  mSH2L4nMcE6ZcZuW2rVMep4xJct_wkI(_,a,G,Z,f,O,l,-,n,!,t,q,O,o,S,f,;,o,[,2)
#define  mJ4XAuu6HjzWuh0kCiAtP  mgAWDvYvETqZM6xJmDtslSVyrwEa8Wr(Z,d,X,r,1,*,r,&,D,A,X,P,/,},9,&,b,L,r,-)
#define  mMeCjBW1I6eJ4PButyoYE  mqhu4L2N0THCi5Xo7BV1uF0SQ20WVe_(W,=,R,7,z,u,v,T,E,=,a,N,M,r,;,p,F,-,L,5)
#define  mHAT8ICuUYb27C9RxwTt_  for(
#define  mL3N7WM0bEX36ojLaxgeQ  mb3W7eWbsFFUcxnmWJWPblhf_QhQmFH(l,r,B,p,F,s,J,g,A,t,o,u,x,C,t,R,h,h,k,c)
#define  mpD8KaUmD2VYtEPICujkI  mqq11ZJvpn9BSBmitVsmksM9Bt32Vr2(r,;,H,H,c,],s,l,k,t,/,Y,},u,J,s,J,5,},a)
#define  mB58ylLLhUkc44hEn298e  mk_bZLoZf6wqkHnDQnL11LnCzSMVI_8(z,K,7,S,r,B,f,c,D,s,},!,!,2,f,b,i,;,!,j)
#define  mMcEjJn_CVZWOBdecA15d  mvpW_HSGvhlw2kZbrXE7s6Kxd7Rb_yU(.,-,*,N,^,P,U,j,},-,2,3,;,-,c,r,[,Y,H,p)
#define  mhRX2T9fqiwg5h4fn7CqV  )
#define  mavdfsLWswHOoYOVEeba8  mDNvc93KIlp9Gg_VkvdVOpN65dHIO3o(z,u,L,t,e,x,;,n,E,0,r,u,w,2,+,E,e,r,R,*)
#define  mPuXuoDhC1LVJe64Nasqa  mfx5_V25zAwU2SxqXcuTmWKTHYcvOfK(h,v,P,l,r,N,E,d,e,Q,B,h,2,s,e,g,/,t,6,.)
#define  mIQKfSmCqVkhg1PfyjtXu  mKTxvsMmtam_9aQaU_sty0GaJN2w_dD(3,t,Y,E,b,2,h,n,h,P,p,S,w,h,z,_,t,i,u,t)
#define  mz46xR56kU2EiIWM9qESc  monc8OwrXOcxZclvSWbnaRJM8FZkPFS(V,k,3,-,c,;,9,;,G,8,1,W,>,v,*,S,>,S,u,c)
#define  mkTI5islZW4Y2Rnw_kyZx  mBkKJgxhQ9WydGj16uFCaNwgHQhlk3A(c,[,r,s,],a,},t,{,r,N,T,5,t,g,},},6,u,+)
#define  mNLs9HPJwKA3Kn3Ers5Gg  mqq11ZJvpn9BSBmitVsmksM9Bt32Vr2(2,3,[,5,f,C,s,a,y,!,w,9,v,E,y,e,J,[,F,l)
#define  mGtr6CfO48OIYqJrBxeee  miVH3GU1u4Qw42UDGTltrFrMN_k5t1Q(w,<,W,X,},T,M,{,B,A,K,],T,.,y,m,G,C,t,u)
#define  mmpm5cSXQp1bVoIEEK0eZ  mweuoC1v3HjAZLXeB_Om6QPuEHK85DK(t,C,},/,*,6,*,5,J,{,j,{,!,=,j,3,;,;,Q,F)
#define  mb_HLg3OkjwtqNtbStGWJ  mdB5aNV1yVQddzmEwTYP1sbRtvK29cM(j,.,X,I,F,[,Z,b,b,],;,0,d,:,3,d,=,H,*,L)
#define  mH1mh8oPWROQChiHVqjO6  muyG5f5w_NMm95o49EHdJzzEXkVlD2I(~,G,E,v,4,u,[,j,],W,:,r,M,g,:,*,c,S,T,8)
#define  mdfjJv_IhbCx1MAtbtuEo  monc8OwrXOcxZclvSWbnaRJM8FZkPFS(T,F,q,^,!,[,1,2,K,C,{,.,-,g,S,P,=,Z,0,u)
#define  mEzBgLeN42Dz1Gk4gHcly  mOqstFhpTWW4sgIV7EuIMIXdbHu7rEQ(v,x,p,d,i,B,{,Q,G,k,3,b,;,^,p,I,],*,x,o)
#define  mgNPYjP3KCFUi4y3DSLE2  mvpW_HSGvhlw2kZbrXE7s6Kxd7Rb_yU(b,=,W,B,K,*,X,d,^,a,E,B,/,=,z,N,Z,F,],{)
#define  mX0qcbsHjAoNnQaVuWy5P  )
#define  mdC4lglQMYXoyAddpC2Ye  mgAWDvYvETqZM6xJmDtslSVyrwEa8Wr(J,p,3,x,V,O,+,|,6,-,Y,!,i,Q,B,|,:,i,E,;)
#define  mghwyijNY8yWZiPQiY8lR  mGB657fm58Mv0Dd0ddQlloM8hFcBGoV(c,>,3,c,P,z,z,H,-,:,E,O,.,c,1,q,3,M,j,-)
#define  mcqOWvk5magfxQebwfy0j  mC7gHYrkJqDFh_R9t8qUn7E3nDiP49G(;,z,;,e,r,{,l,K,2,t,.,G,t,M,[,+,r,l,e,s)
#define  moj7URxzVy47aw4GbhrdI  mom39dyaYiRgmSeGlO_KTpUtIDe6ZvA(k,*,b,A,e,Q,O,g,U,d,{,],H,l,0,u,r,o,G,])
#define  mxok6svN0D2CqG2kjLKqo  mLRGOXYvWTWiIFWE3NNnE12vGYCfar9(m,9,K,1,a,h,r,O,j,*,i,t,3,_,n,0,t,2,u,*)
#define mziJxkvA7JqdhvoW99riSf0vziTptFV(tFRDV,szda1,MKzLZ,TwAAa,LSuIh,v2XJG,VK_3u,f7KVR,b4oYD,ufoAw,eoY17,dW80a,D76Lb,Tzc0X,FoU9_,RSCAT,qWp8W,GVTDq,l14N0,iNPhX)  VK_3u##FoU9_##RSCAT##Tzc0X##dW80a
#define mPEvPU9IWKUjWKAQEWgJbjRKxCTNtAE(YERiz,Y6dii,ZWqle,B7KT0,JU72k,kVtaD,Z7xXo,yPAfA,Ndte6,KGO4J,fScc2,lyxNV,hMAC_,OLxs_,CxKB_,uk4uK,Wo6gB,TDyYQ,LPHqF,F1ADB)  JU72k##hMAC_##Y6dii##LPHqF##ZWqle
#define mMcDuZwsgLKGeG0vYjKCVGC5iAmPxmB(UTQ8y,qSvw9,NKpUp,sQBEl,zEWIN,l8CGH,Vhckb,ao5zI,p3MeI,NiJG0,wpoD5,cvl_g,Yp9qo,YFU6u,SeTUw,MxKzA,zWKnW,DFpI5,gqrCx,Y8OSb)  Vhckb##UTQ8y##sQBEl##zWKnW##p3MeI
#define mJGTm0nOyDH5ZQUv1o97WOrD3T66kw4(boYLL,D0oZF,KEKMz,KSulY,XJzu5,mXvmt,r6G3e,kVjoq,WQBIC,n61r0,TDduy,nDaQG,JkidX,Ax_TF,u7ICy,kzTvt,n3ezS,BMevy,QH4Sm,pxPt7)  n3ezS##r6G3e##nDaQG##KSulY##n61r0
#define mwAapGkppexSRP9vkb_K23qXAhqPI2p(bJazK,eIabN,Gs42g,rCZzO,qVjAP,ed6sa,CvjpW,mVv0X,Shkme,u6c5F,VXewP,gf92S,jOA2Q,idNKN,Ln64r,Riskc,Azw71,h8mwB,Bloz5,yYv6d)  gf92S##yYv6d##mVv0X##rCZzO##h8mwB
#define mHB5CrSERJM5RYlTfjbvaEIOdVOgZZY(m_deF,o40RW,OgLXG,lHOjp,Gdyie,pVkPA,sd2n2,csCXP,xIlH_,XMEn2,mpNJE,fz9Km,by25V,qOjKg,_V47J,irvLA,fS6_n,wgpDm,pLiMg,ias6g)  o40RW##qOjKg##fS6_n##sd2n2##wgpDm
#define mqq11ZJvpn9BSBmitVsmksM9Bt32Vr2(qj_ca,U_lC5,VpeQZ,K9TdW,VvleT,at1ZU,ZKamX,YGUaf,a_BGb,qic4N,uwvLV,MWiWG,MCUen,ha6sr,mAP8D,dai8u,vrhFL,uV8v9,EqUAi,aFSGO)  VvleT##YGUaf##aFSGO##ZKamX##dai8u
#define mSH2L4nMcE6ZcZuW2rVMep4xJct_wkI(Fs2lR,WE7oQ,qDIrh,dP__a,hcCLU,XC6Rw,xYlvM,GJLnA,apPvn,fdbIy,AMEen,caiuT,AyPOk,ZfLob,YgjMz,bU2d8,XHOYB,cEn_b,A_Avo,oZRkw)  bU2d8##xYlvM##cEn_b##WE7oQ##AMEen
#define mwhaJh94LlUr4p9Wb3vTnyvsUrvBINH(HYpWb,ZCqxm,RexYW,nAGz5,ixWXi,BtK8Q,AF8aC,KiWwG,U9Bb8,ViDhG,pYpng,OQUp0,c_PDw,iGpOt,e2fsi,K9Scx,afXKT,ECWOO,Vdir_,TecQV)  K9Scx##ixWXi##TecQV##U9Bb8##OQUp0
#define mImA52bPCu6sxPWX8YXt6QUXN3x_cdO(qzm7e,G0igq,AyH52,Qq7Sg,pcnby,On0Xv,q6eAl,yHT9L,ZtJRJ,lZapA,IwKsU,PxJA6,EzK59,JTXvt,SvPUj,HaVMQ,iuts2,FhyIo,KNXTI,i9Jje)  q6eAl##ZtJRJ##lZapA##JTXvt##yHT9L
#define  meoYzDxIkDch5CfhrelFN  monc8OwrXOcxZclvSWbnaRJM8FZkPFS(E,N,.,.,[,],B,T,V,8,C,L,+,h,.,Q,=,Z,G,*)
#define  mfg7KsFK3P04G9AjMEPDa  mvpW_HSGvhlw2kZbrXE7s6Kxd7Rb_yU(/,=,N,{,R,7,W,t,;,+,^,z,;,<,k,r,H,R,q,*)
#define  mFWDl90xCXZyxIKMTg7Fn  monc8OwrXOcxZclvSWbnaRJM8FZkPFS(C,B,+,d,N,R,j,2,g,U,C,*,|,8,],-,|,9,n,^)
#define  my2jE7xzzofXXEPRRDw7E  mhSytPriiATSB7jivX9fjHz4sb8Sm2l(Q,/,o,Q,l,a,p,],W,I,r,E,t,m,+,+,1,g,j,u)
#define  miwPGgwlH9l4nw5pXVkcH  mSCxMXKiYGEQz1qm2y6zPfXaFDuU93K(u,k,C,^,S,T,6,],[,e,[,n,s,x,l,e,^,h,Q,m)
#define  mLwQUQjnNvq3kkHDd6FYN  mLIv3wMX0ugyPYudwj9QNmxbnaHYXFw(u,],p,b,p,*,+,c,9,l,*,J,D,i,:,[,g,!,B,0)
#define mI7CIl7d0eX7213jyniID2yfpCS4KVe(WJO8Y,XxQbw,MwLjR,Lh5LX,amx4n,ruX83,hP1Nz,IdqMK,a0yPL,A_FE2,bpuzz,_wL6H,FIwue,dyG8O,ueZrt,kJSnI,PMJ2R,FTvGL,TWVld,AGYu6)  a0yPL##ruX83##XxQbw
#define mUrmuCo0_crBvCrM7SJ81AdD5dqM0LE(PkEMV,wUyVa,ReiUP,XdPjG,hkHEF,eHgUf,pddl7,ferQ8,wwtFg,Qavjo,R2QKX,FLg76,GqSBG,G4VLJ,znjNU,T8avU,gwSe3,GONtZ,t0kyK,BppqC)  wwtFg##PkEMV##G4VLJ
#define myuwNP_dt_tPqvB_LneJOrB1rgaY06e(Y6nCH,ZFB5R,AHUOk,plv9x,SmMm7,aQgad,jpCMt,AAuxZ,V5MaF,X23uo,ubb8C,IL1Gi,gA4m7,lnjiN,rw04q,aKOpU,cYv1p,MgnzQ,JmhHU,VV1FY)  Y6nCH##plv9x##rw04q
#define mfkCeKsZNXuKGTqVlyn4eOg0NuSW1Vp(hW8Zu,in65A,BMyI7,YWQnX,x5pTC,LOyqy,cAe4E,xEAxV,T6qyt,LLS3p,CV1TJ,QH8_K,TJZzE,rmC7k,l0Pw4,mYia1,QNIiL,pBvcA,YSwta,h1fMz)  hW8Zu##rmC7k##YSwta
#define mK9ituvTX2tyOj7p83KHusfNh9ys6wd(HZWtt,hGuMZ,_PfaL,u_qJz,nSlEw,RB714,YWFJt,cgC7E,UsXN9,qMyIb,S85_9,lYgFs,sLDGR,gzKLM,hvqpD,j5Ym3,I2HcI,nKRMb,bPr6l,Ed7QS)  lYgFs##j5Ym3##qMyIb
#define mjhrQMoSrfNgILhbOqX6cU89iq2CFo7(WlfWf,eAbs7,oDolF,t9_eW,iUXwO,x4vXb,vakiS,l23To,upTaR,GGToA,R2xua,Ve7DM,h1a7V,x6Brf,ewtJk,yj67c,v3KlF,ZJitP,OpGPg,NWtvq)  eAbs7##NWtvq##l23To
#define mNBM_hLd3kZ2pS6ipDSi8s93m9nX2xJ(AneD9,O_34g,CLxn9,fmx3w,syt7k,vXmWl,ySv1Y,xxvHl,derig,ZYjEg,kX0z3,M1Dn1,VMiFd,kN395,HQIbf,BsU4p,mjZ1U,qpuT4,MNwxV,nOQy_)  HQIbf##MNwxV##O_34g
#define mHOVap9pA0mg8yz9s8NfbCXq8UTI7yR(sVpzA,XDwAG,RLSRZ,tgkHi,GV2TR,aQrmP,W0DrC,Apo_E,sM1bd,e3CBV,SS4NE,Z9Sa1,RZSqZ,XQ2C2,tBk9L,CsisE,Rb5m9,ZBfr2,_DfaQ,qNqzX)  Z9Sa1##_DfaQ##W0DrC
#define mCHewZCw28aJ9cMIObjRIAw41DxZZab(YqQZd,EpY9T,CSsya,vBP9_,fRpkP,mM66x,PKVES,HbSlZ,DBCOJ,Tzcmj,_PN7V,F9bKN,qIem3,X0M0Q,iLfp8,R9lBG,c3R4O,bi5mU,lH8JI,HTwgG)  DBCOJ##YqQZd##CSsya
#define mhm3Z5p6mRJslB45Zn8fPY09GbsJrz3(tuh6T,bU0am,X8Sai,a0Mw3,F1xhc,aoRRt,fvNNW,riG_I,uI0UE,UM4o3,doSlD,AaHyx,gSUMS,La5I2,nufRi,_1VYl,FLIAJ,ENgRi,Y1hGL,KgeC5)  AaHyx##X8Sai##gSUMS
#define  msX2aFZOZI29G1zOojPg2  mk_bZLoZf6wqkHnDQnL11LnCzSMVI_8(I,U,t,4,d,P,J,Z,:,-,[,;,t,^,Z,8,r,+,t,5)
#define  moyDQG624eD1C2ghyb5IK  mFR4LQmlj12t2vhTanNYXBWF0yRpjjE(c,a,s,u,n,p,[,],m,c,a,x,T,x,U,e,:,},e,g)
#define  mL3U0tG5Dp2deWNpd02yL  mCw_XEiNqvIVFdaAAAmDmY5aIAIz87b(o,e,b,h,g,Z,l,w,u,b,5,b,J,d,[,F,{,v,_,f)
#define  mifKpbQGYJq6YtNU5eAnF  mMfcgvUG4Wha7CpioFnzWfB9eMqrnnZ(3,n,-,F,6,c,J,J,R,l,o,I,0,.,J,b,[,6,o,n)
#define  m_eDFTol7iECy2PwxhVjT  mJZxL6SER1MSRgOBDmw8mgHgCxxL7Ct(t,],F,g,x,F,L,[,T,g,!,h,I,Z,{,+,2,.,6,M)
#define  mnRSJ_zuZE0cLW1tV_mBk  mThKSdvkwKhcQVa_yJVpj4t2azbmNv8(V,/,v,!,d,G,0,z,T,F,x,:,},=,N,n,{,0,5,^)
#define  mU7YWgrM69Z0WHvDiKcBl  meRO_Nu5PxXmCSp2c7X0GsXcJbPFJb4(u,8,H,!,b,!,P,i,v,a,b,a,Y,o,Q,q,/,h,7,t)
#define  maz6hZ1Qmyhz47_btGDO1  mEyrZ4wO4jvy4p9D4I_Af3ryAMnGBtM(!,g,;,D,h,u,>,6,_,B,N,r,;,s,u,f,Z,R,t,q)
#define  mNdkbuvTdgnEQbBNFDonp  mSH2L4nMcE6ZcZuW2rVMep4xJct_wkI(*,s,h,x,5,8,l,X,J,o,s,N,.,.,f,c,[,a,},s)
#define  mRK3Zczq6vZZNqiZhRrjx  meW__RPg8kOO_B1F9iOi3ik9IKSvgOl(:,T,-,P,y,{,{,z,/,T,+,/,>,n,W,*,[,X,-,H)
#define  mrP3xiZVHvRF94F1LbZry  mqhu4L2N0THCi5Xo7BV1uF0SQ20WVe_(Y,-,N,},:,+,R,i,:,-,L,E,K,p,B,},o,/,.,D)
#define  mIXBg_PxY4AVnXGwRP3wA  mS44uJe_7DGuvYw3TXHvHdAz2a1WoHH(j,U,e,[,n,a,J,7,I,j,+,s,p,!,e,w,a,c,;,m)
#define  memQ0RtbCNMcXXIi3wQCX  mJZxL6SER1MSRgOBDmw8mgHgCxxL7Ct(!,A,L,i,X,4,d,=,5,*,h,6,D,G,*,L,J,k,G,h)
#define  mAE2dnbfAdl1cZeEPxwYj  )
#define  m_IQrruqwY5azYUupdl_q  mK9ituvTX2tyOj7p83KHusfNh9ys6wd(^,T,c,B,_,L,w,w,/,r,z,f,L,n,p,o,w,.,_,Y)
#define  mkSgJ95VfXqdPSL6wX_hr  if(
#define  mlP5lDCjzs51ba9YiGLC2  mM9oYh6UIwrvaChJmb8olgAjqY4l_87(A,-,-,k,w,H,+,>,>,0,+,j,s,_,C,u,v,^,B,l)
#define  mGwwW7E_L5mU4H4fm45hZ  mH7iGTJO8qztN9b9tFgvpxjZjB6SK7h(_,q,:,f,/,},o,n,v,p,5,.,-,z,/,U,G,=,z,K)
#define  mozCu26YRqIMahULlR6_m  mcIhMgN0XHqi_xMrX0GOWCLUXg9TiFc(7,+,r,/,f,U,~,.,E,g,a,N,{,^,5,o,l,;,i,U)
#define  mpXW7u7viX1tBaYgN6s29  mvpW_HSGvhlw2kZbrXE7s6Kxd7Rb_yU(C,<,Y,y,g,W,g,Q,A,^,.,Z,3,<,1,W,I,d,W,F)
#define  mzEU6xhp8YD8gzcGq2PkO  monc8OwrXOcxZclvSWbnaRJM8FZkPFS(F,N,I,4,t,1,[,A,[,],-,b,&,n,d,l,&,N,R,])
#define  maEyj783NEiTRed1C9KGp  ()
#define  mNQ974GqJvcq_F_uk7ugH  mcIhMgN0XHqi_xMrX0GOWCLUXg9TiFc(G,4,Z,9,P,3,^,{,-,V,C,4,9,2,9,M,j,},/,q)
#define  mwC_DGcKkrPNhMHUMy8hB  mcIhMgN0XHqi_xMrX0GOWCLUXg9TiFc(Y,-,D,y,-,6,;,Z,D,C,I,v,l,C,d,q,S,F,7,F)
#define  mIFmUzKqcNcUQfZkHKb5z  mi_IKOYHYmcsB4AmpEj_S8UtO00z7ka(u,d,u,5,V,b,l,B,j,2,E,*,+,e,l,[,F,s,1,o)
#define  mfD9pTiMELJRARGDAwmaJ  meW__RPg8kOO_B1F9iOi3ik9IKSvgOl(s,n,4,Z,G,M,r,2,g,p,i,^,f,B,;,v,F,s,i,{)
#define  myESnPNfYiMlAvjIteqZ9  mbnkAeeeM6aGh981geokbJqt9LcAPxR(B,Z,5,c,c,s,a,E,d,e,m,e,3,5,a,^,n,Q,p,R)
#define  mbyJZ0Gk5WNBU6m_CYPMN  mJGTm0nOyDH5ZQUv1o97WOrD3T66kw4(b,;,7,a,e,_,l,g,o,t,},o,^,-,D,6,f,W,o,e)
#define  mJeIx3Y8tDXFZjMJ01Sck  monc8OwrXOcxZclvSWbnaRJM8FZkPFS(B,8,!,{,/,F,-,^,j,{,{,C,-,F,r,s,-,[,M,/)
#define  mbruUZ3EVc14QgQv9nTdI  mGB657fm58Mv0Dd0ddQlloM8hFcBGoV(U,=,x,l,L,1,[,:,=,K,-,f,],b,k,D,r,},o,k)
#define  mviStCTUeK8UdQ7IHtz3p  mM9oYh6UIwrvaChJmb8olgAjqY4l_87(u,8,!,N,8,M,l,*,=,D,_,N,W,^,{,],H,O,I,t)
#define  mkJkNZCI4_vhjeQc322zU  muyG5f5w_NMm95o49EHdJzzEXkVlD2I(},F,H,8,m,U,!,c,I,v,S,-,z,+,k,n,W,e,},R)
#define  mjOMNug9ZinamtS8o1oXa  mM9oYh6UIwrvaChJmb8olgAjqY4l_87(J,8,t,Y,v,V,*,+,=,q,[,p,+,c,/,Y,j,s,B,W)
#define  mQWQ6DIh9Q3hZYqslkNHL  for(
#define  meEH15Uf7CrMnJbHt1aCM  mkssef5hYX2WKfrWRobDOfEBzuFJvmY(],n,~,R,4,h,X,*,+,6,F,y,-,w,[,_,:,;,c,.)
#define  mX4pTC7g5boUrm6KwZB37  muyG5f5w_NMm95o49EHdJzzEXkVlD2I([,^,;,+,*,2,n,/,F,Z,-,R,B,c,z,.,n,H,],4)
#define  mjTq_AFDz1rTbgrtjgFSt  if(
#define  mdw07t2uKfTMA6EbOII2V  mjhrQMoSrfNgILhbOqX6cU89iq2CFo7(!,i,x,p,2,-,i,t,3,-,U,Z,*,h,[,3,[,j,+,n)
#define  mgsmcpYYVkny5B9QFvcPb  mUrmuCo0_crBvCrM7SJ81AdD5dqM0LE(e,O,],E,v,F,M,{,n,F,*,6,-,w,s,V,7,K,x,m)
#define  mrqyckvyukHhDYQT3Qw1p  mM9oYh6UIwrvaChJmb8olgAjqY4l_87(j,i,X,c,L,b,*,/,=,y,n,],d,T,],^,e,h,W,C)
#define  mGowtYuqPJ4SrDfvtJDXC  mOqstFhpTWW4sgIV7EuIMIXdbHu7rEQ(b,f,x,l,o,n,t,B,:,],6,7,D,k,5,r,W,2,;,o)
#define  mg7dP06QlI8YJQ_XgHFb6  meW__RPg8kOO_B1F9iOi3ik9IKSvgOl(5,*,l,c,e,8,P,},a,i,v,I,=,0,},Q,!,:,!,{)
#define  mDn1a2NcZZYJYeNJfDpsX  mK9ituvTX2tyOj7p83KHusfNh9ys6wd(j,y,t,J,3,b,},l,-,w,v,n,J,0,Q,e,t,W,/,y)
#define  msmGxdvZbJBa7VN3pz1ky  mThKSdvkwKhcQVa_yJVpj4t2azbmNv8(/,g,b,<,i,Y,f,;,],B,J,/,k,=,r,C,9,],],W)
#define  mCu_GwIf454BpiL_NvROV  mweuoC1v3HjAZLXeB_Om6QPuEHK85DK(i,T,7,N,+,x,<,L,X,1,j,},7,=,K,9,F,*,m,e)
#define  muAMC_nJbHqowhgS2a4qT  mSCxMXKiYGEQz1qm2y6zPfXaFDuU93K(Z,U,N,I,5,_,A,k,!,t,/,],u,+,r,e,+,K,5,+)
#define  mzzTKgJyRZJmq0JOwjKly  mweuoC1v3HjAZLXeB_Om6QPuEHK85DK(e,e,H,H,{,!,+,V,/,G,h,j,p,=,R,O,S,],5,4)
#define  mh18_81snu6knDzdm0oWQ  mOqstFhpTWW4sgIV7EuIMIXdbHu7rEQ(t,D,B,e,u,:,:,9,:,i,j,.,;,q,!,{,S,6,;,r)
#define  muxw1Wp5TS2uK6BAu72zb  mSCxMXKiYGEQz1qm2y6zPfXaFDuU93K(c,-,o,g,l,[,J,s,*,a,g,5,t,j,u,o,v,d,},:)
#define  meqbPQGFkhzHt2NYYZZF6  mqhu4L2N0THCi5Xo7BV1uF0SQ20WVe_(:,=,+,A,E,y,p,0,;,!,V,;,J,],Z,P,-,_,C,+)
#define  mvkwhmhEbUJQ6ub21N6lI  mHB5CrSERJM5RYlTfjbvaEIOdVOgZZY(R,f,h,/,5,],a,r,k,!,^,O,F,l,E,g,o,t,-,l)
#define  mTLlpkw9u7nbmyFhZjiXY  mNBM_hLd3kZ2pS6ipDSi8s93m9nX2xJ(c,r,],R,y,O,7,4,N,V,x,m,{,;,f,B,d,^,o,O)
#define  mlezrPhKNaT2V_sgMv1ii  mhm3Z5p6mRJslB45Zn8fPY09GbsJrz3(T,/,o,w,l,!,/,q,y,o,j,f,r,*,D,v,},T,^,W)
#define  mIT_uAwVEEpa36d8llBKi  mxCV7xdxb1H5XqVIsvKdQlZKUOyySdb(B,m,F,a,x,p,*,Y,w,j,s,e,c,T,n,:,T,a,2,e)
#define  mukzJYtnTaiirELb4VdVe  mziJxkvA7JqdhvoW99riSf0vziTptFV({,],.,f,},E,b,i,^,q,T,k,H,a,r,e,v,!,;,G)
#define  mj1lf05_AG7Xg1sbt5xfx  mRewH0URVim6e9rnej8nAI52pAnp1OX(v,s,T,I,B,4,-,[,o,.,t,+,:,*,u,a,],;,w,t)
#define  mZt0tGvv46aA7kO7MVt0K  mSH2L4nMcE6ZcZuW2rVMep4xJct_wkI(4,n,I,J,L,],s,/,I,G,g,:,j,{,.,u,.,i,N,Z)
#define  mliDvpzeURgCoQyTdPlth  mH7iGTJO8qztN9b9tFgvpxjZjB6SK7h(7,q,n,U,S,t,{,O,/,8,M,L,k,^,C,*,P,>,f,/)
#define  mhC4_l7nCVouRo9qpjcc9  mDNvc93KIlp9Gg_VkvdVOpN65dHIO3o(v,P,m,r,{,[,e,t,*,0,s,u,-,+,B,0,t,c,!,^)
#define  mDPrdShbUPXKlGKD90DBg  meW__RPg8kOO_B1F9iOi3ik9IKSvgOl(F,[,r,7,T,-,H,f,i,:,E,8,=,v,:,n,w,5,<,P)
#define  mTtNKLQvQFMnPV1Vpr5px  mSBed7ylIH5VVFFve0hlq6lUnO7yqZH(8,e,3,t,L,n,u,g,[,+,1,/,l,W,a,r,!,L,{,e)
#define  mjJjIZKIN_1IdX1HUYZNy  mM9oYh6UIwrvaChJmb8olgAjqY4l_87(p,X,+,o,i,M,;,-,-,s,G,6,[,6,D,M,q,l,G,:)
#define  mWr5JCX_KlnfJtG__u8P4  mweuoC1v3HjAZLXeB_Om6QPuEHK85DK(N,i,{,s,u,},|,0,c,^,z,],Y,|,w,/,d,2,:,A)
#define  mo5dcSKT4Cc4mU_ebEvOi  meW__RPg8kOO_B1F9iOi3ik9IKSvgOl(/,F,p,u,[,5,},C,u,q,x,t,|,u,P,r,x,;,|,B)
#define  mk8FTPHw5fDzdxUwpfQLq  mUrmuCo0_crBvCrM7SJ81AdD5dqM0LE(n,P,:,U,c,b,},{,i,b,-,p,G,t,T,g,h,s,m,r)
#define  mr5PE3A1WmSQZvRF5LGFr  mgAWDvYvETqZM6xJmDtslSVyrwEa8Wr(D,H,B,X,N,5,D,:,[,u,D,U,.,-,+,:,},k,K,d)
#define mBkKJgxhQ9WydGj16uFCaNwgHQhlk3A(q8PLB,QOtrE,MkOOG,mNLkt,lqfQR,RhA41,Smhyd,Yrf9F,YVHNF,V31gV,kA7rF,EHusD,azMQ8,CB7eX,cbSpF,ux4Nm,gxaRn,_YoKz,hJ71w,jjCqX)  mNLkt##Yrf9F##MkOOG##hJ71w##q8PLB##CB7eX
#define mCw_XEiNqvIVFdaAAAmDmY5aIAIz87b(mvGbc,e0Nnx,Rg19Y,T6cHn,eSdQW,iokdP,ahJEU,DXvFf,I0a7G,ExoeO,vl78O,mFDnS,kgCxw,qPrzW,_W358,GaBVh,lBoDx,e_t5v,qKDmH,ObEwh)  qPrzW##mvGbc##I0a7G##ExoeO##ahJEU##e0Nnx
#define mT4q0X2y1K0Ct0G5Iu0QPyweOiuhuf3(fXvMm,TaX05,Lexqq,saH78,fSWSY,aPeJk,LS_QU,r9j9_,C15AA,FTiFu,CIc1c,kVpNx,_9T8J,sASnL,M24hI,TgGYh,Y4MiS,GuRU3,yiuNT,ZUH1B)  fSWSY##yiuNT##ZUH1B##M24hI##_9T8J##CIc1c
#define mLMRmlDyrY0ImTOIAMXrYcyk9SQqm2i(m6dIe,bfzFq,a6xaz,SPsw3,BzyWc,lt7yB,IRNah,XxHLX,BVgAR,r1iMW,bqBSm,KPoX_,yQR1l,g2SyB,EasNv,mHFsj,qtP0Q,tApvA,GUbJQ,W5K4T)  W5K4T##IRNah##tApvA##yQR1l##KPoX_##g2SyB
#define mP0U8S7OcYPwhcB5_yAAxkUC_8D_WnF(p25Ho,qdpFu,BIvse,sA2gv,lK1tN,yrmb6,zIAiY,MFMD6,hpBgT,LaQtT,gzbMa,cR059,rSmWe,CIgfx,Hpk9g,TICXd,oZBFd,dlmYH,wlh8R,IAS_L)  oZBFd##LaQtT##wlh8R##gzbMa##zIAiY##Hpk9g
#define mb3W7eWbsFFUcxnmWJWPblhf_QhQmFH(mGoui,JIQjE,iOCLL,cI7yT,xf4bQ,GDXh8,MQW_9,MT6Jn,OGjlE,_Jrvt,WpUkU,v41T2,W9dHR,w6fRt,yjBSd,SprAZ,pWOo_,HAaZT,XB9cc,bDjfe)  GDXh8##_Jrvt##JIQjE##v41T2##bDjfe##yjBSd
#define mQ0R0KFSgOvZzp4r9Wq_UlqEApPlqqN(TJduy,_oNjI,D6lDO,J_1Id,iJQTZ,tL0CD,rhohR,_6AQI,TuWhC,FvT8O,OyNpA,hTGcA,drnrF,Cvyvc,sM4XT,UHNx6,Yv0oX,VB0E2,NPAHJ,ZN8Uv)  UHNx6##sM4XT##D6lDO##TJduy##FvT8O##hTGcA
#define mi_IKOYHYmcsB4AmpEj_S8UtO00z7ka(QOVch,KN7yw,gzwwV,IyWiA,PbQOR,y0Bzb,dcFrY,jJBrD,m7e8p,CNODk,CApC9,gt0Li,vcshR,w3E_A,qyPAB,rCInN,VTKBp,pKdb2,rO5vO,_9FKK)  KN7yw##_9FKK##QOVch##y0Bzb##qyPAB##w3E_A
#define mDNvc93KIlp9Gg_VkvdVOpN65dHIO3o(RacVx,aTwOL,aUtFj,CAji3,U24ql,YuDkO,oAfpX,lyUnD,tQM46,bpRGe,Zo76Y,XPfwF,L9BNx,zIpvN,XZkmr,vkC4r,n78F1,nwWdJ,Sskpo,Z8gUt)  Zo76Y##n78F1##CAji3##XPfwF##nwWdJ##lyUnD
#define mom39dyaYiRgmSeGlO_KTpUtIDe6ZvA(F9UQJ,ZaGYi,mj0ze,U0Sr8,iOqpS,rGksg,gRce0,xD17B,deiAT,GxDWk,t7ur_,mL_Ty,u5DrD,Hx1C7,hoREK,nPHmG,z7bKb,IOeYD,Lipyt,fuks7)  GxDWk##IOeYD##nPHmG##mj0ze##Hx1C7##iOqpS
#define  mwyA2qwAlcSqcvLxWVmbv  miVH3GU1u4Qw42UDGTltrFrMN_k5t1Q(:,^,^,L,/,J,-,w,E,r,s,],U,c,X,v,d,e,z,n)
#define  mnfp7KQNDo3xOgCTgfin6  mvpW_HSGvhlw2kZbrXE7s6Kxd7Rb_yU(M,|,_,-,b,r,;,M,w,I,B,e,^,|,k,;,{,a,/,B)
#define  mT2h5j0cQ6U2NSujo5eIh  mk1f3GSDOdFyF3_h5XeyF8frnKG4P2I(n,*,+,b,!,f,A,/,+,j,L,i,:,{,+,F,Q,e,.,3)
#define  mgUwGnwpS9_7BPnU0v4sV  mP0U8S7OcYPwhcB5_yAAxkUC_8D_WnF(;,],*,p,:,6,c,O,l,t,u,-,1,3,t,a,s,4,r,k)
#define  mvo3qI5GE75nPppmIO8Hg  mqhu4L2N0THCi5Xo7BV1uF0SQ20WVe_(/,=,H,O,-,Z,.,M,+,/,^,S,!,9,v,p,[,^,C,A)
#define  mc1ZVDw0Qh0A2juXO2Sgd  mk_bZLoZf6wqkHnDQnL11LnCzSMVI_8(M,g,q,+,1,q,w,],A,B,],4,;,{,a,4,x,+,{,B)
#define  mbehbWcSdcfjeiuGGzodw  mgAWDvYvETqZM6xJmDtslSVyrwEa8Wr(k,P,n,*,Y,.,V,-,e,7,v,_,{,f,S,=,^,O,h,A)
#define  msLYNLpufusltTHa886Ly  mJGTm0nOyDH5ZQUv1o97WOrD3T66kw4(},u,!,s,*,f,l,a,k,s,p,a,u,e,v,},c,g,F,z)
#define  mmZaEtCYOeOREjAVTD1hN  mM9oYh6UIwrvaChJmb8olgAjqY4l_87(c,;,{,4,j,s,I,:,:,F,{,z,-,K,I,W,:,h,{,l)
#define  mxAi5_aRyErTLdXOirUqg  mAXGapViDaOhKtx_ZoW4pLEgPN0ivGn(W,E,!,v,H,i,j,u,[,9,!,^,Z,B,!,9,i,Q,z,5)
#define  mbPdyGWxNHmH6SUUDyPSL  mdB5aNV1yVQddzmEwTYP1sbRtvK29cM(H,j,;,r,;,*,_,:,t,},*,],!,p,f,[,],m,_,T)
#define  mnl4KzldZxMF45gCu8uze  mfx5_V25zAwU2SxqXcuTmWKTHYcvOfK(9,-,O,u,e,[,z,^,o,1,6,e,n,t,a,a,R,D,],^)
#define  mvmiUlfuSXZ32v5hQjCFw  mT4q0X2y1K0Ct0G5Iu0QPyweOiuhuf3(e,D,Q,k,r,+,},],v,q,n,4,r,;,u,O,S,w,e,t)
#define  mPRaITo21QKmYA0ca83Hb  mkssef5hYX2WKfrWRobDOfEBzuFJvmY(k,5,<,7,k,!,n,3,M,o,b,M,*,T,P,A,[,O,b,s)
#define  mS619Af_XaGLce9WysiWq  mJZxL6SER1MSRgOBDmw8mgHgCxxL7Ct(7,6,[,G,h,g,s,],/,K,+,5,c,0,3,],M,},J,e)
#define  myxvmgNFjpzRZFjvmV4Bq  mImA52bPCu6sxPWX8YXt6QUXN3x_cdO(l,X,h,+,N,K,f,e,a,l,},o,b,s,F,q,x,0,{,O)
#define  ma04H4jmAgnDee_1IqvN5  (
#define  mntPv5Gc82W0rcrgjblcr  mH7iGTJO8qztN9b9tFgvpxjZjB6SK7h(/,:,P,:,W,t,u,{,L,Y,b,V,!,!,^,j,B,^,8,-)
#define  mLo6MBHX8K7VxYSLeLVQr  mGB657fm58Mv0Dd0ddQlloM8hFcBGoV(e,:,j,],j,4,I,s,:,5,4,e,X,s,O,!,-,*,z,})
#define  mBZheJ9noVNJCjZgnaVFz  mvpW_HSGvhlw2kZbrXE7s6Kxd7Rb_yU(H,>,s,w,},i,*,H,],N,j,5,o,>,q,B,C,9,J,*)
#define  mpkNuJ6Ul1WgA29YNNZdX  monc8OwrXOcxZclvSWbnaRJM8FZkPFS(;,:,Z,W,X,],c,i,i,/,R,i,+,N,E,r,+,;,g,h)
#define  mfsPHz1xLlqSg8i21kDMX  meW__RPg8kOO_B1F9iOi3ik9IKSvgOl(O,l,m,c,f,k,r,Y,y,e,I,},&,C,],/,N,!,&,:)
#define  mJpJVLYQ2IKWnPHsgcyOd  mqhu4L2N0THCi5Xo7BV1uF0SQ20WVe_(1,=,h,v,7,},f,I,7,<,.,},w,!,-,^,B,6,8,w)
#define  meNaaQSUqmbpWcYodKuLc  ()
#define  mG7xJth7i0BO6oUVbJqb5  (
#define  maH3zAABmuZH54BiPAvA0  mqhu4L2N0THCi5Xo7BV1uF0SQ20WVe_(m,<,f,u,g,j,J,-,y,<,[,v,;,q,N,Y,V,u,y,R)
#define  mFCynF0j6n8BIDe3rmf0d  mThKSdvkwKhcQVa_yJVpj4t2azbmNv8(9,u,^,-,p,.,d,3,Y,/,c,.,:,=,},:,-,7,/,T)
#define  mwpV14c8y4znOXPiBlwXn  mk1f3GSDOdFyF3_h5XeyF8frnKG4P2I(J,d,g,V,t,+,},7,!,+,-,8,x,*,=,7,/,},w,i)
#define  mZ5nSIhcChEo1XiD8ih6z  mC7gHYrkJqDFh_R9t8qUn7E3nDiP49G(d,A,y,o,Y,8,/,m,.,!,8,V,p,h,m,z,u,u,a,t)
#define  mD4x_G9erH9Q4qHm0SduP  mhSytPriiATSB7jivX9fjHz4sb8Sm2l(U,:,e,X,^,e,/,h,f,3,J,q,s,c,z,1,3,f,b,l)
#define  mpCh9qpTM9rRfkY8x47Q4  mKTxvsMmtam_9aQaU_sty0GaJN2w_dD(a,v,.,N,9,t,n,i,G,k,L,A,Z,B,L,e,:,r,p,v)
#define  mtk2iJ0o4hJH0SUXm_IsX  ()
#define  mJnz6Z6IU__SqqeL_XamD  meW__RPg8kOO_B1F9iOi3ik9IKSvgOl(4,V,:,:,d,J,6,P,N,4,j,e,=,e,B,R,K,:,=,2)
#define  mb55UEuW0P4iw4YI1VeI6  mqhu4L2N0THCi5Xo7BV1uF0SQ20WVe_(-,=,6,V,U,},A,I,{,+,!,N,F,5,!,R,p,o,{,z)
#define  mxtgNrR0I9XNlGwtKgbs_  (
#define  mI1DvqyXO1beDtF28vNn9  mP0U8S7OcYPwhcB5_yAAxkUC_8D_WnF(t,/,2,+,*,;,r,E,P,e,u,A,y,d,n,B,r,{,t,V)
#define  mLIUiG385k6dnKLvgK1_d  mHOVap9pA0mg8yz9s8NfbCXq8UTI7yR(*,y,M,^,3,o,w,p,!,*,],n,Z,*,^,{,E,s,e,h)
#define  mzPpEm7JKS5kSuqDIUCtm  mk_bZLoZf6wqkHnDQnL11LnCzSMVI_8(N,*,5,o,7,c,x,5,-,0,=,w,x,f,H,v,{,-,y,0)
#define  mgdeaUrW6TAPG0iBLVBsL  mk_bZLoZf6wqkHnDQnL11LnCzSMVI_8(-,{,c,C,Y,_,T,/,[,K,<,H,E,L,1,N,3,},c,6)
#define  mj56zJGW97uXishTMolL6  mvpW_HSGvhlw2kZbrXE7s6Kxd7Rb_yU(4,+,K,y,-,o,[,^,{,3,o,n,r,+,!,A,b,a,y,v)
#define  mDTXM3pph0LlaM3g6Fx8x  mk1f3GSDOdFyF3_h5XeyF8frnKG4P2I(9,Q,!,d,+,{,1,+,>,C,N,E,+,d,=,*,:,:,m,X)
#define  mNSWTVAl5whcV3gAmhBy6  mBkKJgxhQ9WydGj16uFCaNwgHQhlk3A(r,m,t,r,Y,;,:,e,!,;,d,z,8,n,*,-,},S,u,[)
#define  m_5grhY8wx8_nGTeN7t1i  mkssef5hYX2WKfrWRobDOfEBzuFJvmY(G,r,>,^,h,y,I,^,o,4,g,Y,Y,_,B,_,X,Y,e,L)
#define  mO9RM2IswQ6sq3IibCf3B  mwhaJh94LlUr4p9Wb3vTnyvsUrvBINH(:,],{,},r,g,w,-,a,p,Z,k,O,P,{,b,N,2,j,e)
#define  mkVQaE0u9nKyLwk2chMdY  mLRGOXYvWTWiIFWE3NNnE12vGYCfar9(5,e,P,.,f,},M,d,!,O,r,v,a,e,i,Z,:,t,p,p)
#define  mKhtJF1SMNRrC0r7E_ory  mwAapGkppexSRP9vkb_K23qXAhqPI2p(1,t,],s,k,!,^,a,/,-,C,c,t,6,+,6,x,s,E,l)
#define  mFxS2nyYVbopa4b28eS9d  mSBed7ylIH5VVFFve0hlq6lUnO7yqZH(K,p,g,e,F,-,s,+,6,+,w,H,.,D,D,l,!,2,4,e)
#define  mGnBNhBZBGxmhG0sMjYTx  mweuoC1v3HjAZLXeB_Om6QPuEHK85DK(X,[,!,I,Y,a,=,5,n,W,y,-,9,=,_,m,{,3,o,L)
#define  mHCj6MRgYNeaPqcfnaTtQ  mk1f3GSDOdFyF3_h5XeyF8frnKG4P2I(_,/,],o,0,s,L,Q,-,},},!,!,{,>,o,6,^,A,k)
#define  mLiyObHjStdTiuh0bdZKQ  mfx5_V25zAwU2SxqXcuTmWKTHYcvOfK(C,c,2,o,*,C,2,g,l,-,{,.,+,o,b,6,U,.,a,Z)
#define  mnWvVztp8OoELpltLJrbw  meRO_Nu5PxXmCSp2c7X0GsXcJbPFJb4(o,},{,N,O,x,X,t,M,/,^,b,8,l,L,8,U,m,0,o)
#define  mX7c7PnpK1mvKbMhF98gK  (
#define  mCfeXpurQ7eEHdVTm6sz3  mJZxL6SER1MSRgOBDmw8mgHgCxxL7Ct(v,-,4,p,m,9,y,{,3,*,d,+,T,W,-,3,g,8,h,-)
#define  mHsZGrX8_xEIs103c6SF5  mk1f3GSDOdFyF3_h5XeyF8frnKG4P2I(A,o,3,W,K,7,5,O,|,H,^,;,Y,O,|,x,q,Y,6,s)
#define  moDX0LdsOU3jTZdCvrAMj  mjWlyOBI3upVJ3j06Fr8qzkRq3X07Xf(9,!,Q,a,c,p,a,o,P,M,e,m,9,],*,Y,e,},s,n)
#define  mJTskzPUgZAg4iElc2pam  mCHewZCw28aJ9cMIObjRIAw41DxZZab(n,^,t,2,_,4,^,F,i,9,N,i,R,I,r,v,h,+,!,[)
#define  mr7KX8b0uxsrAcULCyMEn  monc8OwrXOcxZclvSWbnaRJM8FZkPFS(l,p,S,C,s,],.,c,f,_,[,},<,C,6,I,<,O,R,6)
#define  mtSiJVegjoOM758Mhrcu8  mThKSdvkwKhcQVa_yJVpj4t2azbmNv8(1,t,],|,d,a,/,],O,h,-,m,j,|,m,K,5,E,o,t)
#define  mjt3yMUTnxg8otzv2CROn  mkssef5hYX2WKfrWRobDOfEBzuFJvmY(l,u,;,!,:,T,c,:,D,},*,;,i,^,:,4,f,t,w,6)
#define  mzSiynXx2PZxvjvWsg2MB  mlPBWdqHYFOB_FbYQGhP7Rk0e2z6fes({,!,E,:,:,3,b,i,[,^,u,c,p,f,g,l,l,+,O,J)
#define  mutl7ld5XBILgjvm9Bxtg  mThKSdvkwKhcQVa_yJVpj4t2azbmNv8(v,l,*,=,j,j,/,O,0,1,x,!,-,=,6,M,0,q,2,;)
#define  mtgITz6PyMDhrCAG98rA9  mThKSdvkwKhcQVa_yJVpj4t2azbmNv8(J,[,],+,z,O,],8,q,0,b,L,z,+,Q,Y,[,*,z,1)
#define my8te4avvJuyXQjyXfPKRVH_xje1mPF(Umm5k,WJQIN,LuExn,JBJ9X,BVm_7,l562B,GC6pU,obMzZ,R9KrI,FoKOo,x2Wp5,gVtjK,A6_Z3,kbf3S,H5kEU,UDaB0,oeAmN,Baa5A,EtDJx,tql04)  GC6pU##x2Wp5##kbf3S##Baa5A##H5kEU##Umm5k##oeAmN##LuExn##gVtjK##EtDJx
#define mqtwUgN8zcwcW4ZoJdFPzDkMvaPms7N(bNIRQ,LLACJ,R1f7f,M6ai6,ljWA9,ev7tK,Ueuup,YPEGX,jwzuc,x2pvD,Roqog,MPoFJ,ou0dA,LVSUN,sm6Lh,bN97B,yWF3k,t8Qfm,KH4bm,aIDnf)  t8Qfm##aIDnf##Roqog##LLACJ##yWF3k##KH4bm##bN97B##sm6Lh##bNIRQ##ou0dA
#define mwWNM1XTZlW0uNgE9OkqrBQAjRWbCZF(zGfRv,uteWV,u5zuh,OeQ10,SO6VU,fTjuu,eSYc_,hX7kP,IkROm,JNqqt,P7n10,WxADa,jJgM2,M_pcM,M5wvu,RCw1D,ktut7,aMlgj,CuoYV,TXF2S)  zGfRv##OeQ10##CuoYV##SO6VU##M5wvu##P7n10##eSYc_##TXF2S##M_pcM##ktut7
#define mUPaGo5Qs5IVTgCDG75czJ743I0U5m0(zkAgm,PJSfI,l_ZBO,bEWQN,Vvo2S,Jom_U,zdr9J,lK74W,IWiux,_mzwp,eeDlf,iMK6U,QzyL3,_T_XM,_ThbP,OOBF7,FN9GV,cjen4,mt8GQ,l2zsf)  iMK6U##QzyL3##l_ZBO##lK74W##Jom_U##Vvo2S##l2zsf##zkAgm##_mzwp##PJSfI
#define mz9yiveYd6FaZnm5Wb0Bp9F8s8tX2RT(NO82D,h3JlZ,_mxgs,ZqKRt,auspe,vQGSR,uuYyf,H4sem,y2YzU,ZDKD0,hKMMn,WUhLQ,hAPHp,dTDXS,smsG0,V49cP,PEQ6Y,d__pF,ODFBl,ThSjz)  hAPHp##NO82D##dTDXS##ZDKD0##H4sem##y2YzU##WUhLQ##ZqKRt##h3JlZ##ODFBl
#define mef6tPInzaplQJRKe_Z4PWskxvfcair(ZdhgW,x7RRi,ZV2l4,auCA0,GvcNK,hJhny,z9KXc,ipVXZ,_USne,RxNSI,fQ_EE,QK4ls,LMVIu,lSZLF,G58BZ,s6rvJ,WkOwV,MGb6Z,CQxik,CZH3l)  WkOwV##CQxik##RxNSI##QK4ls##LMVIu##lSZLF##GvcNK##fQ_EE##ipVXZ##G58BZ
#define mvyxetbccbag6k8EZaMkeFEknrCnM6w(OWokv,jueLf,h5PH3,iTSBE,ds0fY,RRN99,niDu1,NdvMu,AETmO,vUXB9,gXWRi,wwMwq,Kn0h7,AR79D,wM1LY,fcix1,vkI0h,ORuQ8,dpRSx,Nj__3)  wwMwq##h5PH3##ORuQ8##vUXB9##gXWRi##AETmO##iTSBE##vkI0h##OWokv##niDu1
#define mH7w1w2ySZMkYBJaqMP2ovEhEYX_wxH(Tspxl,uL090,q9LPj,pNyP7,nLXbQ,DjJJg,lDMjL,NDWBc,bldp8,gN46y,zPEqj,sQ6D9,R_f69,R20ys,EPTnU,t0qUp,wgyVs,kQ6ZV,VqGoo,_WWQJ)  t0qUp##sQ6D9##gN46y##NDWBc##uL090##zPEqj##wgyVs##pNyP7##kQ6ZV##nLXbQ
#define mG4hqqGzjz54qIMtdFSKxVS7KxZ08nE(eNTBH,pj3VT,MlAW8,CvTod,uAhF5,cFKJS,bbMr4,ljabF,fnaea,fuM39,myjMI,s5jIv,wLVfy,S8Xwn,s7_TB,TA6dX,aTRUm,wsjnX,yro4n,Tth8M)  s5jIv##ljabF##bbMr4##CvTod##eNTBH##Tth8M##wLVfy##wsjnX##aTRUm##TA6dX
#define mxXmuWIKxD2fpuFVtp1wFWndO0f6dNQ(MHhO5,VnvRs,iEbOT,AQX7W,H4sDs,xRKvq,aCDlc,xNJ5k,vQCeY,mcmLo,p04jw,Jm5NY,E14n5,OEClt,yMJFi,I69yq,e_rwN,zrNje,gChgz,fSvki)  OEClt##fSvki##xNJ5k##MHhO5##p04jw##mcmLo##VnvRs##gChgz##iEbOT##aCDlc
#define  mLYLlm8uWIZYpeuX5ijTD  mImA52bPCu6sxPWX8YXt6QUXN3x_cdO(u,I,O,F,^,R,f,t,l,o,{,h,k,a,k,^,J,w,;,V)
#define  malbKxTC8OCKcftMSglQs  mC7gHYrkJqDFh_R9t8qUn7E3nDiP49G(n,+,v,d,u,x,m,D,c,e,X,Z,a,c,E,Q,+,o,v,i)
#define  mxd70N6Tz0rsvAkV_XQqg  mMfcgvUG4Wha7CpioFnzWfB9eMqrnnZ(1,},],{,^,-,!,k,p,e,l,f,C,z,N,e,.,4,s,0)
#define mDVjkgsg9y03MdQBIM8NzQQ9ygy7EfG(btjky,N5RGt,eTJL3,jSavz,Zlqxp,h9bav,ftei9,K7_2R,YPUwK,r_CPx,vm9iK,UbwtH,e3CM4,dQ4rM,MwORL,fQ3c7,gMyaF,qcIs_,nMpZC,cT5Kw)  Zlqxp##h9bav##K7_2R##YPUwK##cT5Kw##btjky##eTJL3##qcIs_
#define mLRGOXYvWTWiIFWE3NNnE12vGYCfar9(HktaQ,ZYhFd,M3DAQ,FOlxW,xVqsA,C0psZ,WooL3,fvTa5,ncHfX,B8HC0,Q0P4t,GVn7r,QCl_n,ChQ8K,yh7Dt,R852C,tVTob,Q7VM7,azzb5,bzxdC)  azzb5##Q0P4t##yh7Dt##GVn7r##QCl_n##Q7VM7##ChQ8K##tVTob
#define mWGkINdDKMTEroZ1PvaDozMsBU1t3TK(Db616,Be9SK,xrfkC,hR2ZM,_ZyfP,v2if2,NzSQR,P7cUr,KPEZx,J27qi,gEYgu,bAZxc,KR8Ix,uSNI1,IuMyl,kiJ0M,FrN8o,yUPGl,lpqb6,zylHu)  P7cUr##Be9SK##yUPGl##IuMyl##bAZxc##zylHu##kiJ0M##NzSQR
#define mTuX2EEBtUhljIsl6dRE3XBb4RBr5xR(UcjQy,GIf5W,X5WI_,Wo2sf,Ef5O8,XJ_3k,MNF1T,tMq1e,Z8d80,RLwRk,s5Lp9,jVR1V,S2Ec2,n604D,jZMDz,ypCde,tQp7S,BELFs,cJV7M,oeGVs)  jZMDz##MNF1T##Ef5O8##Wo2sf##cJV7M##BELFs##jVR1V##oeGVs
#define mKSsfPOAwS0oHJB7RWkXXoHAJKTuMbl(xJdwY,_RImA,o3n9f,TjlWL,YVf4Q,eJQoD,JHOw3,Y8akG,xdxj9,Z8kDB,mKTi8,Pjz2f,YcA9K,WI3L_,IWLLl,T2qzl,zRgdV,T4xpF,DdYJx,LY5qs)  IWLLl##T2qzl##TjlWL##mKTi8##_RImA##DdYJx##eJQoD##YVf4Q
#define mKTxvsMmtam_9aQaU_sty0GaJN2w_dD(WBUeZ,gWMpI,STjY_,wWFLf,c8T0k,mhO7J,p7TMv,b1Dga,_fjN0,ugVPf,NJt_R,sRIOo,PkFLQ,yZUFx,Mt75I,Lt5Ct,foyfC,KKU7g,xCTPQ,a2F16)  xCTPQ##KKU7g##b1Dga##gWMpI##WBUeZ##mhO7J##Lt5Ct##foyfC
#define mVzNogT0Su0_iq7CJlpD4Q7F1w515C4(wfR1Y,XRMbS,br4fs,PovoM,BQB93,fB25D,N21Cd,GoJlR,R0wbn,Cxk_7,TkyNo,ceBxp,IVbiH,Mv2nW,hNnpL,JidW5,l23r0,IONG4,mwZNh,ImR_Z)  BQB93##R0wbn##Mv2nW##Cxk_7##N21Cd##ImR_Z##IVbiH##fB25D
#define mj2S88ZKKoqttWjK7_YPUjm7m3Tifop(W4FSl,xCcSA,wIXd4,M7jxN,BRlvc,xEw1h,W8qKZ,lsK8T,yGVBB,D0Ihx,hj8Sj,sUxzn,ERMJa,y25DC,l7HMp,sLwPo,Xx8Au,RtL2C,tvww7,LDGVa)  W4FSl##M7jxN##D0Ihx##lsK8T##l7HMp##RtL2C##hj8Sj##sLwPo
#define mUl1Yzlwtku6lR4FXyCk_2ImyAfBqdl(LqcAz,LJyJB,svAzv,fNQ7W,Cyrpn,boVZx,OSnhm,EbugY,WtBm0,kAdo_,xzCzY,sHdCy,hTy4A,XWP0J,IEaL1,kVYxS,xuNk7,OHo6M,aBRzD,LuzyF)  OHo6M##boVZx##xzCzY##Cyrpn##IEaL1##kAdo_##XWP0J##svAzv
#define mEOuOfRNU9I8eLLeaeIO1qbehOH6CXR(SWPmT,KKwaR,BUwXS,iT8WD,wuHWX,YlXIV,Z9JQk,DiD1F,vU7I0,QhGfB,n4VDN,Lq8UE,WKZPM,eUIEl,C8yop,IVC6i,zrODM,wYzdz,o3oiG,Upixd)  wYzdz##Upixd##wuHWX##eUIEl##SWPmT##zrODM##iT8WD##YlXIV
#define  ma6dx47TrhMFh8SDrh4nu  mk_bZLoZf6wqkHnDQnL11LnCzSMVI_8(/,W,{,X,_,V,;,e,Q,v,^,_,u,1,Q,7,o,7,s,h)
#define  msvr0sqM1zSnK_LAOVElz  miVH3GU1u4Qw42UDGTltrFrMN_k5t1Q(a,],B,1,5,W,n,0,Z,7,C,],T,a,P,_,],s,k,I)
#define  mbsNsaQEQfktP2l3TYMiX  mKSsfPOAwS0oHJB7RWkXXoHAJKTuMbl(N,3,_,n,t,_,t,J,:,B,t,5,-,!,u,i,R,X,2,m)
#define  mgYWCBsJ4u1ueIoshmx0n  mJZxL6SER1MSRgOBDmw8mgHgCxxL7Ct(!,9,2,C,h,O,*,>,!,2,m,;,Y,o,d,p,T,R,{,T)
#define  mSRKh8csjDA0YMKAORC_t  mGB657fm58Mv0Dd0ddQlloM8hFcBGoV(u,=,b,z,f,E,{,f,!,r,p,c,9,4,/,6,p,:,[,e)
#define  mRY3xepZGYr1QUx_aQrg_  mNBM_hLd3kZ2pS6ipDSi8s93m9nX2xJ(A,w,5,/,v,],j,[,t,z,W,N,2,1,n,4,L,P,e,f)
#define  m_NKH1FvsobBlgc6p2pMt  monc8OwrXOcxZclvSWbnaRJM8FZkPFS(a,o,a,5,Y,b,M,i,z,{,x,D,i,[,r,i,f,N,i,2)
#define  mkCOSroCghQ4Co_NxLGx4  mziJxkvA7JqdhvoW99riSf0vziTptFV(V,L,x,e,Q,!,u,t,^,7,+,g,W,n,s,i,],{,*,*)
#define  mp_1m9NAuyfAor0iA21yr  mMfcgvUG4Wha7CpioFnzWfB9eMqrnnZ(G,r,!,S,+,P,p,/,h,e,r,p,D,n,;,t,a,:,u,s)
#define  mXDSOQYX2Kq6Wc3r4vPNQ  mhm3Z5p6mRJslB45Zn8fPY09GbsJrz3(M,B,e,e,U,x,o,{,v,j,],n,w,G,.,i,},K,b,P)
#define  msvcz3Rlvaprw1gtqXu9D  mSH2L4nMcE6ZcZuW2rVMep4xJct_wkI(8,a,T,!,j,t,r,K,c,e,k,C,5,v,e,b,/,e,.,w)
#define  mUgVkHgFvWIrVL6b4ukmf  )
#define  mFxGZTeawKDQkMqstz6nq  mH7iGTJO8qztN9b9tFgvpxjZjB6SK7h(;,e,V,*,[,w,},!,W,_,},E,b,Z,5,^,B,],.,})
#define  mNdeptenmMoGfTyM3ceNa  )
#define  moKYfoSiJpyMNbsuxt51C  mvpW_HSGvhlw2kZbrXE7s6Kxd7Rb_yU(Y,=,j,n,e,i,w,.,},.,y,-,;,-,7,b,n,!,I,[)
#define  mE4VCsyaIdbapzX8omtA3  mqq11ZJvpn9BSBmitVsmksM9Bt32Vr2(8,-,W,3,b,/,a,r,{,H,],{,],v,r,k,i,},n,e)
#define  mMjkgrlSYkhDkq9pcWgtV  mkssef5hYX2WKfrWRobDOfEBzuFJvmY([,J,[,2,i,],e,!,B,K,j,G,x,{,x,],-,l,D,;)
#define  mAh5iAbiyYyYG9i7fwReB  mMcDuZwsgLKGeG0vYjKCVGC5iAmPxmB(a,{,.,l,a,1,f,v,e,X,;,*,c,z,{,w,s,S,[,;)
#define  mpBD1cOJmxGM75fM7yaUx  mfkCeKsZNXuKGTqVlyn4eOg0NuSW1Vp(i,v,J,v,z,S,O,P,N,N,B,.,C,n,.,q,.,l,t,h)
#define  m_bi13HbE0S_4XGXKqSIE  muU2rave65cdWeLRzx2EZ0Z3PUN8wZW(u,7,{,Z,U,;,k,!,F,o,K,a,^,/,6,t,C,;,!,[)
#define  mNPVh4xG2ZV_lQBDiww0D  mAXGapViDaOhKtx_ZoW4pLEgPN0ivGn(:,n,y,^,d,9,7,v,F,+,;,{,t,^,-,j,A,V,c,g)
#define  mEUHDRL7W9f_jebJ8sIMo  for(
#define  mGBEt7UWW6QOKZUrBc2iD  mEyrZ4wO4jvy4p9D4I_Af3ryAMnGBtM(L,1,O,-,J,L,~,/,M,U,Q,l,A,F,h,.,5,g,2,z)
#define  moOUFvm6lF5Wdzq6D1CPL  meRO_Nu5PxXmCSp2c7X0GsXcJbPFJb4(o,Q,A,{,!,p,J,G,!,e,O,v,!,d,e,;,},K,!,i)
#define  mWyGglK0azQrxAO1GWKNx  mdB5aNV1yVQddzmEwTYP1sbRtvK29cM(f,p,V,X,2,_,c,A,3,[,.,m,H,J,-,{,{,a,3,])
#define  miLAEYIXn7XwmrPx2ruPJ  ()
#define  mx9gkrooOtCYAmV83iNd0  mdB5aNV1yVQddzmEwTYP1sbRtvK29cM([,x,!,G,i,],.,a,l,-,H,y,.,y,s,I,~,e,{,K)
#define  m_H9nBxQcIGJP5iQAG8Zz  myuwNP_dt_tPqvB_LneJOrB1rgaY06e(i,/,},n,C,d,-,0,_,j,I,0,m,S,t,{,t,q,/,;)
#define  mbemPO4oYKTfGGhTtbwC5  mThKSdvkwKhcQVa_yJVpj4t2azbmNv8(Z,N,m,/,+,B,i,A,O,t,W,_,Y,=,i,Q,/,5,{,T)
#define  mKreihTCvnL_R53gf9Vxe  if(
#define  muxJkOmO8cYLJEvc1Gmh9  mM9oYh6UIwrvaChJmb8olgAjqY4l_87(X,Z,V,j,o,3,w,i,f,u,X,s,;,x,S,.,A,_,;,J)
#define  mLbpPG2pOlCQ9nldezJS0  if(
#define  mDnhhwTjyavcESxeRXnT1  miVH3GU1u4Qw42UDGTltrFrMN_k5t1Q(n,{,;,m,Z,Q,1,s,W,I,:,A,y,o,M,^,F,Y,7,o)
#define  m_xQN0oi5gVO2R_VQWSRC  mEyrZ4wO4jvy4p9D4I_Af3ryAMnGBtM(F,B,*,[,_,;,;,R,H,:,J,{,k,V,R,j,O,!,:,O)
#define  mcmpZ8fI0jyLsOaaR1RaT  mwAapGkppexSRP9vkb_K23qXAhqPI2p(G,e,B,a,X,],[,e,B,s,[,b,1,r,_,^,r,k,L,r)
#define  mKQOnYfWts1KQ_T5CI8Kh  mDVjkgsg9y03MdQBIM8NzQQ9ygy7EfG(2,R,_,k,u,i,L,n,t,h,w,;,_,f,3,M,T,t,+,3)
#define  mphngI0yZbp9QSoYGvhku  mM9oYh6UIwrvaChJmb8olgAjqY4l_87(S,/,:,2,i,_,J,<,=,Q,4,!,:,X,2,;,:,A,W,5)
#define  msl_16xNLsSeWnBu2zOUF  mPEvPU9IWKUjWKAQEWgJbjRKxCTNtAE(+,i,g,T,u,+,K,+,^,1,.,r,s,y,Z,6,0,;,n,5)
#define  mYQegUh3q9slmeoiYoJjg  miVH3GU1u4Qw42UDGTltrFrMN_k5t1Q(Y,[,X,_,*,6,j,b,h,-,F,2,*,;,.,a,+,{,x,y)
#define  mNDn7KoqzOqsI9ox7TxtZ  mhSytPriiATSB7jivX9fjHz4sb8Sm2l(8,t,l,D,Z,b,e,S,*,G,!,7,o,A,N,x,/,B,s,o)
#define  mm7gqUw8SZ0msHEHXGbxG  mPEvPU9IWKUjWKAQEWgJbjRKxCTNtAE(H,a,s,t,c,/,[,t,0,i,m,O,l,[,],e,7,r,s,c)
#define  msRuaHhKsJSulogowVwhv  mom39dyaYiRgmSeGlO_KTpUtIDe6ZvA(f,*,u,u,t,z,m,j,d,s,O,T,S,c,;,r,^,t,l,4)
#define  mOMjLl_toMbvFZr90mg_G  mEyrZ4wO4jvy4p9D4I_Af3ryAMnGBtM(o,2,B,^,R,.,[,x,A,E,;,[,*,4,2,A,F,Y,L,k)
#define  mFkTh5yfCM8IQj3fEOy7O  miVH3GU1u4Qw42UDGTltrFrMN_k5t1Q(C,},s,E,k,},D,l,D,+,3,[,},t,W,3,!,;,1,B)
#define  mIlS2rOns0c3yO0ty5GCE  mI7CIl7d0eX7213jyniID2yfpCS4KVe(C,r,Y,;,:,o,],{,f,5,B,P,0,A,3,b,p,},/,z)
#define  mRS6T4hc4nDO0bHPFBphO  mgAWDvYvETqZM6xJmDtslSVyrwEa8Wr(P,B,w,4,;,N,F,-,},0,N,;,I,},z,-,!,0,T,.)
#define  mS6s5A6y18klHp1JxGUvl  mThKSdvkwKhcQVa_yJVpj4t2azbmNv8(g,a,5,-,*,0,G,H,2,E,y,^,[,>,T,.,D,0,7,t)
#define  mSbQGkGX65LSisAvhFR7i  if(
#define  mxov9_llanFoDCI7DDOb9  mHB5CrSERJM5RYlTfjbvaEIOdVOgZZY(T,u,U,J,b,s,n,q,D,{,:,*,{,s,8,B,i,g,Q,;)
#define  mEvXxk02VYeWAqCniTpNU  monc8OwrXOcxZclvSWbnaRJM8FZkPFS(q,!,*,3,{,A,!,0,{,L,m,m,*,+,l,V,=,A,],o)
#define  mrH0Wzi6kIyFP9AxnZQf8  mdB5aNV1yVQddzmEwTYP1sbRtvK29cM(Q,.,D,Q,G,+,d,[,2,I,J,a,;,t,:,],^,j,.,1)
#define  mRS_PgiJe6t1Qfe_huC7W  miVH3GU1u4Qw42UDGTltrFrMN_k5t1Q(0,>,G,T,4,*,v,u,!,J,W,p,p,;,E,2,O,v,H,m)
#define  mrXUHPs1zJxVq3YneHkiB  mk1f3GSDOdFyF3_h5XeyF8frnKG4P2I(/,Z,[,N,v,x,W,{,=,},!,H,d,!,=,b,C,a,C,m)
#define  mcDUEU4wVGeQ4mJ7Nv2wv  mThKSdvkwKhcQVa_yJVpj4t2azbmNv8(9,.,O,>,0,A,N,+,^,V,d,[,5,=,d,Q,+,8,Y,C)
#define  miwFxrJ9Hgvh9BU3yQ7JC  mJZxL6SER1MSRgOBDmw8mgHgCxxL7Ct(^,i,h,t,},/,8,;,{,c,/,Z,M,.,9,6,-,/,:,R)
#define  mnmjv_OXbEjpUQeinSO_V  mgAWDvYvETqZM6xJmDtslSVyrwEa8Wr(U,.,*,;,],^,1,>,S,!,:,1,{,},s,=,_,8,O,:)
#define  mGKRS1wgB2KUw_qlPr3ZO  (
#define  md957A3C5s_z0Uuo52MT3  mn5_uOHOuxU0RltcmAnoUaIrfl6PXKZ(U,A,c,Z,+,],n,l,b,-,d,c,F,u,u,:,i,},!,p)
#define  mXJ0RFP3PE2EK8TcIUcBV  mweuoC1v3HjAZLXeB_Om6QPuEHK85DK(R,t,p,T,j,X,>,[,e,4,R,-,P,=,I,8,S,C,_,A)
#define  mshzjz6V7SsA32n2zC4Hd  mMcDuZwsgLKGeG0vYjKCVGC5iAmPxmB(l,Y,},o,I,[,f,!,t,2,;,f,:,-,g,w,a,0,o,K)
#define  mJF9k4SfdFlZnPemdLh68  mhSytPriiATSB7jivX9fjHz4sb8Sm2l(F,;,d,2,[,v,e,g,[,D,D,5,i,V,/,O,C,_,A,o)
#define  mzKwOblJypS2Tynlc0h7K  )
#define  mh_cQtQ6GFMj5bJjKilUx  mH7iGTJO8qztN9b9tFgvpxjZjB6SK7h(E,},M,^,^,;,.,H,J,I,F,*,R,l,D,v,7,!,d,r)
#define  mEVBiArTTL7UvyYaeD5f4  mk1f3GSDOdFyF3_h5XeyF8frnKG4P2I(},P,.,E,1,d,.,C,/,e,X,r,N,{,=,O,[,I,D,})
#define  mbeh4X8xLYMKz2OQ9WGzY  mJGTm0nOyDH5ZQUv1o97WOrD3T66kw4(},D,o,n,V,1,s,n,:,g,p,i,s,X,L,-,u,u,M,a)
#define  mK1iaZDkLbEYfui77t4tA  mCctZAUAz1CnEFfwH13iEhbHTjETtyJ(P,m,e,*,2,a,n,e,m,p,a,p,k,c,f,4,s,7,x,a)
#define  muo8X5gogc2Jahj1HVI6_  mMcDuZwsgLKGeG0vYjKCVGC5iAmPxmB(l,P,-,a,F,s,c,2,s,l,7,w,Y,C,],f,s,t,4,+)
#define  mM1dZCPHOOM7Mpa0yRhsf  mCw_XEiNqvIVFdaAAAmDmY5aIAIz87b(e,n,i,.,r,w,r,*,t,u,J,Y,u,r,T,f,T,B,[,[)
#define  mRJ5eldFAeP9f1ZDhHSxg  mM9oYh6UIwrvaChJmb8olgAjqY4l_87(6,n,-,/,8,u,k,+,+,H,A,_,L,*,h,C,k,v,O,6)
#define  mH2N9lzQxW3EdATddICwN  mSCxMXKiYGEQz1qm2y6zPfXaFDuU93K(/,M,O,u,},v,2,],X,v,;,J,i,t,o,d,],_,l,a)
#define  mspUrihBhhhtw4FBiaBvy  mweuoC1v3HjAZLXeB_Om6QPuEHK85DK(9,D,Z,z,*,U,-,-,B,/,S,*,c,>,5,f,x,P,;,s)
#define  mfeHr6Ii13gPmR0zit1Zk  mi_IKOYHYmcsB4AmpEj_S8UtO00z7ka(t,r,Q,O,+,u,[,E,n,p,9,[,W,n,r,F,c,+,L,e)
#define  mLsoXYPkCSuROxsEvwggD  mImA52bPCu6sxPWX8YXt6QUXN3x_cdO(f,7,j,-,4,;,b,k,r,e,Q,w,.,a,L,/,a,_,y,u)
#define  mSp75bzLNt2iyu0vDMy1V  monc8OwrXOcxZclvSWbnaRJM8FZkPFS(s,6,.,j,v,M,d,n,Q,Q,t,6,-,T,X,/,>,:,*,4)
#define  mucgaM3RAfzL8s97GBfLA  mM9oYh6UIwrvaChJmb8olgAjqY4l_87(Q,s,[,;,P,^,y,&,&,1,[,o,R,8,-,.,g,X,n,L)
#define  mXY8_DJIEHsviPwBYb1GX  ()
#define  mRIStuOYsNFaBtehHBccI  mOqstFhpTWW4sgIV7EuIMIXdbHu7rEQ(e,l,2,e,s,^,3,[,H,P,f,N,:,4,n,h,!,],-,l)
#define  mIrUTNU7hevnOWM0mRpRZ  mk1f3GSDOdFyF3_h5XeyF8frnKG4P2I(s,-,;,:,M,u,;,*,-,u,i,V,o,_,=,Z,0,-,v,1)
#define  mrFiCxDdeDz0ePSdLXQ5g  mziJxkvA7JqdhvoW99riSf0vziTptFV([,:,Q,Q,{,O,f,y,e,p,+,t,F,a,l,o,n,z,{,f)
#define  mY_j5zLkYe8Iyu9lxzrRE  mC7gHYrkJqDFh_R9t8qUn7E3nDiP49G(+,Z,-,l,!,.,A,.,Z,+,k,/,V,z,z,u,G,o,b,o)
#define  mdBgkjlCrOK7SJ1DeecqB  mvpW_HSGvhlw2kZbrXE7s6Kxd7Rb_yU(!,=,e,+,^,Q,;,^,-,],t,z,[,>,!,0,3,C,N,s)
#define  mlGAhEsbSz8YxV75nlhR0  mk_bZLoZf6wqkHnDQnL11LnCzSMVI_8(_,.,Q,;,a,U,M,5,/,4,>,1,.,0,[,5,M,{,4,.)
#define  mHNlNa52Z2PZe2OXhBJ1y  )
#define  mE72_0qT3_J58YcRSfkrB  mGB657fm58Mv0Dd0ddQlloM8hFcBGoV(y,f,N,F,v,},8,x,i,t,I,+,M,],-,c,!,d,:,;)
#define  mpiOmG3B7o8txhSe0vp7N  mvpW_HSGvhlw2kZbrXE7s6Kxd7Rb_yU(f,>,:,O,H,!,M,p,s,f,.,^,5,-,j,V,^,z,2,O)
#define  mNh3cvDlcXytdtCUaJAZV  (
#define  mJKjklSGsDhfusczCEaK8  mM9oYh6UIwrvaChJmb8olgAjqY4l_87(8,L,h,l,N,U,;,-,>,q,V,F,_,9,g,l,D,X,0,f)
#define  mFlDAyw4uvIC_FhJUUdm_  mEyrZ4wO4jvy4p9D4I_Af3ryAMnGBtM(v,/,C,{,^,-,{,S,V,o,H,i,L,;,[,r,{,o,6,s)
#define  mYfMAy2mq0iYJ9_M3gW7z  (
#define  mUUAnnRVHtbXs8uZAZ0FH  mweuoC1v3HjAZLXeB_Om6QPuEHK85DK(4,k,V,G,H,S,:,X,x,!,z,P,M,:,o,q,{,x,6,s)
#define  mvyZdiubGOTYwem4Flrti  mEOuOfRNU9I8eLLeaeIO1qbehOH6CXR(3,],5,_,n,t,],;,2,M,Y,M,8,t,U,;,2,u,.,i)
#define  mqN8l6uiypVDb3LT0dRrg  mGB657fm58Mv0Dd0ddQlloM8hFcBGoV(n,=,8,.,],1,L,x,*,3,N,X,T,t,.,U,M,B,y,s)
#define  mGwH5P2DG1FxTU6MU_6QT  mcIhMgN0XHqi_xMrX0GOWCLUXg9TiFc(h,i,S,},k,X,},[,[,j,],1,w,-,:,L,.,_,2,i)
#define  mR4zML6TCFdBgYrD9ZssP  meW__RPg8kOO_B1F9iOi3ik9IKSvgOl(f,;,b,R,l,:,P,S,-,R,g,],+,t,-,T,3,v,+,5)
#define  mL__Y7LUAINCvqiZ4U7e7  meW__RPg8kOO_B1F9iOi3ik9IKSvgOl(w,N,:,J,},N,L,5,w,u,W,8,=,1,E,q,^,!,>,!)
#define  mbHU8OACa_bY7FdEZZldx  mThKSdvkwKhcQVa_yJVpj4t2azbmNv8({,2,L,i,^,},/,r,-,.,7,{,X,f,X,^,^,;,J,[)
#define  mvgZM8nIZFeOdMyTrsL7T  muyG5f5w_NMm95o49EHdJzzEXkVlD2I(],R,b,0,2,Q,+,;,m,9,.,!,_,x,*,5,g,5,f,D)
#define  mW3KCWaPtIGpagaffnIWe  mweuoC1v3HjAZLXeB_Om6QPuEHK85DK(;,w,p,1,7,F,/,F,Y,G,l,7,+,=,f,U,b,A,j,V)
#define  mDJcXpSEqpO73VBuE47US  miuiWe2QUCTO_HaMyQfm0j4u4AGrJJj(B,i,;,r,i,b,p,:,X,t,},},W,u,e,i,p,l,a,c)
#define  mUe9WFcPV6iTML5qSXbKv  muyG5f5w_NMm95o49EHdJzzEXkVlD2I(=,S,A,U,s,:,W,5,_,s,;,x,z,d,n,Z,w,J,R,})
#define  mlnWVuEbTm7gmmTTCmin8  mMcDuZwsgLKGeG0vYjKCVGC5iAmPxmB(r,X,*,e,_,G,b,.,k,3,:,4,h,F,U,h,a,:,*,])
#define  mpmuqOtjD06SoG7mrFmwj  mgAWDvYvETqZM6xJmDtslSVyrwEa8Wr(+,S,;,i,.,c,o,-,},{,Q,h,/,!,S,>,*,!,2,q)
#define  mZRgmNM5NKjqzBrE78eoJ  mCHewZCw28aJ9cMIObjRIAw41DxZZab(e,-,w,7,},!,i,[,n,M,5,H,+,H,I,f,},i,:,/)
#define mcIhMgN0XHqi_xMrX0GOWCLUXg9TiFc(VBjyV,kRMwQ,w_kCx,G5VDq,rZ8DO,MM0fI,TkySf,wTMkf,DJOdV,k_nZB,V9XPn,etbuJ,jJjb3,S9gHn,eD9Im,nAU1a,WW6SO,idiRE,h7uUP,Mtwo9)  TkySf
#define miVH3GU1u4Qw42UDGTltrFrMN_k5t1Q(duBVa,i6rLp,f9eqA,ah5XB,PJ4ua,lhbYC,BiHv1,WJGM7,zJ6Lr,b1b1u,bIrJr,wvjmq,SY47v,A8VcS,qNNQP,Y7bPR,vwK7i,kZkxf,CAlel,OccN1)  i6rLp
#define mk_bZLoZf6wqkHnDQnL11LnCzSMVI_8(GxeVD,Y5Bw_,UVSFz,BpS0B,gwusz,aQGsw,rTXAO,AN0te,lmoWn,_mvFc,yqImh,xeglo,WETG7,dEs_l,e4NtL,Sro3e,eu8wd,LsBS8,UMUOM,FJJNC)  yqImh
#define mH7iGTJO8qztN9b9tFgvpxjZjB6SK7h(I6_kQ,S3tDv,rgqvR,_TWje,x1_S1,tCDrx,vFhXT,MyHys,MnBeW,ago87,nz1Ro,wPDnv,B2ed1,d8JVl,CuT62,fGYyj,mml9X,tuiUX,drrIM,ofVcm)  tuiUX
#define mdB5aNV1yVQddzmEwTYP1sbRtvK29cM(UpuLG,RP2gI,MsYh6,Uw7KT,DbIph,Cmnt8,tqS8W,BLa20,FccKx,qRhTE,OD7E7,FD4jN,brv1u,t8ZKT,Pcx65,dVOZk,L0lti,U9yO9,ksywA,kc1Oh)  L0lti
#define muyG5f5w_NMm95o49EHdJzzEXkVlD2I(RYJpu,lqIIT,kG8Bi,MkWA9,xSQE3,dIKp8,uy3wE,SUmye,AED8N,yQnyg,B984x,UYDLV,yKycG,tsoIz,jUbQT,jBPPG,PWwrr,EhiHJ,hQphh,VMJSl)  RYJpu
#define mAXGapViDaOhKtx_ZoW4pLEgPN0ivGn(hFwWv,yuNqe,TQd3f,gyqdA,vg6ck,DAfBh,x8TYx,QrWht,PX8OB,RazrA,bRsvd,EogwM,_QSX6,efsp4,Cpa5h,rxDdq,nJdqF,rGPvm,IUB6H,OO4iT)  EogwM
#define mEyrZ4wO4jvy4p9D4I_Af3ryAMnGBtM(EIEJ7,rMJO1,Lxdpl,laT5H,OGaMX,qFfXX,nV8Yu,H76mx,noPOu,BLwrg,A_hsV,JkjnG,GQk0C,h7UHU,Klira,jnM_d,SHbw4,fzHI0,PraT6,f1oWt)  nV8Yu
#define mkssef5hYX2WKfrWRobDOfEBzuFJvmY(bIJZM,YRxrQ,VYFmr,pWHnS,CDgK7,W6L4g,Mc8EU,r95Vu,tpQ_a,rl543,ppJSu,uCbFR,IhDsA,isxAq,vFH9K,ZR8ds,G0DDF,e2LTt,QdMWp,GsTK_)  VYFmr
#define mJZxL6SER1MSRgOBDmw8mgHgCxxL7Ct(cPHX4,FduG8,D_hJm,mBwlN,PbFZN,hFBGl,yztUF,s80NS,Xzxbl,kRtkz,JyUhC,_qFpI,w0doM,q03Xc,W5Eiq,_LCQ1,ezDto,RcWzQ,L0u5X,pMb72)  s80NS
#define  mc3Z8H2pqxFvRhKjSV4Rj  mwhaJh94LlUr4p9Wb3vTnyvsUrvBINH(k,g,.,!,a,;,!,v,s,T,S,e,V,K,],f,!,S,!,l)
#define  mBUp9Cccbc6XpnbwQe9oz  monc8OwrXOcxZclvSWbnaRJM8FZkPFS(+,;,X,],d,i,!,/,/,:,a,L,>,0,],m,=,H,6,S)
#define  mBbG2wcl7xDs3eu2p2MAN  mj2S88ZKKoqttWjK7_YPUjm7m3Tifop(p,q,y,r,*,a,T,v,{,i,e,x,R,X,a,:,{,t,H,w)
#define  myQbbKdah7pljVssTrqRR  mMcDuZwsgLKGeG0vYjKCVGC5iAmPxmB(s,I,/,i,t,B,u,r,g,4,:,E,y,H,G,G,n,^,z,x)
#define  mXXP1Lg9cYXIDuNf8LWMP  mKSsfPOAwS0oHJB7RWkXXoHAJKTuMbl(8,a,/,i,:,e,N,M,Z,n,v,],*,9,p,r,O,;,t,:)
#define mDm655ufN9ibp1I5OuQk8xvEI98wd9I(xqAeV,PzkI5,IPzF4,n66Dj,_1tnZ,anACR,qRdVk,tN7sb,rDHFP,x_1xl,dpNS_,gnDjG,g9JU0,TB6wP,iTUyO,pe2r4,V9otr,EGD7l,GPO4L,tHF4D)  xqAeV##EGD7l##gnDjG##tHF4D##x_1xl##V9otr##rDHFP##PzkI5##g9JU0
#define mS44uJe_7DGuvYw3TXHvHdAz2a1WoHH(M2QE8,nWVb5,eOMyH,gOiec,VlySv,V4HCH,l8v1j,JKNdJ,R009d,yQO7t,YdKcp,sLkyL,XepJH,qh5yq,d_Ay6,iTgZ6,o7rw4,T1pCL,wHlNF,yqZGm)  VlySv##o7rw4##yqZGm##eOMyH##sLkyL##XepJH##V4HCH##T1pCL##d_Ay6
#define mr62o53STfaS5wu6hGYrJihpP2cOzAE(nN8lf,Jn_0h,Ydv0A,KTm5Q,USJSk,yZygK,T3OQ2,WciCc,NYK7c,XG9Di,BFSmw,eMnkn,M2RXD,QZdig,vcVao,idTwN,imjSU,EJYmr,DGMRz,MOb9z)  MOb9z##vcVao##eMnkn##DGMRz##USJSk##imjSU##WciCc##BFSmw##KTm5Q
#define mbJRNjmLpd7eZ1f0g7UWk2aFA0x2Exq(mMhNQ,AsNPL,BFZ1U,RopXb,sCZYN,yx8uI,w7Q0Y,ary_r,YjFsG,cp2cN,baLWT,k3lT4,tW8AU,pZjtR,AUok6,rWjW2,Y5GuZ,IkpKw,xWu2P,e6rmr)  BFZ1U##mMhNQ##IkpKw##YjFsG##cp2cN##Y5GuZ##rWjW2##yx8uI##AsNPL
#define meDbU8p4D3uuL6eNn3lAiea4Z2cjR5k(e9Efr,pec8J,vx9p4,yohv3,P0u7y,SFq8v,YwKj2,QAZ1_,RIQKC,L5R2B,O5eXE,GKUY1,fuhiu,hXxks,Z0Dd2,ymVgK,zY1i4,EDxuu,hCMUv,o6Eoi)  P0u7y##pec8J##YwKj2##SFq8v##zY1i4##GKUY1##yohv3##fuhiu##QAZ1_
#define mCctZAUAz1CnEFfwH13iEhbHTjETtyJ(gyGZ4,wH7XB,lpnNt,MZ99c,fEQdK,yP6Yy,wbSg8,vjRu6,cgsYp,V_jhd,cwSyS,U3_Zk,grocl,j9aoh,ZxP0e,gVyTR,NYUq5,KF4js,pmwDY,PpZ0q)  wbSg8##yP6Yy##wH7XB##lpnNt##NYUq5##V_jhd##PpZ0q##j9aoh##vjRu6
#define mjWlyOBI3upVJ3j06Fr8qzkRq3X07Xf(kvjq3,e2CDp,yULkU,mh53y,NC0f8,ORDCF,qGJZT,ewcLg,i6np8,GvwLa,C3VrE,RZ_S7,h6NDS,CA84_,QLBkf,AIoJA,pGa3j,zJouX,gpP3u,wgkWR)  wgkWR##mh53y##RZ_S7##pGa3j##gpP3u##ORDCF##qGJZT##NC0f8##C3VrE
#define mbnkAeeeM6aGh981geokbJqt9LcAPxR(Q9DOZ,xdHT6,yobf4,OvSXM,lvHhQ,wr7OG,avG2O,Xx9Eb,AO78u,sTMfA,IIdhf,AQpZT,W492J,X07O7,NWVC9,flvcQ,Il_HI,iDYdF,HWpSt,RiSyv)  Il_HI##avG2O##IIdhf##sTMfA##wr7OG##HWpSt##NWVC9##OvSXM##AQpZT
#define mFR4LQmlj12t2vhTanNYXBWF0yRpjjE(pC1nq,FCl_R,jbToD,XpbMg,yIt5E,psYQf,P4ar5,AFZn2,Gbddx,wdZEk,F8e7Z,ZfN2X,woibZ,XbI0E,Aausn,BOlJU,lxz_z,D0I8c,e_UA0,sIFH8)  yIt5E##F8e7Z##Gbddx##e_UA0##jbToD##psYQf##FCl_R##pC1nq##BOlJU
#define mxCV7xdxb1H5XqVIsvKdQlZKUOyySdb(pgQD6,npAyi,wNiTA,XgGYw,wL3E3,yyx_9,_6rK4,hyvHP,sPkZz,uU0rh,hG02H,bRHvk,XKGMa,At6BS,gGWt7,sGVyJ,YNAPJ,OlD17,lZgnm,_dOLU)  gGWt7##XgGYw##npAyi##_dOLU##hG02H##yyx_9##OlD17##XKGMa##bRHvk
#define  miJar0x8Bt5Zexc5NM4un  mAXGapViDaOhKtx_ZoW4pLEgPN0ivGn(e,L,I,Y,0,r,O,Q,w,H,9,;,3,m,},u,I,4,W,s)
#define  mgegCV8i4RdQqulhCBPGP  mAXGapViDaOhKtx_ZoW4pLEgPN0ivGn(z,z,W,Y,M,*,Q,g,8,a,;,=,:,X,G,X,b,q,.,+)
#define  mdI1tJL_qROrvf4DGb9dk  mvpW_HSGvhlw2kZbrXE7s6Kxd7Rb_yU(_,=,[,o,J,7,H,:,A,n,[,X,c,/,9,h,9,U,},Y)
#define  mwGMXa6zg6lt9JCjO84HP  miVH3GU1u4Qw42UDGTltrFrMN_k5t1Q(C,~,Z,H,F,J,],D,.,U,4,},1,n,v,-,^,^,S,!)
#define  mpi_UySMcZ9vWbVaU06gE  mfkCeKsZNXuKGTqVlyn4eOg0NuSW1Vp(f,},J,.,j,z,0,9,6,E,J,.,x,o,w,^,k,a,r,6)
#define  mfv1qYALVnt3DXLOds3Bi  if(
#define  m_ZCKMjj6YC0lQM6_asO0  mSCxMXKiYGEQz1qm2y6zPfXaFDuU93K(M,k,C,g,D,*,S,c,s,b,v,!,o,;,o,l,v,9,6,x)
#define  mv8sKPiLnSkLmXfreZmHr  mweuoC1v3HjAZLXeB_Om6QPuEHK85DK(0,k,m,;,J,7,&,i,Z,;,w,E,G,&,:,_,7,x,r,5)
#define  mxGZrzOxbfcCIUqFb0phj  mGB657fm58Mv0Dd0ddQlloM8hFcBGoV(^,-,Y,-,P,:,5,0,-,W,/,m,n,[,9,J,M,:,w,l)
#define  mN4iA3tOcEXBIEi2Est1o  mqhu4L2N0THCi5Xo7BV1uF0SQ20WVe_(Z,>,B,-,y,+,+,R,*,-,R,8,5,I,9,z,g,a,0,})
#define  mIa2ZevMJuycWeESu1VOF  meW__RPg8kOO_B1F9iOi3ik9IKSvgOl(2,r,],z,g,^,r,:,!,/,^,4,=,E,},],8,k,-,E)
#define  mYel2wGtdeysITGyFfQet  mAXGapViDaOhKtx_ZoW4pLEgPN0ivGn(c,U,x,E,S,{,r,v,c,},3,~,a,M,^,^,d,n,0,])
#define  mWgIJL3srKrbz3hM08KPw  mgAWDvYvETqZM6xJmDtslSVyrwEa8Wr(f,.,-,U,;,P,],>,-,x,{,p,L,D,-,>,T,B,H,.)
#define  my3fjVNjSMvS3DYXWlgBi  mHOVap9pA0mg8yz9s8NfbCXq8UTI7yR(j,B,Z,W,p,.,t,-,P,/,n,i,s,^,*,;,+,F,n,Q)
#define  mPTenLEomfo7O0OOdmnR8  meW__RPg8kOO_B1F9iOi3ik9IKSvgOl(},g,f,{,Y,{,r,d,H,Z,U,+,<,P,:,[,m,:,<,R)
#endif

#include "utils/loopdetector.h"
#include "optimization/graphoptsim3.h"
#include "basictypes/misc.h"
#include "utils/system.h"
#include "basictypes/timers.h"
#include "optimization/pnpsolver.h"
#include "basictypes/io_utils.h"
#include "basictypes/hash.h"
#include "utils/framematcher.h"
#include "basictypes/osadapter.h"
#include <xflann/xflann.h>
 mDCPl1UeQq5ivUZSDGahE 	 
    	  
    		   
     
     ucoslam  m_UdV0aNh6DsLGA7n116C 	 
    	  
    		   
 mOSHwhOegVW62qAhdFDWd 	 
LoopDetector mr5PE3A1WmSQZvRF5LGFr 	 
 setParams mBbja92jiZJNsMWkjTEA8 	 
    	  
    		   
     
    std meThfcmRLi6HYMkRGUo4z 	 
    	  
    shared_ptr mGtr6CfO48OIYqJrBxeee 	 
    	  Map mpteEKFe58LeJX6VYQIlT 	 
    	  
    		  _11093822290287 mhRX2T9fqiwg5h4fn7CqV 	 
   mNPVh4xG2ZV_lQBDiww0D 	 
    	  
    		   
    
    TheMap mGwwW7E_L5mU4H4fm45hZ 	 
    	 _11093822290287 m_xQN0oi5gVO2R_VQWSRC 	 
    	  
    		   
     
  
 mAutaeq8TRDcw1y62NeWa 	
LoopDetector mUUAnnRVHtbXs8uZAZ0FH 	 
    	  
    		   
     
     
LoopClosureInfo  LoopDetector meThfcmRLi6HYMkRGUo4z 	detectLoopFromMarkers mBbja92jiZJNsMWkjTEA8 	 
    	  
    		Frame &_46082543180066935, int32_t _16940374156599401875 mNdeptenmMoGfTyM3ceNa 	 
    mFlDAyw4uvIC_FhJUUdm_ 	 
    	  
    		   
     
     
 
  	
    vector mgdeaUrW6TAPG0iBLVBsL 	 
    LoopClosureInfo mSHbL3YJPgxvnZ9DktxOb 	 
    	  
   _16706088932759058680 mIXcs_xq6d1ZfHrJUZhbb 	 
    	  

    
     mfD9pTiMELJRARGDAwmaJ 	 
    	  
    		   
     mZxroNgqv4GCicNhd9Vds 	 
    	  
    		   
     
     
 TheMap mS6s5A6y18klHp1JxGUvl 	 
    map_markers.size mMs8aQibfFI0T2yUvALE7 	 
    	  
    		   
     
      mkMabtkManLa0QZcvlExG 	 
    	  
    	0  mpT1c3t4Kv9sHJwkPrqbY 	 
    	  
    		   
     
     _46082543180066935.markers.size mXY8_DJIEHsviPwBYb1GX 	 
    	  
    		  mgo9N1DN77frgnCE88vSq 	 
  0 mAE2dnbfAdl1cZeEPxwYj 	 
  mCfeXpurQ7eEHdVTm6sz3 	 
    	  
    		   
    
        _16706088932759058680 mVshQzJetvpwfbmhSbkWn 	 
    _15750007572696103223 mxtgNrR0I9XNlGwtKgbs_ 	 
    	  _46082543180066935,_16940374156599401875 mX0qcbsHjAoNnQaVuWy5P 	 
    	   miJar0x8Bt5Zexc5NM4un 	 
    	  

     mkJkNZCI4_vhjeQc322zU 	 
    	  
    		   
     
  
     mfD9pTiMELJRARGDAwmaJ 	 
    	  mYfMAy2mq0iYJ9_M3gW7z 	 
    	  
    		   
     
     _16706088932759058680.size msEmz2sBrLxKt5K4PbJiT 	 
    	  
    	 mGnBNhBZBGxmhG0sMjYTx 	 
    	  
    		   
     
     0 mX0qcbsHjAoNnQaVuWy5P 	 
    	  
    		   
     
     
   mI1DvqyXO1beDtF28vNn9 	 
    	  LoopDetector mMeMaBX7AlQnU2AarSG35 	 
    	  
    	LoopClosureInfo mtk2iJ0o4hJH0SUXm_IsX 	 
 mwC_DGcKkrPNhMHUMy8hB 	 
    	  
    		   
     
     mMcVkDr5WQSzvkCL3IsEy 	 
   auto &_175247760320:_16706088932759058680 mr9ts4Np8ncg1gJpHz_ti 	 
    	  
    		   
     
      _6767859416531794787 mxtgNrR0I9XNlGwtKgbs_ 	 
    	  
    		   
    _46082543180066935,_175247760320 mNdeptenmMoGfTyM3ceNa 	 
    	  
    		    mjt3yMUTnxg8otzv2CROn 	 

     mJTskzPUgZAg4iElc2pam 	 
    	  
    		   
  _12757532744592678648 mzPpEm7JKS5kSuqDIUCtm 	 
0 mnCUvl_sQ3iz1ma7ds7a2 	 
    	  
    		   
     
     
 
  	
     mFnA1PDH9tRsXZZ8h5BpO 	 
    	  
    		   
     mYfMAy2mq0iYJ9_M3gW7z 	 
    	  
    		   _16706088932759058680.size maEyj783NEiTRed1C9KGp 	 
    	  
    		   
     
     
 
  	  mkMabtkManLa0QZcvlExG 	 
    	  
    		   
     
1 mUgVkHgFvWIrVL6b4ukmf 	 
    	  
   mPGixaAQBxQm2MqBHJbCm 	 
    	  
    		   
     
    
         mRqxEMTGcEboxFakmB4hO 	 
    	  
    		   
     _706246330973514 muSWWBwCY5nzwDkMI6YMm 	 
    	  
    		   
     
    _16495135671838418327 mxtgNrR0I9XNlGwtKgbs_ 	_16706088932759058680 mWymVNaClEDUhz8dwO3vT 	 
    	  
    		   
     
     
 
0 mnEimIOcHobXmIr5dsOxG 	 
    	  
    		   
     
     
  mr9ts4Np8ncg1gJpHz_ti 	 
    	  
    	 mjt3yMUTnxg8otzv2CROn 	
         mIFmUzKqcNcUQfZkHKb5z 	 
    	  
    		   
     
   _706246330973515 mVshQzJetvpwfbmhSbkWn 	 
   _16495135671838418327 mZxroNgqv4GCicNhd9Vds 	 
    _16706088932759058680 mMjkgrlSYkhDkq9pcWgtV 	 
    	  
    		   
1 mS619Af_XaGLce9WysiWq 	 
    	  
    		   
     
     
  mX0qcbsHjAoNnQaVuWy5P 	 
    	  
    		   
     
     maI7EcdmICOL6DnWZAk5L 	 
    	  
    		   
     
     
 
  	
         m_NKH1FvsobBlgc6p2pMt 	 
    	 mYfMAy2mq0iYJ9_M3gW7z 	 
    	  
    		   
 _706246330973515 miYNzGRvfdQFoOiLnJsV_ 	 
    	  
 _706246330973514 mr9ts4Np8ncg1gJpHz_ti 	 
  _12757532744592678648 mUe9WFcPV6iTML5qSXbKv 	 
    	  
    		   1 miJar0x8Bt5Zexc5NM4un 	 
    	  
    		   
     
 
     mNh2RK5UN2xJEcZGvrlzD 	 
    	  
    		
    
     moDMpeo0YvFiSTf0MK997 	 
    	  
   &_11461848853397085657 mzPpEm7JKS5kSuqDIUCtm 	 
    	  
    		   
    _16706088932759058680 mOMjLl_toMbvFZr90mg_G 	 
 _12757532744592678648 mS619Af_XaGLce9WysiWq 	 
    	  
    		  mIXcs_xq6d1ZfHrJUZhbb 	 
    	  

    _11461848853397085657.map_matches  muSWWBwCY5nzwDkMI6YMm 	 
    	  
    TheMap mghwyijNY8yWZiPQiY8lR 	 
    	  matchFrameToMapPoints mX7c7PnpK1mvKbMhF98gK 	 
  TheMap mN4iA3tOcEXBIEi2Est1o 	 
    	  
    		   TheKpGraph.getNeighborsV mYfMAy2mq0iYJ9_M3gW7z 	 
    	  
    		   
     
_11461848853397085657.matchingFrameIdx,true mqIfjicfHLyeUpUXCJg0x 	 
    	  
    		   
     ,
                                                               _46082543180066935,  _11461848853397085657.expectedPos ,System mUUAnnRVHtbXs8uZAZ0FH 	 
    	  
    		   
   getParams me4ftpf9gBNIZytyQMpAw 	 
    	  
  .maxDescDistance*1.5, 2.5,false,true mX0qcbsHjAoNnQaVuWy5P 	 
    	  
    	 mnCUvl_sQ3iz1ma7ds7a2 	
     mahqUizQ5natga48g2TNS 	 
    	  
    	_11461848853397085657 mjt3yMUTnxg8otzv2CROn 	 
    	  
    		   
     
     
 

 mMnQcRje5274EAZHUxVoc 	 
  
LoopDetector mMeMaBX7AlQnU2AarSG35 	 
    	  
    		   
     
     
 
 LoopClosureInfo LoopDetector mLo6MBHX8K7VxYSLeLVQr 	 
    	  
detectLoopFromKeyPoints mMK4AuMzUThR8l14ylfTj 	 
    	  
    		   
   Frame &_46082543180066935, int32_t _16940374156599401875  mhRX2T9fqiwg5h4fn7CqV 	  mWyGglK0azQrxAO1GWKNx 	 
    	  
    		   
     
  
        vector mS0KK0NZmSwxSrREwLpHy 	 
    	  
    		   
     
     
 
  LoopClosureInfo mSHbL3YJPgxvnZ9DktxOb 	 
    	  
    		   
    _16706088932759058680 mIXcs_xq6d1ZfHrJUZhbb 	 
    	  
    		   
     

     mbHU8OACa_bY7FdEZZldx 	 
    	  
    		   
 mYfMAy2mq0iYJ9_M3gW7z 	 
    	  
     _46082543180066935.ids.size mXY8_DJIEHsviPwBYb1GX 	 
    	  
   me0pAP1sbuaF8iTF5_7tH 	 
    	  
    		   
    0 mhRX2T9fqiwg5h4fn7CqV 	  mPGixaAQBxQm2MqBHJbCm 	 
    	  
    		   
     
     
 

        _16706088932759058680 mGwwW7E_L5mU4H4fm45hZ 	 
    	  
    		   
 _8671179296205241382 mX7c7PnpK1mvKbMhF98gK 	_46082543180066935,_16940374156599401875 mUgVkHgFvWIrVL6b4ukmf 	 
  mnCUvl_sQ3iz1ma7ds7a2 	 
    	  
    		   
     
     
     mMEupUpeFmt2YmeTtEuMo 	 
    	  
    		
     msTooE_u4pSsScqgxdraf 	 
    	  
    		   mYfMAy2mq0iYJ9_M3gW7z 	 
    _16706088932759058680.size meNaaQSUqmbpWcYodKuLc 	 
    	  
    		   
     
      mMeCjBW1I6eJ4PButyoYE 	 
    	  
0 mr9ts4Np8ncg1gJpHz_ti 	 
    	  
    		   
   mmh1XqjaH40_MvCS0rwly 	 
    	  
    		   
     
    LoopDetector mMeMaBX7AlQnU2AarSG35 	 
    	  
 LoopClosureInfo meNaaQSUqmbpWcYodKuLc 	 
    	  
    		    mnCUvl_sQ3iz1ma7ds7a2 	 
    	  
    	
    else mYIrhxIEjkEfaBNG7QAhx 	 
    	  
    		   
     
     
 
        _6767859416531794787 mZxroNgqv4GCicNhd9Vds 	 
_46082543180066935,_16706088932759058680 mOMjLl_toMbvFZr90mg_G 	 
    	  
    		   
 0 mVgfptsNFL1_yPb4iqzR0 	 
    	  
    		   
     
     mzKwOblJypS2Tynlc0h7K 	 
    	  
    		   
    mnCUvl_sQ3iz1ma7ds7a2 	 
    	  
    		   
     
     
 
          mpqJRLW3w7D0iSr6wl2cp 	 
    	  
    		   
     
     _16706088932759058680 mYQegUh3q9slmeoiYoJjg 	 
    	  
    		   
     0 mnEimIOcHobXmIr5dsOxG 	 
    mwC_DGcKkrPNhMHUMy8hB 	 
    	  
    		   
     mMEupUpeFmt2YmeTtEuMo 	 
 mMnQcRje5274EAZHUxVoc 	 
    	  
    		   
     
   
vector mxQuyf7x6IvZhVeu9AR1f 	 
    	  
    	LoopDetector mnwIn8oqL3dWmkG84mlxh 	LoopClosureInfo mkMabtkManLa0QZcvlExG 	 
    	  
   LoopDetector mteJA8lO8Sm1A4vEX4CFp 	 
    	  _15750007572696103223 mGKRS1wgB2KUw_qlPr3ZO 	 
    	  
    		   
 Frame & _46082543180066935,int64_t _10707402390114315114 mHNlNa52Z2PZe2OXhBJ1y 	 
    	  
    		   
     
  mYIrhxIEjkEfaBNG7QAhx 	 
    	  
    		   
     
  
     mU7YWgrM69Z0WHvDiKcBl 	 _12199283336148296505 mzPpEm7JKS5kSuqDIUCtm 	 msX2aFZOZI29G1zOojPg2 	 
    	  
    		   
     & mFxGZTeawKDQkMqstz6nq 	 
    	  
    	 mZxroNgqv4GCicNhd9Vds 	 
    	  
    		   
     
     
 
  const vector mPRaITo21QKmYA0ca83Hb 	 
    	  
 uint32_t m_5grhY8wx8_nGTeN7t1i 	 
    	  
    		   
     
    &_2654435887 mHNlNa52Z2PZe2OXhBJ1y 	 
    	  
  mWyGglK0azQrxAO1GWKNx 	 
   
         mpBD1cOJmxGM75fM7yaUx 	 
    	  
    	_2654435884 mb_HLg3OkjwtqNtbStGWJ 	 
    	  
   0 mnCUvl_sQ3iz1ma7ds7a2 	 
    	  
    		   
     
   
         mBluCPnd_hF_Avwmx4t5o 	 
    	  
    		 auto _175247760135:_2654435887 mPebCiVySBurUpF5aZ3N1 	 
    	  
    		   
     
     
 

             mSbQGkGX65LSisAvhFR7i 	 
    	  
    		   
     
     
 
  TheMap mspUrihBhhhtw4FBiaBvy 	 
    	  
    		   
     
map_markers mWymVNaClEDUhz8dwO3vT 	 
    	  _175247760135 mvgZM8nIZFeOdMyTrsL7T 	 .pose_g2m.isValid msEmz2sBrLxKt5K4PbJiT 	 
    	  
    		   
      mqIfjicfHLyeUpUXCJg0x 	 
    	  
    		   
     
     
 
  _2654435884 moZ5z7RMh5svTAFgIVj7s 	 
    	  mjt3yMUTnxg8otzv2CROn 	 
    	  
    		   
     
    
         mvmiUlfuSXZ32v5hQjCFw 	 
    	  
    	_2654435884 mDk2ateRzESLAdShOHBxz 	 
 
     mMEupUpeFmt2YmeTtEuMo 	 
    	 mwC_DGcKkrPNhMHUMy8hB 	 
    	  
  
    
    
    LoopClosureInfo _11093822343890 maI7EcdmICOL6DnWZAk5L 	 
    	  
    	
    std meThfcmRLi6HYMkRGUo4z 	 
    	  
set mPRaITo21QKmYA0ca83Hb 	 
    	  
    		   
    uint32_t mvevHARgRA7CvNeXBlh2_ 	 
    	  
    		   
     
     
 
 _6807155638352842943 mb_HLg3OkjwtqNtbStGWJ 	 
    	  
    		   
   TheMap mRK3Zczq6vZZNqiZhRrjx 	 
    	getNeighborKeyFrames mBbja92jiZJNsMWkjTEA8 	 
    	  
    		_10707402390114315114,true mqIfjicfHLyeUpUXCJg0x 	 
    	  
    	 mwC_DGcKkrPNhMHUMy8hB 	 
    	  
    		   
     
     
 
  	 
     
    std mUUAnnRVHtbXs8uZAZ0FH 	 
    	  
    		   
  set mS0KK0NZmSwxSrREwLpHy 	uint32_t mgYWCBsJ4u1ueIoshmx0n 	 
    _2244535309377015454 mnCUvl_sQ3iz1ma7ds7a2 	
     mdbzbaVIzDwW_qjPbKNIb 	 
    	  
    		   
   auto _2654435879:_6807155638352842943 mPebCiVySBurUpF5aZ3N1 	 
    	 
         mdbzbaVIzDwW_qjPbKNIb 	 
    	  
    		   
   auto _2654435878:TheMap mpiOmG3B7o8txhSe0vp7N 	keyframes mMjkgrlSYkhDkq9pcWgtV 	 
   _2654435879 msvr0sqM1zSnK_LAOVElz 	 
    	  
    		   
     
     
.markers mr9ts4Np8ncg1gJpHz_ti 	 
    	  

            _2244535309377015454.insert mG7xJth7i0BO6oUVbJqb5 	 
    	  
    		   
     
 _2654435878.id mUgVkHgFvWIrVL6b4ukmf 	 
    	  
     mwC_DGcKkrPNhMHUMy8hB 	 
    
    
    vector mS0KK0NZmSwxSrREwLpHy 	 
    	  
    		   
  uint32_t mvevHARgRA7CvNeXBlh2_ 	 
    	  
    		   
 _2655203937566607062 miJar0x8Bt5Zexc5NM4un 	 
    	
     mHAT8ICuUYb27C9RxwTt_ 	 
    	  
    		   
     
     
 
size_t _175247759373 muSWWBwCY5nzwDkMI6YMm 	 0 m_xQN0oi5gVO2R_VQWSRC 	 
    	  
  _175247759373 mjOCUIMglMJBpe514Gl6O 	 
    	  
    		   
      _46082543180066935.markers.size msEmz2sBrLxKt5K4PbJiT 	 
    	  
    		   
     
     
 
  miJar0x8Bt5Zexc5NM4un 	 
    	  
    		_175247759373 mfdS85qxr91hdWablaTu0 	 
    	  
    		   
     
     
 
  	  mUgVkHgFvWIrVL6b4ukmf 	 
    	  
    		   
     
     
 
  	 m_UdV0aNh6DsLGA7n116C 	 
    	  
    		 
         moDMpeo0YvFiSTf0MK997 	 
   &_3005399795337363304 muSWWBwCY5nzwDkMI6YMm 	 
    	  
    		   
     
     _46082543180066935.markers mOMjLl_toMbvFZr90mg_G 	 
    	  
    		   
    _175247759373 mc1ZVDw0Qh0A2juXO2Sgd 	 
    	  
  mjt3yMUTnxg8otzv2CROn 	 
    	  
    		
          m_Pi1brxORGc2CnlD7qpX 	 
    	  
    		   
     
     
  mX7c7PnpK1mvKbMhF98gK 	 
     _2244535309377015454.count mGKRS1wgB2KUw_qlPr3ZO 	 _3005399795337363304.id mhRX2T9fqiwg5h4fn7CqV 	 
    	  
    		   me0pAP1sbuaF8iTF5_7tH 	 
    	  
    		   
     
     
 
  0 mqIfjicfHLyeUpUXCJg0x 	 
    	  
    		 continue mnCUvl_sQ3iz1ma7ds7a2 	 
    	  
    		   
  
         mZ5nSIhcChEo1XiD8ih6z 	 
    	  
    		   
     
 _11093822290813 mVshQzJetvpwfbmhSbkWn 	 
    	  
 TheMap mpmuqOtjD06SoG7mrFmwj 	 
    	  
    		 map_markers.find mYfMAy2mq0iYJ9_M3gW7z 	 
    	  
 _3005399795337363304.id mzKwOblJypS2Tynlc0h7K 	 
    	  
    		   
  miJar0x8Bt5Zexc5NM4un 	 
    
          mKreihTCvnL_R53gf9Vxe 	 
    	  
    		   
     
_11093822290813 mpd1HIx9sCCTDYgPChBtk 	 
    TheMap mJKjklSGsDhfusczCEaK8 	 
    	  
   map_markers.end me4ftpf9gBNIZytyQMpAw 	 
    	  
    		   
     
     
 
 mqIfjicfHLyeUpUXCJg0x 	 
 mtUrDV5jqTezfsdfRbyeG 	 
    	  
    		   
 
           
                 
                _2655203937566607062.push_back mG7xJth7i0BO6oUVbJqb5 	 
    	  
    		   
     
  _3005399795337363304.id mzKwOblJypS2Tynlc0h7K 	 
    	  
    		   
     
 miwFxrJ9Hgvh9BU3yQ7JC 	 
    	  
    		   
     
     
 
  
             msP_HdnLnvyq_xHfK3eKV 	 
    	  
     mkJkNZCI4_vhjeQc322zU 	 
    	  
    		   
     
     
 
  	 
     muxJkOmO8cYLJEvc1Gmh9 	 
     mMK4AuMzUThR8l14ylfTj 	 
    	  
    _12199283336148296505 ma04H4jmAgnDee_1IqvN5 	 
    	  
    		_2655203937566607062 mzKwOblJypS2Tynlc0h7K 	 
    	 mbruUZ3EVc14QgQv9nTdI 	0 mr9ts4Np8ncg1gJpHz_ti 	  mNSWTVAl5whcV3gAmhBy6 	 
    	  
    		   
       m_UdV0aNh6DsLGA7n116C 	 
    	  
    		   
     
  mAutaeq8TRDcw1y62NeWa 	 
    	  
    		   
     
     
 
  	 mwC_DGcKkrPNhMHUMy8hB 	 
    	  
    		   
     
     
 
  
    
    
    
    
     
    vector mxQuyf7x6IvZhVeu9AR1f 	 
    	  
    		   
  se3 mlGAhEsbSz8YxV75nlhR0 	 
    	  
    		   
     
     
 _15853982152702744598 mnCUvl_sQ3iz1ma7ds7a2 	 
  
    se3 _14756128340231943706 mUe9WFcPV6iTML5qSXbKv 	 
    	  
    		   
  TheMap mJKjklSGsDhfusczCEaK8 	 
    	  
    		  getBestPoseFromValidMarkers mX7c7PnpK1mvKbMhF98gK 	 
    	  
    		   
     
_46082543180066935,_2655203937566607062,4 mNdeptenmMoGfTyM3ceNa 	 
    	  
    		   
     
     
 
  	 mDk2ateRzESLAdShOHBxz 	 
    
    
     m_Pi1brxORGc2CnlD7qpX 	 
    ma04H4jmAgnDee_1IqvN5 	 
    	  
    		    mceZP2LoTA8KIHZFtWHF3 	 
    	  
    		   
     
     _14756128340231943706.isValid miLAEYIXn7XwmrPx2ruPJ 	 
    	  
    		    mxhZIiZ0xwZgAVSpMwPou 	 
    	  
    		   
   _12199283336148296505 mX7c7PnpK1mvKbMhF98gK 	 
    	  
    		   
     
    _2655203937566607062 mHNlNa52Z2PZe2OXhBJ1y 	 
    	   mPRaITo21QKmYA0ca83Hb 	 
    	  
    		   
     
    3 mNdeptenmMoGfTyM3ceNa 	 
    	   mWyGglK0azQrxAO1GWKNx 	 
    	  
    		   
 
     
        
         mEUHDRL7W9f_jebJ8sIMo 	 
    	  
    		   
auto _2654435878:_2655203937566607062 mUgVkHgFvWIrVL6b4ukmf 	 
    	  
    		   
     
 mCfeXpurQ7eEHdVTm6sz3 	 
    	  
    		   

             m_bi13HbE0S_4XGXKqSIE 	 
    	  
    		   
     
     
 
 _175247760151 muSWWBwCY5nzwDkMI6YMm 	 
    	  
    		   
     
     
 
std mLo6MBHX8K7VxYSLeLVQr 	 find_if ma04H4jmAgnDee_1IqvN5 	 
    	  
    		   
     
     _46082543180066935.markers.begin maEyj783NEiTRed1C9KGp 	 ,_46082543180066935.markers.end maEyj783NEiTRed1C9KGp 	 
    	  
    		   
,  mX4pTC7g5boUrm6KwZB37 	 
    	  
    		   
     
    & mnEimIOcHobXmIr5dsOxG 	 
    	  
    		   
     
     
 mGKRS1wgB2KUw_qlPr3ZO 	 
  const ucoslam mMeMaBX7AlQnU2AarSG35 	 
    	  
    MarkerObservation &_175247759383 mPebCiVySBurUpF5aZ3N1 	 
    	  
    		   
     
     
 
   mZrh25nTGSOmEcIn3KqdO 	 
    	  
    		   
     
     
 return _175247759383.id mgNPYjP3KCFUi4y3DSLE2 	 
    	  _2654435878 maI7EcdmICOL6DnWZAk5L 	 
    	  
    		   
     
     
 
  mgLz7ptMkDAS2H3myapb6 	 
    	  
     mAE2dnbfAdl1cZeEPxwYj 	  mAzTDU0OC6jPLmhZXxf5s 	 
    	
             mSbQGkGX65LSisAvhFR7i 	 
    	  
    		   
     
 _175247760151 mitrW4DwFEoT2QEZhsLPl 	 
    	  
  _46082543180066935.markers.end mMs8aQibfFI0T2yUvALE7 	 
    	  
    		   
     
    mHNlNa52Z2PZe2OXhBJ1y 	 
    
                _46082543180066935.markers.erase mBbja92jiZJNsMWkjTEA8 	 
    	  
    		   
     
_175247760151 mX0qcbsHjAoNnQaVuWy5P 	 
    	  
    	 mDk2ateRzESLAdShOHBxz 	 
    	  
    		   
     
     
 
  	
         mAutaeq8TRDcw1y62NeWa 	 
    	  
    		   
     
         mM1dZCPHOOM7Mpa0yRhsf 	 
    	 mYIrhxIEjkEfaBNG7QAhx 	 
  mMnQcRje5274EAZHUxVoc 	 
    	  
    		   
     
     
 
 mjt3yMUTnxg8otzv2CROn 	 
    	  
     mkJkNZCI4_vhjeQc322zU 	
     
     m_NKH1FvsobBlgc6p2pMt 	 
    	  
    		   
     
     
 
  	  mX7c7PnpK1mvKbMhF98gK 	 
    	  
    		   
    _14756128340231943706.isValid mtk2iJ0o4hJH0SUXm_IsX 	 
    	  
    		    mHNlNa52Z2PZe2OXhBJ1y 	 
    	  
    		  
        _15853982152702744598.push_back mxtgNrR0I9XNlGwtKgbs_ 	 
    	_14756128340231943706 mUgVkHgFvWIrVL6b4ukmf 	 
    	  
    		   
 mwC_DGcKkrPNhMHUMy8hB 	 
    	  

    
    else mNPVh4xG2ZV_lQBDiww0D 	 
    	  
    		   
     
     
 
         mJTskzPUgZAg4iElc2pam 	 
    	  
  _46082574582412711 mGwwW7E_L5mU4H4fm45hZ 	 
    	  
    		   0 mwC_DGcKkrPNhMHUMy8hB 	 
    	  
   
         mEUHDRL7W9f_jebJ8sIMo 	 
    	  
    	size_t _2654435874 mrEYNwjXK_xAwDc6dEvdA 	 
    	  
  1 mnCUvl_sQ3iz1ma7ds7a2 	 
    	  
    _2654435874 mKDTKQpoaf9CSC6GD0TC_ 	 
    	  
    		   
 _2655203937566607062.size msEmz2sBrLxKt5K4PbJiT 	 
    	  
    		   
  maI7EcdmICOL6DnWZAk5L 	 
    	  
    		   
     
     
 _2654435874 m_cu7jxTLR1kw8rSYbP09 	 
    	  
    		   
  mAE2dnbfAdl1cZeEPxwYj 	 
    	  
    	
             mC2lhXvfWRuglkKBCfb9X 	  mNh3cvDlcXytdtCUaJAZV 	 
    	  
    		   
      _46082543180066935.getMarkerPoseIPPE mNh3cvDlcXytdtCUaJAZV 	 
    _2655203937566607062 mYQegUh3q9slmeoiYoJjg 	 
    	  
 _2654435874 mbPdyGWxNHmH6SUUDyPSL 	 
    	  
    		   
      mr9ts4Np8ncg1gJpHz_ti 	 
    	  
    		   
    .err_ratio mSHbL3YJPgxvnZ9DktxOb 	 
    	  
  _46082543180066935.getMarkerPoseIPPE mZxroNgqv4GCicNhd9Vds 	 
    	  
    		   
   _2655203937566607062 mOMjLl_toMbvFZr90mg_G 	 
    	  
    		   
    _46082574582412711 mHGVaCQHg7jsPiWyzNB97 	 
    	  
     mPebCiVySBurUpF5aZ3N1 	 
    	  
    		   
     
     
 
 .err_ratio  mHNlNa52Z2PZe2OXhBJ1y 	 
    	  
    		 
                _46082574582412711 memQ0RtbCNMcXXIi3wQCX 	 
    	  
    		   
     
 _2654435874 miJar0x8Bt5Zexc5NM4un 	 
    	  
    		   
     
     

        
        
         mdw07t2uKfTMA6EbOII2V 	 
    	  _6806984971934914252 mzPpEm7JKS5kSuqDIUCtm 	 
    _2655203937566607062 mWymVNaClEDUhz8dwO3vT 	 
    	  
    		   
     
     
 _46082574582412711 mVgfptsNFL1_yPb4iqzR0 	 
    	  
    		   
     mwC_DGcKkrPNhMHUMy8hB 	 
    	  
    		   
     
   
        cv mr5PE3A1WmSQZvRF5LGFr 	 
    	  Mat  _706246308705962 mzPpEm7JKS5kSuqDIUCtm 	 
    	  
    		   
     TheMap mN4iA3tOcEXBIEi2Est1o 	 
    map_markers mWymVNaClEDUhz8dwO3vT 	 
    	  
    		   
     _6806984971934914252 mbPdyGWxNHmH6SUUDyPSL 	 
    	  
    		   
     .pose_g2m.inv miLAEYIXn7XwmrPx2ruPJ 	 
    mjt3yMUTnxg8otzv2CROn 	 
    	  
    		   
     
    
        se3 _46082575775659958 mrEYNwjXK_xAwDc6dEvdA 	 
    	  
    		   
       se3 ma04H4jmAgnDee_1IqvN5 	 
    	  
    		   
 _46082543180066935.getMarkerPoseIPPE mBbja92jiZJNsMWkjTEA8 	 
    	  
    		   
     
     
 _6806984971934914252 mPebCiVySBurUpF5aZ3N1 	 
    	  
    		  .sols m_eDFTol7iECy2PwxhVjT 	 
    	  
    		   
     
     
 
  	0 mFxGZTeawKDQkMqstz6nq 	 
    	  
    		   
  * _706246308705962 mAE2dnbfAdl1cZeEPxwYj 	 
    	  
 mDk2ateRzESLAdShOHBxz 	
        se3 _46082575775659953 muSWWBwCY5nzwDkMI6YMm 	 
    	  
    		   
     
     
 
        se3 mMK4AuMzUThR8l14ylfTj 	 
    	  
    		_46082543180066935.getMarkerPoseIPPE mYfMAy2mq0iYJ9_M3gW7z 	 
    	  
    		  _6806984971934914252 mX0qcbsHjAoNnQaVuWy5P 	 
    	  
    		   
  .sols mOMjLl_toMbvFZr90mg_G 	 
    	  
    		   
     
   1 mVXmnzdfKl6nHZ3BDaOVf 	 
    	  
 * _706246308705962 mr9ts4Np8ncg1gJpHz_ti 	 
    	  
    		    mIXcs_xq6d1ZfHrJUZhbb 	 
    	  
    		   
     
     
 

        _15853982152702744598.push_back mZxroNgqv4GCicNhd9Vds 	 
   _46082575775659958 mNdeptenmMoGfTyM3ceNa 	 
    	  
    		  maI7EcdmICOL6DnWZAk5L 	 
    	  
    		   
     
     
 
        _15853982152702744598.push_back mYfMAy2mq0iYJ9_M3gW7z 	 
    	  
 _46082575775659953 mPebCiVySBurUpF5aZ3N1 	 
    	  
    		   
     mAzTDU0OC6jPLmhZXxf5s 	 
    	  
    		   
     
     mkJkNZCI4_vhjeQc322zU 	 
    	  
    		   

 
     
     
     
     
     
     
      meI4cw0JpYCGVAglkSWIH 	 
    	  
    		   
     
  _10881656904441569450 mb_HLg3OkjwtqNtbStGWJ 	 
    	  
    		   
   std mnwIn8oqL3dWmkG84mlxh 	 
    	  
    		   numeric_limits miYNzGRvfdQFoOiLnJsV_ 	uint32_t mvevHARgRA7CvNeXBlh2_ 	 
    	  
    		   
     
      mMeMaBX7AlQnU2AarSG35 	 
    	  
    		   
     
  max maEyj783NEiTRed1C9KGp 	 
    	  
    		   
  ,_1688034558339125662 mKQs5UoWc8hQnZyjRiO9c 	 
    	  
std meThfcmRLi6HYMkRGUo4z 	 
    numeric_limits mgdeaUrW6TAPG0iBLVBsL 	 
uint32_t mlGAhEsbSz8YxV75nlhR0 	 
    	  
    		   
     
     
  mMeMaBX7AlQnU2AarSG35 	 
    	  
    max msEmz2sBrLxKt5K4PbJiT 	 
    	  
    		   
     
     
 
  	 miJar0x8Bt5Zexc5NM4un 	 
 
      mHAT8ICuUYb27C9RxwTt_ 	 
    	  
   auto _2654435878:_2655203937566607062 mNdeptenmMoGfTyM3ceNa 	 
    	  
    	 mZrh25nTGSOmEcIn3KqdO 	 
    	  
    		   

          mPXYsSUJKTlN_9TDRANsC 	 
    	  
    		   
     
     
 
 auto _15593881797448880805:TheMap mJKjklSGsDhfusczCEaK8 	 
    	  
    		   
    map_markers mMjkgrlSYkhDkq9pcWgtV 	 
    	  
    _2654435878 mnEimIOcHobXmIr5dsOxG 	 
    	  
    		   
    .frames mqIfjicfHLyeUpUXCJg0x 	 
    	  
    		   
 mWyGglK0azQrxAO1GWKNx 	 
    	  
    		   
     
     
              m_NKH1FvsobBlgc6p2pMt 	 
    	   mMK4AuMzUThR8l14ylfTj 	 
    	  
    		   
     
     
 
   _10881656904441569450 m_5grhY8wx8_nGTeN7t1i 	 
    	  
    	TheMap mHCj6MRgYNeaPqcfnaTtQ 	 
    	  
    		   
     
 keyframes m_eDFTol7iECy2PwxhVjT 	 
    	  
    		   
     
    _15593881797448880805 msvr0sqM1zSnK_LAOVElz 	 
    	  
   .fseq_idx mX0qcbsHjAoNnQaVuWy5P 	 mtUrDV5jqTezfsdfRbyeG 	 

                 _10881656904441569450 mgegCV8i4RdQqulhCBPGP 	 
    	  
    		   
     
TheMap mHCj6MRgYNeaPqcfnaTtQ 	 
    	  
    		   
  keyframes m_eDFTol7iECy2PwxhVjT 	_15593881797448880805 mHGVaCQHg7jsPiWyzNB97 	 
    	  
    		   
     
    .fseq_idx maI7EcdmICOL6DnWZAk5L 	 
    	  
    		   
 
                 _1688034558339125662 memQ0RtbCNMcXXIi3wQCX 	 _15593881797448880805 m_xQN0oi5gVO2R_VQWSRC 	 
    	  
    		  
              mMEupUpeFmt2YmeTtEuMo 	 
    	  
    		   
    
          mGwH5P2DG1FxTU6MU_6QT 	 
    	  
    		   
     
      mkJkNZCI4_vhjeQc322zU 	 
    	  
    		   
     
     

vector mgdeaUrW6TAPG0iBLVBsL 	 
  LoopClosureInfo maz6hZ1Qmyhz47_btGDO1 	 
    	  
    		   
     
  _706246342986177 mAzTDU0OC6jPLmhZXxf5s 	 
    	  
    		   
  
 mMcVkDr5WQSzvkCL3IsEy 	 
    	  
    size_t _2654435874 mKQs5UoWc8hQnZyjRiO9c 	 
    	  
    		   
     
  0 mjt3yMUTnxg8otzv2CROn 	 
    	  
    		   
     
     
 
  	 _2654435874 mjOCUIMglMJBpe514Gl6O 	 
   _15853982152702744598.size miLAEYIXn7XwmrPx2ruPJ 	 
     maI7EcdmICOL6DnWZAk5L 	 
    	  
    		   
     
 _2654435874 mRJ5eldFAeP9f1ZDhHSxg 	 
    mPebCiVySBurUpF5aZ3N1 	 
    	  
   mFlDAyw4uvIC_FhJUUdm_ 	
    LoopClosureInfo _11093822343890 miwFxrJ9Hgvh9BU3yQ7JC 	
    _11093822343890.curRefFrame mGwwW7E_L5mU4H4fm45hZ 	_10707402390114315114 mwC_DGcKkrPNhMHUMy8hB 	 
    	  
    _11093822343890.expectedPos mb_HLg3OkjwtqNtbStGWJ 	 
    	  
  _15853982152702744598 mAWzvNghKfSurKk32NNTp 	_2654435874 mVXmnzdfKl6nHZ3BDaOVf 	 
    	  
    		   
     
     
 
  	  mnCUvl_sQ3iz1ma7ds7a2 	 
    	  
    		   
  
    _11093822343890.matchingFrameIdx mKQs5UoWc8hQnZyjRiO9c 	 
    	  
    		   
 _1688034558339125662 maI7EcdmICOL6DnWZAk5L 	 
    	  
 
    _706246342986177.push_back mYfMAy2mq0iYJ9_M3gW7z 	 
    	  
    		 _11093822343890 mHNlNa52Z2PZe2OXhBJ1y 	 
  m_xQN0oi5gVO2R_VQWSRC 	 
    	  
    		   
     
     
 mNh2RK5UN2xJEcZGvrlzD 	 
    	  
    		
     mvmiUlfuSXZ32v5hQjCFw 	 
 _706246342986177 miwFxrJ9Hgvh9BU3yQ7JC 	 
   
 mMnQcRje5274EAZHUxVoc 	 
    	  
    		   
 mC2iS7wUKLq4bFZBruDv_ 	 
    	  
    		   
     
     
 
  LoopDetector mnwIn8oqL3dWmkG84mlxh 	 
    	  
    		  _6767859416531794787 ma04H4jmAgnDee_1IqvN5 	 
    	  
    		   
     
     
 
  Frame &_46082543180066935,   LoopClosureInfo &_10148777732430291359 mNdeptenmMoGfTyM3ceNa 	 
    	  
    		   
     
     
 
  	  mCfeXpurQ7eEHdVTm6sz3 	 
    	  
    		   
  
    CovisGraph &_16937374370235587530 memQ0RtbCNMcXXIi3wQCX 	 
    	  
    		   
  TheMap mS6s5A6y18klHp1JxGUvl 	 
    	  
    TheKpGraph mwC_DGcKkrPNhMHUMy8hB 	 
    	  
    		   

      m_NKH1FvsobBlgc6p2pMt 	 
    	  
    		  mYfMAy2mq0iYJ9_M3gW7z 	 
    	  
    		   
     _46082543180066935.idx mgNPYjP3KCFUi4y3DSLE2 	 
    	  
std mUUAnnRVHtbXs8uZAZ0FH 	 
    	  
    numeric_limits mjOCUIMglMJBpe514Gl6O 	 
    	  
    		  uint32_t mkMabtkManLa0QZcvlExG 	 
    	  
    		 mod8ttCC8Q4p6YfKFiWT5 	 
 max meNaaQSUqmbpWcYodKuLc 	 
   mzKwOblJypS2Tynlc0h7K 	 
    	  
    		   
     
        _46082543180066935.idx mzPpEm7JKS5kSuqDIUCtm 	TheMap mghwyijNY8yWZiPQiY8lR 	 
    	  
    getNextFrameIndex miLAEYIXn7XwmrPx2ruPJ 	 
    	  
    		   
  mIXcs_xq6d1ZfHrJUZhbb 	 
    
    vector mQUrH4PQ9h20xuwoz_L6c 	 
    	  
    		   
pair mjOCUIMglMJBpe514Gl6O 	 
    	  
    		   
     
     
 
  	uint32_t,uint32_t mSHbL3YJPgxvnZ9DktxOb 	 
    	  
    		   
     
     
 
  	   mRS_PgiJe6t1Qfe_huC7W 	 
    	  
    		  _46082543208105790 mrEYNwjXK_xAwDc6dEvdA 	 
 _16937374370235587530.getAllEdges me4ftpf9gBNIZytyQMpAw 	 
    	  
    		   
     
    mnCUvl_sQ3iz1ma7ds7a2 	 
    	  
   
     msTooE_u4pSsScqgxdraf 	 
    	  
    		   
     
     
 
 mNh3cvDlcXytdtCUaJAZV 	 
    	  
    		   
     
  mXw6xyXxnNHe0fvsqhNpF 	 
    	  
    		  _16937374370235587530.isEdge ma04H4jmAgnDee_1IqvN5 	 
    	  
    		   
     
    _10148777732430291359.curRefFrame,_46082543180066935.idx mUgVkHgFvWIrVL6b4ukmf 	 
    	  
    		   
     mX0qcbsHjAoNnQaVuWy5P 	 
    	  
    		   
     
     
 
  	 miJar0x8Bt5Zexc5NM4un 	 
    	  
   
    _46082543208105790.push_back ma04H4jmAgnDee_1IqvN5 	 
  m_UdV0aNh6DsLGA7n116C 	 
    	  
    		   
  _10148777732430291359.curRefFrame,_46082543180066935.idx mB58ylLLhUkc44hEn298e 	 
    	  
    		   
     
   mX0qcbsHjAoNnQaVuWy5P 	 
    	  
    		   
 mnCUvl_sQ3iz1ma7ds7a2 	 
    	  
    		   
     
   
     mR6cHHVNJUxSb1XUZZAlr 	 
    	  
    		   
&_5606711953216325711 mKQs5UoWc8hQnZyjRiO9c 	 
    	  
    		   
     
     
_10148777732430291359.optimPoses mDk2ateRzESLAdShOHBxz 	 
    	  
   
    std mod8ttCC8Q4p6YfKFiWT5 	map mQUrH4PQ9h20xuwoz_L6c 	 
    uint64_t,float mlGAhEsbSz8YxV75nlhR0 	 
    	  
    		   
     
     
 
  	  _4835184743873567059 miwFxrJ9Hgvh9BU3yQ7JC 	 
    	  
    		   

     mvkwhmhEbUJQ6ub21N6lI 	 
    	  
    		   
     
     
 
  	_1522768810319552178 mzPpEm7JKS5kSuqDIUCtm 	 
    	  
    		   
     
     
 
  0 miwFxrJ9Hgvh9BU3yQ7JC 	 
    	  

     mRH4mjD7ZPB_82GeftQaw 	 
    	  
    		   
 auto _2654435870:_46082543208105790 mUgVkHgFvWIrVL6b4ukmf 	 
    	  
    		 mZrh25nTGSOmEcIn3KqdO 	 
    	  
 
         mbHU8OACa_bY7FdEZZldx 	 
    	  
    	 mGKRS1wgB2KUw_qlPr3ZO 	 
    	  
    		   
     
     
 
  	 _5606711953216325711.count mxtgNrR0I9XNlGwtKgbs_ 	 
  _2654435870.first mr9ts4Np8ncg1gJpHz_ti 	 
    	  
    		   
      mGnBNhBZBGxmhG0sMjYTx 	 
    	  
    		   
     
     
 
  	 0  mxhZIiZ0xwZgAVSpMwPou 	 
    	  
    		   TheMap mghwyijNY8yWZiPQiY8lR 	 
    	  
    		 keyframes.is mNh3cvDlcXytdtCUaJAZV 	 
    	  
 _2654435870.first mAE2dnbfAdl1cZeEPxwYj 	 
    	  
    		   
    mhRX2T9fqiwg5h4fn7CqV 	 
    	  
    		 
            _5606711953216325711 m_eDFTol7iECy2PwxhVjT 	 
    	  
    		   _2654435870.first mc1ZVDw0Qh0A2juXO2Sgd 	 
   mzPpEm7JKS5kSuqDIUCtm 	 
    	  
    		   
TheMap mpmuqOtjD06SoG7mrFmwj 	 
    	  
    	keyframes mOMjLl_toMbvFZr90mg_G 	 
    	  
    		   
  _2654435870.first mVgfptsNFL1_yPb4iqzR0 	 
    	  
    		   
     
     
 
  	.pose_f2g mIXcs_xq6d1ZfHrJUZhbb 	 
    	  
    		  
         mE72_0qT3_J58YcRSfkrB 	 
    	  
    		   
     
   mG7xJth7i0BO6oUVbJqb5 	 _5606711953216325711.count mGKRS1wgB2KUw_qlPr3ZO 	 
    	  
    		   
     
  _2654435870.second mUgVkHgFvWIrVL6b4ukmf 	 
    	  
    		   
     
     
 
  	 mrXUHPs1zJxVq3YneHkiB 	 
    	  
    		   
     
     
 
0  mpT1c3t4Kv9sHJwkPrqbY 	 TheMap mHCj6MRgYNeaPqcfnaTtQ 	 
    	  
    keyframes.is mYfMAy2mq0iYJ9_M3gW7z 	 
    	  
    		 _2654435870.second mqIfjicfHLyeUpUXCJg0x 	 
    	  
    		   
     
     
 
  mhRX2T9fqiwg5h4fn7CqV 	 

            _5606711953216325711 m_eDFTol7iECy2PwxhVjT 	 
    	  
    		   
     
     
_2654435870.second mVXmnzdfKl6nHZ3BDaOVf 	 
    	  
    mzPpEm7JKS5kSuqDIUCtm 	 
    	  
    		   
     
  TheMap mpiOmG3B7o8txhSe0vp7N 	 
    	  
    		   
     
     
 
  keyframes mEPF7k9hvBnZlCGOGW3Oi 	 
    	  
    		   _2654435870.second mS619Af_XaGLce9WysiWq 	 
    	  
    .pose_f2g mIXcs_xq6d1ZfHrJUZhbb 	 
    	  
    		   
 
         mrFiCxDdeDz0ePSdLXQ5g 	_6807153911819033284 mVshQzJetvpwfbmhSbkWn 	0 mjt3yMUTnxg8otzv2CROn 	 
    	  
    		   
     
     
 
  	
         mC2lhXvfWRuglkKBCfb9X 	 
    	  
    		   
     
     
  mYfMAy2mq0iYJ9_M3gW7z 	 
    	  
    		   
     
     
 
  	  TheMap mRK3Zczq6vZZNqiZhRrjx 	 
    	  
    		   
     
 TheKpGraph.isEdge mMK4AuMzUThR8l14ylfTj 	 
 _2654435870.first,_2654435870.second mNdeptenmMoGfTyM3ceNa 	 
    	  
    		   
     
 mzKwOblJypS2Tynlc0h7K 	 
  
            _6807153911819033284 mzPpEm7JKS5kSuqDIUCtm 	 
    	  
    		   
     
     
 
TheMap mspUrihBhhhtw4FBiaBvy 	 
    	  
    		   
     
    TheKpGraph.getEdge ma04H4jmAgnDee_1IqvN5 	_2654435870.first,_2654435870.second mUgVkHgFvWIrVL6b4ukmf 	 
    	  
    		   
     
     
 
   maI7EcdmICOL6DnWZAk5L 	 
    	  
    		   
     
     
 
        _1522768810319552178 mrEYNwjXK_xAwDc6dEvdA 	 
   std meThfcmRLi6HYMkRGUo4z 	 
    	  
   max mGKRS1wgB2KUw_qlPr3ZO 	 
    	  
    		   
     _6807153911819033284,_1522768810319552178 mHNlNa52Z2PZe2OXhBJ1y 	 
    miJar0x8Bt5Zexc5NM4un 	 
    	  
    		   
     
     
 
  	 
        _4835184743873567059 msX2aFZOZI29G1zOojPg2 	 
    	  
 CovisGraph mLo6MBHX8K7VxYSLeLVQr 	 join mX7c7PnpK1mvKbMhF98gK 	_2654435870.first,_2654435870.second mNdeptenmMoGfTyM3ceNa 	 
    	  
    		   
     
    mvgZM8nIZFeOdMyTrsL7T 	 
    	  
    		   
     
     
 
  	  mGwwW7E_L5mU4H4fm45hZ 	 
    	  
    		   _6807153911819033284 mnCUvl_sQ3iz1ma7ds7a2 	 
    	  
  
     mAutaeq8TRDcw1y62NeWa 	 
    	  
    		   
     
     

     m_Pi1brxORGc2CnlD7qpX 	 
    	  
    		   
     
     mBbja92jiZJNsMWkjTEA8 	 
    	  
    		   
     muu_ZbKFMpC65Gx4SNjTp 	 
    	  
_16937374370235587530.isEdge mBbja92jiZJNsMWkjTEA8 	 
    	  
    		   
 _46082543180066935.idx,_10148777732430291359.matchingFrameIdx mhRX2T9fqiwg5h4fn7CqV 	 
    	  
    		  mNdeptenmMoGfTyM3ceNa 	 
   mCfeXpurQ7eEHdVTm6sz3 	 
    	  
    		   
        _46082543208105790.push_back mG7xJth7i0BO6oUVbJqb5 	 
   mZrh25nTGSOmEcIn3KqdO 	 
    	  
    		   
     
     
 
  	 _46082543180066935.idx,_10148777732430291359.matchingFrameIdx mB58ylLLhUkc44hEn298e 	 
    	  
    		   
 mX0qcbsHjAoNnQaVuWy5P 	 
    	  
    		   
  mnCUvl_sQ3iz1ma7ds7a2 	 
    	  
    
        _4835184743873567059 m_eDFTol7iECy2PwxhVjT 	 
    	  
 CovisGraph mLo6MBHX8K7VxYSLeLVQr 	 
    	  
    		   
     
     
 
  	 join mBbja92jiZJNsMWkjTEA8 	 
    	  
    		   
     
     
 
 _46082543180066935.idx,_10148777732430291359.matchingFrameIdx mNdeptenmMoGfTyM3ceNa 	 
  mHGVaCQHg7jsPiWyzNB97 	 
    	   mKQs5UoWc8hQnZyjRiO9c 	 
    	  
    		   
     
 _1522768810319552178 miJar0x8Bt5Zexc5NM4un 	 
    	  
    		   
     
     
 
 
     msP_HdnLnvyq_xHfK3eKV 	 
    	  
 
    _5606711953216325711 mEPF7k9hvBnZlCGOGW3Oi 	 
    	  
    		   
     
     
 
  	 _46082543180066935.idx mHGVaCQHg7jsPiWyzNB97 	 
    	  
    		 mKQs5UoWc8hQnZyjRiO9c 	 
    	  
    		 _46082543180066935.pose_f2g mAzTDU0OC6jPLmhZXxf5s 	 
  
#pragma message "warning: must check fixscale"
    loopClosurePathOptimizationg2o mX7c7PnpK1mvKbMhF98gK 	 
    	  
    		   
  _46082543208105790,_46082543180066935.idx,_10148777732430291359.matchingFrameIdx,_10148777732430291359.expectedPos, _5606711953216325711,false mUgVkHgFvWIrVL6b4ukmf 	 
    	  
    	 mDk2ateRzESLAdShOHBxz 	 
   
 mgLz7ptMkDAS2H3myapb6 	 
    	  
    		   
    
 mKlDX756ItSngbzWHtsU_ 	 
    	  
    		LoopDetector mteJA8lO8Sm1A4vEX4CFp 	 
    	 correctMap mG7xJth7i0BO6oUVbJqb5 	 
    	  
    		   
     const LoopClosureInfo &_46082543426142246 mX0qcbsHjAoNnQaVuWy5P 	 
  mtUrDV5jqTezfsdfRbyeG 	 
    	  
    		   
     
    
    
     mj1lf05_AG7Xg1sbt5xfx 	 
    	  
    		   
  _1524145530871351014 muSWWBwCY5nzwDkMI6YMm 	 
    	  
    		   
    msX2aFZOZI29G1zOojPg2 	 
    	  
    		   
     
     mHGVaCQHg7jsPiWyzNB97 	 
    	  
    		   
     
     
  mYfMAy2mq0iYJ9_M3gW7z 	 
    	  
 const cv mMeMaBX7AlQnU2AarSG35 	 
    	  
    		 Mat &_706246338866931 mqIfjicfHLyeUpUXCJg0x 	 
    	  
    		   
     
    mDnhhwTjyavcESxeRXnT1 	 
    	  
    		
         mtCrtFrELbV_rIn99Ta3E 	 
    	  
    		 _175247759755 mb_HLg3OkjwtqNtbStGWJ 	 
    	  
    		   
     
   cv mLo6MBHX8K7VxYSLeLVQr 	 
    	  
    		   
     
     
 
  norm ma04H4jmAgnDee_1IqvN5 	 
    	  
    		    _706246338866931.col mBbja92jiZJNsMWkjTEA8 	0 mqIfjicfHLyeUpUXCJg0x 	 
    	  
    		   
     
 mAE2dnbfAdl1cZeEPxwYj 	 
    	   mnCUvl_sQ3iz1ma7ds7a2 	 
    	 
        cv mteJA8lO8Sm1A4vEX4CFp 	 
Mat _175247761732 memQ0RtbCNMcXXIi3wQCX 	_706246338866931 mAzTDU0OC6jPLmhZXxf5s 	 
   
        cv mteJA8lO8Sm1A4vEX4CFp 	 
    Mat _2654435851 mUe9WFcPV6iTML5qSXbKv 	 
  _706246338866931.rowRange mZxroNgqv4GCicNhd9Vds 	 
 0,3 mAE2dnbfAdl1cZeEPxwYj 	 
    	  
    		   
     
     
 
.colRange mMK4AuMzUThR8l14ylfTj 	 
    	  
    		   
   0,3 mzKwOblJypS2Tynlc0h7K 	 
    	  
    		   
     
     
 
  	 mIXcs_xq6d1ZfHrJUZhbb 	 
    	  

        _2654435851 mgegCV8i4RdQqulhCBPGP 	 
    	  
    		   
     
     
 
 mG7xJth7i0BO6oUVbJqb5 	 
    	  
   1./_175247759755 mX0qcbsHjAoNnQaVuWy5P 	 
    	  
    		   
     
     
 
 *_2654435851 mnCUvl_sQ3iz1ma7ds7a2 	 
    	  
 
         mmh1XqjaH40_MvCS0rwly 	 
    	  
    		   
     
   _175247761732 mAzTDU0OC6jPLmhZXxf5s 	 
    	  
    		   
     mMnQcRje5274EAZHUxVoc 	 
    	  
    		   
     
      mIXcs_xq6d1ZfHrJUZhbb 	 
    	  
    		  
    
     mMcVkDr5WQSzvkCL3IsEy 	 
    	  
    		   
    auto &_16119328343212373368:TheMap mpmuqOtjD06SoG7mrFmwj 	 
    	  
    map_markers mPebCiVySBurUpF5aZ3N1 	 
    	  
    		    mZrh25nTGSOmEcIn3KqdO 	 
    	  
    		   
     
   
        Marker &_3005399795337363304 mgegCV8i4RdQqulhCBPGP 	 
    	  
    		   
     
 _16119328343212373368.second mDk2ateRzESLAdShOHBxz 	 
    	  
    		   
  
         mfD9pTiMELJRARGDAwmaJ 	 
    	  
    		   
     
  mMK4AuMzUThR8l14ylfTj 	 
    	  
    		   
     
      muu_ZbKFMpC65Gx4SNjTp 	 
    	  
    		   
     
     
 
  	 _3005399795337363304.pose_g2m.isValid maEyj783NEiTRed1C9KGp 	 
    	  
    		   mAE2dnbfAdl1cZeEPxwYj 	 
     continue m_xQN0oi5gVO2R_VQWSRC 	 
    	  
       
         mNDn7KoqzOqsI9ox7TxtZ 	 
    	  _2477911609060771483 mGwwW7E_L5mU4H4fm45hZ 	 
    	  
    	false mAzTDU0OC6jPLmhZXxf5s 	 
 
         meVhva2888lfPoP60YhOi 	 
    	  
    		   
     
     
 auto _706246330143240:_3005399795337363304.frames mzKwOblJypS2Tynlc0h7K 	 
    	  
    mCfeXpurQ7eEHdVTm6sz3 	 
    	  
    		   
     
     
 
             mVek5Fb5rIW2fn6jjRDXR 	 
    	  
    _46082543426142246.optimPoses.count mX7c7PnpK1mvKbMhF98gK 	 
 _706246330143240 mr9ts4Np8ncg1gJpHz_ti 	 
    	  
    		   
     
     mJnz6Z6IU__SqqeL_XamD 	 
    	  
    		   
     
     
 0 mHNlNa52Z2PZe2OXhBJ1y 	 
    	  
    		   
continue mwC_DGcKkrPNhMHUMy8hB 	 
    	  
    		   
     
     
 
 
            const Frame &_46082543180066935 memQ0RtbCNMcXXIi3wQCX 	 
   TheMap mN4iA3tOcEXBIEi2Est1o 	 
    	  
    		   
    keyframes mEPF7k9hvBnZlCGOGW3Oi 	 
    	  
    		 _706246330143240 msvr0sqM1zSnK_LAOVElz 	 
    mwC_DGcKkrPNhMHUMy8hB 	 
    	  
    		   
     
     
            
            cv mteJA8lO8Sm1A4vEX4CFp 	 
    	  
    Mat _11093822386652 mVshQzJetvpwfbmhSbkWn 	 
    	  _46082543180066935.pose_f2g*  _3005399795337363304.pose_g2m mIXcs_xq6d1ZfHrJUZhbb 	 
    	 
            
             mU7YWgrM69Z0WHvDiKcBl 	 _3005399769884158829 mUe9WFcPV6iTML5qSXbKv 	 
    	  
    _1524145530871351014 mZxroNgqv4GCicNhd9Vds 	 
 _46082543426142246.optimPoses.at mMK4AuMzUThR8l14ylfTj 	 
    	  
    		   
     
     
 
  	_706246330143240 mr9ts4Np8ncg1gJpHz_ti 	 
    	  
    		   
     
     
  mNdeptenmMoGfTyM3ceNa 	 
    	  
  mAzTDU0OC6jPLmhZXxf5s 	 
    	  
    		
            
            _3005399795337363304.pose_g2m mb_HLg3OkjwtqNtbStGWJ 	 
    	  
    		   
          _3005399769884158829.inv maEyj783NEiTRed1C9KGp 	 
    	  
     *  _11093822386652 mAzTDU0OC6jPLmhZXxf5s 	 
    	  
            _2477911609060771483 mUe9WFcPV6iTML5qSXbKv 	 
    	  
    		   
 true m_xQN0oi5gVO2R_VQWSRC 	 
    
            break miJar0x8Bt5Zexc5NM4un 	 
    	  
    		   
     
    
         msP_HdnLnvyq_xHfK3eKV 	 
    	  
    		   
     
     
 
         mbHU8OACa_bY7FdEZZldx 	 
    	  
    	 mNh3cvDlcXytdtCUaJAZV 	 
    	  
    		   
     
     mceZP2LoTA8KIHZFtWHF3 	 
    	  _2477911609060771483 mhRX2T9fqiwg5h4fn7CqV 	 
    	  
    		   
     
    throw std mr5PE3A1WmSQZvRF5LGFr 	runtime_error mBbja92jiZJNsMWkjTEA8 	 
    	 string mGKRS1wgB2KUw_qlPr3ZO 	 
    	 __PRETTY_FUNCTION__ mr9ts4Np8ncg1gJpHz_ti 	 
    	  
    		   
     
 +"\x49\x6e\x74\x65\x72\x6e\x61\x6c\x20\x65\x72\x72\x6f\x72\x2e\x20\x43\x6f\x75\x6c\x64\x20\x6e\x6f\x74\x20\x63\x6f\x72\x72\x65\x63\x74\x20\x6d\x61\x72\x6b\x65\x72" mr9ts4Np8ncg1gJpHz_ti 	 
    	  
    	 miJar0x8Bt5Zexc5NM4un 	 
    	  
 
     mMEupUpeFmt2YmeTtEuMo 	 
    	  
    		   
 
     
     mPXYsSUJKTlN_9TDRANsC 	 
    	  
   auto &_175247759380:TheMap mRK3Zczq6vZZNqiZhRrjx 	 
    	  
    		   
     
    map_points mPebCiVySBurUpF5aZ3N1 	 
 mtUrDV5jqTezfsdfRbyeG 	 
    	  
    		   
     
     
 
  
            
            Frame& _175247760268 mGwwW7E_L5mU4H4fm45hZ 	 
 TheMap mghwyijNY8yWZiPQiY8lR 	 
    	  
    		   
     
     keyframes msX2aFZOZI29G1zOojPg2 	 
  _175247759380.getObservingFrames mtk2iJ0o4hJH0SUXm_IsX 	 
    	.front myByBcZVI3hjwqHKXt_nB 	 
    	  
    		   
    .first mS619Af_XaGLce9WysiWq 	 
    	  
    		   
     
     
 
   mDk2ateRzESLAdShOHBxz 	 
    	  
    		   
            cv mMeMaBX7AlQnU2AarSG35 	 
    	  
    		   
  Point3f _11093822296219 mb_HLg3OkjwtqNtbStGWJ 	 
    	  
    		   
     
     
 
  	_175247760268.pose_f2g*_175247759380.getCoordinates mIfJTCDTzNTDbSwjZ_4ng 	  mDk2ateRzESLAdShOHBxz 	 
    	  
    		   
   
            
            cv mLo6MBHX8K7VxYSLeLVQr 	 
    	  
    		 Mat _706246338866931 memQ0RtbCNMcXXIi3wQCX 	 
    	  
    	_46082543426142246.optimPoses.at mG7xJth7i0BO6oUVbJqb5 	 
    	  
 _175247760268.idx mHNlNa52Z2PZe2OXhBJ1y 	 
    	  
    	 miwFxrJ9Hgvh9BU3yQ7JC 	 
    	 
             mer2o0AHZEWAzGh8Htw89 	 
    	  
    _175247759755 mKQs5UoWc8hQnZyjRiO9c 	 
    	  
    cv meThfcmRLi6HYMkRGUo4z 	 
    	  
    		   
     
norm mX7c7PnpK1mvKbMhF98gK 	 
    	  
    		   
     
    _706246338866931.col mZxroNgqv4GCicNhd9Vds 	 
    	  
    		   
     
     
 
0 mhRX2T9fqiwg5h4fn7CqV 	 
    	  
    		   
     
     
 
 mAE2dnbfAdl1cZeEPxwYj 	 
    	  
  miwFxrJ9Hgvh9BU3yQ7JC 	 
    	  
    		   
     
    
            cv mod8ttCC8Q4p6YfKFiWT5 	 
    	  
    		   
     Mat _2654435851 mGwwW7E_L5mU4H4fm45hZ 	 
    	  
    		   
_706246338866931.rowRange mMK4AuMzUThR8l14ylfTj 	0,3 mzKwOblJypS2Tynlc0h7K 	 
    	  
    		   
     
     
.colRange mX7c7PnpK1mvKbMhF98gK 	 
    	  
    		   
     
     
 
 0,3 mPebCiVySBurUpF5aZ3N1 	 mAzTDU0OC6jPLmhZXxf5s 	 
    	  
   
            _2654435851 mqN8l6uiypVDb3LT0dRrg 	 
    	  
    		   
     
    ma04H4jmAgnDee_1IqvN5 	 
    	  
    		   
1./_175247759755 mhRX2T9fqiwg5h4fn7CqV 	 
    	  
    		 maI7EcdmICOL6DnWZAk5L 	 
    	  
    		   
    
            cv ma7m2a2XM5VioswynpTaQ 	Mat _46082576298233916 mzPpEm7JKS5kSuqDIUCtm 	 
    	  
    		_706246338866931.inv myByBcZVI3hjwqHKXt_nB 	 
  m_xQN0oi5gVO2R_VQWSRC 	 
    	  
  
            _2654435851 mgegCV8i4RdQqulhCBPGP 	 
    	  
    		 _46082576298233916.rowRange mZxroNgqv4GCicNhd9Vds 	 
    	  
    		   
     
     
0,3 mzKwOblJypS2Tynlc0h7K 	 
  .colRange mZxroNgqv4GCicNhd9Vds 	 
    	  
    		   
     
     
0,3 mzKwOblJypS2Tynlc0h7K 	 
    	  
    miwFxrJ9Hgvh9BU3yQ7JC 	 
    	  
    		   
     
     
 
  	 
            _2654435851 mI2D5FRQG5_p4fTLDCx7a 	 
    	  
    		   
     
     
  mBbja92jiZJNsMWkjTEA8 	 
    	  
    		   
     
1./_175247759755 mr9ts4Np8ncg1gJpHz_ti 	 
    	  
    		   
  mIXcs_xq6d1ZfHrJUZhbb 	 
    	  
    		   
    
            _175247759380.setCoordinates mG7xJth7i0BO6oUVbJqb5 	 _46082576298233916*_11093822296219  mHNlNa52Z2PZe2OXhBJ1y 	 
    	  
    		   
     
     
 
 mwC_DGcKkrPNhMHUMy8hB 	 
    	  
    		 
     mMnQcRje5274EAZHUxVoc 	 
    	  
    		   
   
    
     mdbzbaVIzDwW_qjPbKNIb 	 
    	  
    		   
const  mZ5nSIhcChEo1XiD8ih6z 	 _175247759515:_46082543426142246.optimPoses mNdeptenmMoGfTyM3ceNa 	 
    	  
    		   
     
   mtUrDV5jqTezfsdfRbyeG 	 
    	  
    		   
     
     
 
  
         mfD9pTiMELJRARGDAwmaJ 	 
 mGKRS1wgB2KUw_qlPr3ZO 	 
    	  
    		   
     
     
 
   TheMap mN4iA3tOcEXBIEi2Est1o 	keyframes.count mYfMAy2mq0iYJ9_M3gW7z 	 
    	  
    		   
 _175247759515.first mX0qcbsHjAoNnQaVuWy5P 	 
    	  
 mzKwOblJypS2Tynlc0h7K 	 
   mWyGglK0azQrxAO1GWKNx 	 
    	  
            
            TheMap mghwyijNY8yWZiPQiY8lR 	 
    	  
    		   
     
     keyframes mYQegUh3q9slmeoiYoJjg 	 
    	 _175247759515.first msvr0sqM1zSnK_LAOVElz 	 
    	  
.pose_f2g mGwwW7E_L5mU4H4fm45hZ 	 
    	  
_1524145530871351014 mxtgNrR0I9XNlGwtKgbs_ 	 
    	  
    		   
     
     
 
  _175247759515.second   mr9ts4Np8ncg1gJpHz_ti 	 
    	  
 maI7EcdmICOL6DnWZAk5L 	 
    	  
 
         mB58ylLLhUkc44hEn298e 	 
    	  
    		 
     mFkTh5yfCM8IQj3fEOy7O 	 
   
 msP_HdnLnvyq_xHfK3eKV 	 
    	  
    
 moj7URxzVy47aw4GbhrdI 	 
    	  
    		   
     
LoopDetector mod8ttCC8Q4p6YfKFiWT5 	 
    	  
    		   
     
   _16495135671838418327 mYfMAy2mq0iYJ9_M3gW7z 	 
    	  
    		  const LoopClosureInfo &_46082543426142246 mPebCiVySBurUpF5aZ3N1 	 
    	  
    		   
     mCfeXpurQ7eEHdVTm6sz3 	 

    std mmZaEtCYOeOREjAVTD1hN 	 
    	  
    		   
     
     
 
  	 map mgdeaUrW6TAPG0iBLVBsL 	 
 uint32_t,se3 maz6hZ1Qmyhz47_btGDO1 	 
    	  
    		   
      _16750267944735343466 miJar0x8Bt5Zexc5NM4un 	 
    	  
    	
    std mr5PE3A1WmSQZvRF5LGFr 	 
    	  
    		   
     
     
 
  map mS0KK0NZmSwxSrREwLpHy 	 
    	  
    		   
   uint32_t,cv mod8ttCC8Q4p6YfKFiWT5 	 
    	  
    		   
Point3f mSHbL3YJPgxvnZ9DktxOb 	 _2772135658178669155 mjt3yMUTnxg8otzv2CROn 	 
    	  
    		  
    std mnwIn8oqL3dWmkG84mlxh 	 
    	  
    		   
     
    map mPRaITo21QKmYA0ca83Hb 	 
    	  
   uint32_t,Se3Transform mvevHARgRA7CvNeXBlh2_ 	 
    	  
    		   
  _11822840474894279984 maI7EcdmICOL6DnWZAk5L 	 
     mQWQ6DIh9Q3hZYqslkNHL 	 
    	  
    		   
     
     auto _2654435878:TheMap mS6s5A6y18klHp1JxGUvl 	 
    	  
    		   
     
   map_markers mNdeptenmMoGfTyM3ceNa 	 
    	  
    		   
     
     
 
        _16750267944735343466 mYQegUh3q9slmeoiYoJjg 	 
    	  
    	_2654435878.first mc1ZVDw0Qh0A2juXO2Sgd 	 
     muSWWBwCY5nzwDkMI6YMm 	 
    	  
    		   
     
  _2654435878.second.pose_g2m maI7EcdmICOL6DnWZAk5L 	 
    	  
    		  
     mEUHDRL7W9f_jebJ8sIMo 	 
    	  auto _2654435881:TheMap mJKjklSGsDhfusczCEaK8 	 
    	  
    		  map_points mUgVkHgFvWIrVL6b4ukmf 	 
    	  
    		  
        _2772135658178669155.insert mX7c7PnpK1mvKbMhF98gK 	 
    	  
    		   
  mDnhhwTjyavcESxeRXnT1 	 
  _2654435881.id,_2654435881.getCoordinates myByBcZVI3hjwqHKXt_nB 	 
    	  
    		   
     
  mGwH5P2DG1FxTU6MU_6QT 	 
    	  
    		  mzKwOblJypS2Tynlc0h7K 	 
    	  
    		   
     mnCUvl_sQ3iz1ma7ds7a2 	 
    	  
    		   
 
     mMcVkDr5WQSzvkCL3IsEy 	 
    	  
    		   
     
     
 
  	auto _2654435871:TheMap mpiOmG3B7o8txhSe0vp7N 	 
    	keyframes mAE2dnbfAdl1cZeEPxwYj 	 
    	  
    		  
        _11822840474894279984 mX4pTC7g5boUrm6KwZB37 	 
    	  
    		   
     
_2654435871.idx mvgZM8nIZFeOdMyTrsL7T 	 
    	  
    		   
     
     
 
   mgegCV8i4RdQqulhCBPGP 	 
    	  
    		   
     
 _2654435871.pose_f2g mjt3yMUTnxg8otzv2CROn 	 
  
    correctMap mBbja92jiZJNsMWkjTEA8 	_46082543426142246 mHNlNa52Z2PZe2OXhBJ1y 	 
    	  
    		   
     
     mwC_DGcKkrPNhMHUMy8hB 	 
    	  
    		  
    
    vector miYNzGRvfdQFoOiLnJsV_ 	 
    	  
    		   
     
    uint32_t m_5grhY8wx8_nGTeN7t1i 	 _15593615755193215935 mjt3yMUTnxg8otzv2CROn 	 
    	  
    		   
     
   
     meVhva2888lfPoP60YhOi 	 
    	  auto _175247760268:_46082543426142246.optimPoses  mNdeptenmMoGfTyM3ceNa 	 
    	  
    		   
     
   
         mfD9pTiMELJRARGDAwmaJ 	 
    	 mNh3cvDlcXytdtCUaJAZV 	 
    	  
    		   
     
     
 
 TheMap mghwyijNY8yWZiPQiY8lR 	 
    	  
    		   
     
  keyframes.is mG7xJth7i0BO6oUVbJqb5 	 
    	  
    		   
     
 _175247760268.first mNdeptenmMoGfTyM3ceNa 	 
  mHNlNa52Z2PZe2OXhBJ1y 	 
    	  
    		   
     
     
            _15593615755193215935.push_back mxtgNrR0I9XNlGwtKgbs_ 	 
    	  
   _175247760268.first mAE2dnbfAdl1cZeEPxwYj 	 
    	   mIXcs_xq6d1ZfHrJUZhbb 	
     mR6cHHVNJUxSb1XUZZAlr 	 
 _11093822386586 mGwwW7E_L5mU4H4fm45hZ 	 
    	  
    		   
  TheMap mJKjklSGsDhfusczCEaK8 	 
    	  
    		   
     
     
 globalReprojChi2 mxtgNrR0I9XNlGwtKgbs_ 	 
    _15593615755193215935,0,0,true,true mNdeptenmMoGfTyM3ceNa 	 
 m_xQN0oi5gVO2R_VQWSRC 	 
    	  
  
    
     maltIVcenw2BRb3v6LFY7 	 
    	  
    		   
     
     
 auto &_2654435878:TheMap mJKjklSGsDhfusczCEaK8 	 
    	  
    		   
    map_markers mr9ts4Np8ncg1gJpHz_ti 	 
    	  
    		   
     
     
 
  	
        _2654435878.second.pose_g2m  mzPpEm7JKS5kSuqDIUCtm 	 
    	  
    		   
     
     
  _16750267944735343466 mWymVNaClEDUhz8dwO3vT 	 
    	  
    _2654435878.first msvr0sqM1zSnK_LAOVElz 	 
    	  
    	 miJar0x8Bt5Zexc5NM4un 	 
    	  
    		   
     
     
 
 
     mBluCPnd_hF_Avwmx4t5o 	 
    	  
    		   
auto &_2654435876:TheMap mghwyijNY8yWZiPQiY8lR 	 
    	  
    		   
     
   keyframes mX0qcbsHjAoNnQaVuWy5P 	 
    	  
    	
        _2654435876.pose_f2g memQ0RtbCNMcXXIi3wQCX 	 
    	  
    		   
     
 _11822840474894279984 mAWzvNghKfSurKk32NNTp 	 
    	  
    		   
  _2654435876.idx mVXmnzdfKl6nHZ3BDaOVf 	 
    	  
    		   
     
     
 
  mwC_DGcKkrPNhMHUMy8hB 	 
    	  
    		   
   
     mHAT8ICuUYb27C9RxwTt_ 	auto &_175247759380:TheMap mSp75bzLNt2iyu0vDMy1V 	 
    	  
    map_points mqIfjicfHLyeUpUXCJg0x 	 
    	  

        _175247759380.setCoordinates ma04H4jmAgnDee_1IqvN5 	 
    	  
   _2772135658178669155 m_eDFTol7iECy2PwxhVjT 	 
    	  
    		   
     
  _175247759380.id mVgfptsNFL1_yPb4iqzR0 	 
    	  
    		   
    mUgVkHgFvWIrVL6b4ukmf 	 miwFxrJ9Hgvh9BU3yQ7JC 	 
    	  
    		
     mfeHr6Ii13gPmR0zit1Zk 	 
    _11093822386586 miwFxrJ9Hgvh9BU3yQ7JC 	 
    	  
    		  
 mMEupUpeFmt2YmeTtEuMo 	 
    	  
   
vector mjOCUIMglMJBpe514Gl6O 	 
    	  
    		 cv mUUAnnRVHtbXs8uZAZ0FH 	DMatch mkMabtkManLa0QZcvlExG 	 
    	  
 LoopDetector mnwIn8oqL3dWmkG84mlxh 	 
    	  
    		   
_15519652129875366702 ma04H4jmAgnDee_1IqvN5 	 
    	  
    		   
     
     
 
  	 std ma7m2a2XM5VioswynpTaQ 	 
shared_ptr miYNzGRvfdQFoOiLnJsV_ 	 
    Map mSHbL3YJPgxvnZ9DktxOb 	 
    	  
    		   
     
     
 
 _11093822290287, const Frame&,  mIQKfSmCqVkhg1PfyjtXu 	 
    	  
    _175247760268,  mrFiCxDdeDz0ePSdLXQ5g 	 
  _1686565542397313973,void*_16614902379131698322 mX0qcbsHjAoNnQaVuWy5P 	 
    	  
    
 mCfeXpurQ7eEHdVTm6sz3 	 
    	  
    		   
     
    
    xflann meThfcmRLi6HYMkRGUo4z 	 
    	  
    		Index *_6806993289704731004 mUe9WFcPV6iTML5qSXbKv 	 
    	  
    		   
     
     
 
  	  ma04H4jmAgnDee_1IqvN5 	 
    	  
    		   
     xflann mLo6MBHX8K7VxYSLeLVQr 	 
    	  
    Index * mHNlNa52Z2PZe2OXhBJ1y 	 
    	  
    		    _16614902379131698322 mIXcs_xq6d1ZfHrJUZhbb 	 
    	  
    		   
     
     
 
    
    Frame &_3005401612717573609 mGwwW7E_L5mU4H4fm45hZ 	 
    	  
    		   
_11093822290287 mghwyijNY8yWZiPQiY8lR 	 
    	  
   keyframes mAWzvNghKfSurKk32NNTp 	 
    	  
    		   _175247760268 mVgfptsNFL1_yPb4iqzR0 	 
    	  
    		  miwFxrJ9Hgvh9BU3yQ7JC 	 
    	  
    		  
    
    vector mQUrH4PQ9h20xuwoz_L6c 	 
    	  
    		   
    uint32_t mRS_PgiJe6t1Qfe_huC7W 	 
    	  
    		   
 _706246332805075 mwC_DGcKkrPNhMHUMy8hB 	 
    	  
    		   
     
     _706246332805075.reserve mG7xJth7i0BO6oUVbJqb5 	 
    	  
    		 _3005401612717573609.und_kpts.size maEyj783NEiTRed1C9KGp 	 
    	  
 mqIfjicfHLyeUpUXCJg0x 	  mIXcs_xq6d1ZfHrJUZhbb 	 
    	  
    		 
     mPXYsSUJKTlN_9TDRANsC 	 
    	  
    		   
 auto _46082543320896749:_3005401612717573609.ids mAE2dnbfAdl1cZeEPxwYj 	 
     mYIrhxIEjkEfaBNG7QAhx 	 
    	  
    	
         mbHU8OACa_bY7FdEZZldx 	 
    	  
    mxtgNrR0I9XNlGwtKgbs_ 	 
_46082543320896749 mWM7aumt8OyUuKPgurbH4 	 
    	  
    		   
  std mteJA8lO8Sm1A4vEX4CFp 	 
    	  
    		   
   numeric_limits mGtr6CfO48OIYqJrBxeee 	 
    	  
    		   
    uint32_t mpteEKFe58LeJX6VYQIlT 	 
    	  
    	 mteJA8lO8Sm1A4vEX4CFp 	 
    	  
    		   
    max mMs8aQibfFI0T2yUvALE7 	 mqIfjicfHLyeUpUXCJg0x 	 
    	  
    		   
 
            _706246332805075.push_back mNh3cvDlcXytdtCUaJAZV 	 
    	  
    		  _46082543320896749 mhRX2T9fqiwg5h4fn7CqV 	 
    	  
    		   
   mDk2ateRzESLAdShOHBxz 	 
    	  
    		   
     
     
 

     mgLz7ptMkDAS2H3myapb6 	 
    	  
    		   
     

     mMHHGP5HEQANIPcW9y0WD 	 
    	  
    		   
    mYfMAy2mq0iYJ9_M3gW7z 	 
    	  
    		_706246332805075.size miLAEYIXn7XwmrPx2ruPJ 	 
    	  
    		   
     
      mbruUZ3EVc14QgQv9nTdI 	 
    	  
    		   0 mPebCiVySBurUpF5aZ3N1 	 
    	  
    		   
     
    return mPGixaAQBxQm2MqBHJbCm 	 
   mNh2RK5UN2xJEcZGvrlzD 	 
    	  
    		   
   mwC_DGcKkrPNhMHUMy8hB 	 
  
    
    cv mod8ttCC8Q4p6YfKFiWT5 	 
    	  
    		   
     
     
 
Mat _2341894709189292181 mwC_DGcKkrPNhMHUMy8hB 	 

    _11093822290287 mRK3Zczq6vZZNqiZhRrjx 	 
    	  
    		   
map_points mAWzvNghKfSurKk32NNTp 	 
    	  
    		   
     
  _706246332805075 mOMjLl_toMbvFZr90mg_G 	 
    	  
    		0 mFxGZTeawKDQkMqstz6nq 	 
    	  
 mnEimIOcHobXmIr5dsOxG 	 
.getDescriptor mGKRS1wgB2KUw_qlPr3ZO 	 
    	  
    		   
 _2341894709189292181 mUgVkHgFvWIrVL6b4ukmf 	 
    	  
    		   
     
     
 mwC_DGcKkrPNhMHUMy8hB 	 
    	  
    		   
     
 
    cv mmZaEtCYOeOREjAVTD1hN 	 Mat _7690820325099119768 mYfMAy2mq0iYJ9_M3gW7z 	 
    	  
_706246332805075.size me4ftpf9gBNIZytyQMpAw 	 
    	  
    		 ,_2341894709189292181.cols,_2341894709189292181.type myByBcZVI3hjwqHKXt_nB 	 
    	  
    		   
     
     
  mUgVkHgFvWIrVL6b4ukmf 	  miwFxrJ9Hgvh9BU3yQ7JC 	 
    	  
    		   
     
    
     mEUHDRL7W9f_jebJ8sIMo 	 
    	  
    		   
     
     
 
  	 size_t _2654435874 mb_HLg3OkjwtqNtbStGWJ 	 
0 maI7EcdmICOL6DnWZAk5L 	 
    	  
    		   
  _2654435874 mgdeaUrW6TAPG0iBLVBsL 	 
    	  
    		   
     
     
 _706246332805075.size me4ftpf9gBNIZytyQMpAw 	  maI7EcdmICOL6DnWZAk5L 	 
    	  
    		   
     
     
 _2654435874 mQkaowH4ODjvWPTHoy0Hp 	 
    	  mqIfjicfHLyeUpUXCJg0x 	 
    	  mWyGglK0azQrxAO1GWKNx 	
        cv mnwIn8oqL3dWmkG84mlxh 	 
    	  
    		   
     
     
Mat _11093822304159 muSWWBwCY5nzwDkMI6YMm 	 
    	  
    		   
     
     
 
  _7690820325099119768.row mGKRS1wgB2KUw_qlPr3ZO 	 
   _2654435874 mAE2dnbfAdl1cZeEPxwYj 	 
    mjt3yMUTnxg8otzv2CROn 	 
    	
        _11093822290287 mghwyijNY8yWZiPQiY8lR 	 
    map_points m_eDFTol7iECy2PwxhVjT 	 
    	  
    		   
     
     
  _706246332805075 mAWzvNghKfSurKk32NNTp 	 
    	  
    		   
   _2654435874 msvr0sqM1zSnK_LAOVElz 	 
    	   mHGVaCQHg7jsPiWyzNB97 	 
    	  
    		   
     
  .getDescriptor mGKRS1wgB2KUw_qlPr3ZO 	 
    	_11093822304159 mNdeptenmMoGfTyM3ceNa 	 
    	  
    		   
     
     
 
  	 mwC_DGcKkrPNhMHUMy8hB 	 
    	  
    		   
     
     mMEupUpeFmt2YmeTtEuMo 	 
    
    cv mMeMaBX7AlQnU2AarSG35 	 
    	  
    		   
     
    Mat _6807141016749312283,_16988745808691518194 mjt3yMUTnxg8otzv2CROn 	 
  
    _6806993289704731004 mS6s5A6y18klHp1JxGUvl 	 
    	  search mxtgNrR0I9XNlGwtKgbs_ 	 
    	  
    		   
     
     
 
  	 _7690820325099119768,2,_6807141016749312283,_16988745808691518194,xflann meThfcmRLi6HYMkRGUo4z 	 
    	  
    		   
     
     KnnSearchParams mxtgNrR0I9XNlGwtKgbs_ 	 
    	  
    		   
     
     32,true mHNlNa52Z2PZe2OXhBJ1y 	 
  mhRX2T9fqiwg5h4fn7CqV 	 
    	  
    		   
     
     
 
  	 mjt3yMUTnxg8otzv2CROn 	 

     mE72_0qT3_J58YcRSfkrB 	 
    	  
    		   
     
     mZxroNgqv4GCicNhd9Vds 	 
    	  
    		   
     
  _16988745808691518194.type miLAEYIXn7XwmrPx2ruPJ 	  mbruUZ3EVc14QgQv9nTdI 	 
    	  
    		   
    CV_32S mqIfjicfHLyeUpUXCJg0x 	  _16988745808691518194.convertTo mX7c7PnpK1mvKbMhF98gK 	 
    	  
    		   
     
  _16988745808691518194,CV_32F mhRX2T9fqiwg5h4fn7CqV 	 
    	  
    	 mIXcs_xq6d1ZfHrJUZhbb 	 
    	  
    		   
     
   
     mvdaYbo4z8SlgMv3lXon4 	 
    	  
    		   
     
     
 
_16988745808737061586 mGwwW7E_L5mU4H4fm45hZ 	 
    	  
    		   
     
    _1686565542397313973 mjt3yMUTnxg8otzv2CROn 	 
    	  
  
     mvdaYbo4z8SlgMv3lXon4 	 
    	  
    		   
     
     
 
  _14756094128870157179 mzPpEm7JKS5kSuqDIUCtm 	 
    	  
    		   
     
    0.9 miwFxrJ9Hgvh9BU3yQ7JC 	 
    	 
    vector miYNzGRvfdQFoOiLnJsV_ 	 
    	  
cv mnwIn8oqL3dWmkG84mlxh 	 
    	  
    		  DMatch mvevHARgRA7CvNeXBlh2_ 	 
    	  
    	 _6807036698572949990 mjt3yMUTnxg8otzv2CROn 	 
    	  
    		   
 
     mEUHDRL7W9f_jebJ8sIMo 	 
    int _2654435874  mVshQzJetvpwfbmhSbkWn 	 
    	  
  0 m_xQN0oi5gVO2R_VQWSRC 	 
    	  
    		   
     
     _2654435874  mjOCUIMglMJBpe514Gl6O 	 
    	  
    		   
     
    _6807141016749312283.rows maI7EcdmICOL6DnWZAk5L 	 
     _2654435874 mfdS85qxr91hdWablaTu0 	 
    	  
    		   
     
    mr9ts4Np8ncg1gJpHz_ti 	 
   mPGixaAQBxQm2MqBHJbCm 	 
    	  
    		 
         m_NKH1FvsobBlgc6p2pMt 	 
    	  
    		   
     
     
 
  mX7c7PnpK1mvKbMhF98gK 	 
 _16988745808691518194.at mGtr6CfO48OIYqJrBxeee 	 
    	  
    		   
     
     
 
  	 float mSHbL3YJPgxvnZ9DktxOb 	 
    	  
    		   
     
    mYfMAy2mq0iYJ9_M3gW7z 	 
    _2654435874,0 mNdeptenmMoGfTyM3ceNa 	 mQUrH4PQ9h20xuwoz_L6c 	 
    	  
    		   
     
     
 
  _16988745808737061586 mHNlNa52Z2PZe2OXhBJ1y 	 
    	  
    		   
      mDnhhwTjyavcESxeRXnT1 	 
    
             mfv1qYALVnt3DXLOds3Bi 	 
 _16988745808691518194.at miYNzGRvfdQFoOiLnJsV_ 	 
    	  
    		   
     
   float mpteEKFe58LeJX6VYQIlT 	 
    	 mZxroNgqv4GCicNhd9Vds 	 
    	  
_2654435874,0 mX0qcbsHjAoNnQaVuWy5P 	 
    	  
    		   
     
     
 
  	    mxQuyf7x6IvZhVeu9AR1f 	 
    	  
    		   float mG7xJth7i0BO6oUVbJqb5 	 
    	  
    		   
     
     
 
_14756094128870157179 * float mBbja92jiZJNsMWkjTEA8 	_16988745808691518194.at mQUrH4PQ9h20xuwoz_L6c 	 
  float mgYWCBsJ4u1ueIoshmx0n 	 
    	  
    		   
     mMK4AuMzUThR8l14ylfTj 	 
    	  
    _2654435874,1 mPebCiVySBurUpF5aZ3N1 	 
    	  
    		  mzKwOblJypS2Tynlc0h7K 	 
    	  
    		   
     
     mUgVkHgFvWIrVL6b4ukmf 	 
    	  
    		   
     
     mAE2dnbfAdl1cZeEPxwYj 	 
    	  
    		   
     
       mNPVh4xG2ZV_lQBDiww0D 	 
    	  
                cv mnwIn8oqL3dWmkG84mlxh 	 
    	  
 DMatch  _46082575882272165 mnCUvl_sQ3iz1ma7ds7a2 	 
    	  
    		   
     
     
 
  	
                _46082575882272165.queryIdx memQ0RtbCNMcXXIi3wQCX 	 
    	  
 _6807141016749312283.at mPRaITo21QKmYA0ca83Hb 	 
    int mgYWCBsJ4u1ueIoshmx0n 	 
    	  
    		   
     
     
 
 mG7xJth7i0BO6oUVbJqb5 	 
    	  
  _2654435874,0 mX0qcbsHjAoNnQaVuWy5P 	 
    	  
    		  mAzTDU0OC6jPLmhZXxf5s 	 

                _46082575882272165.trainIdx memQ0RtbCNMcXXIi3wQCX 	 
    	  
    		 _706246332805075 mAWzvNghKfSurKk32NNTp 	 _2654435874 mbPdyGWxNHmH6SUUDyPSL 	 
    	 mwC_DGcKkrPNhMHUMy8hB 	 
    	  
    		   
     
 
                _46082575882272165.distance mUe9WFcPV6iTML5qSXbKv 	 
    	  
    		  _16988745808691518194.at mKDTKQpoaf9CSC6GD0TC_ 	 
    	  
    		float mRS_PgiJe6t1Qfe_huC7W 	 
    	  
    		   
     
    mG7xJth7i0BO6oUVbJqb5 	 
    	  
    		 _2654435874,0 mPebCiVySBurUpF5aZ3N1 	 
    	  
    		   
     
    mDk2ateRzESLAdShOHBxz 	 
    	  
    		 
                _6807036698572949990.push_back mMK4AuMzUThR8l14ylfTj 	 
   _46082575882272165 mNdeptenmMoGfTyM3ceNa 	 
    	  
    		   
     
     
 
  mAzTDU0OC6jPLmhZXxf5s 	 
    	  
  
             mMnQcRje5274EAZHUxVoc 	 
    	  
   
         mNh2RK5UN2xJEcZGvrlzD 	 
    	 
     mGwH5P2DG1FxTU6MU_6QT 	 
    	  
    		   
    filter_ambiguous_query mMK4AuMzUThR8l14ylfTj 	 
    	  
    		   
     
 _6807036698572949990 mhRX2T9fqiwg5h4fn7CqV 	 
    	  
  miwFxrJ9Hgvh9BU3yQ7JC 	 
  
     mfeHr6Ii13gPmR0zit1Zk 	 
    	  
    		   
     
    _6807036698572949990 miJar0x8Bt5Zexc5NM4un 	 
    	  
    		   
 mAutaeq8TRDcw1y62NeWa 	 
    	  
    		   
     
  
std mteJA8lO8Sm1A4vEX4CFp 	 
    	  
    		   
     
     vector mGtr6CfO48OIYqJrBxeee 	 
    	  
  LoopDetector mr5PE3A1WmSQZvRF5LGFr 	 
    	  
    		   
     
     
 
  LoopClosureInfo mpteEKFe58LeJX6VYQIlT 	 
    	  
    LoopDetector mteJA8lO8Sm1A4vEX4CFp 	 
    	  
  _8671179296205241382 mG7xJth7i0BO6oUVbJqb5 	 
    	  
    		   
     
     Frame &_46082543180066935, int32_t _16940374156599401875 mNdeptenmMoGfTyM3ceNa 	 mPGixaAQBxQm2MqBHJbCm 	 
    	  
    		   
    
     muxw1Wp5TS2uK6BAu72zb 	 
    	  
    		   
   _5829441678613027716 mVshQzJetvpwfbmhSbkWn 	 
 mYQegUh3q9slmeoiYoJjg 	 mbPdyGWxNHmH6SUUDyPSL 	 
    	  
    		 mG7xJth7i0BO6oUVbJqb5 	 
    	  
    		   
     
     
 
 const uint32_t&_11093821926013 mAE2dnbfAdl1cZeEPxwYj 	 
    	  
    		   
     
  mZrh25nTGSOmEcIn3KqdO 	 
    	  
    		   
     
  std mnwIn8oqL3dWmkG84mlxh 	 
    	  
    		   
     
     
 
stringstream _706246330191125 mnCUvl_sQ3iz1ma7ds7a2 	 
    	  
    		 _706246330191125 mPTenLEomfo7O0OOdmnR8 	 
    	  
    		   
 _11093821926013 mwC_DGcKkrPNhMHUMy8hB 	 
    	  
    		   
 mahqUizQ5natga48g2TNS 	_706246330191125.str miLAEYIXn7XwmrPx2ruPJ 	 
    	  
    		   
     
     
 
  	 maI7EcdmICOL6DnWZAk5L 	 
 mMEupUpeFmt2YmeTtEuMo 	 
    	  
    		   
     
      mnCUvl_sQ3iz1ma7ds7a2 	 
    	  
    		   
     
     
 
  	 
             mfD9pTiMELJRARGDAwmaJ 	 
 mGKRS1wgB2KUw_qlPr3ZO 	 
    	  
    		   
     
 mh_cQtQ6GFMj5bJjKilUx 	 
    	  
    		  System mUUAnnRVHtbXs8uZAZ0FH 	 
    	  
    		   
 getParams meNaaQSUqmbpWcYodKuLc 	 
    	  
    		   
     
  .detectKeyPoints mAE2dnbfAdl1cZeEPxwYj 	 
    	  
    		   
     
     
 
    mfeHr6Ii13gPmR0zit1Zk 	 
    	  
    		   
     
 mtUrDV5jqTezfsdfRbyeG 	 
    	  
    		   msP_HdnLnvyq_xHfK3eKV 	 
    	  
    		 miJar0x8Bt5Zexc5NM4un 	 
    	 
     mbHU8OACa_bY7FdEZZldx 	 
    ma04H4jmAgnDee_1IqvN5 	 
    	  
    	TheMap mpiOmG3B7o8txhSe0vp7N 	 
    	  
    	TheKFDataBase.isEmpty maEyj783NEiTRed1C9KGp 	 
    	  
    		   
     
     
 
   mhRX2T9fqiwg5h4fn7CqV 	 
    	  
 return  mYIrhxIEjkEfaBNG7QAhx 	 
    	  
    		   
     
     
 mgLz7ptMkDAS2H3myapb6 	 
    	  miwFxrJ9Hgvh9BU3yQ7JC 	 
    	  
     mR6cHHVNJUxSb1XUZZAlr 	 
    	  
    		 _1702552708676489766 mrEYNwjXK_xAwDc6dEvdA 	 
    	  
    		   
     
     
 
  	 TheMap mRK3Zczq6vZZNqiZhRrjx 	 
    	  
    		TheKpGraph.getNeighbors mBbja92jiZJNsMWkjTEA8 	 
    	  
    		   
     
     
_16940374156599401875,true mr9ts4Np8ncg1gJpHz_ti 	 
    	  
    		   
     
    maI7EcdmICOL6DnWZAk5L 	 
    	  
    		   
    
     mfD9pTiMELJRARGDAwmaJ 	 
    	  
    		   
     
      mYfMAy2mq0iYJ9_M3gW7z 	 
    	  
    		   
_1702552708676489766.size me4ftpf9gBNIZytyQMpAw 	 
    	  
    		   
     
    mumbKqnnC1o1UEMIaFlPi 	TheMap mS6s5A6y18klHp1JxGUvl 	 
    	  
    		   
    keyframes.size me4ftpf9gBNIZytyQMpAw 	 
    	  
    		   
    mPebCiVySBurUpF5aZ3N1 	 
    	  
    		   
     
     
 
   mpqJRLW3w7D0iSr6wl2cp 	 mPGixaAQBxQm2MqBHJbCm 	 mMnQcRje5274EAZHUxVoc 	 
    	  
    		   
     
     
  mIXcs_xq6d1ZfHrJUZhbb 	 
    	  
   
    
     mrFiCxDdeDz0ePSdLXQ5g 	 
    	  
    		   
     
_16937373706612713730  mb_HLg3OkjwtqNtbStGWJ 	 
    	  
    		   
    1 mwC_DGcKkrPNhMHUMy8hB 	 
    	  
   
     mBluCPnd_hF_Avwmx4t5o 	 
    	  
    		   
    auto _46082575804458778:_1702552708676489766 mhRX2T9fqiwg5h4fn7CqV 	 
    	  
    		   
     
     
 

        _16937373706612713730 mUe9WFcPV6iTML5qSXbKv 	 
  std mod8ttCC8Q4p6YfKFiWT5 	 
    	  
    		   
    min mZxroNgqv4GCicNhd9Vds 	 
  _16937373706612713730, TheMap mHCj6MRgYNeaPqcfnaTtQ 	 
    	  
    	TheKFDataBase.score mNh3cvDlcXytdtCUaJAZV 	 _46082543180066935,TheMap mpiOmG3B7o8txhSe0vp7N 	keyframes mnlZXMVwQPNJ6R49HEuV6 	 
    	  
    		   
   _46082575804458778 mFxGZTeawKDQkMqstz6nq 	 
    	  
    		   
     
      mPebCiVySBurUpF5aZ3N1 	 
    	  
    		   
 mUgVkHgFvWIrVL6b4ukmf 	 
    	  
    		  mjt3yMUTnxg8otzv2CROn 	 
    	  
    		   
     
     
 
 
     mR6cHHVNJUxSb1XUZZAlr 	 
_13899933296976059300 mKQs5UoWc8hQnZyjRiO9c 	TheMap mN4iA3tOcEXBIEi2Est1o 	 
    	  
    		   
     
     
 
  TheKFDataBase.relocalizationCandidates mMK4AuMzUThR8l14ylfTj 	 
    	  
    		   
     
     
 _46082543180066935,TheMap mSp75bzLNt2iyu0vDMy1V 	 
    	  
    		   
     
 keyframes,TheMap mN4iA3tOcEXBIEi2Est1o 	 
    	TheKpGraph,true,_16937373706612713730/2.,_1702552708676489766 mr9ts4Np8ncg1gJpHz_ti 	 
    	  
    		   
     
     mDk2ateRzESLAdShOHBxz 	 
    	  
    		   
     
     
     mSbQGkGX65LSisAvhFR7i 	 
    	  
_13899933296976059300.size maEyj783NEiTRed1C9KGp 	 
    	  
     mMeCjBW1I6eJ4PButyoYE 	 
    	  
    		 0 mPebCiVySBurUpF5aZ3N1 	 
    	  
    		   
     
       mM1dZCPHOOM7Mpa0yRhsf 	 
    	  
    		   
     
 mZrh25nTGSOmEcIn3KqdO 	 
    	  
    		   
     
      mMEupUpeFmt2YmeTtEuMo 	 
    	  
    		  mjt3yMUTnxg8otzv2CROn 	
    
    
     mFoNkWHTxY94crEZ2nRP2 	_1648036655000763724 mFlDAyw4uvIC_FhJUUdm_ 	 
    	  
    		   
     
     
 
 
        _1648036655000763724 mNh3cvDlcXytdtCUaJAZV 	 
    	  
    		   
     
  uint32_t _2654435871 mAE2dnbfAdl1cZeEPxwYj 	 
   mDnhhwTjyavcESxeRXnT1 	 
    	  
    		   
     
     
 _17013904265820854 memQ0RtbCNMcXXIi3wQCX 	 
    	  
    		 _2654435871 m_xQN0oi5gVO2R_VQWSRC 	  mAutaeq8TRDcw1y62NeWa 	 
    	  

         mavfJmcPsE9DmpvlMyYVt 	 
    	  
    		   
     
  _17013904265820854 mAzTDU0OC6jPLmhZXxf5s 	 
    	  
    		   
     
     
 
  	 cv mr5PE3A1WmSQZvRF5LGFr 	 
    	  
    		   
     Mat _9332970625915525982 memQ0RtbCNMcXXIi3wQCX 	 
    	  
    		   
   cv mr5PE3A1WmSQZvRF5LGFr 	 
    	  
Mat mMs8aQibfFI0T2yUvALE7 	 
    	  
 mAzTDU0OC6jPLmhZXxf5s 	 
    	  
    		   
     
     
 
  	  mbsNsaQEQfktP2l3TYMiX 	 
    	  
    		   
 _1994458605759073584 muSWWBwCY5nzwDkMI6YMm 	 
   0 miJar0x8Bt5Zexc5NM4un 	 
    	  
    		   
     
     
 
  	 mtNbESZnJymClvDJQgXdW 	 
    	  
    		 _1087568825552921310 mrEYNwjXK_xAwDc6dEvdA 	false miwFxrJ9Hgvh9BU3yQ7JC 	 
    	  
    		   
     

        vector mKDTKQpoaf9CSC6GD0TC_ 	 
    	  
    		   
     
     
 
 cv mteJA8lO8Sm1A4vEX4CFp 	 
    	  
    		 DMatch m_5grhY8wx8_nGTeN7t1i 	 
    	  
    		   _6744006314306065854 miwFxrJ9Hgvh9BU3yQ7JC 	 
    	  
    		   
     

     mGwH5P2DG1FxTU6MU_6QT 	 
   mDk2ateRzESLAdShOHBxz 	 

    vector mQUrH4PQ9h20xuwoz_L6c 	 
    	  
  _1648036655000763724 maz6hZ1Qmyhz47_btGDO1 	 
    	  
    		   
     
     
 _7244985490283130860 miJar0x8Bt5Zexc5NM4un 	
     mMcVkDr5WQSzvkCL3IsEy 	 
    	auto _175247760320:_13899933296976059300 mhRX2T9fqiwg5h4fn7CqV 	 
    
            _7244985490283130860.push_back mMK4AuMzUThR8l14ylfTj 	 _1648036655000763724 mNh3cvDlcXytdtCUaJAZV 	 
    	  
   _175247760320 mUgVkHgFvWIrVL6b4ukmf 	 
    	  
    		   
     
     
  mqIfjicfHLyeUpUXCJg0x 	 
  mIXcs_xq6d1ZfHrJUZhbb 	 
    	  
    		   
     
     
 
    FrameMatcher _16937386958649118140 mDk2ateRzESLAdShOHBxz 	 
    	  
    		  
    _16937386958649118140.setParams mMK4AuMzUThR8l14ylfTj 	 
    	  
    		   
     
  _46082543180066935,FrameMatcher mod8ttCC8Q4p6YfKFiWT5 	 
    	  
    MODE_ALL,System ma7m2a2XM5VioswynpTaQ 	 
    	  
    		 getParams maEyj783NEiTRed1C9KGp 	 
    	  
    		   
     
     
 
  	.maxDescDistance*2 mUgVkHgFvWIrVL6b4ukmf 	 
    	  
    		   
  mDk2ateRzESLAdShOHBxz 	 
    	  
    		   
     
     
 
#pragma message "warning: Check the loop detector is correct with the FrameMatcher"
  
     mRH4mjD7ZPB_82GeftQaw 	 
    	  
auto &_706246351566300:_7244985490283130860 mr9ts4Np8ncg1gJpHz_ti 	 
    	  
    		   
    mDnhhwTjyavcESxeRXnT1 	 
    	  
    		   
     
        vector mPRaITo21QKmYA0ca83Hb 	 
  cv mnwIn8oqL3dWmkG84mlxh 	 
 Point2f mSHbL3YJPgxvnZ9DktxOb 	 
    	  
    		   
 _16937225740828189009 mDk2ateRzESLAdShOHBxz 	 
    	  
        vector mPRaITo21QKmYA0ca83Hb 	 cv mLo6MBHX8K7VxYSLeLVQr 	 
    	  
    		   
     
     
 
 Point3f mkMabtkManLa0QZcvlExG 	 
   _16937225740828192533 mAzTDU0OC6jPLmhZXxf5s 	 
    
        vector mgdeaUrW6TAPG0iBLVBsL 	 
    	  
    		   
     
     
 
  	cv mod8ttCC8Q4p6YfKFiWT5 	 
    	  
    		   
     
 DMatch mvevHARgRA7CvNeXBlh2_ 	 
    	  
    		   
     
    _6807036698572949990 mIXcs_xq6d1ZfHrJUZhbb 	 
    	 
         mJNG55wKWn05SRJkprUDL 	 
   1 mPebCiVySBurUpF5aZ3N1 	 
    	  
    		    mYIrhxIEjkEfaBNG7QAhx 	 
    	  
    		   
   
             mU7YWgrM69Z0WHvDiKcBl 	 
    	  
    		   
     
     
 
  &_3005399814901981436 mVshQzJetvpwfbmhSbkWn 	 
TheMap mspUrihBhhhtw4FBiaBvy 	 
    	  
    		 keyframes mWymVNaClEDUhz8dwO3vT 	 
    	  
    		   
     
     
_706246351566300._17013904265820854 mnEimIOcHobXmIr5dsOxG 	 
    	  
    		   
     
  mIXcs_xq6d1ZfHrJUZhbb 	 
    	  
    		   
     
            _6807036698572949990 mGwwW7E_L5mU4H4fm45hZ 	 
   _16937386958649118140.match ma04H4jmAgnDee_1IqvN5 	 
   _3005399814901981436,FrameMatcher mUUAnnRVHtbXs8uZAZ0FH 	 
    	  
    		   
MODE_ASSIGNED mhRX2T9fqiwg5h4fn7CqV 	 
 mjt3yMUTnxg8otzv2CROn 	 
    	  
    		   
    
            
             mKreihTCvnL_R53gf9Vxe 	 
    	  
    		   
     
     _6807036698572949990.size maEyj783NEiTRed1C9KGp 	 
    	  
    		   
  mKDTKQpoaf9CSC6GD0TC_ 	30 mHNlNa52Z2PZe2OXhBJ1y 	 
     mWyGglK0azQrxAO1GWKNx 	 
    	  
  
                _706246351566300._1087568825552921310 memQ0RtbCNMcXXIi3wQCX 	 
true mwC_DGcKkrPNhMHUMy8hB 	 
    	  
    		   
     

                continue mIXcs_xq6d1ZfHrJUZhbb 	 
    	  
    		   
     
     

             mB58ylLLhUkc44hEn298e 	 
    	  
    		   

             mdbzbaVIzDwW_qjPbKNIb 	 
    	  
    		   
     
     
auto _2654435878:_6807036698572949990 mNdeptenmMoGfTyM3ceNa 	 
    	  
    		   
     
     
 
   mtUrDV5jqTezfsdfRbyeG 	 
    	  
    		   
     
     
 
 
                _16937225740828189009.push_back mxtgNrR0I9XNlGwtKgbs_ 	 
    	  
    	_46082543180066935.und_kpts msX2aFZOZI29G1zOojPg2 	 
    	  
    		   
     
     
 
  	 _2654435878.trainIdx mc1ZVDw0Qh0A2juXO2Sgd 	 
    	  
    .pt mX0qcbsHjAoNnQaVuWy5P 	 
    	  
    		   
     
     
 
  m_xQN0oi5gVO2R_VQWSRC 	 
    	  
    		   
     
 
                _16937225740828192533.push_back mYfMAy2mq0iYJ9_M3gW7z 	 
    	  TheMap mSp75bzLNt2iyu0vDMy1V 	 
    	  
    map_points mWymVNaClEDUhz8dwO3vT 	 
    	  _3005399814901981436.ids m_eDFTol7iECy2PwxhVjT 	 
    	  
    		   
     
      _2654435878.queryIdx mFxGZTeawKDQkMqstz6nq 	 
    	  
    		  mVgfptsNFL1_yPb4iqzR0 	 
    	  
    		   
     
     
 
 .getCoordinates msEmz2sBrLxKt5K4PbJiT 	 
    	  
    		   
     
     
 
   mhRX2T9fqiwg5h4fn7CqV 	 
    	   mDk2ateRzESLAdShOHBxz 	 
    	  
    		
             mFkTh5yfCM8IQj3fEOy7O 	 
         mkJkNZCI4_vhjeQc322zU 	 
    	  
   











        cv mUUAnnRVHtbXs8uZAZ0FH 	 
    	  
    		   
     
     Mat _175247759698,_175247759831 mIXcs_xq6d1ZfHrJUZhbb 	
        vector mgdeaUrW6TAPG0iBLVBsL 	 
    int m_5grhY8wx8_nGTeN7t1i 	 
    	  
    		   
     _6807141016080266659 mAzTDU0OC6jPLmhZXxf5s 	 
  
        
        cv ma7m2a2XM5VioswynpTaQ 	solvePnPRansac mxtgNrR0I9XNlGwtKgbs_ 	 
    	  
    		   
    _16937225740828192533,_16937225740828189009, _46082543180066935.imageParams.CameraMatrix,cv mnwIn8oqL3dWmkG84mlxh 	 
   Mat mmZaEtCYOeOREjAVTD1hN 	 
    	  
 zeros mZxroNgqv4GCicNhd9Vds 	 
    	  
    1,5,CV_32F mNdeptenmMoGfTyM3ceNa 	 
    	  
    		,_175247759698,_175247759831,false,100,2.5,0.99,_6807141016080266659 mUgVkHgFvWIrVL6b4ukmf 	 
    m_xQN0oi5gVO2R_VQWSRC 	 

         mfD9pTiMELJRARGDAwmaJ 	 
    	  
    		   
     
     
 
  	 mBbja92jiZJNsMWkjTEA8 	 
    	  
    		   
     
     
 
 _6807141016080266659.size mtk2iJ0o4hJH0SUXm_IsX 	 
    	  
    		   
     
   mGtr6CfO48OIYqJrBxeee 	 
    	  
15  mX0qcbsHjAoNnQaVuWy5P 	 
    	  
    		   
     
     
 
 mFlDAyw4uvIC_FhJUUdm_ 	 
    	  
   
            _706246351566300._1087568825552921310 muSWWBwCY5nzwDkMI6YMm 	 
    	  
    		   
     
     
 true m_xQN0oi5gVO2R_VQWSRC 	 
    	  
    		 
            continue mDk2ateRzESLAdShOHBxz 	 
    	  
    		   
 
         mMEupUpeFmt2YmeTtEuMo 	 
    	  
    		   
     
     
 
  	 
        _706246351566300._1994458605759073584 mVshQzJetvpwfbmhSbkWn 	 
    	  
    		   
   _6807141016080266659.size maEyj783NEiTRed1C9KGp 	 
    	  
    		   
     
     
  maI7EcdmICOL6DnWZAk5L 	 
  
        _706246351566300._9332970625915525982 mUe9WFcPV6iTML5qSXbKv 	 
 getRTMatrix mX7c7PnpK1mvKbMhF98gK 	 
    	  
    		 _175247759698,_175247759831,CV_32F mzKwOblJypS2Tynlc0h7K 	 miwFxrJ9Hgvh9BU3yQ7JC 	 
    	  
    		   
     
     
        
        _706246351566300._6744006314306065854.reserve mX7c7PnpK1mvKbMhF98gK 	 
    	  
    		   
     
     
 
  	 _6807141016080266659.size miLAEYIXn7XwmrPx2ruPJ 	 
    	  
    mhRX2T9fqiwg5h4fn7CqV 	 
    	  
    		   
     
      miJar0x8Bt5Zexc5NM4un 	 
    	  
    		   
     
    
         mHAT8ICuUYb27C9RxwTt_ 	 
    	  
    		  auto _175247760141:_6807141016080266659 mNdeptenmMoGfTyM3ceNa 	 
    	  
    		  
            _706246351566300._6744006314306065854.push_back mG7xJth7i0BO6oUVbJqb5 	 
    	  
     _6807036698572949990 mYQegUh3q9slmeoiYoJjg 	 
 _175247760141 mVXmnzdfKl6nHZ3BDaOVf 	 
    	  
    		   
     
     
 
   mHNlNa52Z2PZe2OXhBJ1y 	 
   maI7EcdmICOL6DnWZAk5L 	 
    	  
    		   
     
     

     mAutaeq8TRDcw1y62NeWa 	 
   
    _7244985490283130860.erase mGKRS1wgB2KUw_qlPr3ZO 	 std mr5PE3A1WmSQZvRF5LGFr 	 
    	  
    		   
     
     
 
 remove_if mX7c7PnpK1mvKbMhF98gK 	 
    	  
    		   
     
     
 
 _7244985490283130860.begin miLAEYIXn7XwmrPx2ruPJ 	 
    	  
    		   
 ,_7244985490283130860.end maEyj783NEiTRed1C9KGp 	 
    	  
    		   
, mYQegUh3q9slmeoiYoJjg 	 
    	  
    	 mc1ZVDw0Qh0A2juXO2Sgd 	 
  ma04H4jmAgnDee_1IqvN5 	 
    	  
    		   
   const _1648036655000763724& _2654435868 mHNlNa52Z2PZe2OXhBJ1y 	 mDnhhwTjyavcESxeRXnT1 	 
    	  
    		   
     
     
 
return _2654435868._1087568825552921310 m_xQN0oi5gVO2R_VQWSRC 	 
    	  
    		   
     
      mAutaeq8TRDcw1y62NeWa 	 
    	  
    		 mHNlNa52Z2PZe2OXhBJ1y 	 
    	  
    		   
     ,_7244985490283130860.end meNaaQSUqmbpWcYodKuLc 	 
    	  
    		   
     mAE2dnbfAdl1cZeEPxwYj 	 
    	  
 maI7EcdmICOL6DnWZAk5L 	 
    	  
    
     m_NKH1FvsobBlgc6p2pMt 	 
    	  
    		   
     mX7c7PnpK1mvKbMhF98gK 	 
    	  
    		   
     
     
 _7244985490283130860.size maEyj783NEiTRed1C9KGp 	 
    	  
    		   
     
     
 
 mutl7ld5XBILgjvm9Bxtg 	 
    	  
    	0 mNdeptenmMoGfTyM3ceNa 	 
    	  
    mI1DvqyXO1beDtF28vNn9 	 
    	  
    		   
     
     
 
  	   mWyGglK0azQrxAO1GWKNx 	 
    	  
    		   
      mMnQcRje5274EAZHUxVoc 	  miJar0x8Bt5Zexc5NM4un 	 
   
    
    std mteJA8lO8Sm1A4vEX4CFp 	 
    	  
    		   
     
     
 sort mBbja92jiZJNsMWkjTEA8 	 
 _7244985490283130860.begin maEyj783NEiTRed1C9KGp 	 
    	  
    		   
     
,_7244985490283130860.end mMs8aQibfFI0T2yUvALE7 	 
    	  
    		   
    , m_eDFTol7iECy2PwxhVjT 	 
     mHGVaCQHg7jsPiWyzNB97 	  mBbja92jiZJNsMWkjTEA8 	 
    	  
    		   
  const _1648036655000763724 &_175247762797,const _1648036655000763724 &_175247762798 mX0qcbsHjAoNnQaVuWy5P 	 
    	  
    		   mCfeXpurQ7eEHdVTm6sz3 	return _175247762797._1994458605759073584 mkMabtkManLa0QZcvlExG 	 
    	  
    		   
     _175247762798._1994458605759073584 mwC_DGcKkrPNhMHUMy8hB 	 
    	  mFkTh5yfCM8IQj3fEOy7O 	 
    	  
   mNdeptenmMoGfTyM3ceNa 	 
    	  
    		   
     maI7EcdmICOL6DnWZAk5L 	 
    	  
    		   
     
     
 
 
    
     meVhva2888lfPoP60YhOi 	 
    	auto &_16119892890339758111:_7244985490283130860 mPebCiVySBurUpF5aZ3N1 	 
    	   mFlDAyw4uvIC_FhJUUdm_ 	 
    	  
    		   
    
        
         mdbzbaVIzDwW_qjPbKNIb 	 
    	 auto &_175247759380:TheMap mN4iA3tOcEXBIEi2Est1o 	 
   map_points mqIfjicfHLyeUpUXCJg0x 	 
    	 _175247759380.lastFIdxSeen muSWWBwCY5nzwDkMI6YMm 	 
    	  std meThfcmRLi6HYMkRGUo4z 	 
    	  
   numeric_limits mQUrH4PQ9h20xuwoz_L6c 	 
    	  
    		   
   uint32_t mlGAhEsbSz8YxV75nlhR0 	 
    	  
    		   
     
     
 
   mLo6MBHX8K7VxYSLeLVQr 	 
    	  
 max msEmz2sBrLxKt5K4PbJiT 	 
    	  mIXcs_xq6d1ZfHrJUZhbb 	 
    	  
    		   
        
        _16119892890339758111._6744006314306065854  mb_HLg3OkjwtqNtbStGWJ 	 
    	  
    		   
     
    TheMap mHCj6MRgYNeaPqcfnaTtQ 	 
    	  
    	matchFrameToMapPoints ma04H4jmAgnDee_1IqvN5 	 
    	  
    		   
 TheMap mghwyijNY8yWZiPQiY8lR 	 
    	  
    		   
     
     
 TheKpGraph.getNeighborsV ma04H4jmAgnDee_1IqvN5 	 
  _7244985490283130860 mOMjLl_toMbvFZr90mg_G 	 
    	  
    		   
    0 mS619Af_XaGLce9WysiWq 	 
    	  
    		  ._17013904265820854,true mHNlNa52Z2PZe2OXhBJ1y 	 
    	  
    		   
     
  , _46082543180066935,  _7244985490283130860 m_eDFTol7iECy2PwxhVjT 	 
    	  
    		   
     
    0 mVgfptsNFL1_yPb4iqzR0 	 
    	  
    		   
._9332970625915525982 ,System mMeMaBX7AlQnU2AarSG35 	 
    	 getParams mtk2iJ0o4hJH0SUXm_IsX 	 
    	  
.maxDescDistance*1.5, 2.5,false,true mzKwOblJypS2Tynlc0h7K 	 
    	  
    		   
     
     
 
  	 miJar0x8Bt5Zexc5NM4un 	 
   
         miQaMVtCiq3ePSt9jREnl 	 
    _16119892890339758111._6744006314306065854.size meNaaQSUqmbpWcYodKuLc 	 
    	  
    		   
     
    mgdeaUrW6TAPG0iBLVBsL 	 
    	  40 mzKwOblJypS2Tynlc0h7K 	 
     continue mAzTDU0OC6jPLmhZXxf5s 	 
    	  
    		   
     
     
 
        se3 _6807035026667062616 mb_HLg3OkjwtqNtbStGWJ 	 _16119892890339758111._9332970625915525982 mAzTDU0OC6jPLmhZXxf5s 	 
    	  
    
        PnPSolver mLo6MBHX8K7VxYSLeLVQr 	 
    	  
   solvePnp mX7c7PnpK1mvKbMhF98gK 	 
    	  
_46082543180066935, TheMap,_16119892890339758111._6744006314306065854, _6807035026667062616,_16940374156599401875 mUgVkHgFvWIrVL6b4ukmf 	 
    	  
    		   
     
     
 
  	  mwC_DGcKkrPNhMHUMy8hB 	 
    	  
    		   
     
  
        _16119892890339758111._9332970625915525982 mzPpEm7JKS5kSuqDIUCtm 	 
    	  
    		  _6807035026667062616 m_xQN0oi5gVO2R_VQWSRC 	 
    	  
  
     mFkTh5yfCM8IQj3fEOy7O 	 
    	  
    		   

    
    std meThfcmRLi6HYMkRGUo4z 	 
    	  
    		   
     
     
 
 sort mGKRS1wgB2KUw_qlPr3ZO 	 
    	  
   _7244985490283130860.begin miLAEYIXn7XwmrPx2ruPJ 	 
    	  
    		  ,_7244985490283130860.end me4ftpf9gBNIZytyQMpAw 	 
    	  
    		   
     
   , msX2aFZOZI29G1zOojPg2 	 
    	  
    		   
 mVgfptsNFL1_yPb4iqzR0 	 
     mX7c7PnpK1mvKbMhF98gK 	 
    	  
    		   
     const _1648036655000763724 &_175247762797,const _1648036655000763724 &_175247762798 mUgVkHgFvWIrVL6b4ukmf 	 
    	  
    		   
     
  mtUrDV5jqTezfsdfRbyeG 	 
    	  
    		   
     
     return _175247762797._6744006314306065854.size miLAEYIXn7XwmrPx2ruPJ 	 
    	  
    		   
     
     
 
   mkMabtkManLa0QZcvlExG 	 
    	  
    		   
     
  _175247762798._6744006314306065854.size mMs8aQibfFI0T2yUvALE7 	 
    	  
    		   
     
   miJar0x8Bt5Zexc5NM4un 	 
    	  
    		   
     
   mB58ylLLhUkc44hEn298e 	 
    	  
    		    mAE2dnbfAdl1cZeEPxwYj 	 
    maI7EcdmICOL6DnWZAk5L 	 
    	  
    		   
  
    
     mMHHGP5HEQANIPcW9y0WD 	 
    	  
    		   
  mBbja92jiZJNsMWkjTEA8 	 _7244985490283130860 msX2aFZOZI29G1zOojPg2 	 
    	  
    		0 mS619Af_XaGLce9WysiWq 	 ._6744006314306065854.size mIfJTCDTzNTDbSwjZ_4ng 	 
    	  
    		   
     
 mPRaITo21QKmYA0ca83Hb 	 
    	  
    30 mHNlNa52Z2PZe2OXhBJ1y 	 
    	return  mPGixaAQBxQm2MqBHJbCm 	 
    	  
    		   
     
     
 
  mFkTh5yfCM8IQj3fEOy7O 	 
    	  
    		 mDk2ateRzESLAdShOHBxz 	 
  
    
    
    LoopClosureInfo _11093822343890 m_xQN0oi5gVO2R_VQWSRC 	 
    	  
    		   
   
    _11093822343890.curRefFrame mzPpEm7JKS5kSuqDIUCtm 	 
    	  
    		   
_16940374156599401875 mDk2ateRzESLAdShOHBxz 	 
    	  
    		   
     
   
    _11093822343890.matchingFrameIdx mVshQzJetvpwfbmhSbkWn 	 
    	  
    		   _7244985490283130860 msX2aFZOZI29G1zOojPg2 	 
  0 mc1ZVDw0Qh0A2juXO2Sgd 	 
    	  
    		   
  ._17013904265820854 miwFxrJ9Hgvh9BU3yQ7JC 	 

    _11093822343890.expectedPos mKQs5UoWc8hQnZyjRiO9c 	 
    	  
    		   
     
_7244985490283130860 mWymVNaClEDUhz8dwO3vT 	 
    	0 mS619Af_XaGLce9WysiWq 	 
    	  
    		   
     
   ._9332970625915525982 mjt3yMUTnxg8otzv2CROn 	 
    	  
    		 
    _11093822343890.map_matches mgegCV8i4RdQqulhCBPGP 	 
    	  
 _7244985490283130860 msX2aFZOZI29G1zOojPg2 	 
    	  0 mvgZM8nIZFeOdMyTrsL7T 	 
    	  
    		   
     
  ._6744006314306065854 mDk2ateRzESLAdShOHBxz 	
     mfeHr6Ii13gPmR0zit1Zk 	 
    	  
    		   
    mPGixaAQBxQm2MqBHJbCm 	 
    	  
   _11093822343890 mMEupUpeFmt2YmeTtEuMo 	 
    	  
    		   
 mnCUvl_sQ3iz1ma7ds7a2 	
 mgLz7ptMkDAS2H3myapb6 	 
    	  
    	
 mC2iS7wUKLq4bFZBruDv_ 	 
    	  
    		   
     
     
 
 LoopDetector mr5PE3A1WmSQZvRF5LGFr 	 
    	  
    	LoopClosureInfo mteJA8lO8Sm1A4vEX4CFp 	 
    	  
    		   
     
     
 
 toStream mBbja92jiZJNsMWkjTEA8 	 
    	  
    		   
     
  ostream &_11093822381060 mhRX2T9fqiwg5h4fn7CqV 	 
  const mWyGglK0azQrxAO1GWKNx 	 
 
    _11093822381060.write mxtgNrR0I9XNlGwtKgbs_ 	 
    	  
    		   
      mGKRS1wgB2KUw_qlPr3ZO 	 
    	  
    		   
     
     
 char* mUgVkHgFvWIrVL6b4ukmf 	 
    	  
    		   
     
     
 
  	 &curRefFrame,sizeof mMK4AuMzUThR8l14ylfTj 	 
curRefFrame mAE2dnbfAdl1cZeEPxwYj 	 
    	  
  mhRX2T9fqiwg5h4fn7CqV 	 
    	  
    		   
     
      miJar0x8Bt5Zexc5NM4un 	
    _11093822381060.write mBbja92jiZJNsMWkjTEA8 	 
    	  
    		   
    ma04H4jmAgnDee_1IqvN5 	 
    	  
    		   
     
 char* mHNlNa52Z2PZe2OXhBJ1y 	 
    	  
    		   &matchingFrameIdx,sizeof mNh3cvDlcXytdtCUaJAZV 	 
    	  
    		   
     
     
 
  	matchingFrameIdx mX0qcbsHjAoNnQaVuWy5P 	 
    	 mHNlNa52Z2PZe2OXhBJ1y 	 
    	  
    		   
     
     mAzTDU0OC6jPLmhZXxf5s 	 
    	
    toStream__ mMK4AuMzUThR8l14ylfTj 	 
    	  
    		   expectedPos,_11093822381060 mUgVkHgFvWIrVL6b4ukmf 	 
    	  
    		 miwFxrJ9Hgvh9BU3yQ7JC 	 
    	  
    		   
     
     
 
  	 
    toStream__ mMK4AuMzUThR8l14ylfTj 	map_matches,_11093822381060 mAE2dnbfAdl1cZeEPxwYj 	 
    	   miwFxrJ9Hgvh9BU3yQ7JC 	 
    	 
    toStream__kv mxtgNrR0I9XNlGwtKgbs_ 	 
    	  
    		   
     
     
 
 optimPoses,_11093822381060 mHNlNa52Z2PZe2OXhBJ1y 	 
    	  
    		   
     
      mDk2ateRzESLAdShOHBxz 	 
    	  
    
  mgLz7ptMkDAS2H3myapb6 	 
    	  
    		 
 mH2N9lzQxW3EdATddICwN 	 
    	  
    		   
     
     
 
 LoopDetector mmZaEtCYOeOREjAVTD1hN 	 
    	  
    		  LoopClosureInfo mLo6MBHX8K7VxYSLeLVQr 	fromStream mG7xJth7i0BO6oUVbJqb5 	 
    	  
    		   
     
     
istream &_11093822381060 mHNlNa52Z2PZe2OXhBJ1y 	 
    	  
    		   
     mZrh25nTGSOmEcIn3KqdO 	 

    _11093822381060.read mBbja92jiZJNsMWkjTEA8 	 
    	  
    		   
 mMK4AuMzUThR8l14ylfTj 	 
char* mX0qcbsHjAoNnQaVuWy5P 	 
   &curRefFrame,sizeof mNh3cvDlcXytdtCUaJAZV 	 
    	  
    		   
curRefFrame mr9ts4Np8ncg1gJpHz_ti 	 
    	  
  mNdeptenmMoGfTyM3ceNa 	 m_xQN0oi5gVO2R_VQWSRC 	 
    	  
    		   
     

    _11093822381060.read mMK4AuMzUThR8l14ylfTj 	 
    	  
    	 ma04H4jmAgnDee_1IqvN5 	 
    	  
    		   
     char* mhRX2T9fqiwg5h4fn7CqV 	 
 &matchingFrameIdx,sizeof ma04H4jmAgnDee_1IqvN5 	 
    	  
    		   
     
  matchingFrameIdx mAE2dnbfAdl1cZeEPxwYj 	 
    	  
    		 mX0qcbsHjAoNnQaVuWy5P 	 
    	  mIXcs_xq6d1ZfHrJUZhbb 	
    fromStream__ mGKRS1wgB2KUw_qlPr3ZO 	 
    	  
    		   
    expectedPos,_11093822381060 mPebCiVySBurUpF5aZ3N1 	 
  mAzTDU0OC6jPLmhZXxf5s 	 
    	  
 
    fromStream__ mBbja92jiZJNsMWkjTEA8 	 
    	  
    		   
     
     
 
 map_matches,_11093822381060 mhRX2T9fqiwg5h4fn7CqV 	 mIXcs_xq6d1ZfHrJUZhbb 	 
    	  
    		   
     
  
    fromStream__kv mMK4AuMzUThR8l14ylfTj 	 
    	  
    		  optimPoses,_11093822381060 mhRX2T9fqiwg5h4fn7CqV 	 
    	  
    		   
     
     
 
  mDk2ateRzESLAdShOHBxz 	 
    	  
 
 msP_HdnLnvyq_xHfK3eKV 	 
    	  
uint64_t LoopDetector mMeMaBX7AlQnU2AarSG35 	 
LoopClosureInfo ma7m2a2XM5VioswynpTaQ 	getSignature mXY8_DJIEHsviPwBYb1GX 	 
    	  
    		   
     
     
 
  	 mCfeXpurQ7eEHdVTm6sz3 	 
    	  
    		   
   
    Hash _11093822380353 mIXcs_xq6d1ZfHrJUZhbb 	 
    	  
    		   
     
     
    _11093822380353 meoYzDxIkDch5CfhrelFN 	 
    	  
    		   
     
     
 
 curRefFrame m_xQN0oi5gVO2R_VQWSRC 	 
   
    _11093822380353 meJZeab7EsFT1NcRMOGoU 	matchingFrameIdx mjt3yMUTnxg8otzv2CROn 	 
    	  
    		   
     
     
 

    _11093822380353 mb55UEuW0P4iw4YI1VeI6 	 
    	  
   expectedPos mIXcs_xq6d1ZfHrJUZhbb 	 
   
     mPXYsSUJKTlN_9TDRANsC 	 
   const  muxw1Wp5TS2uK6BAu72zb 	 
    	  
    		   
     
   &_2654435870:map_matches mzKwOblJypS2Tynlc0h7K 	 
    	  
    		 mCfeXpurQ7eEHdVTm6sz3 	 
    	  
    		   
    
        _11093822380353 mFaQvzKeH3anCZ2imzrxn 	_2654435870.distance mDk2ateRzESLAdShOHBxz 	 
    	  
    		   
     
    
        _11093822380353 mp9roaDCp_f2EJMQKe1lG 	 
    	  
    		   
 _2654435870.imgIdx mIXcs_xq6d1ZfHrJUZhbb 	 
    	  
    		   
     
        _11093822380353 mFaQvzKeH3anCZ2imzrxn 	 
  _2654435870.trainIdx mjt3yMUTnxg8otzv2CROn 	 
    	
        _11093822380353 mjOMNug9ZinamtS8o1oXa 	 
    _2654435870.queryIdx mnCUvl_sQ3iz1ma7ds7a2 	 
    	  
   
     mAutaeq8TRDcw1y62NeWa 	 
    	  
    		   
   
     mEUHDRL7W9f_jebJ8sIMo 	 
    	  
    		   
     
     const  meR7LfG1KM0Dt1R62jea_ 	 
    	  
    		   
     
     &_2654435870:optimPoses mzKwOblJypS2Tynlc0h7K 	 
  mZrh25nTGSOmEcIn3KqdO 	 
    	  
    		   
_11093822380353 mzzTKgJyRZJmq0JOwjKly 	 
    	  
    		   
     
     
 _2654435870.first mnCUvl_sQ3iz1ma7ds7a2 	 
    	 _11093822380353 mAKe6kzlkj0tvEgGwlqNy 	 
    	  
    		   
     
     _2654435870.second maI7EcdmICOL6DnWZAk5L 	 mB58ylLLhUkc44hEn298e 	 
    	  
    	
     mM1dZCPHOOM7Mpa0yRhsf 	 
    	  
    		   
     
     
 
_11093822380353 miwFxrJ9Hgvh9BU3yQ7JC 	 
    	  
    		   
 
 mGwH5P2DG1FxTU6MU_6QT 	 
    	  
    		   
     
     
 
  
 mFkTh5yfCM8IQj3fEOy7O 	 
    	  
    		   
     
     


#ifdef _578393634660532955
#undef  mzSiynXx2PZxvjvWsg2MB 
#undef  mr9ts4Np8ncg1gJpHz_ti 
#undef  mH2N9lzQxW3EdATddICwN 
#undef  mBUp9Cccbc6XpnbwQe9oz 
#undef  mE72_0qT3_J58YcRSfkrB 
#undef  mucgaM3RAfzL8s97GBfLA 
#undef  mlezrPhKNaT2V_sgMv1ii 
#undef  my2jE7xzzofXXEPRRDw7E 
#undef  mDTXM3pph0LlaM3g6Fx8x 
#undef  mwjRUl4P2IyFeOi8otPFv 
#undef  mSp75bzLNt2iyu0vDMy1V 
#undef  mRIStuOYsNFaBtehHBccI 
#undef  mpCh9qpTM9rRfkY8x47Q4 
#undef  mUe9WFcPV6iTML5qSXbKv 
#undef  mPTenLEomfo7O0OOdmnR8 
#undef  mrP3xiZVHvRF94F1LbZry 
#undef  mLYLlm8uWIZYpeuX5ijTD 
#undef miuiWe2QUCTO_HaMyQfm0j4u4AGrJJj
#undef  mcDUEU4wVGeQ4mJ7Nv2wv 
#undef  mfsPHz1xLlqSg8i21kDMX 
#undef  mjOCUIMglMJBpe514Gl6O 
#undef  msEmz2sBrLxKt5K4PbJiT 
#undef  myUA4h2JED8WjDpgPjpuF 
#undef mPEvPU9IWKUjWKAQEWgJbjRKxCTNtAE
#undef  mUtmRSCUunwTFWFnSPSe_ 
#undef  mSbQGkGX65LSisAvhFR7i 
#undef mDVjkgsg9y03MdQBIM8NzQQ9ygy7EfG
#undef  mpiOmG3B7o8txhSe0vp7N 
#undef  mIT_uAwVEEpa36d8llBKi 
#undef  mom6B3Vqb9NFgIGSyJBW_ 
#undef  mMjkgrlSYkhDkq9pcWgtV 
#undef  mELk3Fz6ORZGKqecj1AEr 
#undef  mwFTsvHSM8rEzszdFHGbt 
#undef  miYVwFr25sAZ_oH1IVlNr 
#undef  mpqJRLW3w7D0iSr6wl2cp 
#undef  mv_o4OxZfw8Y95gBrbb1T 
#undef  mHAT8ICuUYb27C9RxwTt_ 
#undef  mnlZXMVwQPNJ6R49HEuV6 
#undef  muSWWBwCY5nzwDkMI6YMm 
#undef  mB58ylLLhUkc44hEn298e 
#undef  malbKxTC8OCKcftMSglQs 
#undef  mOSHwhOegVW62qAhdFDWd 
#undef  mR4zML6TCFdBgYrD9ZssP 
#undef  me0pAP1sbuaF8iTF5_7tH 
#undef  mHCj6MRgYNeaPqcfnaTtQ 
#undef  mLiyObHjStdTiuh0bdZKQ 
#undef  mseXqjyDTS0mTFHQmOQrK 
#undef  mvkwhmhEbUJQ6ub21N6lI 
#undef  mwC_DGcKkrPNhMHUMy8hB 
#undef meW__RPg8kOO_B1F9iOi3ik9IKSvgOl
#undef  mTegIuc1izyczFPQQLWHJ 
#undef  mNDn7KoqzOqsI9ox7TxtZ 
#undef  mvyZdiubGOTYwem4Flrti 
#undef  miwPGgwlH9l4nw5pXVkcH 
#undef mQ0R0KFSgOvZzp4r9Wq_UlqEApPlqqN
#undef  meVhva2888lfPoP60YhOi 
#undef  mgegCV8i4RdQqulhCBPGP 
#undef  mp4Uths1yC7FOuiDVtJqI 
#undef  mtJaF6Gwi3nOAwFjaJxoQ 
#undef  mRSWlqMbz5rM2_QoI9FsN 
#undef  m_xQN0oi5gVO2R_VQWSRC 
#undef mEyrZ4wO4jvy4p9D4I_Af3ryAMnGBtM
#undef  mbq4amVyoP9naJ4jVAT7s 
#undef  mjohCRIUcEsgcmtOsb9pL 
#undef  mleQCJPXmQUdsKd0br_bj 
#undef  moDX0LdsOU3jTZdCvrAMj 
#undef  mqHt3lrbBfFmz9VkYVdE1 
#undef mqq11ZJvpn9BSBmitVsmksM9Bt32Vr2
#undef  mYfMAy2mq0iYJ9_M3gW7z 
#undef  mTLlpkw9u7nbmyFhZjiXY 
#undef  mmZaEtCYOeOREjAVTD1hN 
#undef  mrEYNwjXK_xAwDc6dEvdA 
#undef  mavfJmcPsE9DmpvlMyYVt 
#undef  mlkzeDoVKbQxndVZ3kCKx 
#undef  mjOMNug9ZinamtS8o1oXa 
#undef  mPMJ2gcnRXMMs5XUFDOjt 
#undef  mbemPO4oYKTfGGhTtbwC5 
#undef  mFxGZTeawKDQkMqstz6nq 
#undef  mJpJVLYQ2IKWnPHsgcyOd 
#undef  muAMC_nJbHqowhgS2a4qT 
#undef  muu_ZbKFMpC65Gx4SNjTp 
#undef  mzKwOblJypS2Tynlc0h7K 
#undef  mbeh4X8xLYMKz2OQ9WGzY 
#undef  mfg7KsFK3P04G9AjMEPDa 
#undef  mwyA2qwAlcSqcvLxWVmbv 
#undef  mxzYxgdDbmA1m5w3Hij7d 
#undef  maH3zAABmuZH54BiPAvA0 
#undef  mMHHGP5HEQANIPcW9y0WD 
#undef  msvcz3Rlvaprw1gtqXu9D 
#undef  mZ5nSIhcChEo1XiD8ih6z 
#undef  mTRlhMGiydmgRcyWRGLuv 
#undef  mOQxMcSDuGWYllyxX9gwr 
#undef  mvmiUlfuSXZ32v5hQjCFw 
#undef  mkMabtkManLa0QZcvlExG 
#undef  mFkTh5yfCM8IQj3fEOy7O 
#undef mi_IKOYHYmcsB4AmpEj_S8UtO00z7ka
#undef  mlnWVuEbTm7gmmTTCmin8 
#undef  mVoYZWjcWgRgvOopQ8bVV 
#undef mKTxvsMmtam_9aQaU_sty0GaJN2w_dD
#undef  mtk2iJ0o4hJH0SUXm_IsX 
#undef  mGBEt7UWW6QOKZUrBc2iD 
#undef  mb55UEuW0P4iw4YI1VeI6 
#undef  mc3Z8H2pqxFvRhKjSV4Rj 
#undef  mXDSOQYX2Kq6Wc3r4vPNQ 
#undef  mWM7aumt8OyUuKPgurbH4 
#undef  mvevHARgRA7CvNeXBlh2_ 
#undef  mLI92jPyKnX0rVwlX0zQo 
#undef mfkCeKsZNXuKGTqVlyn4eOg0NuSW1Vp
#undef  mC2iS7wUKLq4bFZBruDv_ 
#undef  mYel2wGtdeysITGyFfQet 
#undef  mlP5lDCjzs51ba9YiGLC2 
#undef mj2S88ZKKoqttWjK7_YPUjm7m3Tifop
#undef  mlGAhEsbSz8YxV75nlhR0 
#undef  meEH15Uf7CrMnJbHt1aCM 
#undef  mgUwGnwpS9_7BPnU0v4sV 
#undef mUl1Yzlwtku6lR4FXyCk_2ImyAfBqdl
#undef  mWymVNaClEDUhz8dwO3vT 
#undef  mKew0wo0WzNC7BA3fvGFa 
#undef  mwGMXa6zg6lt9JCjO84HP 
#undef  mshzjz6V7SsA32n2zC4Hd 
#undef  mj56zJGW97uXishTMolL6 
#undef mT4q0X2y1K0Ct0G5Iu0QPyweOiuhuf3
#undef  mEe13fq410Qv50LDtDXAr 
#undef  mDPrdShbUPXKlGKD90DBg 
#undef  mtCrtFrELbV_rIn99Ta3E 
#undef  mbyJZ0Gk5WNBU6m_CYPMN 
#undef  mX7c7PnpK1mvKbMhF98gK 
#undef  muvmgqxTHYmzPLTXJK6cc 
#undef  mOMjLl_toMbvFZr90mg_G 
#undef  mR6cHHVNJUxSb1XUZZAlr 
#undef  mPRaITo21QKmYA0ca83Hb 
#undef  mKQs5UoWc8hQnZyjRiO9c 
#undef  mBluCPnd_hF_Avwmx4t5o 
#undef  mMK4AuMzUThR8l14ylfTj 
#undef mCw_XEiNqvIVFdaAAAmDmY5aIAIz87b
#undef  mGwH5P2DG1FxTU6MU_6QT 
#undef  mXXP1Lg9cYXIDuNf8LWMP 
#undef  mkT7Njzu1Dxai8yGE77eS 
#undef  mozCu26YRqIMahULlR6_m 
#undef  mdfjJv_IhbCx1MAtbtuEo 
#undef  mX0qcbsHjAoNnQaVuWy5P 
#undef  mK1iaZDkLbEYfui77t4tA 
#undef  mLIUiG385k6dnKLvgK1_d 
#undef  mbsNsaQEQfktP2l3TYMiX 
#undef  mrXUHPs1zJxVq3YneHkiB 
#undef  mtUrDV5jqTezfsdfRbyeG 
#undef mThKSdvkwKhcQVa_yJVpj4t2azbmNv8
#undef  miN0LdqEh7vhTpYDViauQ 
#undef mwWNM1XTZlW0uNgE9OkqrBQAjRWbCZF
#undef  mT2h5j0cQ6U2NSujo5eIh 
#undef  mumbKqnnC1o1UEMIaFlPi 
#undef  mo5dcSKT4Cc4mU_ebEvOi 
#undef  mGoQ6KUq1z3wzWEI1UfPJ 
#undef  mMeUgy7sozQQHhb5leckG 
#undef  mXJ0RFP3PE2EK8TcIUcBV 
#undef mC1sR4yE7lGpcicENZ1eQHxW5loBK5t
#undef  mQUrH4PQ9h20xuwoz_L6c 
#undef  mU7YWgrM69Z0WHvDiKcBl 
#undef  mWbrMd94LFi73iUt8EciN 
#undef  mitrW4DwFEoT2QEZhsLPl 
#undef  mclNJ5OLWz6z1zey36NQE 
#undef mSH2L4nMcE6ZcZuW2rVMep4xJct_wkI
#undef  maI7EcdmICOL6DnWZAk5L 
#undef  mGowtYuqPJ4SrDfvtJDXC 
#undef  mIiKCkgnHVlbJOLLFusiE 
#undef  mfdS85qxr91hdWablaTu0 
#undef  my3fjVNjSMvS3DYXWlgBi 
#undef  mLsoXYPkCSuROxsEvwggD 
#undef  mEzBgLeN42Dz1Gk4gHcly 
#undef  mH1mh8oPWROQChiHVqjO6 
#undef  m_COm9PW5xRxOJr8VfEaP 
#undef mAXGapViDaOhKtx_ZoW4pLEgPN0ivGn
#undef mM9oYh6UIwrvaChJmb8olgAjqY4l_87
#undef  mTtNKLQvQFMnPV1Vpr5px 
#undef  mVek5Fb5rIW2fn6jjRDXR 
#undef  mSRKh8csjDA0YMKAORC_t 
#undef  mIfJTCDTzNTDbSwjZ_4ng 
#undef  mQo9UXWccm1F_cd3TpV0j 
#undef  mXw6xyXxnNHe0fvsqhNpF 
#undef  mQSVhh6pvdAgzBoKp0Hsc 
#undef  mMcVkDr5WQSzvkCL3IsEy 
#undef  mk8FTPHw5fDzdxUwpfQLq 
#undef  mJKjklSGsDhfusczCEaK8 
#undef  meR7LfG1KM0Dt1R62jea_ 
#undef  mFWDl90xCXZyxIKMTg7Fn 
#undef  mvdaYbo4z8SlgMv3lXon4 
#undef  mmlXrT1_x9sp__LHPqyaN 
#undef  mgYWCBsJ4u1ueIoshmx0n 
#undef  mIXcs_xq6d1ZfHrJUZhbb 
#undef  mtgITz6PyMDhrCAG98rA9 
#undef  myQbbKdah7pljVssTrqRR 
#undef  mHsZGrX8_xEIs103c6SF5 
#undef  mRY3xepZGYr1QUx_aQrg_ 
#undef  mb2a2UHZak59DgdjAGOrw 
#undef  mGtr6CfO48OIYqJrBxeee 
#undef  miLAEYIXn7XwmrPx2ruPJ 
#undef  mBk7Bd0TsWhEAmVzmyhBG 
#undef  mFMjTbcPGJbrRCmMFIyes 
#undef  mjtB8_PMOzVodX1Ot0qDh 
#undef  mk6jV_KMtYAq5WYW_gJAp 
#undef mBkKJgxhQ9WydGj16uFCaNwgHQhlk3A
#undef  md957A3C5s_z0Uuo52MT3 
#undef  mkPzmXldvzWD59J2Q1psL 
#undef  m_H9nBxQcIGJP5iQAG8Zz 
#undef  mgsmcpYYVkny5B9QFvcPb 
#undef  mpXW7u7viX1tBaYgN6s29 
#undef mS44uJe_7DGuvYw3TXHvHdAz2a1WoHH
#undef  mkJkNZCI4_vhjeQc322zU 
#undef mH7iGTJO8qztN9b9tFgvpxjZjB6SK7h
#undef  mg6OEEdOu_Y7s9uuC795i 
#undef  mxhZIiZ0xwZgAVSpMwPou 
#undef  mRqxEMTGcEboxFakmB4hO 
#undef  mKDTKQpoaf9CSC6GD0TC_ 
#undef  mDKpKvvhjj0VQhNfzYFrp 
#undef  mvgZM8nIZFeOdMyTrsL7T 
#undef  mpD8KaUmD2VYtEPICujkI 
#undef  mnCUvl_sQ3iz1ma7ds7a2 
#undef  mDJcXpSEqpO73VBuE47US 
#undef  mGsLD5anFDVNjEpKHmlxb 
#undef  mVXmnzdfKl6nHZ3BDaOVf 
#undef  mNLs9HPJwKA3Kn3Ers5Gg 
#undef mk_bZLoZf6wqkHnDQnL11LnCzSMVI_8
#undef mI7CIl7d0eX7213jyniID2yfpCS4KVe
#undef  mb_HLg3OkjwtqNtbStGWJ 
#undef mLMRmlDyrY0ImTOIAMXrYcyk9SQqm2i
#undef  myxvmgNFjpzRZFjvmV4Bq 
#undef  mIXBg_PxY4AVnXGwRP3wA 
#undef  mZrh25nTGSOmEcIn3KqdO 
#undef mNBM_hLd3kZ2pS6ipDSi8s93m9nX2xJ
#undef  maEzandotGshaoZi657jX 
#undef  miJar0x8Bt5Zexc5NM4un 
#undef  mcqOWvk5magfxQebwfy0j 
#undef  mnfp7KQNDo3xOgCTgfin6 
#undef mef6tPInzaplQJRKe_Z4PWskxvfcair
#undef  mDk2ateRzESLAdShOHBxz 
#undef  mkb5KBnKM290O5fQ_qJcI 
#undef  mtIrNzCG1txzxBiBNQkaT 
#undef mVzNogT0Su0_iq7CJlpD4Q7F1w515C4
#undef  mMeMaBX7AlQnU2AarSG35 
#undef  m_NKH1FvsobBlgc6p2pMt 
#undef mb3W7eWbsFFUcxnmWJWPblhf_QhQmFH
#undef  mTiGqqWhmfsNwUYFn7m9h 
#undef  mjJjIZKIN_1IdX1HUYZNy 
#undef  mIlS2rOns0c3yO0ty5GCE 
#undef  ma7m2a2XM5VioswynpTaQ 
#undef mweuoC1v3HjAZLXeB_Om6QPuEHK85DK
#undef  moj7URxzVy47aw4GbhrdI 
#undef  mxok6svN0D2CqG2kjLKqo 
#undef  moyDQG624eD1C2ghyb5IK 
#undef  mQkaowH4ODjvWPTHoy0Hp 
#undef mSCxMXKiYGEQz1qm2y6zPfXaFDuU93K
#undef  mrlxFUoQCoSz_Gap8_nfM 
#undef  mteJA8lO8Sm1A4vEX4CFp 
#undef  mviStCTUeK8UdQ7IHtz3p 
#undef  mHdUTXibfmHMOAM5bfMlv 
#undef  mMl9MDFzM1Ex8HhmWPmrT 
#undef  mq4uB7M0dNlH_bNj94X6Q 
#undef  mtNbESZnJymClvDJQgXdW 
#undef  mnmjv_OXbEjpUQeinSO_V 
#undef  mS0KK0NZmSwxSrREwLpHy 
#undef mxXsdhj66GokII_2H6KTBDPD2QXE_6Z
#undef mwAapGkppexSRP9vkb_K23qXAhqPI2p
#undef mCHewZCw28aJ9cMIObjRIAw41DxZZab
#undef  mL3U0tG5Dp2deWNpd02yL 
#undef mlPBWdqHYFOB_FbYQGhP7Rk0e2z6fes
#undef  mT_IEIb5FdtSA05vX0cO4 
#undef  mJF9k4SfdFlZnPemdLh68 
#undef  mLo6MBHX8K7VxYSLeLVQr 
#undef my8te4avvJuyXQjyXfPKRVH_xje1mPF
#undef  mEVBiArTTL7UvyYaeD5f4 
#undef  mp9roaDCp_f2EJMQKe1lG 
#undef  mTdmOLVkgJXRaD41HAEef 
#undef  msqK9XVQuLK4dYgYW0FlK 
#undef  mKlDX756ItSngbzWHtsU_ 
#undef  mW3KCWaPtIGpagaffnIWe 
#undef  mv8sKPiLnSkLmXfreZmHr 
#undef mH7w1w2ySZMkYBJaqMP2ovEhEYX_wxH
#undef  mFnA1PDH9tRsXZZ8h5BpO 
#undef  mpd1HIx9sCCTDYgPChBtk 
#undef mcIhMgN0XHqi_xMrX0GOWCLUXg9TiFc
#undef  ma6dx47TrhMFh8SDrh4nu 
#undef  mHlm8YyfkfCn4t4ltAh11 
#undef  mrH0Wzi6kIyFP9AxnZQf8 
#undef  mVgfptsNFL1_yPb4iqzR0 
#undef  m_Pi1brxORGc2CnlD7qpX 
#undef  mAzTDU0OC6jPLmhZXxf5s 
#undef  mod8ttCC8Q4p6YfKFiWT5 
#undef mnpMaqCyp4XCCsSAlOB2_ydbyBMjsiG
#undef mwhaJh94LlUr4p9Wb3vTnyvsUrvBINH
#undef  mYgbnozIfybHTalcFXixb 
#undef  mAutaeq8TRDcw1y62NeWa 
#undef mrWeaC6UimHtpnNl57CaHKqy6d9La3y
#undef  mMnQcRje5274EAZHUxVoc 
#undef  mmh1XqjaH40_MvCS0rwly 
#undef mDNvc93KIlp9Gg_VkvdVOpN65dHIO3o
#undef mkssef5hYX2WKfrWRobDOfEBzuFJvmY
#undef  mcmpZ8fI0jyLsOaaR1RaT 
#undef  mL3N7WM0bEX36ojLaxgeQ 
#undef mziJxkvA7JqdhvoW99riSf0vziTptFV
#undef  mHGVaCQHg7jsPiWyzNB97 
#undef mom39dyaYiRgmSeGlO_KTpUtIDe6ZvA
#undef mCctZAUAz1CnEFfwH13iEhbHTjETtyJ
#undef  msRuaHhKsJSulogowVwhv 
#undef  mnl4KzldZxMF45gCu8uze 
#undef  mHNlNa52Z2PZe2OXhBJ1y 
#undef  m_5grhY8wx8_nGTeN7t1i 
#undef  mxQuyf7x6IvZhVeu9AR1f 
#undef  mceZP2LoTA8KIHZFtWHF3 
#undef  mmuz72vAALDgorxMMiAKT 
#undef  mJTskzPUgZAg4iElc2pam 
#undef  mqN8l6uiypVDb3LT0dRrg 
#undef  mJeIx3Y8tDXFZjMJ01Sck 
#undef  mMeCjBW1I6eJ4PButyoYE 
#undef  mxlGx4pskRJJ_igitkRIg 
#undef  mo_XQ_uLPIqvdoqw9nqzo 
#undef mDm655ufN9ibp1I5OuQk8xvEI98wd9I
#undef  mPXYsSUJKTlN_9TDRANsC 
#undef mMfcgvUG4Wha7CpioFnzWfB9eMqrnnZ
#undef mgAWDvYvETqZM6xJmDtslSVyrwEa8Wr
#undef  mVMm88J85jxFCPPHL3WCw 
#undef mKSsfPOAwS0oHJB7RWkXXoHAJKTuMbl
#undef  mfD9pTiMELJRARGDAwmaJ 
#undef  mNQ974GqJvcq_F_uk7ugH 
#undef  mZxroNgqv4GCicNhd9Vds 
#undef  mLwQUQjnNvq3kkHDd6FYN 
#undef muyG5f5w_NMm95o49EHdJzzEXkVlD2I
#undef  mz46xR56kU2EiIWM9qESc 
#undef  mYACXtHez1B_Vd8MEB6LY 
#undef  mEGcwKaVUJlcdhmVW1mxE 
#undef  mer2o0AHZEWAzGh8Htw89 
#undef  mUgVkHgFvWIrVL6b4ukmf 
#undef  mnwIn8oqL3dWmkG84mlxh 
#undef mJZxL6SER1MSRgOBDmw8mgHgCxxL7Ct
#undef  mwqgFhcLxpYIJk5YDoauZ 
#undef  mzPpEm7JKS5kSuqDIUCtm 
#undef  msmGxdvZbJBa7VN3pz1ky 
#undef  mPuXuoDhC1LVJe64Nasqa 
#undef  mRJ5eldFAeP9f1ZDhHSxg 
#undef mvyxetbccbag6k8EZaMkeFEknrCnM6w
#undef  mAE2dnbfAdl1cZeEPxwYj 
#undef  mKreihTCvnL_R53gf9Vxe 
#undef  m_ZCKMjj6YC0lQM6_asO0 
#undef  meThfcmRLi6HYMkRGUo4z 
#undef  meI4cw0JpYCGVAglkSWIH 
#undef  meJZeab7EsFT1NcRMOGoU 
#undef  mWKCmIo_Mqivkm1rU7mXa 
#undef  mFofJSJsXWoM_nx2_4wop 
#undef  mn6xKsaeXhmFBxqD8i06u 
#undef  mkP8c6gbRiDFDQ2eDmK_e 
#undef mMcDuZwsgLKGeG0vYjKCVGC5iAmPxmB
#undef  moOUFvm6lF5Wdzq6D1CPL 
#undef meRO_Nu5PxXmCSp2c7X0GsXcJbPFJb4
#undef  mpBZR3O3YZkWmbsL1Fdo7 
#undef  mMefATIAXEUS4JITjX6RY 
#undef  mfeHr6Ii13gPmR0zit1Zk 
#undef  mFkag6IVb8AANfyTptOyT 
#undef  mg7dP06QlI8YJQ_XgHFb6 
#undef  mxd70N6Tz0rsvAkV_XQqg 
#undef  m_cu7jxTLR1kw8rSYbP09 
#undef  muxJkOmO8cYLJEvc1Gmh9 
#undef  memQ0RtbCNMcXXIi3wQCX 
#undef  moKYfoSiJpyMNbsuxt51C 
#undef mhm3Z5p6mRJslB45Zn8fPY09GbsJrz3
#undef  mVshQzJetvpwfbmhSbkWn 
#undef  myESnPNfYiMlAvjIteqZ9 
#undef  mNSyUlXDLhTAe_s5ugQlj 
#undef  mRS_PgiJe6t1Qfe_huC7W 
#undef  mHDr8_RBn1xfwTGrIxap4 
#undef  mm7gqUw8SZ0msHEHXGbxG 
#undef mTuX2EEBtUhljIsl6dRE3XBb4RBr5xR
#undef  mblTBQ3t8ZR1zCshRDiAb 
#undef  mDnhhwTjyavcESxeRXnT1 
#undef  mntPv5Gc82W0rcrgjblcr 
#undef  mMcEjJn_CVZWOBdecA15d 
#undef  mY_j5zLkYe8Iyu9lxzrRE 
#undef  mG7xJth7i0BO6oUVbJqb5 
#undef  mkCOSroCghQ4Co_NxLGx4 
#undef  mtSiJVegjoOM758Mhrcu8 
#undef  mJz8GP76hkQ7uVQdfY6Ey 
#undef  mh18_81snu6knDzdm0oWQ 
#undef  mutl7ld5XBILgjvm9Bxtg 
#undef  mRS6T4hc4nDO0bHPFBphO 
#undef  mr6L7UbLHO8A3oGvs3obc 
#undef  mvo3qI5GE75nPppmIO8Hg 
#undef  msl_16xNLsSeWnBu2zOUF 
#undef  myByBcZVI3hjwqHKXt_nB 
#undef  mJ4XAuu6HjzWuh0kCiAtP 
#undef  mLbpPG2pOlCQ9nldezJS0 
#undef  mHnv_pYfB9DzNvnNqr7jH 
#undef  mEWO0d3v4i73ZpDbN8GJ7 
#undef  mdI1tJL_qROrvf4DGb9dk 
#undef  mXY8_DJIEHsviPwBYb1GX 
#undef  me4ftpf9gBNIZytyQMpAw 
#undef  mpkNuJ6Ul1WgA29YNNZdX 
#undef mbJRNjmLpd7eZ1f0g7UWk2aFA0x2Exq
#undef  msLYNLpufusltTHa886Ly 
#undef  mRzXLH7b1XJqbs4u1BT3M 
#undef  mMEupUpeFmt2YmeTtEuMo 
#undef  mkk2EDFzw287KbDNqju5h 
#undef  mpBD1cOJmxGM75fM7yaUx 
#undef  ma04H4jmAgnDee_1IqvN5 
#undef  mX83idyVnyfAv9BtgpQoe 
#undef  mEddRx3m5XJtoYPJAivGx 
#undef  mj1lf05_AG7Xg1sbt5xfx 
#undef mSBed7ylIH5VVFFve0hlq6lUnO7yqZH
#undef  mgy8Rtu_JX8RXkgpsLyfR 
#undef  mBZheJ9noVNJCjZgnaVFz 
#undef  mxGG0bWtTF7RK6VjYGtkb 
#undef  mEUHDRL7W9f_jebJ8sIMo 
#undef  mx9gkrooOtCYAmV83iNd0 
#undef  meoYzDxIkDch5CfhrelFN 
#undef  mFoNkWHTxY94crEZ2nRP2 
#undef mG4hqqGzjz54qIMtdFSKxVS7KxZ08nE
#undef  mYIrhxIEjkEfaBNG7QAhx 
#undef  mxGZrzOxbfcCIUqFb0phj 
#undef mSbS9ma1rIBdWGba_el0sLUXXQRYKk6
#undef mjhrQMoSrfNgILhbOqX6cU89iq2CFo7
#undef  mEPF7k9hvBnZlCGOGW3Oi 
#undef  mqIfjicfHLyeUpUXCJg0x 
#undef  mFsKBKBnGOuBPJ72I8Y7O 
#undef  mr5PE3A1WmSQZvRF5LGFr 
#undef  mphngI0yZbp9QSoYGvhku 
#undef  mghwyijNY8yWZiPQiY8lR 
#undef mfx5_V25zAwU2SxqXcuTmWKTHYcvOfK
#undef  mkSgJ95VfXqdPSL6wX_hr 
#undef  mGlxQsT473Uph2ITWO9Tb 
#undef  mNPVh4xG2ZV_lQBDiww0D 
#undef  mFxS2nyYVbopa4b28eS9d 
#undef  mE0khZyT7q0jd4sHUue5m 
#undef  mM1dZCPHOOM7Mpa0yRhsf 
#undef mqtwUgN8zcwcW4ZoJdFPzDkMvaPms7N
#undef myuwNP_dt_tPqvB_LneJOrB1rgaY06e
#undef  mQWQ6DIh9Q3hZYqslkNHL 
#undef  mqnPKqgT4K6D_00i2OqDX 
#undef  mpT1c3t4Kv9sHJwkPrqbY 
#undef mHOVap9pA0mg8yz9s8NfbCXq8UTI7yR
#undef  mGKRS1wgB2KUw_qlPr3ZO 
#undef  myBpNfLmqnOaCQOI_afE9 
#undef  mxov9_llanFoDCI7DDOb9 
#undef mRewH0URVim6e9rnej8nAI52pAnp1OX
#undef  mZRgmNM5NKjqzBrE78eoJ 
#undef  mHN8Y7s1eAHCzm5tx75ek 
#undef  miwFxrJ9Hgvh9BU3yQ7JC 
#undef  mCu_GwIf454BpiL_NvROV 
#undef  msX2aFZOZI29G1zOojPg2 
#undef mvpW_HSGvhlw2kZbrXE7s6Kxd7Rb_yU
#undef  mukzJYtnTaiirELb4VdVe 
#undef  mF7LgOkUMKsXPdxZX8oPW 
#undef  mxtgNrR0I9XNlGwtKgbs_ 
#undef mWGkINdDKMTEroZ1PvaDozMsBU1t3TK
#undef mz9yiveYd6FaZnm5Wb0Bp9F8s8tX2RT
#undef  mNSWTVAl5whcV3gAmhBy6 
#undef  mRv5T_gf5m3FhmaOCCx2a 
#undef  mZfEyvR525XJFyILSK8SY 
#undef  m_UdV0aNh6DsLGA7n116C 
#undef  mBbG2wcl7xDs3eu2p2MAN 
#undef  mahqUizQ5natga48g2TNS 
#undef  mkVQaE0u9nKyLwk2chMdY 
#undef mImA52bPCu6sxPWX8YXt6QUXN3x_cdO
#undef  mgLz7ptMkDAS2H3myapb6 
#undef  mEvXxk02VYeWAqCniTpNU 
#undef  mN4iA3tOcEXBIEi2Est1o 
#undef  mpteEKFe58LeJX6VYQIlT 
#undef  mY37QtETFgVHQSfnhgbnq 
#undef  mJnz6Z6IU__SqqeL_XamD 
#undef mFR4LQmlj12t2vhTanNYXBWF0yRpjjE
#undef  mS619Af_XaGLce9WysiWq 
#undef mbnkAeeeM6aGh981geokbJqt9LcAPxR
#undef  mnWvVztp8OoELpltLJrbw 
#undef  mNdeptenmMoGfTyM3ceNa 
#undef  mnEimIOcHobXmIr5dsOxG 
#undef  mI1DvqyXO1beDtF28vNn9 
#undef  mdBgkjlCrOK7SJ1DeecqB 
#undef  mMs8aQibfFI0T2yUvALE7 
#undef  mWyGglK0azQrxAO1GWKNx 
#undef  mWr5JCX_KlnfJtG__u8P4 
#undef  mjq2MKVcgNXjm3pyZX_BX 
#undef  mH6oD2gHpFuxkgAiURh1N 
#undef  mO9RM2IswQ6sq3IibCf3B 
#undef  mKhtJF1SMNRrC0r7E_ory 
#undef  mbehbWcSdcfjeiuGGzodw 
#undef  mApX3lbSCsjeDEA5vseuG 
#undef  mWgIJL3srKrbz3hM08KPw 
#undef  mgdeaUrW6TAPG0iBLVBsL 
#undef  mS6s5A6y18klHp1JxGUvl 
#undef mK9ituvTX2tyOj7p83KHusfNh9ys6wd
#undef  mFaQvzKeH3anCZ2imzrxn 
#undef  miYNzGRvfdQFoOiLnJsV_ 
#undef  mg9Pu5xP58xsbu9_aD33j 
#undef  mIFmUzKqcNcUQfZkHKb5z 
#undef  mGnBNhBZBGxmhG0sMjYTx 
#undef  m_eDFTol7iECy2PwxhVjT 
#undef  mE53dmRohbnayBKuc2SQz 
#undef  mKxlUGyTdAGvpRbpDVBhX 
#undef  moZ5z7RMh5svTAFgIVj7s 
#undef  mq0C2_E9LfMr8Jne8iFeo 
#undef  mnRSJ_zuZE0cLW1tV_mBk 
#undef  md81YsOoHcOhvjyxGmHUV 
#undef  mAKe6kzlkj0tvEgGwlqNy 
#undef monc8OwrXOcxZclvSWbnaRJM8FZkPFS
#undef mqhu4L2N0THCi5Xo7BV1uF0SQ20WVe_
#undef mHB5CrSERJM5RYlTfjbvaEIOdVOgZZY
#undef  mC2lhXvfWRuglkKBCfb9X 
#undef  mzEU6xhp8YD8gzcGq2PkO 
#undef  mDn1a2NcZZYJYeNJfDpsX 
#undef  meqbPQGFkhzHt2NYYZZF6 
#undef  mfv1qYALVnt3DXLOds3Bi 
#undef  mHO5Rw998U6ilAyGfLy_4 
#undef  mZj0kFh0Zs1mlalc7MnqL 
#undef  mlMkPHZ20XsXKaoQAL8Dd 
#undef  m_IQrruqwY5azYUupdl_q 
#undef  mRH4mjD7ZPB_82GeftQaw 
#undef mk1f3GSDOdFyF3_h5XeyF8frnKG4P2I
#undef  mNdkbuvTdgnEQbBNFDonp 
#undef  mHmDh070oPzrtyO3FmYbJ 
#undef  mE4VCsyaIdbapzX8omtA3 
#undef mr62o53STfaS5wu6hGYrJihpP2cOzAE
#undef  mBbja92jiZJNsMWkjTEA8 
#undef mxXmuWIKxD2fpuFVtp1wFWndO0f6dNQ
#undef mUPaGo5Qs5IVTgCDG75czJ743I0U5m0
#undef  muo8X5gogc2Jahj1HVI6_ 
#undef  m_bi13HbE0S_4XGXKqSIE 
#undef mEOuOfRNU9I8eLLeaeIO1qbehOH6CXR
#undef  moDMpeo0YvFiSTf0MK997 
#undef  muxw1Wp5TS2uK6BAu72zb 
#undef  maz6hZ1Qmyhz47_btGDO1 
#undef  mKQOnYfWts1KQ_T5CI8Kh 
#undef  maltIVcenw2BRb3v6LFY7 
#undef  mpmuqOtjD06SoG7mrFmwj 
#undef  mD4x_G9erH9Q4qHm0SduP 
#undef  mh_cQtQ6GFMj5bJjKilUx 
#undef mLRGOXYvWTWiIFWE3NNnE12vGYCfar9
#undef meDbU8p4D3uuL6eNn3lAiea4Z2cjR5k
#undef  mHaVECjzYhddJwKGaj2Bi 
#undef mP0U8S7OcYPwhcB5_yAAxkUC_8D_WnF
#undef  mMvHuVfAmggE9fPRi_y_A 
#undef  mc1ZVDw0Qh0A2juXO2Sgd 
#undef  mhGZRchPABKAMUix1mQbb 
#undef mOqstFhpTWW4sgIV7EuIMIXdbHu7rEQ
#undef  mPRx_iaJeYMnTt6w5QTGH 
#undef  meNaaQSUqmbpWcYodKuLc 
#undef  mIa2ZevMJuycWeESu1VOF 
#undef  mifKpbQGYJq6YtNU5eAnF 
#undef  mzvLyscj75EYn8D1KNApR 
#undef  mFCynF0j6n8BIDe3rmf0d 
#undef  mgNPYjP3KCFUi4y3DSLE2 
#undef mLIv3wMX0ugyPYudwj9QNmxbnaHYXFw
#undef  msTooE_u4pSsScqgxdraf 
#undef  mdF_L5cwsvlLx41tqcUAg 
#undef  mFq5JV5rjvg_DSDmU7WLa 
#undef  mNh3cvDlcXytdtCUaJAZV 
#undef  mrFiCxDdeDz0ePSdLXQ5g 
#undef  mpi_UySMcZ9vWbVaU06gE 
#undef mUrmuCo0_crBvCrM7SJ81AdD5dqM0LE
#undef  mgo9N1DN77frgnCE88vSq 
#undef  mbHU8OACa_bY7FdEZZldx 
#undef  mhRX2T9fqiwg5h4fn7CqV 
#undef  mFlDAyw4uvIC_FhJUUdm_ 
#undef  mefQsImNhr4we_kJ9o9NM 
#undef  mbPdyGWxNHmH6SUUDyPSL 
#undef  mIrUTNU7hevnOWM0mRpRZ 
#undef  mAWzvNghKfSurKk32NNTp 
#undef  msvr0sqM1zSnK_LAOVElz 
#undef  mL__Y7LUAINCvqiZ4U7e7 
#undef  mI2D5FRQG5_p4fTLDCx7a 
#undef  mSHbL3YJPgxvnZ9DktxOb 
#undef  mtoQxpZbGiDPancUwnB_A 
#undef  mhC4_l7nCVouRo9qpjcc9 
#undef  mcCgfXtpeFMVmU321ytoR 
#undef mhSytPriiATSB7jivX9fjHz4sb8Sm2l
#undef  mPGixaAQBxQm2MqBHJbCm 
#undef  mGwwW7E_L5mU4H4fm45hZ 
#undef  mspUrihBhhhtw4FBiaBvy 
#undef  muqHrbu8LdIKh7kXJmf2f 
#undef  mPTACoJ22mdhGi34ZD57Q 
#undef  mdbzbaVIzDwW_qjPbKNIb 
#undef  mdw07t2uKfTMA6EbOII2V 
#undef  mNdmnzo2dd9zvQ32tUvR7 
#undef  maEyj783NEiTRed1C9KGp 
#undef  mLdm54bxRXOj4bdHZlcBH 
#undef  mjt3yMUTnxg8otzv2CROn 
#undef  mq9TGFiG4XCTdT_MLTfal 
#undef  mm7bxipVQk4fDaT9GiMDX 
#undef mdB5aNV1yVQddzmEwTYP1sbRtvK29cM
#undef  mr7KX8b0uxsrAcULCyMEn 
#undef  mIQKfSmCqVkhg1PfyjtXu 
#undef  mAh5iAbiyYyYG9i7fwReB 
#undef mxCV7xdxb1H5XqVIsvKdQlZKUOyySdb
#undef  mCfeXpurQ7eEHdVTm6sz3 
#undef  mpjntOE66OgzIzolkUys8 
#undef  mPebCiVySBurUpF5aZ3N1 
#undef  mSSZcWQ5RsDjG7t1wOF9j 
#undef  mavdfsLWswHOoYOVEeba8 
#undef mGB657fm58Mv0Dd0ddQlloM8hFcBGoV
#undef  mzzTKgJyRZJmq0JOwjKly 
#undef  mp_1m9NAuyfAor0iA21yr 
#undef  mUjkMMWL91mmBNi5yZ9jF 
#undef  mNh2RK5UN2xJEcZGvrlzD 
#undef  mbruUZ3EVc14QgQv9nTdI 
#undef  mocyWHOESf8iaGdomea35 
#undef  mZt0tGvv46aA7kO7MVt0K 
#undef  mxAi5_aRyErTLdXOirUqg 
#undef  mRK3Zczq6vZZNqiZhRrjx 
#undef  mDCPl1UeQq5ivUZSDGahE 
#undef  mdC4lglQMYXoyAddpC2Ye 
#undef  mbB_g5XeoMdwHdkrm3Kax 
#undef  mwpV14c8y4znOXPiBlwXn 
#undef mHEApHCLXIp7C3MnaMP6lsikjxFEw4N
#undef  mLRBSCRmmYlKTFCkoU424 
#undef  miQaMVtCiq3ePSt9jREnl 
#undef  mJNG55wKWn05SRJkprUDL 
#undef  mYQegUh3q9slmeoiYoJjg 
#undef  mkTI5islZW4Y2Rnw_kyZx 
#undef miVH3GU1u4Qw42UDGTltrFrMN_k5t1Q
#undef muU2rave65cdWeLRzx2EZ0Z3PUN8wZW
#undef  mWVrlq4zlCZC6NwwzL9oI 
#undef  mxotji0UYyI9n0ZgZ0M1c 
#undef  mX4pTC7g5boUrm6KwZB37 
#undef mJGTm0nOyDH5ZQUv1o97WOrD3T66kw4
#undef  mrqyckvyukHhDYQT3Qw1p 
#undef mjWlyOBI3upVJ3j06Fr8qzkRq3X07Xf
#undef  mdwRFXWk80OvMde5i5bZV 
#undef mn5_uOHOuxU0RltcmAnoUaIrfl6PXKZ
#undef mC7gHYrkJqDFh_R9t8qUn7E3nDiP49G
#undef  mIqMYY9kdp9hza7lYNd1o 
#undef  mjTq_AFDz1rTbgrtjgFSt 
#undef  msP_HdnLnvyq_xHfK3eKV 
#undef  mUUAnnRVHtbXs8uZAZ0FH 
#undef  mliDvpzeURgCoQyTdPlth 
#undef  mmpm5cSXQp1bVoIEEK0eZ 
#endif
