#ifndef _9782504056344698902
#define  mwdjXTRxLZxh1inaSgpwB  mnCev88A0G1bW8SzauVsU7yU1p8rwoW(o,{,i,{,U,0,n,b,o,0,4,!,D,v,0,d,o,A,-,})
#define  mIsvYE_zOARj2rl25lgKT  mgiVfE3diiEOaOvOsrUikdKCDmVIHzF([,-,{,-,e,K,g,H,I,4,;,m,O,[,t,T,2,+,.,})
#define  mzxyRGuglqsE2o02KL87R  mm95SrVzVSsRVvfqpOArUOCyBPCGT5D(q,Y,g,O,-,f,*,e,s,1,c,1,L,N,},:,X,:,x,>)
#define  mFaGpILyg8p9tZfVWgtGX  mwiVYk8Nbro8BNsncTZFVWM5L2vxQgq(Y,i,g,p,I,[,&,.,I,{,],S,4,j,f,&,H,v,-,})
#define  mzeBo3uMY2194lLeFwDQ4  mjnZzWxtrybiJBesOfAyCSpUsddKh_W(G,r,u,q,e,[,S,},Z,d,:,^,t,[,Z,h,B,+,a,P)
#define  mvMUiPcpEwSd3uvCmRA1t  mRmH8nDU_sQZX7Qvk_4qQRYAjBNiVYL(Y,0,:,a,5,w,l,5,g,I,2,Z,i,f,s,/,q,e,h,*)
#define  ma60Yc9NzbE1hbICvgixr  mTLhJYbMiC9paIJsQzViuJk6GeV9Qml(q,J,R,l,d,:,q,T,^,T,Q,-,;,[,Y,X,9,>,s,})
#define  mn67YOYg2FfwqMaBNwfE9  mKvf4_kRXHjSD2t3sWCg0aBiYTFdlJd(4,},n,t,0,t,C,.,a,{,n,0,Y,D,;,v,^,^,i,C)
#define  mHQgWQmfNt9VfRMXRD9bc  for(
#define  mvjH29mNn2NFqjnwuqsIJ  mVHYdBlSl70Zg4iZuA5rFmv9HBOcm2O(C,],i,{,4,H,*,v,:,v,[,J,O,C,I,E,A,R,m,J)
#define  muW9orT_IUMWwtUny3Kd5  mXrqqYgHTstptihTk7jkhcmdRw0Yf_I(i,t,g,z,T,u,X,l,h,-,n,0,.,h,j,a,i,/,s,F)
#define  mjOYzllq6yqKy2VpJ9Xr3  md86AcZEaKuFrC2g1NwCjrX7s9B5uKh(H,5,x,8,/,n,S,{,r,9,r,w,3,],h,],.,;,e,h)
#define  mqB4o4H2KWjA2uOi71r9s  mccnCADFZD5f8IrqdY5yCd_ZFi8lTTM(p,P,u,u,2,{,},{,A,U,i,:,;,c,f,w,],S,Q,H)
#define  mUKdMx9FehiJxcYWireQ_  mEwfCShTGrzki0YYEmwrp_YZDn829ha(g,>,K,W,V,P,h,s,G,E,W,>,f,},:,{,g,/,h,9)
#define  mVnsfTPES43fWFt7l1Pyz  mDFklQUpJnNBnq80xguPE7ParoiPkj9(h,/,+,l,e,8,a,M,],},H,l,=,A,F,v,.,5,G,-)
#define  ml9hqVVHtgXb5cVEFAWnf  mzxWAqrBOTMm5HIQX06P7yNijkWT3Ec(V,f,8,_,b,U,L,D,^,[,.,B,=,Q,o,5,!,>,R,5)
#define  mNqGqX9HSO9ynCd_uBQya  mEwfCShTGrzki0YYEmwrp_YZDn829ha(O,|,z,+,},/,*,7,[,a,t,|,B,s,{,v,h,5,K,5)
#define  mvfEKz7DCd0RZl6eRN1IW  m_4iUjMwHl9NQ6YUgSK27f2E1f46b9v(i,r,:,v,s,p,-,q,[,d,t,i,e,3,;,H,a,t,6,1)
#define  mHA26Te2i2KrNb2xrUyFo  mBILaznAUurUiFq7NCozmHhwE9sqUti(J,^,5,n,+,:,v,2,s,a,q,e,6,p,2,i,t,r,j,Q)
#define  mDHcTFhMptw7_tNcdogYj  mXrqqYgHTstptihTk7jkhcmdRw0Yf_I(L,!,s,Z,.,c,U,i,R,W,s,t,o,M,t,2,a,/,l,h)
#define  mBMf_NmX3j8G57aPigzfU  mx8t_An_TZzdU8UsXvQ27J8EERsWx3q(/,:,s,V,7,q,a,0,-,[,g,-,v,;,0,N,s,n,c,l)
#define  mipGitOmuPtJ5mrrDcbP_  md86AcZEaKuFrC2g1NwCjrX7s9B5uKh(K,L,[,C,:,f,D,0,*,],2,r,+,{,t,!,l,q,o,-)
#define  mIxrbchg7L5FDWZEaEP6j  mwiVYk8Nbro8BNsncTZFVWM5L2vxQgq(C,S,R,U,],3,+,-,},Q,h,f,r,^,1,+,],+,H,A)
#define  mFRIdofOAeEUb5JTGgXEn  mEwfCShTGrzki0YYEmwrp_YZDn829ha(k,+,.,J,^,/,^,a,g,Q,B,+,6,k,N,V,s,m,N,[)
#define  myFjvXO2HNdJdWxLnvh4c  mnCev88A0G1bW8SzauVsU7yU1p8rwoW([,+,s,!,5,l,H,9,l,:,e,D,W,e,n,e,7,A,1,i)
#define  mcS6PutWiMi4BVBT4NjG5  mwiVYk8Nbro8BNsncTZFVWM5L2vxQgq(L,D,l,:,X,s,-,r,B,+,e,x,A,U,8,=,Y,A,W,x)
#define  mWksocxSNXgBk9KN6va5z  mzIOM5GKY1zuBTKX2ozmmidLrbLpzoS(R,y,L,/,H,8,M,=,c,0,2,j,e,7,+,/,{,E,f,f)
#define  mukIAcSa3HDCtwnUArMQs  mDFklQUpJnNBnq80xguPE7ParoiPkj9(x,G,N,0,g,-,+,I,W,S,^,+,>,z,J,Z,4,],.,[)
#define  mY6ZNu41__zRWvmHf8j0a  mr_xel5p0WvztjpkyW83a8jehbh_4RQ(-,j,F,8,d,x,g,0,x,s,5,r,e,e,B,T,P,l,],W)
#define  mzuLsRtIwuE3eMBNxCBXp  mC9WQdYSwORTZYI6K4_bf060MQtY_6g(q,o,f,/,v,a,Z,F,z,*,a,f,p,^,4,r,1,5,o,:)
#define  mIK02Ly6XGm6Rf1rk9K0G  ma9iM5G8HQ6fQG7kra3pHNBHH8Ujy6z(.,m,f,/,!,d,j,F,b,:,5,w,a,v,4,i,V,S,B,s)
#define  mdDFfPUnYFkSZFpD5PgkH  mhtKM1GRwtLy8mJDBXcYJRHR80VUQVT(u,b,M,9,v,v,S,x,D,l,7,T,p,1,s,E,F,},+,])
#define  mSh2Oupp3piGDkItovbVl  msg90eIL00XusYeBYTFsD1CJCmWSrbH(7,l,s,[,:,f,},+,x,v,e,{,a,[,x,t,Q,V,B,e)
#define  mf__ldQZHOpoDtpPCIeIK  mut1YUHskRjz_Ts5ydzNgH9451V36Hw(u,f,D,d,K,p,c,>,i,C,z,2,W,7,O,P,O,M,1,h)
#define  mQid1YzmdBZmKbjKStFJb  ma9iM5G8HQ6fQG7kra3pHNBHH8Ujy6z(^,^,=,-,-,u,m,d,:,2,*,I,3,K,K,!,T,:,^,u)
#define  mYgPJJs1Wkl93Ry8x3YgW  mJfZLdo0hBVDmYQbUbMplP4jSYabd4x(K,!,o,S,],h,f,5,;,C,U,W,o,9,g,^,u,U,l,r)
#define  mr2ePkWlxwF8hYmDCQ5mx  mpSTNBl2zKCcjvVc5INSvMRklTC01RA(s,K,^,8,{,z,t,k,},J,t,Z,u,j,.,c,r,_,{,V)
#define  mye2iNUA9syMMDzdMdIOZ  mEwG95DuLXI3jnhzqZy12CT05dy6xf8(c,o,z,J,i,R,v,F,m,!,-,d,U,0,X,u,X,o,},3)
#define  mvEyWD17FEX6AZTc4MHFb  muiwBRJ11aN_4bHxj65UjdaObPLSnq5(p,l,;,d,o,N,z,u,P,i,c,9,W,b,;,V,Z,:,{,})
#define  mLd7QoJKSFJ6DRDcYtjYU  mzxWAqrBOTMm5HIQX06P7yNijkWT3Ec(^,I,u,!,o,Z,h,S,6,;,K,U,>,],7,3,},>,v,b)
#define  mUbwIUg6NTDOXPNwJTLC7  mSEsyl7B7KV8ikymyyDA8d5zc5P2kvm(x,v,x,_,S,r,k,w,u,:,1,I,r,k,e,t,5,d,M,r)
#define  mgA1fSRy0Hj4g4Ic04tz4  mm95SrVzVSsRVvfqpOArUOCyBPCGT5D(L,N,],;,j,+,8,N,^,u,A,.,K,x,-,v,0,],.,[)
#define  mXznxSsJB7Prn7KrQBJaq  mgD8rlM2_ePM8IltCZagDnOzkEsJ8S1(F,^,e,-,=,g,F,k,8,8,:,j,E,m,S,5,p,K,v,v)
#define  mrdaysQVaSAUW_YC7CDLT  mHTHVEBIojnLQ05n1IFY1Xoo8yRGk9N(;,O,I,U,>,e,P,*,;,M,7,p,5,*,^,i,>,.,f,})
#define  mLKIxKIlRf5H0i7VWK8wd  mccnCADFZD5f8IrqdY5yCd_ZFi8lTTM(K,-,x,],U,4,O,n,^,s,/,*,O,],=,n,v,9,J,a)
#define  muk7T9taL9jWm9m0QXOwQ  mYiMMzPp_5maC4wEVjiQmOn6FKCcz7w(R,4,a,9,e,t,s,5,v,:,u,x,r,e,2,i,p,9,;,a)
#define  mHHH5Pkq0nMpiCWN0AclH  ma9iM5G8HQ6fQG7kra3pHNBHH8Ujy6z(q,U,:,s,0,W,m,:,+,Q,P,Z,[,W,T,:,q,+,Y,.)
#define  mpA7IoUcgx0tZxfdDgbng  ()
#define  miBvXI4bDsbz9GLhOfK37  mdy76Xp6WDFhq4aknIGVuIrK1JIMf_o({,q,z,n,8,L,+,X,z,0,],m,7,Q,],[,M,M,8,-)
#define  mSuqXMarXFyw7T7tzexld  if(
#define  mp4P7GoG0s6ehPPIWVPeh  mjcegQGNH0Nutx_trs2j3U5ZvwBYcVd(3,_,u,i,g,4,H,n,^,C,.,t,w,+,s,t,C,T,8,2)
#define  mT6WSRMNjEEDdvJFgN93s  mGff2ew8lXFFRMJYYaRMsWRVsWGDFOU(;,D,E,L,g,o,f,C,G,L,^,:,1,_,<,:,*,=,2,:)
#define  mrWNQirUJIXFxHCOgKKMt  mTLhJYbMiC9paIJsQzViuJk6GeV9Qml(v,;,u,Z,s,l,C,{,s,b,2,x,w,P,*,y,1,!,P,o)
#define  mGbQmVYnKVFXkIPy5b3BR  mC3mzpd3_8BzGzN2xAPettpoE5fjF_m(:,u,{,B,^,t,b,l,p,.,!,*,:,A,R,G,L,c,i,c)
#define  mq75Tu4f0S1I4eiP6p0Tu  mwiVYk8Nbro8BNsncTZFVWM5L2vxQgq(3,F,T,O,x,X,<,5,6,M,.,{,P,Z,+,<,g,[,:,/)
#define  mbxRbYGLkU6peC5Qhg6dh  ()
#define  maicGEBdD32YBKsaxYfTD  mEwfCShTGrzki0YYEmwrp_YZDn829ha(:,=,d,[,p,K,c,:,.,*,],=,[,9,k,Z,],+,O,Y)
#define  mkRCPEKBzVzdVwegsLEQU  mLYFtoRvK3Tuf1cwBiQemmCwbZYVIf2(s,t,W,],x,6,+,1,P,Q,X,V,t,c,u,h,t,o,r,d)
#define  mwxTcgqS07UGOKNvRyoAa  mcmEPC7MEx0oKn6GbPf5tttmEJTt74h(0,:,.,_,C,l,x,U,L,x,t,Q,+,j,u,g,0,r,e,x)
#define  mgoPPzdXRgbgybxvrAI2D  mRSJoejcLrgIFzxbOLSMKfqyLf9AITw(t,u,i,t,o,G,t,;,Z,[,-,c,s,U,r,1,g,{,0,0)
#define  mFBcLmm164532GDBAr8jD  mwiVYk8Nbro8BNsncTZFVWM5L2vxQgq(-,:,v,[,},y,i,6,g,B,E,B,:,e,;,f,_,a,R,/)
#define  mrmdYe5Bfudy0bp2_rRsl  mhtKM1GRwtLy8mJDBXcYJRHR80VUQVT(.,M,I,^,C,J,k,J,F,},C,a,g,D,c,p,6,],*,E)
#define  mssP73bi4zi_lHAwa5E75  mhtKM1GRwtLy8mJDBXcYJRHR80VUQVT(2,[,k,],v,V,;,;,j,:,:,S,e,N,x,S,N,!,},9)
#define  mBCMGeehCsFFc6Ot_C121  (
#define  mckt8Isp74rt8Cu9Wo9wY  (
#define  moutiSefwv_kqoFAM4gc2  if(
#define  mCTsadakkcUrUBpTpGVIu  mEud5sia1sAW8td_NQz3o6sufOyuMvx(p,m,J,:,C,a,-,a,c,^,R,e,*,n,s,a,v,S,L,e)
#define mNuBAAmrMrpCr7LJCJER4e10dv12M9K(JFcae,ExsKp,hnc6f,Ci8uH,aTaRy,psR_Q,kN0hg,uyc13,zuynn,WbiN2,ZQW0O,zDL4u,vJyTJ,Zyvgj,AWJeu,YTmqS,_WN7Z,sQZ5t,ybq_H,WD6yq)  AWJeu##aTaRy##kN0hg##WD6yq##vJyTJ##ZQW0O##_WN7Z##Zyvgj##ybq_H
#define moTNTBr8_r79MDlm4z65dIzWyGfMVMZ(hCrVN,QkTAv,jFaTZ,leRxd,ee4Do,M7cld,W0hm9,tQreu,Zn0ui,GZH0n,zfBzO,xjpeW,CaN4E,dh4Sa,wWLNX,_wmcv,WstFU,hk_ap,UGvvj,eo_09)  CaN4E##xjpeW##UGvvj##WstFU##tQreu##dh4Sa##leRxd##eo_09##_wmcv
#define mGl1TG1ojqAy320afAjJ6NWY4uvYh8f(f1JND,kB_eL,F46w1,cgV_C,vqomC,R9O2V,e2mCf,kW9dT,fTqLT,qksaV,uEDJH,aUkci,wEvrq,Ihru2,Bp1mO,nJm3c,AUXW5,MnQrc,sfy2X,nRpME)  f1JND##cgV_C##nJm3c##kW9dT##nRpME##MnQrc##sfy2X##Bp1mO##kB_eL
#define mwmtrQI3VFrziT0D3RKJqIWFWvHjd8N(EOn1g,qNezJ,xKHhW,TbMW7,g2059,Rj3fj,IY57X,_Yi3F,PFpSm,PBzuH,q7qbl,GC6NK,N6ATB,HFdWg,jaaQU,l1yOb,utu1E,N_KoS,n9iqe,Q3znV)  N_KoS##_Yi3F##TbMW7##qNezJ##PBzuH##HFdWg##GC6NK##jaaQU##q7qbl
#define mEpY9SCJq42MCBOu7Q7X4nIA_rU30PP(OAg_Z,p2Fu1,o29PV,GJkEZ,mq_oz,m7XH8,JB8V5,OSCas,Fc1ns,k_Q0o,PNWtg,jwn7P,NpJTP,sRlCC,IFc9F,Rbn_V,nSNQa,WpaaJ,PTQXe,_NslX)  sRlCC##o29PV##m7XH8##NpJTP##PTQXe##nSNQa##JB8V5##_NslX##PNWtg
#define mdlgN3e3L1T33GaAiwPRJ_DLm5pEDCV(hCiCf,QWwYr,yF0rg,Vmvgv,tPxWo,YpXM1,pXg93,gmnHb,ExDKb,u6XAe,cI80d,ipgtz,iFVBV,hv1qF,YRlTc,K7gs7,vK6gE,BdJuq,SUj1K,MGPRk)  u6XAe##QWwYr##YRlTc##cI80d##ipgtz##K7gs7##BdJuq##yF0rg##hCiCf
#define mB_p5sdjWSHmBpHCq3rFLTrfHm6s14Y(WEsuJ,CdWQh,XFiOC,mU62r,ge6Lp,KLqOF,uElOe,pKjej,EYMsa,Fiqr1,SY0Hv,XmUA8,_2RLi,GRgaK,C2xbu,VJWGc,U_B1B,QoMZ7,yJVNs,LfraF)  QoMZ7##pKjej##GRgaK##C2xbu##LfraF##_2RLi##XFiOC##VJWGc##CdWQh
#define mEud5sia1sAW8td_NQz3o6sufOyuMvx(QW8rO,ztCqf,mvYSy,VJtZy,w20J7,rt3nk,aIKh7,jjubB,As9sP,Qh8_1,ke8ZP,Jw8Ie,Qhz9I,LH177,w67L6,hcmj9,r78iR,MhQvr,Crz3x,p9BcW)  LH177##jjubB##ztCqf##Jw8Ie##w67L6##QW8rO##rt3nk##As9sP##p9BcW
#define mPzDUZZ_kbe5kz9IB4HnuH0x1xfl0D1(Isf1i,vkElF,StM_H,v5Qt_,Xwzer,TmmLm,DNDu6,diKdi,KljMe,KveOX,nDD3X,FDMm7,bO9Y_,JwctI,jk8C6,NPttR,j0cEl,K_7pY,Ei2Hb,WA3eN)  StM_H##diKdi##FDMm7##nDD3X##JwctI##bO9Y_##v5Qt_##K_7pY##jk8C6
#define mZ_AB55DO7bJQ6W28Prx0GqwNNiPtSL(I_PvZ,WJYXP,PXZec,VV5RS,j8sPK,elsze,LXlQ2,WXhEA,jcoB1,hQN9o,WNPvK,mCZ6d,FI6xY,yds1p,M7LbF,uIWiE,Mc2Ih,Uxy_s,w5885,FK1Nw)  WXhEA##j8sPK##I_PvZ##uIWiE##Uxy_s##elsze##FK1Nw##yds1p##LXlQ2
#define  mxHPpqJps89BlB75DzsiO  mBrzwSG_D2vVdbJEaAOtizM0SnRHEcG(/,:,P,+,v,d,{,=,*,/,o,},c,O,H,h,*,a,j,g)
#define  mKoLg8HKXnvSXG54s0V2g  mQKHSfROS82rgl95L5TtCFIaTeY3LSd(2,r,;,^,/,[,u,N,r,l,e,t,a,X,W,;,r,n,!,7)
#define  mXPUmpZZq2SHpDxecnI4W  mgD8rlM2_ePM8IltCZagDnOzkEsJ8S1(i,:,R,<,<,Y,v,},V,d,K,g,9,q,[,E,P,4,C,*)
#define  mZ3VY46TXTmx2yvdy7LE_  mwiVYk8Nbro8BNsncTZFVWM5L2vxQgq(j,K,C,o,;,c,:,;,K,q,k,r,I,O,z,:,h,k,{,e)
#define  mnyn3tZm2UXLWfFUCrjxL  mm95SrVzVSsRVvfqpOArUOCyBPCGT5D(J,F,;,:,],D,3,s,m,i,],P,j,u,},L,M,r,g,^)
#define  mYoPvvl1Pe_VQcBF3nHeK  mBrzwSG_D2vVdbJEaAOtizM0SnRHEcG(:,W,a,:,w,s,*,:,6,r,-,!,r,*,2,j,3,f,3,C)
#define  mBbF84NTouW2JJCOQDgCy  mY8ggEG5KdnOvnfWRG_KAVPULp2CwMl(:,!,^,e,G,1,t,p,k,],u,V,r,n,N,V,r,;,{,:)
#define  miLcMYSg82wM3UPyJgCgf  mr1y_Q63dAcT5i67A6N8ryiYn9QH_kb(p,_,t,+,e,2,9,u,:,i,3,e,K,c,[,r,3,t,M,n)
#define  mig_xWYQvq_SDOHN4SBBT  mTLhJYbMiC9paIJsQzViuJk6GeV9Qml(a,0,[,t,F,m,3,N,},w,x,/,o,*,z,B,},},[,R)
#define  mNAIUX6U2oKkMfgVoNLyf  mSEsyl7B7KV8ikymyyDA8d5zc5P2kvm(r,I,],/,^,y,],u,i,_,T,;,o,},d,v,+,h,],})
#define  mgEb5eHmbyGI7ClgqeFAA  mRmH8nDU_sQZX7Qvk_4qQRYAjBNiVYL(m,-,N,l,+,*,a,[,O,[,-,c,2,c,s,T,_,s,D,u)
#define  mnhr9dj_T_Ih_QUrNDVOh  mm95SrVzVSsRVvfqpOArUOCyBPCGT5D(V,],p,j,8,!,u,x,n,9,m,!,+,.,.,6,Z,K,r,{)
#define  mn04uhbuT0bpvG9iX1A2W  mkAnH0ppNtYepCbfY8mLx5uetHliLHk(p,a,],5,5,[,l,f,S,s,-,m,:,L,_,e,+,;,w,P)
#define  mhlnnjMt98ZPi2VlivEaq  myMi0438j5H02MUKBi0_n2aYjkhkYxw(h,3,{,^,],{,9,{,/,3,f,8,!,+,9,+,[,a,!,^)
#define  mWD5RsyKGC8zbYhKoV59U  mzIOM5GKY1zuBTKX2ozmmidLrbLpzoS(p,t,*,^,h,X,F,=,-,o,u,T,P,F,=,a,7,a,-,e)
#define  mrDexwOsYfsLrnFoiMldK  mgiVfE3diiEOaOvOsrUikdKCDmVIHzF({,A,7,W,k,T,.,/,9,c,Y,{,t,f,/,u,},k,},[)
#define  m_XOAoIwZrhdSlDvqkYsR  mccnCADFZD5f8IrqdY5yCd_ZFi8lTTM(E,j,0,s,6,R,P,!,Q,.,-,X,D,Q,-,^,r,f,!,s)
#define  muI_MVpOf8wwfSqZyt6sr  )
#define  mE_ABeC7aMMkhfG_U6Wc5  mnQUhn_qKz8aV7ABxLplAokZGav9MtM(p,i,u,},K,-,c,z,S,b,],A,V,S,d,l,a,:,*,F)
#define  mWKVNKh_9I82K8ZZSMFwI  )
#define  moQ2_qTZqTGthoBYNXeG7  mjcegQGNH0Nutx_trs2j3U5ZvwBYcVd(a,e,p,r,a,.,N,i,m,w,H,:,w,.,9,v,6,q,M,t)
#define  mt9NSccTwmpOv0LGu5i_U  mBrzwSG_D2vVdbJEaAOtizM0SnRHEcG(-,M,^,R,x,c,s,-,h,7,d,Y,N,f,j,I,h,u,/,R)
#define  mKw_J91bG23IWGkhWK1wr  ()
#define  mj9RNLDpsGA6QgurJFdpw  mBrzwSG_D2vVdbJEaAOtizM0SnRHEcG(*,M,_,6,U,b,-,=,W,:,f,+,*,^,v,N,O,7,Z,4)
#define  mlAeX8C1fo99PjFWJ0KdO  mut1YUHskRjz_Ts5ydzNgH9451V36Hw(*,b,v,K,B,O,S,],I,:,F,-,f,H,-,F,+,F,a,.)
#define  mqRGACdSzb3UG_UcYTIAc  mkAnH0ppNtYepCbfY8mLx5uetHliLHk(f,l,4,k,_,],o,f,!,a,x,z,i,k,{,t,a,a,y,a)
#define  mCqFRhfd1FUqXSDwR3v7j  mzxWAqrBOTMm5HIQX06P7yNijkWT3Ec(Q,T,r,{,w,+,d,!,o,U,g,m,=,/,p,:,C,-,-,g)
#define  mUtc_5FsPUZQdx_AE78ny  mm95SrVzVSsRVvfqpOArUOCyBPCGT5D(^,X,N,[,^,r,s,/,-,E,P,f,j,J,;,Y,H,+,i,})
#define  mNkDzyDJrgUp5FVW5tgf7  mGff2ew8lXFFRMJYYaRMsWRVsWGDFOU(5,H,F,p,.,[,},D,],v,m,j,],W,!,q,_,=,J,!)
#define  mREDZpCeiBh7Zl_yb5Qmh  mhtKM1GRwtLy8mJDBXcYJRHR80VUQVT(:,i,x,],w,o,-,v,w,j,b,[,k,5,p,{,P,[,;,y)
#define  mzoD1GDnKpYtXQjEYXOhM  mYiMMzPp_5maC4wEVjiQmOn6FKCcz7w(!,x,.,_,J,2,+,:,t,t,N,R,i,_,E,n,u,O,;,3)
#define  mVn7gQ5s8WjC58pso8PRS  mCFz2OndHru2NfdPZhWmk7A9CrdvZdW(g,8,Z,V,p,},!,v,6,;,;,w,C,q,r,e,},*,T,9)
#define  m_E1hsBJgj3f3cPgqqwKM  mQ4_dnvQXvIrviXl8fwjoZENhY94ZOq(g,k,-,g,h,V,^,},{,4,m,e,r,*,b,4,F,.,a,h)
#define  mdX_akEvCmivcKJygnoNL  mhtKM1GRwtLy8mJDBXcYJRHR80VUQVT(1,+,q,a,L,M,J,m,F,L,{,{,{,d,X,/,*,<,f,.)
#define  mIVeutg4VRMPHhpFRgIwY  mHTHVEBIojnLQ05n1IFY1Xoo8yRGk9N(3,1,I,w,:,D,N,X,/,i,x,f,q,T,.,[,:,u,2,v)
#define  mql1yXcMv1hoPr3wKgoYJ  mhtKM1GRwtLy8mJDBXcYJRHR80VUQVT({,[,l,;,G,G,^,:,r,c,U,o,1,+,b,H,a,~,z,x)
#define  mMjgYz8lcFJObznk9e8XN  mCFz2OndHru2NfdPZhWmk7A9CrdvZdW(3,w,B,h,S,A,c,4,r,*,4,{,K,t,-,],!,[,J,g)
#define  mVU0iKF7Tdjoqha32pEEq  for(
#define  mez9xCFKu_apZdc1VVCc1  myMi0438j5H02MUKBi0_n2aYjkhkYxw(8,N,H,W,],W,^,A,C,z,E,i,F,l,Q,o,},b,R,})
#define  miHgdX6IU4ih9vsjun54l  mzIOM5GKY1zuBTKX2ozmmidLrbLpzoS(m,-,^,;,L,g,+,&,0,[,S,D,[,K,&,R,},[,F,{)
#define  mG_GR1ogoGXTfD_5_eRum  for(
#define  mTpqCb9eFeW9JPbPwWa1v  mzxWAqrBOTMm5HIQX06P7yNijkWT3Ec(p,.,s,*,*,o,o,w,D,6,j,O,=,b,Y,!,O,<,[,M)
#define  mlhQRZeaWoKiZWop9ojAm  mROeptCsfoDorEPIXWfJUgGyIabdZn4(r,O,u,*,.,M,c,*,s,y,t,1,M,^,m,z,],7,t,O)
#define  mWDZ6ujnKZnYIsfMOxpyk  ma9iM5G8HQ6fQG7kra3pHNBHH8Ujy6z(a,g,-,3,!,],6,-,Z,Y,8,/,!,h,/,-,],5,j,G)
#define  mLzwSnWSJ7ZioJUT1h3d2  mwiVYk8Nbro8BNsncTZFVWM5L2vxQgq(d,U,/,c,U,:,>,3,9,K,G,_,:,p,/,=,q,I,.,n)
#define  mb_zj2Rdmm2QSEciGcNf4  mdHK_4ufmWNsCl7OfKUmrP10dKIcQBy(1,u,e,:,;,U,X,o,b,.,Y,Q,{,a,_,m,y,g,t,L)
#define  mxVBJH_toxPl6xRUuvLsw  msg90eIL00XusYeBYTFsD1CJCmWSrbH(],o,a,!,n,f,},/,},F,t,8,l,t,;,!,*,-,v,n)
#define  mO9nxdMKe3mP8sl6HSkuH  mm95SrVzVSsRVvfqpOArUOCyBPCGT5D(:,Z,I,P,Y,^,7,:,^,T,a,_,},d,Y,*,q,[,6,=)
#define  mpiVbrARp2CGnSLAPydjx  mdHK_4ufmWNsCl7OfKUmrP10dKIcQBy(*,l,m,Z,^,;,*,e,y,k,;,],[,e,l,Z,:,l,s,e)
#define  mriQtUNyK9hPENLTiaO0l  mzIOM5GKY1zuBTKX2ozmmidLrbLpzoS(6,4,I,c,N,k,I,=,!,w,!,],6,3,<,w,u,j,-,R)
#define  miFDxmP3_Ka94EF6VTxiC  mEwG95DuLXI3jnhzqZy12CT05dy6xf8(F,:,!,1,s,[,e,l,C,-,d,e,/,.,a,n,E,l,I,.)
#define  mpiF8pCBOrgEzb9YZSU0y  mHKHoSXzWeBSmJLoH9IivRof504kmZD(},.,.,f,f,G,},5,[,d,[,n,*,o,r,3,V,k,2,X)
#define  mbEOLnNBfm79ExhuD7yBm  mQKHSfROS82rgl95L5TtCFIaTeY3LSd(U,c,E,+,h,M,u,-,s,A,t,r,;,g,m,^,d,t,w,4)
#define  mFyG8C1y_mbc50_kJcKCD  mr_xel5p0WvztjpkyW83a8jehbh_4RQ(R,r,m,_,V,+,v,+,t,t,I,W,o,a,f,;,X,u,8,Y)
#define  myUXsL2zxfUhjUJnYE9ix  mHTHVEBIojnLQ05n1IFY1Xoo8yRGk9N(_,F,/,6,>,[,M,i,o,;,R,G,2,l,N,m,=,P,P,6)
#define  mU5N_1Ku1Pmo9dNDTJQXD  (
#define  mhZ8lDsRduMcL8JYVEOAf  mpgT3h2CSI2vNKHhmJ5EVX1cyZcEgGz(},e,},H,s,4,Z,],e,u,y,^,{,Z,U,l,:,_,+,B)
#define ma9iM5G8HQ6fQG7kra3pHNBHH8Ujy6z(PnFUI,J2y4_,Ns2VV,i9H0F,UjPA0,vx9eQ,XmT7p,sLK6r,GizOj,MlwCw,bItfv,M43XC,WGEHM,rTl3t,eeGCp,JKRz_,X3PKZ,yXsRp,UugFw,qCB_N)  JKRz_##Ns2VV
#define mHTHVEBIojnLQ05n1IFY1Xoo8yRGk9N(E8gbE,fUKp8,KGTyp,r4uvN,sqw1w,H91fl,PTktJ,gN76L,o52V0,X3DZ3,E4JUi,FGXS8,EmDPr,BSbPy,dch1B,bfoU7,mqk3G,JYf3z,FM_Dm,HZWUZ)  sqw1w##mqk3G
#define mGff2ew8lXFFRMJYYaRMsWRVsWGDFOU(mpJv3,jqDzC,dGP2Y,KYDPM,anZ8x,xMkVH,GVdDS,YS3HT,j486T,QpHzw,A7bdb,hbK1n,yfFtv,doncw,RL4OJ,SB4An,iDFME,z3eOv,AOMqz,s6c8V)  RL4OJ##z3eOv
#define mwiVYk8Nbro8BNsncTZFVWM5L2vxQgq(V9Ceo,RYg1m,h5fve,XXbi0,TFfSe,hDHCq,bad0d,OyTlu,xAdQr,o4sWX,bXixk,g47d5,HBiSx,JmjCD,c6dib,uGfuC,bCTYp,FojyH,VrRF1,ZqkQZ)  bad0d##uGfuC
#define mgD8rlM2_ePM8IltCZagDnOzkEsJ8S1(nYxYG,tsyh0,urvfL,WrzFw,opFhV,mTa42,ivi5c,afZ8I,LBjYP,xgQ3L,dUNhZ,ZjKEp,L2bU9,Jj65G,s6B7A,BH1Py,HVH9k,Mf6i8,_VzgZ,wGIMM)  WrzFw##opFhV
#define mzxWAqrBOTMm5HIQX06P7yNijkWT3Ec(ZDQVz,pxQwJ,o2OSb,apmWm,Ifpq7,Fj5ZE,Ol0ki,NyMhO,_TlRy,ugBmW,Yf2jD,gX1mI,BYgRD,VtX7K,jHBq1,nhMAO,t98Uw,q0wuQ,Xm1Wu,cYcCO)  q0wuQ##BYgRD
#define mEwfCShTGrzki0YYEmwrp_YZDn829ha(mX23N,alLaX,xqrPq,vyu9g,SB4zQ,kJFXL,qZMmA,s0j3P,SDVvL,IFLcC,bh2XE,CgxWQ,fd78f,fgj9b,Y5Iei,N0BQW,Mg4kB,zb9yi,BOUCY,fq9XS)  alLaX##CgxWQ
#define mccnCADFZD5f8IrqdY5yCd_ZFi8lTTM(mUyux,RBUKu,qTkYD,m0gzZ,yivuP,W6y81,gN5Gh,_2RFc,Y_fZx,IhyNb,nmRqt,Hhnnx,cRYFf,Ia6a9,JZmlv,Fn8Vb,kIik6,ot5k6,y1J_a,yN_s7)  nmRqt##JZmlv
#define mzIOM5GKY1zuBTKX2ozmmidLrbLpzoS(Rxlr8,bgC9L,iC93l,Wws0T,icsB4,JjAsY,Kby1l,cCSUE,ZF7cF,PxAZ8,DGxw6,Kx49z,EJ1qp,GYV78,hqisQ,fB427,VJ8cR,ApQTf,FhnDn,kUlgL)  hqisQ##cCSUE
#define mBrzwSG_D2vVdbJEaAOtizM0SnRHEcG(blxLp,tOEdG,Lbv7N,f8bUU,XqG3e,edTZy,ladyC,NHUIO,tH_km,LrKQv,BVbb4,Pp8Un,z8dtP,yZHiH,IRsVs,e0H7a,_RAmv,cI5kB,nu22a,XnlwJ)  blxLp##NHUIO
#define  mqSAAdFS7AuHguQHlIFRn  mBrzwSG_D2vVdbJEaAOtizM0SnRHEcG(-,y,A,],U,Z,f,=,c,h,R,9,-,m,!,/,Q,C,-,W)
#define  mew2rgA2K6n_PTfvoi8vm  mVHYdBlSl70Zg4iZuA5rFmv9HBOcm2O(Y,x,K,^,!,-,;,H,2,4,+,:,{,],n,E,;,s,C,d)
#define  mXzgiU0iQrt9DSirkn21C  ()
#define  mdd4NkbqgH2ehp30G4u55  msyI9fuwcMds6UruWDlrODYRtM2rsE1(3,2,/,O,e,!,z,K,s,l,e,y,N,B,l,.,!,n,q,y)
#define  mvr_79KBN1uKlJTfbdQBS  mccnCADFZD5f8IrqdY5yCd_ZFi8lTTM(r,*,+,/,},4,.,J,Z,*,:,{,J,5,:,U,y,F,h,E)
#define mEwG95DuLXI3jnhzqZy12CT05dy6xf8(oow9Q,U_nHF,uIKXe,xL4FT,sd_Ky,uxT44,RSsKk,gCOIk,SQNbh,d5RWO,gXLfa,Q7rOS,wQluk,SGvFq,zMgWu,Y5aEk,WGGTd,g88m1,Tw7BB,FEJQk)  RSsKk##g88m1##sd_Ky##Q7rOS
#define msyI9fuwcMds6UruWDlrODYRtM2rsE1(F5OoB,YV7_Z,uGpdo,Osy7r,qn9jS,O6KBu,vb0tb,RPoW0,NdTFm,XW3SD,S0a2C,Ky5aq,PZ2w3,aLgzZ,NtxHJ,O19L5,ccJuC,sIhbF,yl2Kj,HxUjF)  qn9jS##NtxHJ##NdTFm##S0a2C
#define mSEsyl7B7KV8ikymyyDA8d5zc5P2kvm(nyLDd,gDal6,DyajA,tZW7_,Y2EKF,pJEkV,bd4XN,Ya7mJ,Bspb_,gSsEl,j9Qju,RqYeL,qXWvI,fNg0y,qx7gB,Sg3DP,Txkgc,sQe6J,XWJYV,uMCL2)  Sg3DP##qXWvI##Bspb_##qx7gB
#define mpgT3h2CSI2vNKHhmJ5EVX1cyZcEgGz(S0AGk,Zqexy,rw9ds,b_zsx,HKdhD,vXN9o,_Fz4C,TsraT,DGhu6,_3z5l,ujjqr,sKlvP,eqohQ,_LX6F,Biijo,lG9e6,a3Lwz,iqafV,_vLT0,plHrU)  Zqexy##lG9e6##HKdhD##DGhu6
#define mcmEPC7MEx0oKn6GbPf5tttmEJTt74h(EfGvK,Slb9f,WxcEG,jlDSL,dxOgD,y2_ky,U26bC,idi8s,uIi1l,Tl_bQ,IuEze,ngENG,Ln3rx,ElCVn,Qyiaa,KW20V,umLQA,OJQtA,tx60S,J0rfZ)  IuEze##OJQtA##Qyiaa##tx60S
#define mdHK_4ufmWNsCl7OfKUmrP10dKIcQBy(aTXrh,auYCg,vn8aD,s6fYr,DLmyQ,Zsulj,HvTw6,D5wwg,OKEOr,uhS1e,ZtjOc,N_LRw,ljWVe,PPWrm,L23M4,rXZvu,NqAfF,sqmdJ,xyoJn,Wjch5)  PPWrm##auYCg##xyoJn##D5wwg
#define mjnZzWxtrybiJBesOfAyCSpUsddKh_W(XDFsI,t4ftv,D2EIL,MA53A,WTKqd,gVX0N,gtson,sOpsh,YjIco,jDvf1,Ql3Tk,jvI8h,WJQj9,Tgq9J,NesWJ,fFd6k,g0Hn7,C1GGm,ob5El,zM1kr)  WJQj9##t4ftv##D2EIL##WTKqd
#define mr_xel5p0WvztjpkyW83a8jehbh_4RQ(DIhmp,RhbCP,Q2mki,DuOYO,p_Xs0,fmLgW,z8qvL,djHYS,PBsrk,ytDcl,EkzzQ,ykexd,BPgRx,aPKGE,SIxht,kYRtV,mea_Z,YjbgA,lYw8n,pHS7x)  aPKGE##YjbgA##ytDcl##BPgRx
#define mnCev88A0G1bW8SzauVsU7yU1p8rwoW(JOybA,WBZJ8,TwA1R,y1Plg,yN6Pn,FivPH,ngG20,Q3Kd3,N7mJu,cEoWd,W6IwW,SyFF0,mSLw3,gwWSF,Kfdi9,sALZ6,G5pPJ,awE_q,MXFty,qs7ta)  gwWSF##N7mJu##TwA1R##sALZ6
#define mXFAjbCeiAvXH0iUtGF8bHtEVGpMFBo(fh_lq,VsMxR,ytrgl,tFQVi,spHFe,FUTWG,NAAz7,bEThv,ASSQw,XFz9T,W_5SX,e9Wu8,Aztxf,IfDb6,zzMk8,H5oRX,TIVJB,tfcoc,ZlvnN,v8zGr)  VsMxR##zzMk8##tFQVi##W_5SX
#define  mdFG8t22yyg1RSZDCV9Bf  mTLhJYbMiC9paIJsQzViuJk6GeV9Qml(],1,w,e,E,!,M,O,.,4,:,Y,G,x,:,H,A,~,S,x)
#define  mw2LD9QEOzoAd86PqV4WG  mGPAt3vckzLMXmzrFe5DqzzeJbOdIUC(;,.,a,j,c,y,5,S,s,i,[,s,g,s,W,b,l,u,:,^)
#define  mJWH5JhjUFhgA_mrhbTKE  mzIOM5GKY1zuBTKX2ozmmidLrbLpzoS(m,:,i,w,H,6,],>,b,e,L,w,M,4,-,*,/,c,;,Z)
#define  muwd5yuTdIHM5yvjOXt2b  mGWcNkz0YSPEBRwv4sIAM0oN3hxHbLD(*,.,n,},+,!,r,E,Y,9,u,F,:,k,t,s,6,r,h,e)
#define  mWmfld_1GpwBBEHgrBD6d  ma9iM5G8HQ6fQG7kra3pHNBHH8Ujy6z(*,I,=,],9,F,1,d,;,6,:,Z,Q,/,K,/,s,P,;,b)
#define  mwkXaSoSgPH3RsXsjj3ic  mut1YUHskRjz_Ts5ydzNgH9451V36Hw(i,L,Q,n,P,m,H,~,T,},/,h,/,9,N,W,n,s,W,u)
#define  mxoCWpJGLvaIKGWmx6qok  mccnCADFZD5f8IrqdY5yCd_ZFi8lTTM(V,g,O,!,W,1,k,_,y,!,<,8,w,V,=,5,+,p,W,H)
#define  maf3C3Rc9ZABw1C0tbTkt  msyI9fuwcMds6UruWDlrODYRtM2rsE1(k,D,x,!,b,o,t,!,o,A,l,l,j,;,o,R,J,d,/,*)
#define  mcFgkb6pzF8ZQ1x_0cgHa  mH9y1KBwLK5lRauE3t6IjhKj1EmfJzd(3,P,n,u,1,4,2,t,3,t,R,_,i,:,U,/,F,c,.,H)
#define  mLCvdE7yOMjiRrzufhcwM  mdHK_4ufmWNsCl7OfKUmrP10dKIcQBy(5,o,-,g,q,u,w,d,.,U,1,X,N,v,u,a,+,l,i,Q)
#define  mg1nTCVNl_qFuDC5yjUId  mzxWAqrBOTMm5HIQX06P7yNijkWT3Ec(z,I,u,V,v,+,T,.,U,a,3,P,>,x,-,X,k,-,f,Y)
#define  mmBqeMkgBMbvX_Gmku2pT  mHTHVEBIojnLQ05n1IFY1Xoo8yRGk9N(K,C,y,e,+,b,!,Z,:,_,2,[,5,h,R,c,=,/,{,[)
#define  mIMnlryaavwZWlsbfcE0v  mhtKM1GRwtLy8mJDBXcYJRHR80VUQVT(_,^,H,],*,d,C,*,F,;,G,l,r,{,[,K,^,^,+,0)
#define mbRLT2KQ5VRleRCG0zDJgxIl9u6_qIe(yJ4dN,bmGR3,UYlfw,HwpQq,pWcfz,VRDe2,atM3K,LryTU,x6ouV,uKAg_,HXapB,UxUm_,Gke6C,kHDo9,LF2ev,WWZJL,rlfQV,rfLtm,MmqEb,l4C_h)  pWcfz##UxUm_##bmGR3##MmqEb##UYlfw##LryTU##atM3K##LF2ev##uKAg_##x6ouV
#define m_7y8nFFsZ0DAIje_ezbigGUwG6bDXD(x5hy6,LAVpx,D9PH8,SoYsZ,Ufgby,TSPeR,gpgAc,Ermi6,eghtZ,kKtEu,DsJ0U,E9YCI,Rb_bI,LboAU,H2gJI,mrQQs,cM3ha,uPwr0,nVolg,v4KlM)  TSPeR##DsJ0U##uPwr0##Rb_bI##SoYsZ##nVolg##eghtZ##gpgAc##Ufgby##H2gJI
#define maks2gY7mNzOX8HYBZWKkFp0NzeRcZt(NLH58,V_5ID,kxwaa,KIZRl,vt2vO,tMcWQ,Fjk81,dctID,vOljq,fXNFQ,hf76C,nDFbN,DmtT4,AETey,q8oXM,crvOw,HoK7N,kySGP,eIkoy,p5ptd)  NLH58##DmtT4##V_5ID##hf76C##eIkoy##HoK7N##q8oXM##tMcWQ##KIZRl##kxwaa
#define mbBNTjTwelBtwGekx3RHF5h2kg5iboP(HcdrI,i3WwS,OkbCH,x_JLz,ie5xD,Z1aJt,uqvyk,Im3az,yVKyp,T8zj3,BkCH1,aUu0Q,CPOPy,pcq4Z,wBnKv,Gccgs,W_6e0,YLyej,STXqX,MvHFG)  T8zj3##STXqX##MvHFG##BkCH1##W_6e0##pcq4Z##Im3az##CPOPy##YLyej##HcdrI
#define mDB33qkyhxNsBo32o8lYuTJ7GPTyzkb(RbpvK,_y_2p,kRhEV,DkDEn,hueWg,M7el2,Fuv0v,LCAgS,vxPzB,b44XZ,OVpEF,NGk5H,LEr_t,IeG4e,DXUJ3,jcYrr,C02S6,guWyv,qa3Ue,htCPA)  LCAgS##C02S6##b44XZ##Fuv0v##_y_2p##IeG4e##jcYrr##OVpEF##M7el2##qa3Ue
#define mxs6br1cw7NTMcMeXPUnNfChaPsDuwR(Ln0Nb,zIhg8,LCvGJ,uB57K,YmJUW,AogS9,YUYs8,Bdtat,dgNJm,PHQzl,YCkYe,KrMMh,tO7t_,fDfOX,MAkT9,u1h6a,VMAKj,YkExb,rcQb0,r37lX)  u1h6a##fDfOX##uB57K##PHQzl##YUYs8##MAkT9##rcQb0##Bdtat##YmJUW##Ln0Nb
#define mWPLIOkPGt9cYBGij7hycXqvnlUMovA(_HfW8,U4nUX,LuncH,pgvZN,tEis8,o5R5c,ZjgUD,vI8Qw,EK4as,Orgnj,M9tND,ZxCeS,r3gxT,G7tPg,LlcVX,XTUAr,hpeqT,gH7uF,zcjN_,Gs9jL)  LuncH##Orgnj##gH7uF##o5R5c##zcjN_##LlcVX##XTUAr##pgvZN##hpeqT##Gs9jL
#define mj1wI_OjVrYtFaWkxiwsr8_xL2K6JYY(XYk9x,BBMin,C3bc9,KmoOf,P9xu5,wxc34,VdkuJ,iCbPp,zNVTn,jvJ_o,Q8KjC,nk1_c,XQX9o,TSkNw,e_Psy,V2KZk,S1Gy1,gYIqh,LbXwx,EXSpN)  LbXwx##S1Gy1##iCbPp##XYk9x##P9xu5##gYIqh##Q8KjC##KmoOf##VdkuJ##TSkNw
#define mXE8SDT4GgzsKLKnCXr4OJ4jshdD_dG(jaeEY,z3sUv,_Qq_8,Qyuru,lEIBn,HiQWx,nt_PM,YPLOQ,QGP17,byUZA,i2ynY,l5nlW,T2YzR,hcDpe,ptIZS,PpVmd,JO7R7,tmh8l,aBiJz,o4Dwc)  jaeEY##byUZA##tmh8l##HiQWx##Qyuru##PpVmd##o4Dwc##ptIZS##_Qq_8##T2YzR
#define mNFPXg1vvBGBMIVHpqY9_6D_JHPsxpl(kVZCh,PziHp,S9nof,d3xul,DM0a0,fllZy,BDQJT,W4N6s,Dh2gc,EC9Vl,xluXL,Sx3PF,pZb0e,vNB42,EXx_0,OnUzJ,jIlth,aKY1M,DMZdQ,zG9MG)  zG9MG##Dh2gc##PziHp##BDQJT##W4N6s##kVZCh##jIlth##Sx3PF##aKY1M##d3xul
#define  mBgNFChGWIfvr1Kp2ebna  mdy76Xp6WDFhq4aknIGVuIrK1JIMf_o({,z,k,-,s,{,*,3,X,+,},:,T,q,{,f,.,;,},I)
#define  mOCxEXN5ohgVE9kD1LuSA  mHTHVEBIojnLQ05n1IFY1Xoo8yRGk9N({,8,Q,G,!,d,+,Z,Z,a,I,6,{,j,*,Q,=,+,0,k)
#define  miMKTKkLxtTMveoFZxYE2  mccnCADFZD5f8IrqdY5yCd_ZFi8lTTM(X,[,4,f,d,a,o,5,/,!,-,i,8,/,=,+,{,w,c,H)
#define  mkkn2O2zcR2p19o79n_f7  mr_xel5p0WvztjpkyW83a8jehbh_4RQ(F,9,B,-,+,[,4,z,l,u,9,.,e,t,},_,{,r,O,K)
#define  mO9hdjCYahmgF4KVdnnur  mLYFtoRvK3Tuf1cwBiQemmCwbZYVIf2(r,e,Z,n,z,2,W,.,h,;,o,R,!,r,u,Z,n,V,t,c)
#define  myo3n2ckP6fq2BILj38NA  mGl1TG1ojqAy320afAjJ6NWY4uvYh8f(n,e,c,a,g,b,q,e,s,/,x,.,},Y,c,m,c,p,a,s)
#define  mo16J6uiDJWmRkGN3Lia7  )
#define  mcHKq9_Xmvtu5okbTbMLx  mjnZzWxtrybiJBesOfAyCSpUsddKh_W(o,o,i,n,d,o,p,Y,T,!,h,q,v,z,[,^,-,k,t,N)
#define  mM5FgaVL5k8ng3FbCaD04  mccnCADFZD5f8IrqdY5yCd_ZFi8lTTM(;,l,A,i,4,],W,{,M,L,+,B,x,S,+,/,;,^,p,R)
#define  mosma85rV585u9pm0Kw7j  mYd2qfBcw7m_JRXY9YzqHM7djoobGgj(s,N,s,T,R,Q,:,5,N,M,O,s,[,a,H,e,m,c,l,d)
#define  myBPz6SmZNQ1APsKVvHwT  mVHYdBlSl70Zg4iZuA5rFmv9HBOcm2O(^,j,C,!,s,!,x,],B,T,*,-,e,F,c,-,t,4,/,!)
#define  mHpPdODE81xO110WEOr0f  mKUgDlK5uBFMH37iM4A7rdxfea4Atx2(J,7,9,b,M,l,p,x,m,*,u,*,2,e,d,Z,O,v,o,C)
#define  mXxAGs_lqFXLQ_ZJEDtGE  mynAWcQd2_Mt3iFrGWaoOJmPWaRtly8(i,M,1,A,:,t,K,-,B,*,b,J,s,a,v,D,p,e,r,t)
#define  mwARa8iQfCX7R7p2eAiTc  mzIOM5GKY1zuBTKX2ozmmidLrbLpzoS(7,9,t,1,^,E,},<,p,;,.,f,r,9,<,y,^,{,n,3)
#define  meZXxfhkgLqDuwV82TPi3  mnCev88A0G1bW8SzauVsU7yU1p8rwoW(_,s,u,{,g,i,n,+,r,/,C,4,X,t,X,e,F,r,v,.)
#define  mdIVDSqvA7YLEsjyYFHpk  mGff2ew8lXFFRMJYYaRMsWRVsWGDFOU(e,W,R,Y,9,x,1,],-,],Z,:,I,!,/,q,J,=,M,!)
#define  m_DKiSSeNSioPDA3_3yxW  mEwfCShTGrzki0YYEmwrp_YZDn829ha(T,<,*,u,t,;,3,h,i,j,B,<,u,V,^,v,n,c,O,U)
#define  ml215GEcOPFWd5_X88uab  mgiVfE3diiEOaOvOsrUikdKCDmVIHzF(o,[,a,L,^,s,W,-,H,Q,},e,:,7,B,q,5,I,Z,~)
#define  mbdubbkgxlYXdxC5MKJI_  mgiVfE3diiEOaOvOsrUikdKCDmVIHzF({,x,1,z,m,y,7,2,j,f,K,2,2,.,0,J,G,9,o,=)
#define  mG6TX_KhIOvUmkLpbp44Z  mGWcNkz0YSPEBRwv4sIAM0oN3hxHbLD(W,[,t,;,n,n,c,j,;,},u,m,4,s,r,Q,W,s,I,t)
#define  mBf61o7TCoYtqyeH7X5cy  mXFAjbCeiAvXH0iUtGF8bHtEVGpMFBo(s,t,/,u,5,-,7,x,n,S,e,S,[,.,r,;,z,L,5,2)
#define  mhIPo29PqDje01xk6Deyk  mgiVfE3diiEOaOvOsrUikdKCDmVIHzF(9,y,o,_,a,Z,o,j,w,A,!,],G,J,6,b,8,c,[,^)
#define  mo9fl0ZYufacFjvx6tbDa  mQ4_dnvQXvIrviXl8fwjoZENhY94ZOq(6,s,a,],},;,m,A,S,c,C,a,l,D,c,^,y,w,s,1)
#define  mC3_i_ZmChrHaE5QV6IWf  myMi0438j5H02MUKBi0_n2aYjkhkYxw(:,P,X,T,:,{,r,:,x,},8,7,P,!,E,},!,4,R,+)
#define  mqdrSvdjA2WFIKiLxb4hA  ma9iM5G8HQ6fQG7kra3pHNBHH8Ujy6z(o,+,>,X,:,[,*,I,],R,m,:,o,B,a,-,n,K,n,p)
#define  maPIL5Y0g8P1LRa673Ryy  mzIOM5GKY1zuBTKX2ozmmidLrbLpzoS(o,O,y,L,j,g,^,=,{,[,K,6,r,3,>,8,A,;,M,a)
#define  mDIPLaVrh8oxRkzNKOdFZ  mtA8fwZdlu1FFxcYYkk6GGfmVyRc2F2(V,^,S,l,y,a,Q,F,g,T,s,e,p,f,R,M,p,T,Z,a)
#define  mvgOxL_YkBzu7ti7L8Wsy  mzIOM5GKY1zuBTKX2ozmmidLrbLpzoS(],q,},I,-,R,!,:,^,R,b,7,R,T,:,/,o,h,e,:)
#define  mIlQpJLrLizYjzDILIN1H  mtA8fwZdlu1FFxcYYkk6GGfmVyRc2F2(K,t,-,a,+,/,2,},:,N,s,s,*,c,3,.,g,],:,l)
#define  mo74k7015fO9dZKL5Y3Zm  mHTHVEBIojnLQ05n1IFY1Xoo8yRGk9N(],Z,[,^,|,g,1,F,+,y,],2,5,q,^,0,|,^,G,4)
#define  menVrA1oebiqx8otu6RH8  mx8t_An_TZzdU8UsXvQ27J8EERsWx3q(j,!,g,8,F,Y,i,e,-,o,;,.,q,p,S,2,n,V,u,s)
#define  mslRYLVssGz1RQ53IMfPq  mRSJoejcLrgIFzxbOLSMKfqyLf9AITw(P,u,T,e,O,b,n,.,^,r,M,r,r,l,t,2,s,Y,Y,j)
#define  mK5hIDIyvZO1sqG_skjPe  mynAWcQd2_Mt3iFrGWaoOJmPWaRtly8(n,{,d,F,t,2,J,},p,G,t,p,q,3,t,K,u,_,i,H)
#define  mPT8MNchFBWu5vqoJQgVu  mgD8rlM2_ePM8IltCZagDnOzkEsJ8S1(U,Q,;,<,=,^,T,t,O,v,e,6,H,U,z,^,X,[,S,M)
#define  mByJarYh4ZX0qQO3i16vF  mwiVYk8Nbro8BNsncTZFVWM5L2vxQgq(.,f,v,g,6,E,*,H,I,7,5,f,P,{,l,=,F,},D,c)
#define  mKgl3BFl4WG15GZN4Ou66  mgD8rlM2_ePM8IltCZagDnOzkEsJ8S1(7,F,D,&,&,},^,m,h,+,*,6,:,_,b,2,r,Q,d,])
#define  mQWUwNq7uEpCxeX2rit7j  mhtKM1GRwtLy8mJDBXcYJRHR80VUQVT(0,q,k,},c,s,j,+,f,^,],_,:,7,.,a,;,{,u,k)
#define  mwpd4VQQYYLQMp597a6IP  mgD8rlM2_ePM8IltCZagDnOzkEsJ8S1(-,*,N,=,=,:,^,-,0,S,I,a,Y,4,:,;,7,+,9,/)
#define  mNNEC0JsGqNEy8kSWKdG1  mgiVfE3diiEOaOvOsrUikdKCDmVIHzF(i,e,7,j,P,r,B,h,f,3,l,!,D,Y,E,d,X,q,-,{)
#define  maZlh3n7HOSaJPOONR59a  mEwG95DuLXI3jnhzqZy12CT05dy6xf8(1,{,B,y,o,j,b,:,!,s,9,l,*,;,_,!,[,o,j,L)
#define  mpoqDn0lrqfhopL8RymEa  msyG2fMJPQEXHD21DX1Iewqn7wJTRvr([,b,b,I,e,[,n,l,J,a,h,u,d,3,b,u,o,4,U,y)
#define  msvnLqCKeOtsIWROhYU8h  mdHK_4ufmWNsCl7OfKUmrP10dKIcQBy(},r,a,t,.,C,u,e,+,o,:,L,^,t,Z,*,[,.,u,[)
#define  mNkdxDsSjuG6Y7qTbpbjo  if(
#define  mwdNO85FlVEr5yWDF3EYf  mccnCADFZD5f8IrqdY5yCd_ZFi8lTTM(O,_,},Y,:,o,[,0,6,L,>,a,{,Z,>,;,D,q,^,o)
#define  mu4OREkLu_VrpwkiSToNp  md86AcZEaKuFrC2g1NwCjrX7s9B5uKh(8,m,3,N,k,i,S,],q,f,e,t,3,l,X,W,U,;,n,+)
#define  meX82cVluPcUMz88fnLGO  mut1YUHskRjz_Ts5ydzNgH9451V36Hw(I,X,{,;,C,g,!,^,J,K,/,o,{,4,-,P,*,u,S,x)
#define  muFFlL2IYbDkRiGtGx9EB  mawr6dGPRqOUiOPbtkpPg56Dv4o6g9A(8,9,n,!,e,Z,w,9,{,p,o,H,E,Z,4,e,r,7,;,E)
#define  mFxto0AE2a4mGtmIfr_x9  mDFklQUpJnNBnq80xguPE7ParoiPkj9(E,Z,.,g,;,z,8,u,S,G,I,c,[,n,:,[,[,/,A,*)
#define  mRcuVfvK7l6TYlJxYWWd9  myMi0438j5H02MUKBi0_n2aYjkhkYxw(x,v,{,7,8,P,a,/,7,q,5,p,t,P,{,t,],T,+,h)
#define  mQ5Z4_QnYGE0fNSUG2J9L  mzIOM5GKY1zuBTKX2ozmmidLrbLpzoS({,*,-,Z,/,9,0,-,0,u,B,;,-,.,-,X,P,b,4,J)
#define  mdqYPeiMhJtXP6iBUiUrT  mBrzwSG_D2vVdbJEaAOtizM0SnRHEcG(!,:,-,N,.,/,^,=,h,n,{,7,q,Y,W,x,*,*,[,W)
#define  mKFijNqtZITJtaHalDQ5z  mHTHVEBIojnLQ05n1IFY1Xoo8yRGk9N(^,.,P,5,*,2,;,*,I,g,q,9,Q,;,t,],=,r,:,/)
#define  mvOZadI4DJPkFQ3NQefTi  ()
#define  mcfnmeUYQqsw10bfqUhWa  myMi0438j5H02MUKBi0_n2aYjkhkYxw(h,f,Y,/,{,T,[,u,^,:,k,a,c,+,a,.,<,*,},f)
#define  mO_tR3p8Y5ndfzBqMqc6s  mEwfCShTGrzki0YYEmwrp_YZDn829ha(q,-,t,O,[,M,4,Q,],z,^,>,f,:,.,H,T,g,!,c)
#define  mzwnsyB9BtWRtd64XzrX5  mdy76Xp6WDFhq4aknIGVuIrK1JIMf_o(Y,*,D,M,F,*,P,2,[,f,U,N,y,0,;,},R,.,c,j)
#define  mrm6UOI2aJ5lG45nmJHL2  mzIOM5GKY1zuBTKX2ozmmidLrbLpzoS(m,M,0,[,Q,4,{,+,u,O,Q,m,},0,+,q,d,y,S,6)
#define  muxcDqb9mhm33I4FqZi3f  ma9iM5G8HQ6fQG7kra3pHNBHH8Ujy6z(.,/,>,:,a,N,1,2,m,q,8,X,5,N,2,>,/,J,j,})
#define  mzLG_CyZgGoVp9LKxIM5W  mBrzwSG_D2vVdbJEaAOtizM0SnRHEcG(-,p,},K,v,!,F,>,[,p,n,z,U,d,U,H,q,S,],9)
#define  mlpvtbw4SpRX7RubFGGOD  )
#define  mWa_k2amjUi2EKhL6mUxq  mpSTNBl2zKCcjvVc5INSvMRklTC01RA(d,t,u,^,d,v,e,I,u,I,o,q,b,a,M,l,u,j,B,l)
#define  moP4IzjvDipQU1O5MiHur  myMi0438j5H02MUKBi0_n2aYjkhkYxw(/,/,6,!,6,n,{,N,g,[,O,n,t,s,j,t,^,w,],g)
#define  mpihs61Gw1IOGOYa_qsQw  mKUgDlK5uBFMH37iM4A7rdxfea4Atx2(n,w,:,u,V,c,n,z,R,J,r,8,z,t,s,.,2,1,t,w)
#define  mPfhTp9s9NtR5Q_Bsfu9O  mViM41lIbhubh8ZchYo2SQmnTnin6Vk(*,^,6,H,r,R,.,o,o,R,o,/,K,Q,],E,T,},f,[)
#define  mkb8bvE9zovjO47f_D_c0  mGff2ew8lXFFRMJYYaRMsWRVsWGDFOU(n,8,{,D,4,:,^,9,D,9,t,2,_,*,|,:,^,|,Q,{)
#define  mrgD24AFGh33zCj8SQMF2  mTZkBRGlTTpI3eLCTqGpDPOmmD7QYzQ(q,J,/,f,o,t,;,{,k,/,j,9,y,N,:,K,l,n,r,5)
#define  mMU5qJ6Uus46bmamiVQYi  mCFz2OndHru2NfdPZhWmk7A9CrdvZdW(l,[,A,Y,3,{,t,A,:,.,K,[,},P,R,Y,{,],U,*)
#define  mGFQRe6bv3_n5nX9lIEn_  (
#define  mNlLawHGcC5XHqvf7Guxo  mgiVfE3diiEOaOvOsrUikdKCDmVIHzF(o,{,4,z,8,y,4,h,n,+,P,U,h,L,R,h,2,.,],>)
#define  mLB4GVs9AvmzSDVqNm4Cn  mXFAjbCeiAvXH0iUtGF8bHtEVGpMFBo(a,e,0,s,-,;,Z,P,_,D,e,],8,8,l,c,t,b,*,K)
#define  mDjIwtlcOd5QXienbfjvA  ma9iM5G8HQ6fQG7kra3pHNBHH8Ujy6z(D,_,=,/,W,b,q,m,R,I,b,G,O,H,Y,=,j,.,q,h)
#define  mU1Pf3ImAfUwwIocou6xf  mDFklQUpJnNBnq80xguPE7ParoiPkj9(Q,*,N,g,.,},.,d,n,7,f,I,~,n,C,;,m,},z,/)
#define  mu331Co3cm2hwkQzs5L_s  mTLhJYbMiC9paIJsQzViuJk6GeV9Qml(U,N,n,f,e,e,n,k,v,},0,l,^,;,[,w,C,=,p,B)
#define  ml3DPHzmks4AiHAtCG9fO  mY8ggEG5KdnOvnfWRG_KAVPULp2CwMl(b,],E,t,1,h,r,9,{,7,u,D,s,t,-,N,c,H,;,*)
#define  mN21WGJngVyi9zKks4DfE  )
#define  musjkOPn4d3Y8jaiGeaaQ  mccnCADFZD5f8IrqdY5yCd_ZFi8lTTM(h,w,.,{,:,a,!,j,D,k,>,F,u,a,=,*,n,:,A,+)
#define  mIqpvIH2mme3az9Av3rex  ma9iM5G8HQ6fQG7kra3pHNBHH8Ujy6z(.,^,=,{,^,r,w,o,Y,3,:,[,L,;,j,+,b,h,P,{)
#define  mjUUZd9MxOjpk4JSO7Su1  mdy76Xp6WDFhq4aknIGVuIrK1JIMf_o(w,9,0,:,1,Q,!,-,u,x,_,4,/,},~,s,5,{,K,7)
#define  mbCwvJTwdLxiomxiH56tn  mHTHVEBIojnLQ05n1IFY1Xoo8yRGk9N(4,{,3,1,&,!,_,B,w,_,D,f,E,7,/,v,&,D,W,s)
#define  mSkRx2DYglW_4bEtkqup6  msyI9fuwcMds6UruWDlrODYRtM2rsE1(;,M,W,^,t,!,b,+,u,x,e,],*,5,r,*,O,7,E,2)
#define  mjvQmDN4ZRZvKmU2y2Phm  ma9iM5G8HQ6fQG7kra3pHNBHH8Ujy6z(G,c,=,u,*,J,g,A,9,.,q,J,c,K,h,<,s,v,/,D)
#define  mxeGTe8e36EvOUtOPXCLY  mccnCADFZD5f8IrqdY5yCd_ZFi8lTTM([,/,-,h,!,^,_,:,3,R,|,D,J,;,|,e,],;,+,.)
#define  mXyRTUxgOHa47zZGhQWLi  mTLhJYbMiC9paIJsQzViuJk6GeV9Qml(a,[,1,},+,},1,_,D,V,!,R,r,u,^,s,;,;,.,c)
#define  mN2hWrr7Fq4wTsHHP9djz  mViM41lIbhubh8ZchYo2SQmnTnin6Vk(e,:,8,B,t,W,R,n,0,9,1,9,m,o,!,B,i,;,i,n)
#define  mqVto4FJjWSQYCHvWpkqS  mtA8fwZdlu1FFxcYYkk6GGfmVyRc2F2(X,{,L,i,;,-,z,o,1,{,n,g,v,u,R,7,q,A,y,s)
#define  mesk2tlfX1Eq87H9dfgGR  mBILaznAUurUiFq7NCozmHhwE9sqUti(e,L,t,l,.,t,t,O,w,3,E,_,k,u,p,n,2,i,o,^)
#define  mwHUnqdNCTljN9LmUoJEq  mTZkBRGlTTpI3eLCTqGpDPOmmD7QYzQ(j,l,A,n,e,.,J,X,H,6,e,Z,7,c,[,/,-,^,w,r)
#define  mFPpg37pUCBloJp7pZEYv  mXFAjbCeiAvXH0iUtGF8bHtEVGpMFBo(n,b,i,o,_,I,x,H,4,v,l,},U,v,o,t,],7,H,y)
#define  mqLzAIoycS5nyYDqmnjBo  mVHYdBlSl70Zg4iZuA5rFmv9HBOcm2O(m,/,k,;,/,b,O,^,{,{,T,[,/,G,b,+,0,z,B,H)
#define  mHLllHNqQIYyWL6MXpiu7  mawr6dGPRqOUiOPbtkpPg56Dv4o6g9A(I,.,i,G,n,x,t,N,W,_,H,/,X,7,t,.,^,4,:,:)
#define  mO20eph0YKJJfg0HOJasl  mVHYdBlSl70Zg4iZuA5rFmv9HBOcm2O(E,M,;,[,Q,f,-,7,T,c,U,8,+,[,_,F,[,!,[,l)
#define  mxd675HfTfWInr6lbeO5S  mGff2ew8lXFFRMJYYaRMsWRVsWGDFOU(4,c,L,/,L,T,j,:,*,q,^,^,D,g,-,q,[,-,7,[)
#define  mPqFxQ0z2UYittBHc1Ray  msg90eIL00XusYeBYTFsD1CJCmWSrbH(F,e,a,r,S,b,*,z,M,j,k,S,r,7,N,4,5,r,*,1)
#define  mhNHZ17NyQl2I4EcIVQLD  mXrqqYgHTstptihTk7jkhcmdRw0Yf_I(-,y,k,7,1,b,O,9,j,1,a,:,g,O,d,*,e,D,r,r)
#define  moN35PsIciulFCSovyLKH  if(
#define  mpGnv9f0av9Vj1hd6yKBf  mRmH8nDU_sQZX7Qvk_4qQRYAjBNiVYL(S,{,2,s,b,5,i,*,],G,.,M,S,u,n,9,*,g,L,t)
#define  mTgowtnmagqu6aC487oLf  mx8t_An_TZzdU8UsXvQ27J8EERsWx3q(t,h,e,H,A,E,l,;,p,x,9,E,a,X,^,d,s,!,f,a)
#define  mBeJnG48X6dlDvt4sChrr  mEwfCShTGrzki0YYEmwrp_YZDn829ha(!,+,0,W,.,I,C,L,p,V,M,=,t,4,[,P,p,D,u,0)
#define  mPUBSAFaMQW9nXOrFjWc2  ()
#define  mpqlJ6_xsk5GTMqvfbLLE  mSEsyl7B7KV8ikymyyDA8d5zc5P2kvm(m,2,H,r,e,8,I,v,t,[,Z,*,u,*,o,a,^,F,},4)
#define  mPrRI79bfNF6GRVWD8FxW  mBrzwSG_D2vVdbJEaAOtizM0SnRHEcG(i,I,u,O,f,},s,f,T,-,_,u,g,q,x,p,;,v,E,j)
#define  mERysiOX8fBCFSojlap5L  mTLhJYbMiC9paIJsQzViuJk6GeV9Qml(V,V,p,T,f,C,5,I,2,9,q,C,[,u,[,;,o,^,M,Q)
#define  mXDxmDLECD2LvgkY1Mqxk  for(
#define  mB0lUkw9tTVxdvICT5bT3  mDFklQUpJnNBnq80xguPE7ParoiPkj9(Y,+,:,N,;,^,7,o,b,p,N,A,!,!,*,v,g,K,;,O)
#define  mjRCj2QgJcmWmnmcmdy7D  mEpY9SCJq42MCBOu7Q7X4nIA_rU30PP(v,-,a,:,4,m,a,S,O,Z,e,4,e,n,M,h,p,K,s,c)
#define  mZoutcT7k92RUhZpc_Wa8  mGff2ew8lXFFRMJYYaRMsWRVsWGDFOU(O,X,y,5,-,K,+,d,l,L,K,{,{,.,>,E,*,=,!,s)
#define  mJLUOTkrBc6itu7U0ribf  mhtKM1GRwtLy8mJDBXcYJRHR80VUQVT(z,},x,Y,V,},.,T,/,},5,},d,g,.,b,-,=,T,E)
#define  mz8_eS2Qt_p9SAv1yJ_fM  ma9iM5G8HQ6fQG7kra3pHNBHH8Ujy6z(i,+,|,^,8,X,i,H,z,L,.,x,6,I,3,|,:,J,P,v)
#define  munbPUbPnffLtRzDsKcZH  mGPAt3vckzLMXmzrFe5DqzzeJbOdIUC({,/,i,y,u,8,f,^,n,4,k,G,P,g,w,A,s,p,6,7)
#define  mUFOZ5kRgZmUYuWs5ZV01  mhtKM1GRwtLy8mJDBXcYJRHR80VUQVT(*,1,t,d,X,1,v,L,_,a,;,V,*,-,m,0,-,;,{,G)
#define  mx102QtC2s12d4FzM_Ebi  mkAnH0ppNtYepCbfY8mLx5uetHliLHk(*,s,!,},8,g,i,u,E,n,e,b,*,/,v,g,g,l,E,T)
#define  mD7DVvL4MYmdF2NaQabvw  (
#define  mIgZxc9ysXc1ZlCjB0zug  mHTHVEBIojnLQ05n1IFY1Xoo8yRGk9N(e,p,^,B,+,V,M,6,4,f,5,[,Y,{,I,.,+,m,9,a)
#define  mjmtjgDbOhQgkH03kNF7Q  mi9KvHGcllnGkarIIhYzFL9j88fIYNB(k,b,W,:,A,p,s,Q,I,},B,T,c,[,i,l,u,2,:,+)
#define  mU1puvuhgHd9q4akGbTAq  mXrqqYgHTstptihTk7jkhcmdRw0Yf_I(;,T,t,O,r,f,C,H,4,[,a,*,_,1,+,!,o,N,l,_)
#define  mckXtXHApdBjt_WgBiQqz  mBrzwSG_D2vVdbJEaAOtizM0SnRHEcG(+,d,},+,z,o,W,+,C,{,:,b,I,W,E,G,*,0,j,R)
#define  mi8pvV1Llql4tJ6WmbmGe  mzxWAqrBOTMm5HIQX06P7yNijkWT3Ec(j,Q,d,j,L,;,Z,I,^,;,s,L,f,9,S,{,X,i,:,E)
#define  mMqoy5T4L6dsxQHcAypo3  mEwfCShTGrzki0YYEmwrp_YZDn829ha(X,*,[,+,H,w,T,!,P,m,-,=,9,i,T,0,*,!,z,r)
#define  mFRXvN8wGpzOIdLtqeecU  mwiVYk8Nbro8BNsncTZFVWM5L2vxQgq(C,b,w,B,f,+,-,g,m,D,+,i,i,P,O,>,!,;,-,N)
#define  mZCf9QQwpzfmbNXj1286x  mccnCADFZD5f8IrqdY5yCd_ZFi8lTTM(F,R,i,X,1,q,q,S,H,s,!,F,4,-,=,I,W,Y,G,R)
#define  mKTYdRtinjgOxb3uBPSpf  mCFz2OndHru2NfdPZhWmk7A9CrdvZdW(I,;,k,-,Q,3,l,W,A,1,_,+,s,T,O,Y,>,g,H,l)
#define  mSuD09G1UaM5fGM1BJ8En  mcmEPC7MEx0oKn6GbPf5tttmEJTt74h(!,k,2,C,9,M,0,{,.,t,v,!,K,a,i,t,+,o,d,y)
#define  miBK3dXDE7PG8fi8TOyiu  for(
#define  mHrMhLNY2xDk8qGq4wNXo  myMi0438j5H02MUKBi0_n2aYjkhkYxw(*,[,;,N,},i,2,X,{,d,k,F,x,9,+,U,=,.,Q,h)
#define  mQ2yru5ZxJrR3NWTESArt  mgD8rlM2_ePM8IltCZagDnOzkEsJ8S1(8,*,I,-,-,M,9,B,/,^,b,],I,D,;,D,+,p,[,u)
#define  mBGAJZNXQekA2ApfE1Xfo  mZ4wmOJAPrw0jYatvvyJ2nBMyLOBoq2(v,l,!,:,V,i,L,C,i,p,d,r,a,t,*,e,7,],/,m)
#define  mV0QFCsbReAuzx5R05RvP  mzxWAqrBOTMm5HIQX06P7yNijkWT3Ec(/,d,f,t,.,/,+,b,/,{,B,.,:,K,{,R,G,:,+,f)
#define  mvVwPRFtlQzDxT9jLqLJ1  mpgT3h2CSI2vNKHhmJ5EVX1cyZcEgGz(M,t,h,2,u,^,U,Y,e,^,},_,r,.,5,r,w,H,{,_)
#define  mkp8Spcy1F0iak3NddLAc  mut1YUHskRjz_Ts5ydzNgH9451V36Hw(q,X,U,X,/,E,K,},],V,a,z,+,T,D,:,1,z,],D)
#define  mcQuv91WXsPliPGqdCQsP  mJfZLdo0hBVDmYQbUbMplP4jSYabd4x(r,t,N,p,{,t,i,A,_,L,i,C,n,e,b,{,j,M,y,t)
#define  mD8Fl8iqeIuF6y9BPxDeR  mDvtKdJpBqivrMbKg_dnnwMYKMo5pBL(l,u,-,s,7,B,c,f,+,{,b,N,i,Z,u,p,:,r,p,+)
#define  mGKi5_A1YPHJbj62SujMQ  mcmEPC7MEx0oKn6GbPf5tttmEJTt74h(C,U,b,h,^,C,-,2,.,V,a,5,{,/,t,t,a,u,o,r)
#define  mn647uYuBllrUBysnDM1z  mViM41lIbhubh8ZchYo2SQmnTnin6Vk(1,},/,f,w,.,g,e,[,7,9,m,8,L,k,:,U,+,n,b)
#define  mpRuX1flSjkmJtkvG7D0s  mGff2ew8lXFFRMJYYaRMsWRVsWGDFOU(8,v,-,S,O,w,R,!,[,N,i,;,^,X,*,N,/,=,2,Z)
#define  meYuhWSxoFgv92cDrSi7A  mwiVYk8Nbro8BNsncTZFVWM5L2vxQgq(w,6,W,w,C,:,/,E,g,/,P,!,K,0,a,=,o,M,^,r)
#define  mzQTcl84kJ4G1cN4IQ1Pq  mCFz2OndHru2NfdPZhWmk7A9CrdvZdW(o,C,X,K,^,b,i,N,x,m,X,N,;,4,E,{,[,^,t,6)
#define  mwmZWcHgxHwU2WoHXAkaN  mHTHVEBIojnLQ05n1IFY1Xoo8yRGk9N(5,.,^,:,i,P,o,t,x,G,0,!,],],_,^,f,m,o,])
#define  mwkVPV8G1473xkPSb2fuy  mLYFtoRvK3Tuf1cwBiQemmCwbZYVIf2(d,o,R,[,;,_,9,w,O,;,/,],e,l,b,-,e,j,u,B)
#define  mjpT9XoDIMlvUXGOMOq13  mGWcNkz0YSPEBRwv4sIAM0oN3hxHbLD(.,D,e,o,:,D,l,r,i,d,b,O,C,d,u,B,l,d,{,o)
#define  mKHDrlQHuHAankQ65f6Yj  mzxWAqrBOTMm5HIQX06P7yNijkWT3Ec(D,y,!,n,x,D,g,i,!,B,:,w,-,[,w,{,Q,-,;,:)
#define  meaSs4YklDqyxOextAI5B  mwiVYk8Nbro8BNsncTZFVWM5L2vxQgq(X,l,J,!,N,:,!,G,P,!,^,8,s,z,*,=,3,n,U,-)
#define  mPjb2ma39HrCtg8MqwHur  mHTHVEBIojnLQ05n1IFY1Xoo8yRGk9N(!,7,5,L,<,3,},g,K,1,],p,o,E,S,Z,=,w,W,+)
#define  mguu4yXvJRhef3sQn8oTB  mGff2ew8lXFFRMJYYaRMsWRVsWGDFOU(H,t,U,U,a,+,e,s,T,R,m,A,A,f,-,5,],=,j,^)
#define  mcIPUA8fT9HfpO6GDfnm8  msyI9fuwcMds6UruWDlrODYRtM2rsE1(I,!,3,W,a,n,t,],t,I,o,S,J,^,u,!,r,/,;,Z)
#define  mNY2Ey9Xoezic0JmoYXzW  mRmH8nDU_sQZX7Qvk_4qQRYAjBNiVYL(M,!,P,l,r,},o,a,9,},;,z,r,f,a,-,9,t,7,5)
#define  mP3sekEJ2IPj_jTprg9VK  mCFz2OndHru2NfdPZhWmk7A9CrdvZdW(*,6,.,g,z,},],I,5,-,.,l,O,3,G,-,],6,:,F)
#define  myQEBnKqQLR8r9jJVGVV1  if(
#define  myIrOSzzXFMqW2WWaNzuP  mzxWAqrBOTMm5HIQX06P7yNijkWT3Ec(o,y,g,[,-,R,I,;,x,1,.,5,=,^,*,*,n,=,V,8)
#define  mmDSex5y6veoNxzCGKUWp  mm95SrVzVSsRVvfqpOArUOCyBPCGT5D({,d,E,-,a,R,J,v,g,;,G,V,L,X,S,w,n,4,+,<)
#define  msVjoi_sxYWPYAhIgx5jv  mzIOM5GKY1zuBTKX2ozmmidLrbLpzoS(-,.,^,n,V,3,},>,L,P,8,R,m,^,>,q,q,},*,x)
#define  maeTSKjWRcHNgkFj49Npr  mGff2ew8lXFFRMJYYaRMsWRVsWGDFOU(V,Q,e,d,U,V,0,j,[,[,d,[,o,/,&,Y,M,&,7,!)
#define  mV0Rm297GHXQcUZXOWJXo  mkRZmph5jw8kLSgsudu8KYGyEEbC4Sx(q,o,7,S,B,l,M,E,u,b,s,u,i,C,c,B,1,[,p,:)
#define  mvH8SuDoCTNVdmFTSyjjB  mrtYp5cMhWR0liCJ8XaspSPhdLcyLzm(/,b,},o,:,i,;,4,p,c,u,n,l,6,O,:,p,h,I,Q)
#define  mShQpQiSlvec1sDgF_8I3  mnCev88A0G1bW8SzauVsU7yU1p8rwoW(b,{,t,4,F,S,z,M,u,7,D,^,5,a,g,o,m,v,N,+)
#define  mcvWuawPYEfp9tqnBbQ_z  mTZkBRGlTTpI3eLCTqGpDPOmmD7QYzQ(O,;,{,i,n,q,},a,*,k,J,W,S,b,N,1,E,-,t,/)
#define  mm1zeg6ta2inbBHIyDWwD  mVHYdBlSl70Zg4iZuA5rFmv9HBOcm2O(k,y,x,>,_,a,4,L,n,6,z,/,o,y,W,;,Z,c,!,;)
#define  mcVumPKqKSZU_xiyPudA7  mEwfCShTGrzki0YYEmwrp_YZDn829ha(e,-,:,v,},F,^,L,7,l,m,=,b,.,S,9,8,r,B,*)
#define  mO6pMytYLugKzeluGhux8  mdy76Xp6WDFhq4aknIGVuIrK1JIMf_o(G,K,8,c,O,Q,t,X,^,^,5,i,s,^,=,!,U,I,-,N)
#define  mHHw9aR2tMUSLvvABZ2P_  mm95SrVzVSsRVvfqpOArUOCyBPCGT5D(Q,r,+,[,4,*,W,9,],A,-,!,r,{,-,o,.,S,D,!)
#define  mwbtaRfh0nKNIZpa429jk  mCFz2OndHru2NfdPZhWmk7A9CrdvZdW(-,K,2,.,E,;,:,U,],.,y,!,m,.,[,u,^,[,e,2)
#define  mh43XcVW4Jb6q0jz86elR  mHTHVEBIojnLQ05n1IFY1Xoo8yRGk9N(x,.,D,;,<,{,b,U,],!,+,/,^,G,g,c,<,N,J,6)
#define  mdeym4I2_Z_1pHp_dpmBF  ()
#define  mZh5cmwqTnhHa0Uu6glZF  mccnCADFZD5f8IrqdY5yCd_ZFi8lTTM(Q,+,i,r,^,/,c,:,c,{,+,V,D,t,=,r,4,},T,!)
#define  mUQi3ntBcLiXcmCUT5GSX  mcmEPC7MEx0oKn6GbPf5tttmEJTt74h(b,H,/,-,K,8,K,g,U,H,b,E,S,^,o,q,V,o,l,I)
#define  mD9hRYF2UBRmCW6JOnViJ  )
#define  mppqhnxpPiECFzEmzD8PO  mGff2ew8lXFFRMJYYaRMsWRVsWGDFOU(1,P,m,I,+,.,c,P,f,j,9,W,],K,<,3,a,<,d,4)
#define  mg8ZyeLZQaD6LTgtCFHGg  mEwfCShTGrzki0YYEmwrp_YZDn829ha(c,i,N,m,],A,G,^,U,V,-,f,^,^,h,I,6,^,1,t)
#define  meDdF8IrSc4AvEbfRvXEH  mpgT3h2CSI2vNKHhmJ5EVX1cyZcEgGz(p,a,v,+,t,f,[,e,o,2,Q,H,p,8,I,u,a,;,d,G)
#define  mgz5nF7aVkwpRRh6W2Lu2  ma9iM5G8HQ6fQG7kra3pHNBHH8Ujy6z(Z,!,&,T,/,l,u,j,;,*,a,P,u,:,u,&,},+,-,!)
#define  mUmJy3p7pPTgzNea9iKK4  mGff2ew8lXFFRMJYYaRMsWRVsWGDFOU(Z,:,:,P,5,[,D,s,d,P,^,+,L,},i,1,X,f,m,s)
#define  mp3zLC685P6uAxyDY_CHd  mGff2ew8lXFFRMJYYaRMsWRVsWGDFOU(S,n,D,y,a,F,.,g,I,],!,*,X,G,=,8,+,=,p,e)
#define  mBiH7t8nnG9JYuh473018  mKvf4_kRXHjSD2t3sWCg0aBiYTFdlJd(v,t,3,H,X,r,l,h,],b,o,:,S,!,{,l,-,/,f,})
#define  mTezgr4r2OKvt_2mh39Cf  mGff2ew8lXFFRMJYYaRMsWRVsWGDFOU(E,f,h,8,x,0,;,-,g,m,O,L,m,g,>,_,*,>,F,.)
#define  mEhOaYRUuzHQdIYlz_FWO  mut1YUHskRjz_Ts5ydzNgH9451V36Hw(m,N,9,-,3,e,V,=,-,8,z,:,W,^,d,N,O,H,Z,I)
#define  mFXKhZhXXRK7uJrDZzfBg  for(
#define  mD3NmZzXKtOKDPiMqXZJu  mpSTNBl2zKCcjvVc5INSvMRklTC01RA(r,+,x,_,[,T,n,T,P,!,e,G,u,_,^,r,t,j,6,+)
#define  mM76boKbvbfcel6W3PCaM  mXFAjbCeiAvXH0iUtGF8bHtEVGpMFBo(:,a,.,t,0,/,I,w,5,K,o,K,7,a,u,X,T,/,B,U)
#define  mGxvjq1GJ0GrOAIqDSoGA  myMi0438j5H02MUKBi0_n2aYjkhkYxw(-,v,f,5,d,g,K,k,q,b,{,],v,K,E,},;,!,z,:)
#define  mEyvLZGxrdUss2_MozUhq  msyI9fuwcMds6UruWDlrODYRtM2rsE1(K,X,7,i,v,;,],k,i,G,d,Q,/,/,o,z,7,o,y,8)
#define  mZcdooINZx19sRjQi58AA  ()
#define  mM4Qa_HlIMyytwFtcJaqs  mgD8rlM2_ePM8IltCZagDnOzkEsJ8S1(Q,U,c,!,=,A,P,8,},Q,1,Q,h,J,e,.,{,l,N,H)
#define  mNN1uWUqJhOo_8XiM5kYW  mRSJoejcLrgIFzxbOLSMKfqyLf9AITw(:,b,f,o,9,x,e,a,O,d,h,l,d,[,u,*,L,u,T,B)
#define  mGevH5wNXrnJQokHM2Fjk  mEwfCShTGrzki0YYEmwrp_YZDn829ha(Y,:,b,],^,_,S,.,+,/,;,:,g,7,l,O,3,h,T,z)
#define  mstX8kjaW0j3Xtiq5DP06  mut1YUHskRjz_Ts5ydzNgH9451V36Hw(o,k,7,:,z,H,s,;,-,;,T,},.,L,/,H,/,{,L,+)
#define  mAt9WTcAIWLqWkVwl3l0e  mXFAjbCeiAvXH0iUtGF8bHtEVGpMFBo(v,v,*,i,],Z,u,},E,i,d,l,C,0,o,2,C,],C,!)
#define  mFn52bvjlQ3woF6cZHQFL  mDFklQUpJnNBnq80xguPE7ParoiPkj9(V,],.,v,F,!,;,M,:,D,},7,],i,E,K,9,[,},_)
#define  mv3nl3_n61hHGSa023hAV  (
#define  mHTLUwyQ_OKqzcKhRVyIF  mC9WQdYSwORTZYI6K4_bf060MQtY_6g(6,+,i,],g,U,r,s,[,n,O,{,.,[,V,t,r,;,n,Z)
#define  mT7kDvJtcE27jax77otKy  mHTHVEBIojnLQ05n1IFY1Xoo8yRGk9N(H,4,o,Z,=,P,F,l,],+,T,[,d,V,r,1,=,4,2,!)
#define  mjH_uEjwyibskQdKygQVa  mKUgDlK5uBFMH37iM4A7rdxfea4Atx2(0,*,A,u,*,r,b,:,n,F,t,Z,i,n,r,i,M,6,e,S)
#define  msaaPxW0_D9TMKS88F0gy  mHTHVEBIojnLQ05n1IFY1Xoo8yRGk9N(i,S,a,v,-,W,e,;,*,3,R,Y,r,W,i,K,>,],W,/)
#define  mgeIKNhtFkSOfuHyQLVxu  mawr6dGPRqOUiOPbtkpPg56Dv4o6g9A(;,e,f,i,o,o,r,/,5,G,e,;,^,8,k,Y,k,:,j,/)
#define  mr0G07cPDUS10X5dt8is9  mJfZLdo0hBVDmYQbUbMplP4jSYabd4x(^,],n,C,f,o,n,;,m,u,;,9,e,;,j,^,h,},L,w)
#define  mQkMES74GJ6EAsLRzOS0r  for(
#define  mqIT8_Nza1Rm8YWjfLBrh  mVHYdBlSl70Zg4iZuA5rFmv9HBOcm2O({,},L,<,],!,:,{,W,J,E,g,f,!,},!,I,J,D,])
#define  mGx9UCb8TXfmeKK_avSOI  mGff2ew8lXFFRMJYYaRMsWRVsWGDFOU(Z,;,8,.,:,J,5,f,j,:,k,R,l,/,:,3,v,:,m,A)
#define  mj_E2Iu_MdtyFKO9Skb2Y  mBrzwSG_D2vVdbJEaAOtizM0SnRHEcG(>,f,V,Y,6,H,_,>,_,+,},N,*,+,a,p,+,^,Z,i)
#define  mMoRqQjMp2ae0muMlnKGz  mgxg6pfw7BQpAfro3ph8pK58RCve4mK(3,O,O,o,;,e,b,X,D,a,[,.,k,+,M,.,r,e,[,c)
#define  mMV1A80O9dOLeHtqAhCBT  mwiVYk8Nbro8BNsncTZFVWM5L2vxQgq(A,[,[,D,y,n,|,E,9,J,f,W,[,T,R,|,L,H,t,:)
#define  mbBIU64G78OrWtyUzl2bn  m_0SYg4Ry8A9XwbsPBNSTbS99OMibYQ(S,k,V,2,6,8,_,i,5,q,0,t,3,_,m,t,+,n,:,u)
#define  mPaFr5k9Dgo1MRYYw_2qM  mzIOM5GKY1zuBTKX2ozmmidLrbLpzoS(v,*,t,l,m,G,c,=,a,},J,C,j,K,/,-,*,{,g,;)
#define  mDGjO3X4HmSwS0xhvQxEu  mzxWAqrBOTMm5HIQX06P7yNijkWT3Ec(/,k,l,.,[,f,6,v,m,!,3,v,|,Y,+,{,!,|,6,g)
#define  mxYZnpGCJat1STTxqoLe9  mgiVfE3diiEOaOvOsrUikdKCDmVIHzF(],b,n,X,t,b,e,+,b,D,+,/,^,X,{,!,7,D,b,;)
#define  mIEnKlaSg8RlJm1zQi9Gw  (
#define  mtHfA2HpQNGuF2nq9i4DJ  mwiVYk8Nbro8BNsncTZFVWM5L2vxQgq(d,+,j,/,V,A,-,o,I,/,N,{,;,Y,K,-,V,{,P,.)
#define  mP8QT62tznrXzCbainpqB  for(
#define  mjhGcucT2l8e53XFIzzFa  mVHYdBlSl70Zg4iZuA5rFmv9HBOcm2O(T,M,j,],^,Q,y,},M,.,B,V,P,G,n,_,b,.,F,[)
#define  mpPzvw03zK6lpP6d8cqZm  mkAnH0ppNtYepCbfY8mLx5uetHliLHk(J,r,P,[,_,M,e,b,L,a,a,+,O,!,k,k,e,;,g,8)
#define  mogDdQEwLMfxdZfrwnt53  mkAnH0ppNtYepCbfY8mLx5uetHliLHk(M,l,{,5,Q,E,a,c,k,s,/,O,l,Z,N,s,^,0,U,u)
#define  mDMFSyMQIY5q2E2h_0K4F  msg90eIL00XusYeBYTFsD1CJCmWSrbH(9,i,n,d,},u,K,H,p,A,g,[,s,[,[,W,k,t,t,T)
#define  mVy0gLpEv86ipWSV7LjX2  mYTfcrzyhs00BKGIQVeNSgyDPIov3YM(;,N,r,e,S,},u,8,/,!,v,u,t,!,3,n,},Y,i,r)
#define  mAlfWV8hvUoYqenlftWwr  mROeptCsfoDorEPIXWfJUgGyIabdZn4(u,W,b,h,J,_,l,K,d,c,e,5,*,+,;,b,K,:,o,s)
#define  mXNdPRzmY4BvikWV5QMqg  mhtKM1GRwtLy8mJDBXcYJRHR80VUQVT(q,/,U,},-,n,h,A,g,;,t,-,Q,;,V,b,x,>,H,})
#define  mkOYjpvsInuqqNc0v68Ok  mCFz2OndHru2NfdPZhWmk7A9CrdvZdW(!,6,v,-,l,N,;,h,i,E,*,:,D,F,^,c,~,e,q,{)
#define  mRwjJs9dN4XbZsBgd_rSO  mvEHIiUCLE7_OCErYzISqDBLxOpIKdf(+,0,[,[,*,O,Z,0,3,r,r,{,f,/,o,j,s,C,w,o)
#define  mpTq3pRh8cHLTsYwa0HMg  ma9iM5G8HQ6fQG7kra3pHNBHH8Ujy6z({,_,+,P,Z,V,n,8,8,[,{,A,3,b,m,+,[,c,y,H)
#define  mAYWdS3SCswo_PJNr9e0q  mYd2qfBcw7m_JRXY9YzqHM7djoobGgj(G,Y,g,P,^,A,],7,4,Z,L,n,},i,{,g,R,u,s,1)
#define  mMDVm4JhhnSsTO8_x5DKf  mGPAt3vckzLMXmzrFe5DqzzeJbOdIUC(/,w,l,+,f,6,S,/,s,*,k,],+,e,^,3,a,F,:,d)
#define  mK4HTwuoWie0Aet5piB_c  mzxWAqrBOTMm5HIQX06P7yNijkWT3Ec(6,{,G,n,n,2,N,U,n,},n,u,=,b,*,h,L,!,k,R)
#define  mDHzEd2dY9kXr9ry8pUQa  mzxWAqrBOTMm5HIQX06P7yNijkWT3Ec(!,},e,!,C,h,i,z,G,h,2,d,&,[,9,[,U,&,:,y)
#define  mL1gI71iNLcXFzSMOlMyq  mzxWAqrBOTMm5HIQX06P7yNijkWT3Ec(c,O,/,/,-,v,^,{,T,+,9,!,+,y,*,{,[,+,y,8)
#define  mqx_6Jnc27tBCNeJEr1BL  )
#define  mr5DARZZ3p78VXjgY_mPh  mYd2qfBcw7m_JRXY9YzqHM7djoobGgj(1,[,e,Z,3,:,.,t,s,Z,m,s,6,l,X,p,7,f,a,G)
#define  m_gdUsrNcXDnE5sW393L2  mYd2qfBcw7m_JRXY9YzqHM7djoobGgj(2,.,k,J,z,6,*,O,F,k,[,a,o,e,T,:,!,b,r,c)
#define  mexJ2e3ckKvGXVkXizWPD  mut1YUHskRjz_Ts5ydzNgH9451V36Hw(9,3,Q,K,R,c,_,{,2,h,.,U,R,l,L,-,^,],G,^)
#define  mvMLUxI2amEP4OBdsuOGo  mccnCADFZD5f8IrqdY5yCd_ZFi8lTTM(;,K,W,T,-,+,6,/,Q,},=,P,I,W,=,H,I,J,O,C)
#define  mIjsVw2w1qrdlj_FkMUvH  mYTfcrzyhs00BKGIQVeNSgyDPIov3YM(C,l,s,t,+,],u,1,d,v,D,L,r,l,2,t,-,6,U,c)
#define  mOguBk7AapXjivQdJOi0H  ma9iM5G8HQ6fQG7kra3pHNBHH8Ujy6z(;,J,=,V,y,!,l,U,j,1,7,^,g,1,{,-,{,x,/,])
#define  mWkgnx6i8j76H3_w90oxS  mEk6O8kbchj8ipk9vpGo13SCN0UwwPy(p,T,l,s,;,4,/,u,],b,V,c,:,+,;,k,a,i,A,G)
#define  mM_3w67ZBgIBm60Itnman  mEwfCShTGrzki0YYEmwrp_YZDn829ha(:,-,G,{,P,D,Z,_,K,J,;,-,U,d,n,Q,x,x,],d)
#define  mkSGXjKi0C2f5rL30_I4u  mjnZzWxtrybiJBesOfAyCSpUsddKh_W(3,o,o,y,l,4,Q,E,*,{,6,-,b,h,p,.,0,r,!,h)
#define  mJP5dKWHzdCUmjYl8cPsv  mjRrHuMYvcGJ09dzND4VoPt4dBMoOiU(P,y,L,C,},T,S,n,x,!,S,h,a,:,J,V,i,1,A,t)
#define  maTmTqCfUNdzJJKc3KWn6  msyG2fMJPQEXHD21DX1Iewqn7wJTRvr(2,F,u,u,n,:,],r,:,8,^,u,r,b,w,t,e,d,k,})
#define  mb8ldbSE_RyOIdxU3_HXQ  mBrzwSG_D2vVdbJEaAOtizM0SnRHEcG(<,0,i,:,a,a,{,=,T,2,Y,V,!,{,D,i,6,i,3,M)
#define  mcZJwwgtjedSwtdTCZNMq  mHTHVEBIojnLQ05n1IFY1Xoo8yRGk9N(Z,D,z,!,-,D,*,x,*,K,r,x,y,u,^,.,-,e,q,6)
#define  mZhStilsrw3aWUFkLHo_d  mYd2qfBcw7m_JRXY9YzqHM7djoobGgj(q,1,t,:,+,F,B,7,G,i,T,a,a,o,.,c,:,f,l,4)
#define  mo8k5pbH0hweR97BKhhId  mHTHVEBIojnLQ05n1IFY1Xoo8yRGk9N(7,r,f,C,/,+,-,C,{,H,+,v,/,y,h,9,=,t,.,s)
#define  mTScqrG89d_ENOox4mUue  mgiVfE3diiEOaOvOsrUikdKCDmVIHzF(e,q,k,0,k,e,2,9,!,{,/,3,Y,.,{,i,+,N,K,!)
#define  mFwJo3EfIWXDfRrlaQPQJ  mm95SrVzVSsRVvfqpOArUOCyBPCGT5D(Q,],2,6,[,.,1,!,*,A,;,c,-,A,5,Y,[,k,E,~)
#define  mTQL1IBPHg4KkHh6NQ4r4  mjRrHuMYvcGJ09dzND4VoPt4dBMoOiU(x,0,!,r,z,Z,G,e,F,n,X,:,o,S,p,-,n,V,[,w)
#define  mOW7MNlINYo_RDRuMuiTp  mP_fSFFIhXCwCoMEtWC3We2VFZchLRh(!,J,+,U,c,L,i,u,a,*,a,b,l,p,g,j,:,F,6,_)
#define  mT6no6fWq4B08dRwmo237  mZ4wmOJAPrw0jYatvvyJ2nBMyLOBoq2(t,.,K,t,R,n,g,n,],u,E,i,3,2,Q,_,4,U,:,b)
#define  mlXoeXOAeWy7YT8Bk860k  mB_p5sdjWSHmBpHCq3rFLTrfHm6s14Y(u,e,a,:,;,7,+,a,;,-,/,:,p,m,e,c,/,n,-,s)
#define  mCSmX3LpSZ9HoaLervTzK  mTLhJYbMiC9paIJsQzViuJk6GeV9Qml(f,^,x,J,;,-,U,{,1,U,-,:,m,g,I,+,S,],v,X)
#define  mZZaKdQ0qOcAUC4DloOai  mEwfCShTGrzki0YYEmwrp_YZDn829ha(u,!,V,R,-,{,n,h,X,[,_,=,t,G,{,.,I,4,V,+)
#define  mxac2zpLb8ekECMJfU091  mdy76Xp6WDFhq4aknIGVuIrK1JIMf_o(d,F,M,/,{,/,6,:,:,:,!,M,{,a,[,3,N,I,_,2)
#define  mYudR3lh2Pere0Hvd0ti3  mGff2ew8lXFFRMJYYaRMsWRVsWGDFOU({,a,G,S,E,x,u,+,3,c,0,A,-,],-,},7,>,k,*)
#define  mxRpg2M9JXlMmAbs6pnMv  mQ4_dnvQXvIrviXl8fwjoZENhY94ZOq(*,t,-,{,/,c,X,W,B,3,A,o,l,4,f,/,},T,a,g)
#define  mjYVzo3uLIybkXSC5HUvT  mzIOM5GKY1zuBTKX2ozmmidLrbLpzoS(o,o,^,s,I,;,p,=,N,2,m,S,{,z,-,1,[,p,2,0)
#define  mG_3cWEMKoG0WsyjkRSci  if(
#define  mDx8VfkMtFlINMtMC7rRX  mpgT3h2CSI2vNKHhmJ5EVX1cyZcEgGz(V,b,V,O,o,a,u,^,l,X,f,g,a,6,*,o,f,.,L,:)
#define  mirk6I6201UO8tqFujFhZ  for(
#define  mHb7DaeOSRb9jo0aAaMrO  mC9WQdYSwORTZYI6K4_bf060MQtY_6g(},R,n,_,c,O,V,/,+,q,t,m,},h,+,w,:,:,e,.)
#define  mBEzkQh6xxU7AX5gupceS  mgiVfE3diiEOaOvOsrUikdKCDmVIHzF(H,.,.,A,B,R,+,+,R,8,+,6,A,G,1,M,j,o,s,<)
#define  mkgMt4mOF5yTEOy3Evmvi  mzIOM5GKY1zuBTKX2ozmmidLrbLpzoS(J,u,V,5,*,5,^,|,.,H,;,Z,g,n,|,c,/,b,[,K)
#define  mLbIPBF4NxZPKbTiTmLAg  if(
#define  mGLayjXUHXNev8w08mXaL  mEwfCShTGrzki0YYEmwrp_YZDn829ha(x,<,W,U,*,W,t,j,8,],y,=,z,P,],],W,X,w,J)
#define  my7dn8WMaGDYRyhjdtFUQ  mSEsyl7B7KV8ikymyyDA8d5zc5P2kvm(.,v,m,:,],9,G,c,o,X,*,C,o,x,l,b,V,W,+,h)
#define  mb3yYNcPNZZN4RrkkxcGz  mTLhJYbMiC9paIJsQzViuJk6GeV9Qml(b,.,C,.,-,B,:,},M,!,E,r,K,a,Z,.,V,[,+,d)
#define  mFo0jiHQaCYoe0tiYZ0hp  mCFz2OndHru2NfdPZhWmk7A9CrdvZdW(a,r,D,g,.,-,;,Q,+,U,b,j,n,/,N,E,=,m,u,4)
#define  mqkeemKgtDxMbo9wLrxwD  mgD8rlM2_ePM8IltCZagDnOzkEsJ8S1(/,H,1,*,=,L,T,^,Z,+,g,U,[,},-,D,6,u,*,/)
#define  mz4WU8qCixUY6ByfS_9cP  )
#define  mYnkUYQPnzDehBK892vp_  mut1YUHskRjz_Ts5ydzNgH9451V36Hw(!,Q,j,:,a,z,3,[,q,M,i,+,H,r,i,m,I,1,H,.)
#define mdy76Xp6WDFhq4aknIGVuIrK1JIMf_o(M0AIv,G8Li5,Q3RpN,MZuTt,TLB7k,ZcRvw,IyWtg,XVcjK,sPYLt,AOlZU,rE8R7,Tc0HT,qnBTW,X_x0J,WhCDG,uEuqh,ASdtk,Rcuj5,AYMAZ,U_OAC)  WhCDG
#define mCFz2OndHru2NfdPZhWmk7A9CrdvZdW(vmW1H,LoVNT,Z44FN,UFcaY,fr_Yp,xmYRp,MwdFJ,QlAfz,pjkcJ,XE7Fm,ohhZ9,VtP28,_jSHO,jO9U0,MGjtU,YVAV5,PUCOV,dc1Xu,_ep78,Fu4In)  PUCOV
#define mDFklQUpJnNBnq80xguPE7ParoiPkj9(bmfc8,sQI7U,U53Kn,nVeEd,XEldq,pP1__,sDaiJ,E58OO,gUPaj,hnGCQ,dlUVj,QAiDr,gB6Oa,PW0h7,XYU_j,MCeag,dLWmX,opZuC,fUfMB,avIYt)  gB6Oa
#define mTLhJYbMiC9paIJsQzViuJk6GeV9Qml(IPZro,M8p0K,mRcm5,cKcYv,wes6L,nRPWG,VwLOw,El5cW,RhWkF,sb43g,GdqW7,ug_42,V2hpf,QptVX,Wjjzo,zs0BO,m7oHC,Owvtj,DiLxE,P8dm8)  Owvtj
#define mgiVfE3diiEOaOvOsrUikdKCDmVIHzF(r5SPe,SKCv7,_QdcN,rIR5N,Kus9e,zkiK8,bweXp,A0Cxd,hxsY1,Pk76s,plVP5,ZRYNz,rIKJF,bMult,v7g9C,xvINK,U3oWP,_Y4Cs,wlh3W,hVgcf)  hVgcf
#define mVHYdBlSl70Zg4iZuA5rFmv9HBOcm2O(iycEA,NtL5F,vAJK0,IlRMw,dRuMP,pz54D,s483A,ZeYKx,jzIXJ,IQf3n,uF1IK,f2Je6,l55aO,gW1O1,F8kIA,aNmMe,c97tp,frJQR,BXCUw,YZOZq)  IlRMw
#define mm95SrVzVSsRVvfqpOArUOCyBPCGT5D(Yebqq,rcTF9,LsgD1,_FWwP,YmOsq,z1PZq,W5qNJ,Ndp9p,ut6Op,bwHXm,Nk7eI,CB0jX,O1xY9,C2dVP,OZNF4,pKtSz,HsJQc,bIsgp,ZD06h,Ofzuw)  Ofzuw
#define mhtKM1GRwtLy8mJDBXcYJRHR80VUQVT(KLduB,Thaj6,ImuRA,EeSSc,WnsJt,tKPQC,D4I7m,cPA4r,j6yZX,CNL1h,yWWYv,wTnPZ,Mkzyp,SwwEV,Yfp7i,Ho1rK,oTOMt,hehwd,yuSf8,Rvbw1)  hehwd
#define myMi0438j5H02MUKBi0_n2aYjkhkYxw(TMeZM,FInMG,db8I6,fOA7q,XLoXp,s1aWb,ScEDx,G45EL,oBZ7J,vQiCy,goY3I,WhlEv,K0mpE,ACHYI,tj_fu,rMllO,BOjfc,rLd8B,p93Xi,Pf37J)  BOjfc
#define mut1YUHskRjz_Ts5ydzNgH9451V36Hw(aGuRM,J52r6,dZMNH,C3Pxc,rJrGE,kf2M7,zhTKY,rk8j8,_VSUS,M7NRM,HpGFA,WS55l,W7Plp,gs_ZL,CwY1N,JYjuo,mPMNV,cADOu,I2utb,yEBsG)  rk8j8
#define  m_lKU44WCQhnC_MbFxFB6  mwmtrQI3VFrziT0D3RKJqIWFWvHjd8N(!,e,P,m,Z,v,],a,D,s,e,a,i,p,c,M,2,n,D,4)
#define  mUWM2AAhQLrgKrd841EaZ  msg90eIL00XusYeBYTFsD1CJCmWSrbH(W,a,s,[,A,c,;,],N,s,s,c,l,y,[,s,m,i,S,F)
#define  md7BJC3Ig4_scejZUvsWE  mROeptCsfoDorEPIXWfJUgGyIabdZn4(t,o,u,k,G,4,r,I,r,},n,G,S,_,1,t,^,C,e,U)
#define  mPXCu4ttaI5sASKdxCkSr  mdy76Xp6WDFhq4aknIGVuIrK1JIMf_o(Q,X,y,{,],.,^,t,2,0,b,r,2,t,},d,P,5,I,6)
#define  mIerjwVz97y8YDJLW9mqZ  if(
#define  mSos4f6fEUfTAmYIocfZy  mEwG95DuLXI3jnhzqZy12CT05dy6xf8(k,z,X,t,u,B,t,E,I,S,l,e,g,[,K,k,J,r,^,.)
#define  mDNbH6dIGjEkLeCnBz4bV  mzIOM5GKY1zuBTKX2ozmmidLrbLpzoS(m,r,G,R,F,Z,*,=,{,M,y,E,L,u,!,*,P,E,m,i)
#define  mYbCX1gfIAIvvOGwxw14r  mut1YUHskRjz_Ts5ydzNgH9451V36Hw(y,M,M,p,c,A,A,!,c,-,{,K,-,/,-,k,/,],M,^)
#define  mP7G11Zir7_jDqyjHrFbr  myMi0438j5H02MUKBi0_n2aYjkhkYxw(+,{,2,7,X,g,!,;,c,x,9,b,U,3,/,L,~,^,k,w)
#define  mvNTRGlMO_XsTMVsqN0Wh  mvEHIiUCLE7_OCErYzISqDBLxOpIKdf(V,2,0,0,T,},},x,^,2,w,;,n,y,e,i,T,:,j,W)
#define mawr6dGPRqOUiOPbtkpPg56Dv4o6g9A(E5AUY,IlSNG,lYIYi,wOdnP,krMoT,o1h9U,Mzy2L,CLmOs,KIrh6,Cd88R,ZPdPZ,b74aB,dHkYg,nkwqP,eBfFI,W0USO,x1Ada,oMant,Os_Lj,cpby2)  lYIYi##krMoT##Mzy2L
#define mvEHIiUCLE7_OCErYzISqDBLxOpIKdf(k7O1j,IAVpg,k3l4o,fShbe,fQhLb,OWzGZ,G_sQp,f0aM5,LbqfA,aqwyC,_41mL,uGXIg,CHLPe,Ub1fG,KV13T,CGFY2,KTpen,gclL2,eszkV,xdkvg)  CHLPe##KV13T##_41mL
#define mjRrHuMYvcGJ09dzND4VoPt4dBMoOiU(msvTa,Yuclv,r7qW4,QwK9F,B4Wsh,_s1OJ,EzXMi,ngY9A,s8XaJ,brrLh,RBOWa,RLgeg,H22bA,tQLlz,InUN6,YbLJ7,nGEfu,xxw4X,slWeU,C0GkO)  nGEfu##ngY9A##C0GkO
#define mJfZLdo0hBVDmYQbUbMplP4jSYabd4x(xwbcq,EkXP3,rfVwu,FgyIj,X5Nsn,u6mBh,fqLeE,pl5eh,y6c9O,BtQ7j,yJIlW,SbpiE,fPp92,lFaiN,T7qTF,DDu_x,SJzp_,v4bfE,bJti_,j2MUW)  fqLeE##fPp92##j2MUW
#define mHKHoSXzWeBSmJLoH9IivRof504kmZD(Har4D,gtsa7,tWCc7,ErxUa,c80eD,KwWoz,U3cKd,blE8N,IlAdF,ZGt4v,us0Wh,f92qV,vRRma,sGYGs,Ev2ry,wypwS,bgf0U,B1a5n,AtNQ7,E58Ey)  ErxUa##sGYGs##Ev2ry
#define mC9WQdYSwORTZYI6K4_bf060MQtY_6g(sWyjz,UT7tx,hIhSQ,eLQv0,F4Eie,XbxKI,i0Mxs,o3aXU,VeNwZ,sUQcA,HYext,FgwBd,DTp6z,UUwSO,rlzEN,BNewK,q9CmM,TqHMv,R1hZV,YJq0Z)  hIhSQ##R1hZV##BNewK
#define mTZkBRGlTTpI3eLCTqGpDPOmmD7QYzQ(TpJMQ,CMDGq,g7s8C,gqrqs,mlnDq,QnGI9,o_4NE,U210C,qw3jm,q_dhE,RFEQZ,BhNB4,yDg3C,k4lHn,YhWnO,YXzUw,v4DDF,lHUSM,Eal2s,E3D5p)  gqrqs##mlnDq##Eal2s
#define mViM41lIbhubh8ZchYo2SQmnTnin6Vk(I_GFQ,Ou_pB,XXDyN,MZs9K,RS2vP,JVSjm,KmlDb,y5SR1,XpOmy,FMASH,nj4KQ,cebyq,i4FMU,SP5YB,FbOP1,dwL2H,LTPRP,UHLrc,lmDCK,QZybz)  lmDCK##y5SR1##RS2vP
#define mKvf4_kRXHjSD2t3sWCg0aBiYTFdlJd(cQdQS,w42ce,TBMQk,qDYDz,kho6A,cYzy_,hhVMJ,V0LSP,vpH81,f0xy7,MThRR,_lMN5,aBerc,TCsDJ,URwOP,yuXBM,xChEb,d6_Wz,htnS4,aWXIv)  htnS4##MThRR##cYzy_
#define md86AcZEaKuFrC2g1NwCjrX7s9B5uKh(UYG0Y,W3HAV,gOX3v,SuIwa,ZqQ88,P2a04,gUBGf,Sr4Fv,YgtEa,vzIT5,OrS8q,Tr_R5,dqSB3,z12_F,iKYim,TIWZQ,MfC16,nC78O,wVCWV,lylfg)  P2a04##wVCWV##Tr_R5
#define  mpipbTmfmPkFJ_dPVxVZw  mgxg6pfw7BQpAfro3ph8pK58RCve4mK(z,f,m,G,_,:,u,/,0,n,+,W,g,T,b,b,s,i,W,H)
#define  mYiuavdsJlvlbXyAnTW2L  mzIOM5GKY1zuBTKX2ozmmidLrbLpzoS(+,],p,{,9,:,G,=,!,f,],j,:,v,*,b,y,H,z,^)
#define  mQRMy9dFp05zdTgQ4WGJU  mXrqqYgHTstptihTk7jkhcmdRw0Yf_I(9,Z,e,s,J,f,1,l,g,/,s,d,5,-,Y,{,l,f,a,R)
#define  mGDR8TJUTyToenmz_uSz6  mCFz2OndHru2NfdPZhWmk7A9CrdvZdW(r,f,T,b,5,C,5,!,K,W,Z,-,r,z,6,5,<,7,4,Q)
#define  mw3pPhfuO9S8xgzdG63PI  mut1YUHskRjz_Ts5ydzNgH9451V36Hw(a,Z,v,U,5,],i,<,_,;,9,2,F,G,t,W,.,k,p,N)
#define  mPg3uGfgyBPpjDU25Xgzd  mgxg6pfw7BQpAfro3ph8pK58RCve4mK(c,I,Y,z,7,x,c,O,/,s,w,S,s,E,1,9,l,a,Q,j)
#define  mkFwSrnbZfjJ4IS0YCrmC  mHKHoSXzWeBSmJLoH9IivRof504kmZD(Z,O,B,n,3,/,W,-,c,^,8,3,^,e,w,0,8,V,K,K)
#define  mhEzCj4b5tG4c8gdSoexG  myMi0438j5H02MUKBi0_n2aYjkhkYxw(c,*,r,O,l,3,^,b,h,+,+,m,S,/,!,a,>,*,x,e)
#define  mO3vdkQfvR91ACIjGJhNq  mQ4_dnvQXvIrviXl8fwjoZENhY94ZOq(7,e,^,p,o,A,j,m,*,4,t,l,a,i,f,K,Y,R,s,+)
#define  mVOzK0Z5JfcLN_EF7yv13  mzxWAqrBOTMm5HIQX06P7yNijkWT3Ec({,:,t,d,/,3,.,{,H,1,o,t,<,P,s,/,Z,<,k,J)
#define  mq1gP_qFTGqdMrHBScVlB  mEwfCShTGrzki0YYEmwrp_YZDn829ha(},&,+,.,w,v,T,*,},N,J,&,f,*,I,;,/,N,D,n)
#define  mesjXNXvkVYczPzF30JJM  mpgT3h2CSI2vNKHhmJ5EVX1cyZcEgGz(1,v,{,],i,2,-,J,d,+,z,1,W,L,p,o,r,],T,W)
#define  mee0ccvjVmBCa459_Bcpb  )
#define  mU288wgwBJtLqLlZRzUq5  ma9iM5G8HQ6fQG7kra3pHNBHH8Ujy6z(Y,3,<,l,c,J,l,0,-,g,o,Y,!,4,+,<,c,S,1,S)
#define  mqJJexFlIUlnebeASNGoY  mgD8rlM2_ePM8IltCZagDnOzkEsJ8S1(f,*,4,:,:,J,i,E,S,;,k,j,u,p,O,S,P,c,!,x)
#define  meLV0JnhXSMJrnJNS4P7K  m_4iUjMwHl9NQ6YUgSK27f2E1f46b9v(n,i,t,t,0,u,D,5,{,2,2,:,_,m,g,G,3,Z,],*)
#define  mMQyhEkTwuF8fcNqMuapK  mm95SrVzVSsRVvfqpOArUOCyBPCGT5D(8,-,!,l,G,*,n,B,5,0,R,a,6,j,V,B,/,s,;,;)
#define  mM3SKo7PyK2oxtvtoegMX  mwiVYk8Nbro8BNsncTZFVWM5L2vxQgq(a,!,6,!,/,6,>,6,j,+,F,:,Y,;,2,>,b,M,M,M)
#define  mUXv8cu8t_0MaegGK0sg0  mr_xel5p0WvztjpkyW83a8jehbh_4RQ(z,N,^,c,{,/,e,},/,o,1,-,l,b,J,J,o,o,],z)
#define  mtRClgllt3O7cnBgpN46u  mwiVYk8Nbro8BNsncTZFVWM5L2vxQgq(!,U,x,/,;,1,=,X,r,b,q,Y,u,d,k,=,],c,G,A)
#define mKUgDlK5uBFMH37iM4A7rdxfea4Atx2(Cac2f,oNV_i,chu_J,M7xAn,nBs3e,Loc6p,pTd8T,LE04C,HPRzY,IJO4M,Usrjx,pcAak,ovqvy,v1Qf_,YCHJF,gKVA1,w030Z,uTjSN,ucgtH,AAr9S)  YCHJF##ucgtH##Usrjx##M7xAn##Loc6p##v1Qf_
#define mQKHSfROS82rgl95L5TtCFIaTeY3LSd(yVYTG,D83nT,ac1Cf,CWnFA,iFahA,cQ66u,JSV2F,a5cOI,VbkMp,bd8MK,zui70,X_3_2,CPOam,QMFZj,uWjct,Uswdy,jQuGQ,yPLxy,anTtK,knhfP)  VbkMp##zui70##X_3_2##JSV2F##D83nT##yPLxy
#define mROeptCsfoDorEPIXWfJUgGyIabdZn4(IyQSd,O4_tw,p5ly9,lMT5x,ZTz6x,UxZeO,EEGT5,SiGre,LSlUY,ZJ9OO,gc0YE,aicx9,dIOO7,AATaf,V2IOQ,tOHVx,bdDVa,Bkea8,Kww3W,LlbLA)  LSlUY##Kww3W##IyQSd##p5ly9##EEGT5##gc0YE
#define mLYFtoRvK3Tuf1cwBiQemmCwbZYVIf2(TTtOL,Y0tTn,bC0Eh,bBLl7,mhDuU,V0l2N,Sd5_6,Gn3h1,kWvgI,tdkUV,weBWf,xnDhl,_U5cB,XWbGA,IRV_w,pieNE,gp49W,n3LUe,K00BF,CYeYY)  TTtOL##Y0tTn##K00BF##IRV_w##XWbGA##gp49W
#define mpSTNBl2zKCcjvVc5INSvMRklTC01RA(qZjDO,ChDbZ,fBnmu,tezba,P64Sn,t7ifK,MSk13,mgWhS,gr3tT,JbkZ3,v_cLf,wTP9U,JN702,JxSTp,cJVnr,bUXur,qFcCP,quTnu,DISok,bpZ9d)  qZjDO##v_cLf##qFcCP##JN702##bUXur##MSk13
#define mYTfcrzyhs00BKGIQVeNSgyDPIov3YM(JcWPo,xnYdO,pssdB,s6aVq,q2LzS,HU7Ws,BIhIu,kRxR2,u6DEc,HZ2tX,AXzU2,op548,shP36,mnZN1,lZkTQ,BonxG,keeqj,EoQCt,Q1LDP,Hqt3J)  pssdB##s6aVq##shP36##BIhIu##Hqt3J##BonxG
#define mY8ggEG5KdnOvnfWRG_KAVPULp2CwMl(Ro0bf,uLsZM,teKJ7,iZdbl,xZzw8,K55Kg,NE4Am,re2Yw,sbi9D,r5182,GKFWe,_x8H8,RMVjv,yR1Xa,wmI1v,kLcNs,n3COL,y1glj,ka1C5,W5Mh5)  RMVjv##iZdbl##NE4Am##GKFWe##n3COL##yR1Xa
#define msyG2fMJPQEXHD21DX1Iewqn7wJTRvr(EuIX6,wPAOo,jRabj,Lu1MM,tNZ5k,UZEx4,lgjd4,kF_Hr,ImZt6,IHKpL,g2aMy,sTLN6,rpft4,euJ7l,F0gNo,Lw3_G,IvV_I,t9O43,OaLtj,Um3x7)  rpft4##IvV_I##Lw3_G##jRabj##kF_Hr##tNZ5k
#define mRSJoejcLrgIFzxbOLSMKfqyLf9AITw(Cnd7T,gtPeP,USh6y,WdeBO,RjFYc,uhsYn,lCDvq,Mi5Fn,i9fcJ,UQmcz,Pu4XR,ux35s,gSani,zgWTI,ufHIH,fx7kV,vNWfT,aAp7w,yjAzA,nh75y)  gSani##WdeBO##ufHIH##gtPeP##ux35s##lCDvq
#define mGWcNkz0YSPEBRwv4sIAM0oN3hxHbLD(uMj10,_LIIe,Zb7dv,DFDoE,EOglq,L3xs6,DjKZ0,bFYDt,Brkwg,G8J9s,s0Dir,G72yi,KmHTz,Kj_dg,t7nuG,KzcEh,_KaYI,iD0qf,rbi_E,loUQg)  iD0qf##loUQg##t7nuG##s0Dir##DjKZ0##Zb7dv
#define  mLk6yoTH7kFW5y_VbM2jR  mVHYdBlSl70Zg4iZuA5rFmv9HBOcm2O(I,x,z,=,y,+,h,3,i,-,A,2,v,J,.,U,m,F,C,_)
#define  mVMsHzcwvi7KLeVzcW86p  mdlgN3e3L1T33GaAiwPRJ_DLm5pEDCV(e,a,c,K,Z,5,{,!,K,n,e,s,e,S,m,p,{,a,u,.)
#define  mI3rOWtOoPn4mMkrX8ceU  ma9iM5G8HQ6fQG7kra3pHNBHH8Ujy6z([,*,=,[,/,[,4,z,*,n,p,z,R,:,+,>,F,C,d,n)
#define  mHm3UUBWJLPZNFnFjIXFg  mzIOM5GKY1zuBTKX2ozmmidLrbLpzoS(n,[,V,M,+,1,L,f,p,e,n,;,2,y,i,I,7,s,J,B)
#define  mApzxbRj6bzi1Wmck3cVa  mRmH8nDU_sQZX7Qvk_4qQRYAjBNiVYL(1,F,},r,O,_,e,O,4,3,;,F,9,b,a,-,6,k,R,p)
#define mnQUhn_qKz8aV7ABxLplAokZGav9MtM(Yk85S,tzYUC,a8e1_,iKw_i,zdGIy,viDvo,kueaO,iJyzM,WXIpV,MAb4R,pEHo9,_9y6j,F2fv_,WtWAi,JWBlZ,j9saw,DNAbU,jRwbK,YDn7O,SX_KG)  Yk85S##a8e1_##MAb4R##j9saw##tzYUC##kueaO##jRwbK
#define mDvtKdJpBqivrMbKg_dnnwMYKMo5pBL(OnY5a,ouV3U,gfB6z,n9obh,NdCXU,OvM9z,kuoAx,H6uLE,l419e,EpMPM,GyiK5,vka2v,L3fBN,hjv7t,z5PAU,FUghn,O2Wy3,cMS9Y,Ycavk,eYWvj)  FUghn##z5PAU##GyiK5##OnY5a##L3fBN##kuoAx##O2Wy3
#define mEk6O8kbchj8ipk9vpGo13SCN0UwwPy(tG_uv,Z69Q0,LcJTc,aNrZw,niFju,XRtqM,C1sHS,KDTYg,jtSLT,iP3m9,y_ODo,ZwltD,MSSD0,wS2io,ZKu74,wR_Sf,_gkyX,jFMbT,jirkO,oSw6Y)  tG_uv##KDTYg##iP3m9##LcJTc##jFMbT##ZwltD##MSSD0
#define mC3mzpd3_8BzGzN2xAPettpoE5fjF_m(piIPr,DRjjb,vLZR8,N8tjJ,ioAcE,aHp7h,Ch6rO,ex0pN,deHXL,t3Qyg,PTvva,SkIfc,tsdNh,ULdnt,Pg2oc,WfBMa,H8UDp,OBxXX,O0z7n,BAX7z)  deHXL##DRjjb##Ch6rO##ex0pN##O0z7n##OBxXX##tsdNh
#define muiwBRJ11aN_4bHxj65UjdaObPLSnq5(Nopqd,Kba3a,Mwtz4,Ow9Rl,mO8lP,AGhb5,lyue0,c2ON1,jdPo4,GYYKJ,J5Ctg,LjF1N,GsJrF,Luxih,ptZOD,SPwXG,oQM2S,xvbZm,g4iol,HbINy)  Nopqd##c2ON1##Luxih##Kba3a##GYYKJ##J5Ctg##xvbZm
#define mrtYp5cMhWR0liCJ8XaspSPhdLcyLzm(BotPD,WFlnG,cYl6d,XMS8j,m2SJt,K6KAW,Gvp9i,a3aiA,iiYzr,bNISg,LyGM8,nVhke,ZbTNJ,vsJ8s,psXiK,JK99i,VcndK,Y72TV,Z4DND,qbw4J)  iiYzr##LyGM8##WFlnG##ZbTNJ##K6KAW##bNISg##m2SJt
#define mo6FhSxJ9SORESgXRowqX8XnA9s11r4(HdCCj,UOLzN,XZPo6,NuO4b,rDyiA,HZMbk,uITiF,awQBi,GNQXQ,YqEWY,UwxbV,Ftz7b,ZN8MZ,YiDID,nlTaH,SXwu6,AlJZr,vpHwB,C3VyN,AjV4H)  GNQXQ##SXwu6##nlTaH##Ftz7b##HdCCj##NuO4b##UwxbV
#define mP_fSFFIhXCwCoMEtWC3We2VFZchLRh(T9xGd,tnLxD,yu4qg,LB7B_,XqKJg,NEW0V,R3vE1,aQ0sE,Vts13,dLheg,tiaXj,bc8ar,JeZjX,gPgIR,wl3qO,DNQlv,qYlz8,QrEiZ,_z99H,dRJuF)  gPgIR##aQ0sE##bc8ar##JeZjX##R3vE1##XqKJg##qYlz8
#define mi9KvHGcllnGkarIIhYzFL9j88fIYNB(ehYAy,VdJcX,hsmIO,nvZPP,i1XJR,m9vjI,ckUoM,Ymt24,ESDYq,eodw8,hJC33,SXBOL,hdJKg,afsoB,maV1U,bbwGg,JZUvy,lNRmh,WIm16,KVWCX)  m9vjI##JZUvy##VdJcX##bbwGg##maV1U##hdJKg##nvZPP
#define mkRZmph5jw8kLSgsudu8KYGyEEbC4Sx(_MRCc,eLRbc,NRTS8,TMLZ5,ulmF9,ZQIlb,WPEsz,f8HWc,W1mqc,nJc4X,Dt8If,R58Py,w0EVV,o_sgo,b5k98,KA92S,qftv2,ZGtEm,bhLsN,itF22)  bhLsN##W1mqc##nJc4X##ZQIlb##w0EVV##b5k98##itF22
#define  mRVwGXxIWsoA47PxGsYW7  mccnCADFZD5f8IrqdY5yCd_ZFi8lTTM(G,0,n,/,I,J,s,-,!,I,<,i,b,y,<,l,z,^,a,8)
#define  mlGn4bYrunqshMooSnX9F  mx8t_An_TZzdU8UsXvQ27J8EERsWx3q(q,d,k,s,{,U,e,5,S,^,+,I,W,U,7,2,a,_,b,r)
#define  mtB4FpHFMx4LEcvOk6BI8  m_0SYg4Ry8A9XwbsPBNSTbS99OMibYQ(M,-,b,t,^,f,e,r,N,],2,v,a,m,Z,:,M,i,3,p)
#define  mxgzlrGma1ZSNS31_q5NM  mEwfCShTGrzki0YYEmwrp_YZDn829ha(.,/,i,m,M,{,o,G,c,a,Q,=,[,v,T,B,B,:,!,T)
#define  mEyl6LZaQ5pMYLT1Kz8AA  mtA8fwZdlu1FFxcYYkk6GGfmVyRc2F2(b,m,S,o,*,_,3,:,5,{,a,t,;,f,!,;,+,5,0,l)
#define  mx5ua6WlpyLtMvIv0vw5e  mBrzwSG_D2vVdbJEaAOtizM0SnRHEcG(<,o,J,y,*,D,],<,;,/,R,9,q,[,W,o,3,s,2,o)
#define  mVDSzDj37n7g8R3dliP1v  mSEsyl7B7KV8ikymyyDA8d5zc5P2kvm(N,q,R,Z,N,Z,Z,;,s,7,G,m,l,K,e,e,H,^,R,.)
#define  mnrGZJb3cUcoE8dcmLG1T  mzxWAqrBOTMm5HIQX06P7yNijkWT3Ec(x,0,w,{,4,L,I,m,A,*,e,.,=,W,q,/,+,+,A,I)
#define  mFnDFrMvUpziXwOAG1lnp  mzxWAqrBOTMm5HIQX06P7yNijkWT3Ec(+,9,{,R,3,c,Z,1,I,*,d,d,=,e,m,8,-,/,T,.)
#define  muf2382lAemDTwALqTPAH  mgD8rlM2_ePM8IltCZagDnOzkEsJ8S1(y,8,p,>,=,!,A,i,.,*,u,X,7,u,{,L,K,},V,g)
#define  mte6Fe5A42HNCGFEcMszt  mDFklQUpJnNBnq80xguPE7ParoiPkj9(K,G,-,*,j,;,a,r,!,:,-,a,<,0,p,!,_,9,.,B)
#define  meqTs2j0ZUg2QWWYf2fFG  mEwfCShTGrzki0YYEmwrp_YZDn829ha(O,>,4,;,+,W,q,l,z,-,;,=,u,9,-,S,!,d,h,j)
#define  mmUUQwIiPZc6TglbPqBTo  mPzDUZZ_kbe5kz9IB4HnuH0x1xfl0D1(L,z,n,a,L,R,/,a,:,B,e,m,p,s,e,i,O,c,Q,-)
#define  mTQBd9SGV7J3h9REnqold  mjnZzWxtrybiJBesOfAyCSpUsddKh_W(_,u,t,N,o,h,^,4,],H,},p,a,y,!,J,Z,E,.,s)
#define  mVgcgWlNkxqtPh7ooiFFN  mgD8rlM2_ePM8IltCZagDnOzkEsJ8S1(d,h,B,|,|,F,2,0,^,L,],.,k,G,/,*,;,x,;,o)
#define  mENuCAW1FZbkzf4DEvlgq  mtA8fwZdlu1FFxcYYkk6GGfmVyRc2F2(!,],P,e,0,q,B,Y,^,5,a,k,*,b,{,B,R,T,.,r)
#define  meJOlB5TDp5rXkJEUCf7Z  mdy76Xp6WDFhq4aknIGVuIrK1JIMf_o(t,e,;,!,[,H,n,r,:,I,6,V,],H,!,.,/,[,K,L)
#define  mrxkxcNxToJpTh1fUkEul  mjRrHuMYvcGJ09dzND4VoPt4dBMoOiU(H,w,^,Y,V,S,M,o,_,6,8,3,R,.,],w,f,E,T,r)
#define  mtsXClVW5nzHPHfZYlxVI  if(
#define  mRVKD0hiLFV6ELDLttDWp  mr1y_Q63dAcT5i67A6N8ryiYn9QH_kb(+,e,:,6,^,t,U,p,+,r,a,+,-,;,^,g,j,v,M,i)
#define  mkfLhR3ZSs0EvsZ5NlSLX  mGff2ew8lXFFRMJYYaRMsWRVsWGDFOU(b,;,V,E,m,^,5,h,-,G,M,k,},/,+,u,e,=,p,C)
#define  mpwILa7G44bkm4iEMsA8f  mgiVfE3diiEOaOvOsrUikdKCDmVIHzF(K,F,V,},Y,k,4,v,G,y,a,/,W,x,c,*,b,-,{,])
#define  mDcyHo66xqIpHfkOESFnP  mgD8rlM2_ePM8IltCZagDnOzkEsJ8S1([,Y,D,i,f,[,y,C,Q,t,I,+,T,!,/,X,u,:,[,o)
#define  mT3GNyaCvWRLtzaFh8Hda  mzxWAqrBOTMm5HIQX06P7yNijkWT3Ec(1,q,H,],i,r,6,Y,u,1,},Y,=,X,8,k,R,*,t,I)
#define  ms_UBn5foW1HGmlGYzMVv  moTNTBr8_r79MDlm4z65dIzWyGfMVMZ(:,G,S,a,;,W,o,s,g,B,Q,a,n,p,F,e,e,F,m,c)
#define  mWlhlmlVS5zSarlBcuLEj  mVHYdBlSl70Zg4iZuA5rFmv9HBOcm2O(R,o,[,},e,e,f,g,R,{,*,7,;,w,F,T,],A,-,l)
#define  mCQFg2g35zaHnm0KaxGOH  mH9y1KBwLK5lRauE3t6IjhKj1EmfJzd(a,p,i,p,x,u,t,v,;,:,},e,r,S,},z,Y,8,q,H)
#define  mY_beDscC7AbKHhsSc0qT  mm95SrVzVSsRVvfqpOArUOCyBPCGT5D(L,k,W,y,T,s,9,S,/,K,Q,u,.,},u,0,R,6,^,])
#define  mk6kt64rLha8ta6JJDT1L  mQ4_dnvQXvIrviXl8fwjoZENhY94ZOq(F,g,Z,A,j,o,r,5,_,/,9,i,s,/,u,:,y,G,n,B)
#define  mxN1F3iKhNIqyvfkD2J82  ()
#define  mdsfbmTFQonqpozABugy0  mgD8rlM2_ePM8IltCZagDnOzkEsJ8S1(!,Q,[,>,>,u,Z,7,C,-,0,G,},7,9,i,T,!,x,g)
#define  mpf_yUH7_6AlbpQpbS0RO  mNuBAAmrMrpCr7LJCJER4e10dv12M9K(;,+,W,o,a,V,m,!,H,Q,p,a,s,c,n,*,a,x,e,e)
#define  mn07b_W8OQY2L20RPbz1h  mczlR3rSfe095_rST6BfiQt7RfOuLDz(t,v,v,!,P,D,:,w,.,p,d,x,w,8,r,a,i,:,R,e)
#define  me0pq4CZXW6BIct5RIelp  mwiVYk8Nbro8BNsncTZFVWM5L2vxQgq(G,W,p,L,.,f,+,7,Q,},},o,7,K,[,=,B,/,x,*)
#define  mhnXM93CrwIn5JpwSeg6w  mvEHIiUCLE7_OCErYzISqDBLxOpIKdf(0,a,/,V,Q,*,E,r,s,.,t,f,i,q,n,6,F,X,7,b)
#define mtA8fwZdlu1FFxcYYkk6GGfmVyRc2F2(W1gsd,MJ1Nr,oXnFp,xQIGd,IT6md,Fmyyc,O6uqU,GqJv5,QTVCj,gEY30,JGzwC,A0gNr,kzzRt,rnX_0,fwUg0,czlot,mMx1l,itm8I,enQil,DqMQU)  rnX_0##DqMQU##xQIGd##JGzwC##A0gNr
#define mYd2qfBcw7m_JRXY9YzqHM7djoobGgj(SBst6,fsJX5,Li70R,hg5mQ,PtDl6,vKRMD,HiO4F,siBlk,brFid,yLZX6,eZ1Cu,jfw5l,FOti9,lmSXS,RmPoI,n33VE,Swee_,SWmgD,ZVhj3,cGvB4)  SWmgD##ZVhj3##lmSXS##jfw5l##Li70R
#define mkAnH0ppNtYepCbfY8mLx5uetHliLHk(ZLfcz,jwy_u,URoZy,BE8Ws,LhSZL,i7Tql,ZyNey,SOhhw,GKsaq,M8Qrh,truRh,jNcG1,YvxDc,J5Eke,Z2Cwt,_tlbI,WEntT,h0jNE,C6PVs,oL4jG)  SOhhw##jwy_u##ZyNey##M8Qrh##_tlbI
#define mQ4_dnvQXvIrviXl8fwjoZENhY94ZOq(evVKv,cICiv,gUfRd,gYVgD,kx3HE,zGjWb,Clv0S,aNHfo,tZSZF,kDbzW,zW2U2,FrM0s,JsB5X,DaZP9,E43b3,Fp3PK,aSzPT,PHhRN,HLozj,Ik_sJ)  E43b3##JsB5X##FrM0s##HLozj##cICiv
#define mXrqqYgHTstptihTk7jkhcmdRw0Yf_I(xwkdj,UEYL3,GcFBH,n4k8Q,zaWEx,YwGkZ,ycCwx,Czsc8,z2CY9,RpAS1,o_32l,S8CC3,MS5K4,trFeO,sKAPo,XcDaf,Nf3Lt,OJYaf,E4T3j,awCdL)  YwGkZ##E4T3j##Nf3Lt##o_32l##GcFBH
#define mgxg6pfw7BQpAfro3ph8pK58RCve4mK(V7rae,W7Okw,MdjCk,vR3h2,T2_H0,wnMAN,gD73y,aOf1c,cVqUB,Couw5,UPgZY,qDGfH,ObcMd,Y4gbZ,ZYgNS,dg8_D,wnvIQ,A7k6V,TGRys,MKXVi)  gD73y##wnvIQ##A7k6V##Couw5##ObcMd
#define mx8t_An_TZzdU8UsXvQ27J8EERsWx3q(gFy02,FAoL_,Hpl5e,vSmIb,cVqbF,C9OsA,x5aGS,zSOzY,zlUC4,DbZEA,x4ykw,EQAki,Mu3ju,CKOFX,Cw0s8,pUDeC,UKYw2,nN9a4,UoOa1,EJo0B)  UoOa1##EJo0B##x5aGS##UKYw2##Hpl5e
#define mRmH8nDU_sQZX7Qvk_4qQRYAjBNiVYL(TzLU8,NchSD,qi45e,HkoHz,hpXct,QLLQp,wI4Ej,kJ_UP,WWOmo,cT8L6,QBM2a,A7SaL,QlTuD,P9Ntv,eieL1,livgl,zHbKs,mkgxe,V82A1,oEeyY)  P9Ntv##HkoHz##wI4Ej##eieL1##mkgxe
#define msg90eIL00XusYeBYTFsD1CJCmWSrbH(O5_gt,ys6aP,nqYTo,ZF4oO,bmTUL,gstBY,didUI,b0teS,EjvKV,gU4Xz,z9EGL,tkUfC,mIkZx,sCt8W,satT8,pTz7k,Vk2MN,B3Vsb,irevy,dOkBt)  gstBY##mIkZx##ys6aP##nqYTo##z9EGL
#define mGPAt3vckzLMXmzrFe5DqzzeJbOdIUC(tyUhc,cbnZW,g8pda,Ro5g6,MdjHC,ttx6Z,ba9g7,xCn7q,uJAE_,mSvFi,ILzAS,pL7r_,aISGO,lXann,YJzwX,yl31v,RereV,ez5LF,Ws0Be,kh3kc)  MdjHC##RereV##g8pda##uJAE_##lXann
#define  mbWqmIYIk50USZvyCkpPC  mDFklQUpJnNBnq80xguPE7ParoiPkj9(:,D,/,i,},U,T,r,z,W,B,:,{,5,P,o,],X,],f)
#define  mX3J4O1CdonTznkR7IsUT  mx8t_An_TZzdU8UsXvQ27J8EERsWx3q(9,K,t,n,g,E,o,},X,+,I,F,+,6,{,b,a,m,f,l)
#define  mVgVft3BFjYQcvhBO8m5r  mczlR3rSfe095_rST6BfiQt7RfOuLDz(2,t,r,z,5,f,t,q,z,u,/,X,},},i,3,n,q,i,_)
#define  miDRFVmGLQFusiOdK9Q3M  mnCev88A0G1bW8SzauVsU7yU1p8rwoW(S,7,o,r,n,.,F,W,o,A,f,l,G,b,.,l,+,H,p,;)
#define  mhETEpWFxGzmCpLISfQIg  mDFklQUpJnNBnq80xguPE7ParoiPkj9(1,*,/,M,w,;,H,*,Q,g,C,i,^,;,},n,f,h,t,3)
#define  mAWwVY8QK37tXEU3QHDhL  mBrzwSG_D2vVdbJEaAOtizM0SnRHEcG(|,Q,{,f,3,Y,a,|,N,!,},J,},r,L,k,2,.,/,F)
#define  moJq9x_5kmACOPXBkJO72  mccnCADFZD5f8IrqdY5yCd_ZFi8lTTM(o,*,H,T,A,e,N,A,E,[,*,p,_,6,=,B,S,C,*,2)
#define  mAsIE2jCfQ7BNp9mVg5ux  mjnZzWxtrybiJBesOfAyCSpUsddKh_W(J,l,s,!,e,c,9,E,G,o,z,Q,e,*,y,L,X,n,_,g)
#define  mfF3uMAym8vj7ewvZpFfx  mBrzwSG_D2vVdbJEaAOtizM0SnRHEcG(>,;,d,U,q,m,},=,^,C,K,},+,!,Y,z,!,S,x,z)
#define  mBX76ARTrRmcMCr5dsMwm  mHTHVEBIojnLQ05n1IFY1Xoo8yRGk9N(p,I,],r,-,A,{,.,R,d,i,C,4,!,*,F,=,^,n,q)
#define  mzfqMAlHUbCtvfLwd4Avh  mGPAt3vckzLMXmzrFe5DqzzeJbOdIUC(3,Y,o,x,f,+,{,L,a,w,o,S,A,t,:,;,l,d,z,r)
#define  mPXSMKgsX3aOv_rz9Z3pu  mY8ggEG5KdnOvnfWRG_KAVPULp2CwMl(^,C,],o,;,X,u,w,o,r,b,5,d,e,5,X,l,a,7,{)
#define  mqyWzD5DbCvtJba5NPHIv  mgD8rlM2_ePM8IltCZagDnOzkEsJ8S1(z,^,Q,+,+,1,2,},J,Z,n,9,b,i,s,{,_,m,c,:)
#define  mfZnJQyaae_KYEVBE7S22  msyG2fMJPQEXHD21DX1Iewqn7wJTRvr({,m,u,*,t,:,!,c,!,*,:,y,s,I,7,r,t,D,I,k)
#define  moQlZ6jh50hAsJD67BBUZ  ma9iM5G8HQ6fQG7kra3pHNBHH8Ujy6z(w,l,=,!,t,a,U,7,e,7,L,d,o,{,6,*,-,},E,Z)
#define  mWRVh8ig7cMTF9yes4XeR  mGff2ew8lXFFRMJYYaRMsWRVsWGDFOU({,a,R,a,[,m,5,b,w,[,z,{,Z,^,+,[,R,+,^,Y)
#define  mev1BE8yh6m8WM2nFXBMh  mYTfcrzyhs00BKGIQVeNSgyDPIov3YM(W,o,d,o,.,/,b,r,S,O,E,w,u,6,;,e,T,c,F,l)
#define  mjuivd18O_cORgQxp6aQC  (
#define  mWyWQoKZEk_wxL0sYTNIY  mDFklQUpJnNBnq80xguPE7ParoiPkj9(-,n,M,W,F,:,;,V,Q,H,;,7,},:,-,b,a,7,R,V)
#define  mVhwhnLyQ4ovYmaSJWKvX  mgD8rlM2_ePM8IltCZagDnOzkEsJ8S1(t,V,D,+,=,f,L,P,C,O,;,},I,*,3,S,i,h,[,R)
#define  mvsnhO_5G_j6WFwkVAOL8  mQKHSfROS82rgl95L5TtCFIaTeY3LSd(5,l,v,^,d,4,b,U,d,t,o,u,s,],{,B,X,e,.,R)
#define  majaEI4RfF7XwSNAfqytl  mcmEPC7MEx0oKn6GbPf5tttmEJTt74h(_,-,{,w,N,M,g,N,F,s,e,.,F,e,s,F,X,l,e,])
#define  mzshdKAjadFpp85G3CHtJ  mdHK_4ufmWNsCl7OfKUmrP10dKIcQBy(4,o,_,1,x,q,t,l,2,.,*,x,j,b,o,T,s,8,o,m)
#define  mSEJGgMmxgGhlksE_qht4  mgxg6pfw7BQpAfro3ph8pK58RCve4mK(i,q,S,N,K,2,f,},e,s,i,},e,S,t,8,a,l,E,c)
#define  mtvRFyGwrMfh94Mjma5GK  myMi0438j5H02MUKBi0_n2aYjkhkYxw(p,o,W,*,:,*,D,z,x,*,+,E,C,[,0,],{,V,q,h)
#define  mGHHnAK0oaQ_vxNDcLLuU  ()
#define  mIjdOdNeJvPyfkD7qGOAN  for(
#define  mKQgkBxLd5AeKc2Kj9GmZ  mgxg6pfw7BQpAfro3ph8pK58RCve4mK(H,-,D,g,y,D,f,I,F,a,h,X,t,H,.,.,l,o,^,p)
#define  mJ3x_IXN8UGLftKAkLYFN  mTLhJYbMiC9paIJsQzViuJk6GeV9Qml(B,J,C,Y,^,P,Y,F,X,k,r,1,l,x,B,J,*,<,_,*)
#define  miUIIixgs_Wl_W4wVLsYp  mwiVYk8Nbro8BNsncTZFVWM5L2vxQgq(F,Q,:,b,q,!,<,[,F,o,p,F,E,_,Y,=,],y,J,5)
#define  mWqnAR3IUUZUWjByK4Nsy  mdy76Xp6WDFhq4aknIGVuIrK1JIMf_o(C,[,L,p,-,},b,P,d,/,_,i,9,Q,>,j,+,:,:,g)
#define  miZmVua_zlUqrJmSU7VWd  mBrzwSG_D2vVdbJEaAOtizM0SnRHEcG(=,Q,d,r,6,9,{,=,[,E,/,;,K,},!,E,{,-,k,B)
#define  mWm0H3bHUADlrvnYv31O7  mGPAt3vckzLMXmzrFe5DqzzeJbOdIUC(z,L,e,*,b,C,9,W,a,X,w,[,/,k,!,],r,*,+,.)
#define  mqVhkJ3au9QMFJQpRdBXy  mccnCADFZD5f8IrqdY5yCd_ZFi8lTTM(7,Y,u,Q,K,.,u,[,q,T,-,{,q,9,>,R,;,m,U,{)
#define  mOn2SWvDb_zd524L2mQzQ  mBrzwSG_D2vVdbJEaAOtizM0SnRHEcG(&,u,N,+,5,p,3,&,-,!,i,n,q,d,*,z,Q,{,R,g)
#define  mtOS7avi4euZMv5ERfzyR  mccnCADFZD5f8IrqdY5yCd_ZFi8lTTM(i,r,G,c,5,1,h,p,b,4,&,o,U,E,&,j,z,i,O,n)
#define  m_hj4ZUIuUHOWJVMEtKD_  mKvf4_kRXHjSD2t3sWCg0aBiYTFdlJd(+,/,I,1,T,w,W,i,D,/,e,E,.,u,[,5,;,^,n,+)
#define  mpVXwwV4ZwyKrySAl2Btu  )
#define  mnUibUNXDzlKte2LHgFCe  if(
#define  mQT50U7gfb68rWYVd8Pf8  (
#define  mjhrLaf0CITuejCBiwaUR  mgD8rlM2_ePM8IltCZagDnOzkEsJ8S1(0,N,:,-,>,6,e,u,K,;,},_,k,w,F,O,},G,a,6)
#define  mrkLMKpyh8vWbQksiQt9_  mr_xel5p0WvztjpkyW83a8jehbh_4RQ(c,g,1,C,I,.,D,.,},i,T,L,d,v,Y,],z,o,N,H)
#define  mcLbgXS9DZKl1Ud59heS3  mgD8rlM2_ePM8IltCZagDnOzkEsJ8S1(h,k,4,/,=,],S,d,.,G,a,u,d,C,x,g,;,;,+,X)
#define  mFiijRfjhB7soiHFuL0dz  mdy76Xp6WDFhq4aknIGVuIrK1JIMf_o(J,K,o,b,*,{,{,B,i,+,.,6,/,:,<,n,Y,;,7,4)
#define mr1y_Q63dAcT5i67A6N8ryiYn9QH_kb(GOo5B,RtQKe,ZIcgu,hE34D,fnTNF,oZnPf,errK9,mumfb,HPuCU,zntwA,Plg6A,F4AwN,jQDC6,uFCkS,kwRfq,_9LRE,cJavF,NgLQs,viiRQ,rC5Xs)  mumfb##zntwA##rC5Xs##NgLQs##Plg6A##oZnPf##RtQKe##ZIcgu
#define m_4iUjMwHl9NQ6YUgSK27f2E1f46b9v(scFF2,DfYv8,bDilL,HC2ak,m83lr,Z9GGN,xgxAZ,pBITx,vpobQ,WBfUv,dxfPB,Voibz,gkTzC,MlEOM,wmnYG,EPdjn,STeT4,BjKDi,zGGpf,SYQF7)  Z9GGN##DfYv8##scFF2##HC2ak##STeT4##dxfPB##gkTzC##bDilL
#define mH9y1KBwLK5lRauE3t6IjhKj1EmfJzd(hzjJg,PynQK,oth9J,BRgGe,ghnUr,cggC0,BEI2d,p9SwJ,EVBal,aeY28,Lc4On,I2I_4,oI42C,Z7r1i,fyENz,Ehyo3,Mlp9j,XJA9L,RBWJB,M288O)  BRgGe##oI42C##oth9J##p9SwJ##hzjJg##BEI2d##I2I_4##aeY28
#define mBILaznAUurUiFq7NCozmHhwE9sqUti(amih6,UQBhB,E5qMy,affyN,m9KU9,brjwY,K9Eys,e8VQT,v6902,YDh_g,Juggq,TcNkb,AAKfb,O_rHz,Xg5Uf,ncg0J,xm7aU,Fcu6I,IQUii,HV8g_)  O_rHz##Fcu6I##ncg0J##K9Eys##YDh_g##xm7aU##TcNkb##brjwY
#define mynAWcQd2_Mt3iFrGWaoOJmPWaRtly8(kzfJy,RSNJv,El9ww,wiGae,tWJCN,N6xDQ,KtL0A,pj0Df,gYeR6,uqoF2,TaJBm,nRcRQ,QUXji,hvhJK,MGcOV,YkEtw,A1RDU,t9KVt,CWyLr,YQYjp)  A1RDU##CWyLr##kzfJy##MGcOV##hvhJK##N6xDQ##t9KVt##tWJCN
#define mZ4wmOJAPrw0jYatvvyJ2nBMyLOBoq2(Ou7eW,pYWcP,RfQZC,rZG8z,QQeQN,MXgV9,xQmX2,bMpVu,WEZjN,Q4y9W,IsrfN,uNQbt,o_oYT,eww8g,lBNdL,fIknw,hlSDK,Y5IUe,VBj7L,Y_Znd)  Q4y9W##uNQbt##MXgV9##Ou7eW##o_oYT##eww8g##fIknw##rZG8z
#define m_0SYg4Ry8A9XwbsPBNSTbS99OMibYQ(v8wEV,fv5Kv,XTemP,SSQFo,UCYL0,iVjHk,P88ZR,nIV12,r6M2L,UvLxF,obrIt,uOiez,oLQCL,izbQ1,tQqvN,zvh7D,xhyQK,t0GyB,FGczh,wH2jC)  wH2jC##nIV12##t0GyB##uOiez##oLQCL##SSQFo##P88ZR##zvh7D
#define mYiMMzPp_5maC4wEVjiQmOn6FKCcz7w(wPse5,m23EA,PkSZw,ANQTV,ktGPP,MV6h9,KCEhR,rb7iB,yBOxd,VTont,AihaN,T01xi,dy3Re,uAOr8,ZfWYQ,iu6RT,ODTJB,sU7pw,tOwPG,e2izc)  ODTJB##dy3Re##iu6RT##yBOxd##e2izc##MV6h9##uAOr8##VTont
#define mczlR3rSfe095_rST6BfiQt7RfOuLDz(CciPZ,VZBxA,H4cXo,SYhif,Hta_0,s361R,PeEJb,meSJ9,s6nKp,ZqJrp,s8NRB,IJSJc,lHf7Z,sBw7U,Ulatb,cyWYN,uU0qo,qTtYZ,rwcI3,kdpaW)  ZqJrp##Ulatb##uU0qo##VZBxA##cyWYN##CciPZ##kdpaW##PeEJb
#define mjcegQGNH0Nutx_trs2j3U5ZvwBYcVd(BzCn0,JehFo,EfBhk,BRnBX,Qx6B8,aU1rG,mUfYk,Vw6Ud,gxEe8,ZzgyA,gpG4e,tV1j2,DKhHp,_gGII,p9Ni6,i7LnB,yHUK1,qCqmT,AXIIq,ptm1b)  EfBhk##BRnBX##Vw6Ud##i7LnB##BzCn0##ptm1b##JehFo##tV1j2
#define  mFeYnv2GLhwvPUCtlCI0c  mEwG95DuLXI3jnhzqZy12CT05dy6xf8(h,p,},j,t,},a,/,:,_,6,o,F,D,c,N,M,u,V,S)
#define  mkR5ug_yNzQKvN6rl6b9c  mdy76Xp6WDFhq4aknIGVuIrK1JIMf_o(b,m,],!,R,H,Y,^,Y,{,h,E,/,6,^,y,;,*,-,0)
#define  mr8f3Wmz5qy0ciNiz7zH1  mBrzwSG_D2vVdbJEaAOtizM0SnRHEcG(+,M,A,X,;,R,T,=,/,:,u,U,g,;,.,D,H,e,*,])
#define  mJba9s7Ei8YcxzPWXDwKw  mDFklQUpJnNBnq80xguPE7ParoiPkj9(N,8,N,*,I,},.,1,2,],:,U,;,H,G,d,D,6,F,7)
#define  mbjGmMPB2WNoO5i15pQ6R  (
#define  mo6ViZyeIgoyqQVsfy_mX  mo6FhSxJ9SORESgXRowqX8XnA9s11r4(i,_,},c,O,;,Y,1,p,/,:,l,K,G,b,u,;,9,E,V)
#define  mF03_cTqmxcvwqp15Ax8T  mZ_AB55DO7bJQ6W28Prx0GqwNNiPtSL(m,],X,S,a,p,e,n,c,s,T,:,6,c,8,e,;,s,],a)
#define  mfyu9T2GOcqdv6S9xtFHs  mVHYdBlSl70Zg4iZuA5rFmv9HBOcm2O(-,V,8,~,h,^,F,{,V,O,],:,b,k,.,^,/,+,z,{)
#define  mOl_pqYmh5ssBcJIZ6q0J  mCFz2OndHru2NfdPZhWmk7A9CrdvZdW(],[,e,!,r,F,S,.,},.,w,*,A,N,{,d,;,n,4,3)
#define  mTbFmYTUNtf7zntd6hHWU  mTLhJYbMiC9paIJsQzViuJk6GeV9Qml(E,4,[,K,V,d,X,.,T,{,!,S,[,-,o,i,s,{,},w)
#define  maGP440HVufJqhdScy4Rw  mHKHoSXzWeBSmJLoH9IivRof504kmZD(^,;,m,i,M,v,F,k,p,:,v,],J,n,t,D,s,B,B,^)
#endif

#ifndef _UCOSLAM_LOOPDETECTOR_H
#define _UCOSLAM_LOOPDETECTOR_H
#include "map.h"
#include <thread>
 mmUUQwIiPZc6TglbPqBTo 	 
    	  
    		   
     
     
  ucoslam  mnhr9dj_T_Ih_QUrNDVOh 	 
    	  
    		   
     

 mgEb5eHmbyGI7ClgqeFAA 	 
 LoopDetector mBgNFChGWIfvr1Kp2ebna 	 
    	  
    		   
     
 
    std mYoPvvl1Pe_VQcBF3nHeK 	 
    	  
    		   
shared_ptr mmDSex5y6veoNxzCGKUWp 	 
    	  
   Map mXNdPRzmY4BvikWV5QMqg 	 
    	  
    		   
     
 TheMap mxYZnpGCJat1STTxqoLe9 	 
    
public:
    
     mIjsVw2w1qrdlj_FkMUvH 	 
    	  
    		   
     
  LoopClosureInfo mnhr9dj_T_Ih_QUrNDVOh 	 
    	  
    		   
     
 
         mwdjXTRxLZxh1inaSgpwB 	 
    	  
    		   
  clear mxN1F3iKhNIqyvfkD2J82 	 
    	  
    		   
     
     
 
 mNNEC0JsGqNEy8kSWKdG1 	 
    	  
    		   
 
            optimPoses.clear mvOZadI4DJPkFQ3NQefTi 	 
    	  
    		   
  mJba9s7Ei8YcxzPWXDwKw 	 
    	  
    		   
   
          mWyWQoKZEk_wxL0sYTNIY 	 
    	  
    		   
         mUXv8cu8t_0MaegGK0sg0 	 
    	  
    		   foundLoop mPUBSAFaMQW9nXOrFjWc2 	 
    	  
    		   const mMU5qJ6Uus46bmamiVQYi 	 
    	  mjH_uEjwyibskQdKygQVa 	 
    	  
    		   
     
   optimPoses.size mGHHnAK0oaQ_vxNDcLLuU 	 
    	  
    		   
     
     
 
 meaSs4YklDqyxOextAI5B 	 
    	  
    		   
     
     
 
  0 mGxvjq1GJ0GrOAIqDSoGA 	 
    	  
    		   
     
     
 
  	   mWyWQoKZEk_wxL0sYTNIY 	 
    	  
    		   
     
     
 
  	 
        
         mzoD1GDnKpYtXQjEYXOhM 	 
   curRefFrame mEhOaYRUuzHQdIYlz_FWO 	 std mHHH5Pkq0nMpiCWN0AclH 	 
    	  
   numeric_limits mFiijRfjhB7soiHFuL0dz 	 
    	  
    		 uint32_t mzxyRGuglqsE2o02KL87R 	 
 mGx9UCb8TXfmeKK_avSOI 	 
   max mKw_J91bG23IWGkhWK1wr 	 
     mstX8kjaW0j3Xtiq5DP06 	 
    	  
    		   
     
  
        
         mesk2tlfX1Eq87H9dfgGR 	 
    	  
    		   
     
     
 
  	matchingFrameIdx mO6pMytYLugKzeluGhux8 	 
    	  
    		   
     
     std mHHH5Pkq0nMpiCWN0AclH 	numeric_limits mBEzkQh6xxU7AX5gupceS 	 uint32_t mf__ldQZHOpoDtpPCIeIK 	 
    	  
    		   
 mvr_79KBN1uKlJTfbdQBS 	 
max mdeym4I2_Z_1pHp_dpmBF 	 
    	  
 mOl_pqYmh5ssBcJIZ6q0J 	 
    	  
    		  
        
        cv mHHH5Pkq0nMpiCWN0AclH 	 
    	  
    		   Mat expectedPos mstX8kjaW0j3Xtiq5DP06 	 
    	  
    		   
        
        std mqJJexFlIUlnebeASNGoY 	 
    	  
    		   
vector mGDR8TJUTyToenmz_uSz6 	 
    	  
    		   
     
     
 
cv mvr_79KBN1uKlJTfbdQBS 	 
    	  
    		   
     
   DMatch mzxyRGuglqsE2o02KL87R 	 
     map_matches mJba9s7Ei8YcxzPWXDwKw 	 
    	  
    		   
     
     
        std mvr_79KBN1uKlJTfbdQBS 	 
    	  
    		   
     
map mte6Fe5A42HNCGFEcMszt 	 
    	  
    		   
     
     
 
  uint32_t, cv mHHH5Pkq0nMpiCWN0AclH 	 
    	  
    		 Mat mhEzCj4b5tG4c8gdSoexG 	 optimPoses mqLzAIoycS5nyYDqmnjBo 	 
    	  

         mEyvLZGxrdUss2_MozUhq 	 
    	  
    		   
     
  toStream mckt8Isp74rt8Cu9Wo9wY 	 
    ostream &rtr muI_MVpOf8wwfSqZyt6sr 	 
    	  
    		   
     
     
const mJba9s7Ei8YcxzPWXDwKw 	 
    	  
 
         mrkLMKpyh8vWbQksiQt9_ 	 
    	  
    		   
  fromStream mGFQRe6bv3_n5nX9lIEn_ 	 
istream &rtr mpVXwwV4ZwyKrySAl2Btu 	 
    	  
    mMQyhEkTwuF8fcNqMuapK 	 
    	  
  
        uint64_t getSignature mbxRbYGLkU6peC5Qhg6dh 	 
    	  
    		   
     
     
 
   mstX8kjaW0j3Xtiq5DP06 	 
    	  
    		   
     
     
 
  
     mkp8Spcy1F0iak3NddLAc 	 
    	  
    		  mxYZnpGCJat1STTxqoLe9 	 
    	  
 
     mcHKq9_Xmvtu5okbTbMLx 	 
    	  
   setParams mckt8Isp74rt8Cu9Wo9wY 	 
    	  
    		   
  std mqJJexFlIUlnebeASNGoY 	 
    	shared_ptr mmDSex5y6veoNxzCGKUWp 	 
Map mf__ldQZHOpoDtpPCIeIK 	 
    	  map mz4WU8qCixUY6ByfS_9cP 	 mMQyhEkTwuF8fcNqMuapK 	 
    	  
    		   
    LoopClosureInfo  detectLoopFromMarkers mv3nl3_n61hHGSa023hAV 	 
    	  
    		   
  Frame &frame, int32_t curRefKf  mee0ccvjVmBCa459_Bcpb 	 
    	  
    		   
     
     
 
 mOl_pqYmh5ssBcJIZ6q0J 	
    LoopClosureInfo detectLoopFromKeyPoints mv3nl3_n61hHGSa023hAV 	 
    	  
    		   
 Frame &frame, int32_t curRefKf mee0ccvjVmBCa459_Bcpb 	 
    	  
    		   
     
     
 
  	 mqLzAIoycS5nyYDqmnjBo 	 
    	  
    
     mAt9WTcAIWLqWkVwl3l0e 	 
    	  
    		correctMap mD7DVvL4MYmdF2NaQabvw 	 
    	  
    		   
 const LoopClosureInfo &lcsol mqx_6Jnc27tBCNeJEr1BL 	 
 mstX8kjaW0j3Xtiq5DP06 	 
    	  
    		   
     
     

private:
    
    vector mqIT8_Nza1Rm8YWjfLBrh 	 
 LoopClosureInfo mzxyRGuglqsE2o02KL87R 	 
    	  
      _15750007572696103223 mGFQRe6bv3_n5nX9lIEn_ 	 
    	  
    		   
     Frame & _46082543180066935,int64_t _10707402390114315114 mz4WU8qCixUY6ByfS_9cP 	 
    	  
    		   
 mzwnsyB9BtWRtd64XzrX5 	 

    std mV0QFCsbReAuzx5R05RvP 	 
    	  
    		vector mFiijRfjhB7soiHFuL0dz 	 
    	  
    		   LoopClosureInfo mNlLawHGcC5XHqvf7Guxo 	 
    	  
    		   _8671179296205241382 mU5N_1Ku1Pmo9dNDTJQXD 	 
    	  
    		   
     
      Frame &_46082543180066935, int32_t _16940374156599401875 mo16J6uiDJWmRkGN3Lia7 	 
    	  
    		   
 mOl_pqYmh5ssBcJIZ6q0J 	 
    	  
    		
     mcHKq9_Xmvtu5okbTbMLx 	 
    	  
    		   _6767859416531794787 mGFQRe6bv3_n5nX9lIEn_ 	 
    	  
    Frame &_46082543180066935,   LoopClosureInfo &_10148777732430291359 mlpvtbw4SpRX7RubFGGOD 	 
    	  
    		   
 mqLzAIoycS5nyYDqmnjBo 	 
    	  
    		   
    
     mvsnhO_5G_j6WFwkVAOL8 	 
    	  
    		 _16495135671838418327 mQT50U7gfb68rWYVd8Pf8 	 
    	  
    		   
     
     
 
const LoopClosureInfo &_46082543426142246 mN21WGJngVyi9zKks4DfE 	 
    	  
    		   
      mXyRTUxgOHa47zZGhQWLi 	 
    	  
    		   
  
     mAt9WTcAIWLqWkVwl3l0e 	 
_16786277844087146768 mBCMGeehCsFFc6Ot_C121 	 
    	Frame &_46082543180066935,const LoopClosureInfo &_46082543426142246 mlpvtbw4SpRX7RubFGGOD 	 
    	  
    	 mUFOZ5kRgZmUYuWs5ZV01 	 
  
    
    vector mw3pPhfuO9S8xgzdG63PI 	 
    	  
    		   
cv mqJJexFlIUlnebeASNGoY 	 
    	  
    		   
     DMatch mzxyRGuglqsE2o02KL87R 	 
    	  
    		   
     
   _15519652129875366702 mIEnKlaSg8RlJm1zQi9Gw 	 
   std mGx9UCb8TXfmeKK_avSOI 	 
    	  
    		   shared_ptr mqIT8_Nza1Rm8YWjfLBrh 	 
    	  
    		   
     
     
 
Map ma60Yc9NzbE1hbICvgixr 	 
    	  
    		   
     
 _11093822290287, const Frame&,  miLcMYSg82wM3UPyJgCgf 	 
    	  
_175247760268,  mU1puvuhgHd9q4akGbTAq 	 
    	  
    		   
 _1686565542397313973,void*_6806993289704731004 mN21WGJngVyi9zKks4DfE 	 
    	  
    		  mMQyhEkTwuF8fcNqMuapK 	 
    	  
    		   
     
    
    
 mPXCu4ttaI5sASKdxCkSr 	 
    	 mMQyhEkTwuF8fcNqMuapK 	 
    	  
    		   
     
     
 
 
 mIsvYE_zOARj2rl25lgKT 	 
    	  
    		   
     
     
 
  	 
#endif

#ifdef _9782504056344698902
#undef  mUmJy3p7pPTgzNea9iKK4 
#undef  mo9fl0ZYufacFjvx6tbDa 
#undef  mPXCu4ttaI5sASKdxCkSr 
#undef  mhnXM93CrwIn5JpwSeg6w 
#undef  moQlZ6jh50hAsJD67BBUZ 
#undef  mFwJo3EfIWXDfRrlaQPQJ 
#undef mEwfCShTGrzki0YYEmwrp_YZDn829ha
#undef  mw3pPhfuO9S8xgzdG63PI 
#undef  mp4P7GoG0s6ehPPIWVPeh 
#undef  mD3NmZzXKtOKDPiMqXZJu 
#undef  mVy0gLpEv86ipWSV7LjX2 
#undef  mpGnv9f0av9Vj1hd6yKBf 
#undef  mckt8Isp74rt8Cu9Wo9wY 
#undef  mKgl3BFl4WG15GZN4Ou66 
#undef  mD9hRYF2UBRmCW6JOnViJ 
#undef  mgEb5eHmbyGI7ClgqeFAA 
#undef  ms_UBn5foW1HGmlGYzMVv 
#undef  mm1zeg6ta2inbBHIyDWwD 
#undef mRmH8nDU_sQZX7Qvk_4qQRYAjBNiVYL
#undef  mY_beDscC7AbKHhsSc0qT 
#undef  mVDSzDj37n7g8R3dliP1v 
#undef mKUgDlK5uBFMH37iM4A7rdxfea4Atx2
#undef  mjuivd18O_cORgQxp6aQC 
#undef  mFn52bvjlQ3woF6cZHQFL 
#undef  mERysiOX8fBCFSojlap5L 
#undef  mTScqrG89d_ENOox4mUue 
#undef  maicGEBdD32YBKsaxYfTD 
#undef  mgA1fSRy0Hj4g4Ic04tz4 
#undef  muxcDqb9mhm33I4FqZi3f 
#undef  mkOYjpvsInuqqNc0v68Ok 
#undef  mNkDzyDJrgUp5FVW5tgf7 
#undef  mqRGACdSzb3UG_UcYTIAc 
#undef  mWkgnx6i8j76H3_w90oxS 
#undef  mIK02Ly6XGm6Rf1rk9K0G 
#undef  miHgdX6IU4ih9vsjun54l 
#undef  mWmfld_1GpwBBEHgrBD6d 
#undef  mfF3uMAym8vj7ewvZpFfx 
#undef  mwdjXTRxLZxh1inaSgpwB 
#undef  mCSmX3LpSZ9HoaLervTzK 
#undef  mHQgWQmfNt9VfRMXRD9bc 
#undef  mez9xCFKu_apZdc1VVCc1 
#undef  mAYWdS3SCswo_PJNr9e0q 
#undef  mE_ABeC7aMMkhfG_U6Wc5 
#undef msyI9fuwcMds6UruWDlrODYRtM2rsE1
#undef  mSEJGgMmxgGhlksE_qht4 
#undef mkAnH0ppNtYepCbfY8mLx5uetHliLHk
#undef  mr2ePkWlxwF8hYmDCQ5mx 
#undef  mIMnlryaavwZWlsbfcE0v 
#undef mhtKM1GRwtLy8mJDBXcYJRHR80VUQVT
#undef  mslRYLVssGz1RQ53IMfPq 
#undef  mcIPUA8fT9HfpO6GDfnm8 
#undef  ml215GEcOPFWd5_X88uab 
#undef mWPLIOkPGt9cYBGij7hycXqvnlUMovA
#undef myMi0438j5H02MUKBi0_n2aYjkhkYxw
#undef  mdDFfPUnYFkSZFpD5PgkH 
#undef  mIjsVw2w1qrdlj_FkMUvH 
#undef  mGDR8TJUTyToenmz_uSz6 
#undef  mzshdKAjadFpp85G3CHtJ 
#undef  mmDSex5y6veoNxzCGKUWp 
#undef  mr0G07cPDUS10X5dt8is9 
#undef  mrmdYe5Bfudy0bp2_rRsl 
#undef  mFRXvN8wGpzOIdLtqeecU 
#undef  mq1gP_qFTGqdMrHBScVlB 
#undef m_4iUjMwHl9NQ6YUgSK27f2E1f46b9v
#undef  mFxto0AE2a4mGtmIfr_x9 
#undef  mNlLawHGcC5XHqvf7Guxo 
#undef  mJ3x_IXN8UGLftKAkLYFN 
#undef  mgeIKNhtFkSOfuHyQLVxu 
#undef  mcvWuawPYEfp9tqnBbQ_z 
#undef  mxd675HfTfWInr6lbeO5S 
#undef mY8ggEG5KdnOvnfWRG_KAVPULp2CwMl
#undef  mZZaKdQ0qOcAUC4DloOai 
#undef  mGbQmVYnKVFXkIPy5b3BR 
#undef  mjvQmDN4ZRZvKmU2y2Phm 
#undef  mJba9s7Ei8YcxzPWXDwKw 
#undef  mGLayjXUHXNev8w08mXaL 
#undef  mpihs61Gw1IOGOYa_qsQw 
#undef  mKFijNqtZITJtaHalDQ5z 
#undef  mZ3VY46TXTmx2yvdy7LE_ 
#undef  mh43XcVW4Jb6q0jz86elR 
#undef  mOl_pqYmh5ssBcJIZ6q0J 
#undef mccnCADFZD5f8IrqdY5yCd_ZFi8lTTM
#undef mvEHIiUCLE7_OCErYzISqDBLxOpIKdf
#undef  mWqnAR3IUUZUWjByK4Nsy 
#undef  mOCxEXN5ohgVE9kD1LuSA 
#undef  mLCvdE7yOMjiRrzufhcwM 
#undef  mfyu9T2GOcqdv6S9xtFHs 
#undef  miBK3dXDE7PG8fi8TOyiu 
#undef mGl1TG1ojqAy320afAjJ6NWY4uvYh8f
#undef  mQT50U7gfb68rWYVd8Pf8 
#undef  mjpT9XoDIMlvUXGOMOq13 
#undef  maeTSKjWRcHNgkFj49Npr 
#undef  mSuqXMarXFyw7T7tzexld 
#undef mx8t_An_TZzdU8UsXvQ27J8EERsWx3q
#undef  mCTsadakkcUrUBpTpGVIu 
#undef  mbWqmIYIk50USZvyCkpPC 
#undef  me0pq4CZXW6BIct5RIelp 
#undef mVHYdBlSl70Zg4iZuA5rFmv9HBOcm2O
#undef  mY6ZNu41__zRWvmHf8j0a 
#undef  meYuhWSxoFgv92cDrSi7A 
#undef  meX82cVluPcUMz88fnLGO 
#undef ma9iM5G8HQ6fQG7kra3pHNBHH8Ujy6z
#undef  mPg3uGfgyBPpjDU25Xgzd 
#undef  mPT8MNchFBWu5vqoJQgVu 
#undef  mIlQpJLrLizYjzDILIN1H 
#undef  mWyWQoKZEk_wxL0sYTNIY 
#undef  mUFOZ5kRgZmUYuWs5ZV01 
#undef  mev1BE8yh6m8WM2nFXBMh 
#undef mjnZzWxtrybiJBesOfAyCSpUsddKh_W
#undef  mHb7DaeOSRb9jo0aAaMrO 
#undef  mM_3w67ZBgIBm60Itnman 
#undef muiwBRJ11aN_4bHxj65UjdaObPLSnq5
#undef mdy76Xp6WDFhq4aknIGVuIrK1JIMf_o
#undef  mcHKq9_Xmvtu5okbTbMLx 
#undef mTZkBRGlTTpI3eLCTqGpDPOmmD7QYzQ
#undef  mV0Rm297GHXQcUZXOWJXo 
#undef  mKHDrlQHuHAankQ65f6Yj 
#undef  mZCf9QQwpzfmbNXj1286x 
#undef  mIsvYE_zOARj2rl25lgKT 
#undef  maZlh3n7HOSaJPOONR59a 
#undef  mv3nl3_n61hHGSa023hAV 
#undef  mZhStilsrw3aWUFkLHo_d 
#undef  mkp8Spcy1F0iak3NddLAc 
#undef  mqyWzD5DbCvtJba5NPHIv 
#undef  mO6pMytYLugKzeluGhux8 
#undef  mBX76ARTrRmcMCr5dsMwm 
#undef mbBNTjTwelBtwGekx3RHF5h2kg5iboP
#undef  mO_tR3p8Y5ndfzBqMqc6s 
#undef  mxgzlrGma1ZSNS31_q5NM 
#undef  mDMFSyMQIY5q2E2h_0K4F 
#undef  mvr_79KBN1uKlJTfbdQBS 
#undef  mguu4yXvJRhef3sQn8oTB 
#undef  mRVwGXxIWsoA47PxGsYW7 
#undef  mql1yXcMv1hoPr3wKgoYJ 
#undef  mj_E2Iu_MdtyFKO9Skb2Y 
#undef  mjmtjgDbOhQgkH03kNF7Q 
#undef  mAlfWV8hvUoYqenlftWwr 
#undef  mTpqCb9eFeW9JPbPwWa1v 
#undef mynAWcQd2_Mt3iFrGWaoOJmPWaRtly8
#undef  mM5FgaVL5k8ng3FbCaD04 
#undef  mq75Tu4f0S1I4eiP6p0Tu 
#undef  mIjdOdNeJvPyfkD7qGOAN 
#undef  mrm6UOI2aJ5lG45nmJHL2 
#undef  mzLG_CyZgGoVp9LKxIM5W 
#undef  mjOYzllq6yqKy2VpJ9Xr3 
#undef  mU1puvuhgHd9q4akGbTAq 
#undef  mDx8VfkMtFlINMtMC7rRX 
#undef mRSJoejcLrgIFzxbOLSMKfqyLf9AITw
#undef  mFXKhZhXXRK7uJrDZzfBg 
#undef  md7BJC3Ig4_scejZUvsWE 
#undef mC9WQdYSwORTZYI6K4_bf060MQtY_6g
#undef  mbxRbYGLkU6peC5Qhg6dh 
#undef mNFPXg1vvBGBMIVHpqY9_6D_JHPsxpl
#undef  mWm0H3bHUADlrvnYv31O7 
#undef  mn647uYuBllrUBysnDM1z 
#undef  mLzwSnWSJ7ZioJUT1h3d2 
#undef  mcFgkb6pzF8ZQ1x_0cgHa 
#undef  mOn2SWvDb_zd524L2mQzQ 
#undef  mpiVbrARp2CGnSLAPydjx 
#undef mjRrHuMYvcGJ09dzND4VoPt4dBMoOiU
#undef mKvf4_kRXHjSD2t3sWCg0aBiYTFdlJd
#undef mGPAt3vckzLMXmzrFe5DqzzeJbOdIUC
#undef  mYgPJJs1Wkl93Ry8x3YgW 
#undef  mhEzCj4b5tG4c8gdSoexG 
#undef  mvOZadI4DJPkFQ3NQefTi 
#undef  mGevH5wNXrnJQokHM2Fjk 
#undef  mMV1A80O9dOLeHtqAhCBT 
#undef  mFaGpILyg8p9tZfVWgtGX 
#undef  mwdNO85FlVEr5yWDF3EYf 
#undef  mb_zj2Rdmm2QSEciGcNf4 
#undef  mx102QtC2s12d4FzM_Ebi 
#undef mEwG95DuLXI3jnhzqZy12CT05dy6xf8
#undef  muk7T9taL9jWm9m0QXOwQ 
#undef mwiVYk8Nbro8BNsncTZFVWM5L2vxQgq
#undef  mPUBSAFaMQW9nXOrFjWc2 
#undef  mI3rOWtOoPn4mMkrX8ceU 
#undef  mtOS7avi4euZMv5ERfzyR 
#undef  mhZ8lDsRduMcL8JYVEOAf 
#undef  mO9nxdMKe3mP8sl6HSkuH 
#undef  miFDxmP3_Ka94EF6VTxiC 
#undef  mn04uhbuT0bpvG9iX1A2W 
#undef  mCqFRhfd1FUqXSDwR3v7j 
#undef  mtHfA2HpQNGuF2nq9i4DJ 
#undef  mMQyhEkTwuF8fcNqMuapK 
#undef  mG_3cWEMKoG0WsyjkRSci 
#undef mQ4_dnvQXvIrviXl8fwjoZENhY94ZOq
#undef mzxWAqrBOTMm5HIQX06P7yNijkWT3Ec
#undef  maPIL5Y0g8P1LRa673Ryy 
#undef  mGHHnAK0oaQ_vxNDcLLuU 
#undef  mjRCj2QgJcmWmnmcmdy7D 
#undef mbRLT2KQ5VRleRCG0zDJgxIl9u6_qIe
#undef mnQUhn_qKz8aV7ABxLplAokZGav9MtM
#undef  mcZJwwgtjedSwtdTCZNMq 
#undef  mUbwIUg6NTDOXPNwJTLC7 
#undef  mX3J4O1CdonTznkR7IsUT 
#undef mSEsyl7B7KV8ikymyyDA8d5zc5P2kvm
#undef  mFBcLmm164532GDBAr8jD 
#undef  mJP5dKWHzdCUmjYl8cPsv 
#undef  mcLbgXS9DZKl1Ud59heS3 
#undef  mWDZ6ujnKZnYIsfMOxpyk 
#undef  mqVto4FJjWSQYCHvWpkqS 
#undef  miZmVua_zlUqrJmSU7VWd 
#undef  mQkMES74GJ6EAsLRzOS0r 
#undef m_0SYg4Ry8A9XwbsPBNSTbS99OMibYQ
#undef  mN21WGJngVyi9zKks4DfE 
#undef  mGKi5_A1YPHJbj62SujMQ 
#undef  mpiF8pCBOrgEzb9YZSU0y 
#undef mawr6dGPRqOUiOPbtkpPg56Dv4o6g9A
#undef mDvtKdJpBqivrMbKg_dnnwMYKMo5pBL
#undef  mFyG8C1y_mbc50_kJcKCD 
#undef  mwARa8iQfCX7R7p2eAiTc 
#undef mDB33qkyhxNsBo32o8lYuTJ7GPTyzkb
#undef  m_XOAoIwZrhdSlDvqkYsR 
#undef  mcS6PutWiMi4BVBT4NjG5 
#undef  mig_xWYQvq_SDOHN4SBBT 
#undef  mp3zLC685P6uAxyDY_CHd 
#undef  maf3C3Rc9ZABw1C0tbTkt 
#undef mZ4wmOJAPrw0jYatvvyJ2nBMyLOBoq2
#undef msg90eIL00XusYeBYTFsD1CJCmWSrbH
#undef moTNTBr8_r79MDlm4z65dIzWyGfMVMZ
#undef  mqSAAdFS7AuHguQHlIFRn 
#undef  mMqoy5T4L6dsxQHcAypo3 
#undef  m_DKiSSeNSioPDA3_3yxW 
#undef  mvgOxL_YkBzu7ti7L8Wsy 
#undef  mWD5RsyKGC8zbYhKoV59U 
#undef  mkgMt4mOF5yTEOy3Evmvi 
#undef  mpqlJ6_xsk5GTMqvfbLLE 
#undef  mPaFr5k9Dgo1MRYYw_2qM 
#undef  mFeYnv2GLhwvPUCtlCI0c 
#undef  mjhGcucT2l8e53XFIzzFa 
#undef  mFo0jiHQaCYoe0tiYZ0hp 
#undef  mpPzvw03zK6lpP6d8cqZm 
#undef mZ_AB55DO7bJQ6W28Prx0GqwNNiPtSL
#undef  my7dn8WMaGDYRyhjdtFUQ 
#undef  mtvRFyGwrMfh94Mjma5GK 
#undef mczlR3rSfe095_rST6BfiQt7RfOuLDz
#undef  mTbFmYTUNtf7zntd6hHWU 
#undef  mPfhTp9s9NtR5Q_Bsfu9O 
#undef  mrWNQirUJIXFxHCOgKKMt 
#undef mpgT3h2CSI2vNKHhmJ5EVX1cyZcEgGz
#undef  mg8ZyeLZQaD6LTgtCFHGg 
#undef  mIgZxc9ysXc1ZlCjB0zug 
#undef  mdFG8t22yyg1RSZDCV9Bf 
#undef  mukIAcSa3HDCtwnUArMQs 
#undef  mbEOLnNBfm79ExhuD7yBm 
#undef  mk6kt64rLha8ta6JJDT1L 
#undef  mNNEC0JsGqNEy8kSWKdG1 
#undef  mREDZpCeiBh7Zl_yb5Qmh 
#undef  ml9hqVVHtgXb5cVEFAWnf 
#undef  mqx_6Jnc27tBCNeJEr1BL 
#undef  mzwnsyB9BtWRtd64XzrX5 
#undef  mZcdooINZx19sRjQi58AA 
#undef mDFklQUpJnNBnq80xguPE7ParoiPkj9
#undef  mrkLMKpyh8vWbQksiQt9_ 
#undef  mqkeemKgtDxMbo9wLrxwD 
#undef  mvsnhO_5G_j6WFwkVAOL8 
#undef  mb8ldbSE_RyOIdxU3_HXQ 
#undef  mdeym4I2_Z_1pHp_dpmBF 
#undef  muf2382lAemDTwALqTPAH 
#undef  mO9hdjCYahmgF4KVdnnur 
#undef  mXNdPRzmY4BvikWV5QMqg 
#undef  muW9orT_IUMWwtUny3Kd5 
#undef mut1YUHskRjz_Ts5ydzNgH9451V36Hw
#undef  mDIPLaVrh8oxRkzNKOdFZ 
#undef  miLcMYSg82wM3UPyJgCgf 
#undef mzIOM5GKY1zuBTKX2ozmmidLrbLpzoS
#undef  mNAIUX6U2oKkMfgVoNLyf 
#undef  mBCMGeehCsFFc6Ot_C121 
#undef  mzQTcl84kJ4G1cN4IQ1Pq 
#undef mdHK_4ufmWNsCl7OfKUmrP10dKIcQBy
#undef mEud5sia1sAW8td_NQz3o6sufOyuMvx
#undef  mBGAJZNXQekA2ApfE1Xfo 
#undef  mXDxmDLECD2LvgkY1Mqxk 
#undef  mP8QT62tznrXzCbainpqB 
#undef  mcQuv91WXsPliPGqdCQsP 
#undef  mEhOaYRUuzHQdIYlz_FWO 
#undef  mrdaysQVaSAUW_YC7CDLT 
#undef  mkRCPEKBzVzdVwegsLEQU 
#undef  myUXsL2zxfUhjUJnYE9ix 
#undef  muI_MVpOf8wwfSqZyt6sr 
#undef  mXznxSsJB7Prn7KrQBJaq 
#undef  mdX_akEvCmivcKJygnoNL 
#undef  mAWwVY8QK37tXEU3QHDhL 
#undef  mirk6I6201UO8tqFujFhZ 
#undef mtA8fwZdlu1FFxcYYkk6GGfmVyRc2F2
#undef  mjH_uEjwyibskQdKygQVa 
#undef  mP7G11Zir7_jDqyjHrFbr 
#undef  mjUUZd9MxOjpk4JSO7Su1 
#undef  mCQFg2g35zaHnm0KaxGOH 
#undef  mSh2Oupp3piGDkItovbVl 
#undef mGff2ew8lXFFRMJYYaRMsWRVsWGDFOU
#undef  mcfnmeUYQqsw10bfqUhWa 
#undef  mee0ccvjVmBCa459_Bcpb 
#undef mEpY9SCJq42MCBOu7Q7X4nIA_rU30PP
#undef  mgoPPzdXRgbgybxvrAI2D 
#undef  mqB4o4H2KWjA2uOi71r9s 
#undef  mssP73bi4zi_lHAwa5E75 
#undef  mhIPo29PqDje01xk6Deyk 
#undef mXE8SDT4GgzsKLKnCXr4OJ4jshdD_dG
#undef  mP3sekEJ2IPj_jTprg9VK 
#undef  mIqpvIH2mme3az9Av3rex 
#undef  mT6no6fWq4B08dRwmo237 
#undef  mxYZnpGCJat1STTxqoLe9 
#undef  moutiSefwv_kqoFAM4gc2 
#undef  mXyRTUxgOHa47zZGhQWLi 
#undef mgxg6pfw7BQpAfro3ph8pK58RCve4mK
#undef  mFiijRfjhB7soiHFuL0dz 
#undef  mVgVft3BFjYQcvhBO8m5r 
#undef  mHm3UUBWJLPZNFnFjIXFg 
#undef  mFnDFrMvUpziXwOAG1lnp 
#undef  msaaPxW0_D9TMKS88F0gy 
#undef  munbPUbPnffLtRzDsKcZH 
#undef  myFjvXO2HNdJdWxLnvh4c 
#undef  mxac2zpLb8ekECMJfU091 
#undef  mriQtUNyK9hPENLTiaO0l 
#undef  mBMf_NmX3j8G57aPigzfU 
#undef  mGxvjq1GJ0GrOAIqDSoGA 
#undef mrtYp5cMhWR0liCJ8XaspSPhdLcyLzm
#undef  mTQBd9SGV7J3h9REnqold 
#undef  mosma85rV585u9pm0Kw7j 
#undef  mkkn2O2zcR2p19o79n_f7 
#undef mkRZmph5jw8kLSgsudu8KYGyEEbC4Sx
#undef  mM76boKbvbfcel6W3PCaM 
#undef  mHpPdODE81xO110WEOr0f 
#undef  mKoLg8HKXnvSXG54s0V2g 
#undef  mNY2Ey9Xoezic0JmoYXzW 
#undef  mkSGXjKi0C2f5rL30_I4u 
#undef  mShQpQiSlvec1sDgF_8I3 
#undef  mw2LD9QEOzoAd86PqV4WG 
#undef  mnrGZJb3cUcoE8dcmLG1T 
#undef  mLk6yoTH7kFW5y_VbM2jR 
#undef  mhlnnjMt98ZPi2VlivEaq 
#undef  mew2rgA2K6n_PTfvoi8vm 
#undef  msVjoi_sxYWPYAhIgx5jv 
#undef  miDRFVmGLQFusiOdK9Q3M 
#undef  mLKIxKIlRf5H0i7VWK8wd 
#undef  mpRuX1flSjkmJtkvG7D0s 
#undef  mmUUQwIiPZc6TglbPqBTo 
#undef  mL1gI71iNLcXFzSMOlMyq 
#undef  mU1Pf3ImAfUwwIocou6xf 
#undef  mesk2tlfX1Eq87H9dfgGR 
#undef  mKTYdRtinjgOxb3uBPSpf 
#undef  mwkXaSoSgPH3RsXsjj3ic 
#undef  mo16J6uiDJWmRkGN3Lia7 
#undef  mckXtXHApdBjt_WgBiQqz 
#undef  mkfLhR3ZSs0EvsZ5NlSLX 
#undef  mzeBo3uMY2194lLeFwDQ4 
#undef  mPXSMKgsX3aOv_rz9Z3pu 
#undef  mYoPvvl1Pe_VQcBF3nHeK 
#undef  mYnkUYQPnzDehBK892vp_ 
#undef  mWksocxSNXgBk9KN6va5z 
#undef  mMoRqQjMp2ae0muMlnKGz 
#undef  mU288wgwBJtLqLlZRzUq5 
#undef  mqJJexFlIUlnebeASNGoY 
#undef  mLbIPBF4NxZPKbTiTmLAg 
#undef  mUQi3ntBcLiXcmCUT5GSX 
#undef  mkR5ug_yNzQKvN6rl6b9c 
#undef mjcegQGNH0Nutx_trs2j3U5ZvwBYcVd
#undef  mD8Fl8iqeIuF6y9BPxDeR 
#undef  mUWM2AAhQLrgKrd841EaZ 
#undef  mo74k7015fO9dZKL5Y3Zm 
#undef  mzoD1GDnKpYtXQjEYXOhM 
#undef  mIerjwVz97y8YDJLW9mqZ 
#undef mgD8rlM2_ePM8IltCZagDnOzkEsJ8S1
#undef  mOguBk7AapXjivQdJOi0H 
#undef  mHA26Te2i2KrNb2xrUyFo 
#undef  mRcuVfvK7l6TYlJxYWWd9 
#undef  miMKTKkLxtTMveoFZxYE2 
#undef mo6FhSxJ9SORESgXRowqX8XnA9s11r4
#undef  maGP440HVufJqhdScy4Rw 
#undef  moQ2_qTZqTGthoBYNXeG7 
#undef mYTfcrzyhs00BKGIQVeNSgyDPIov3YM
#undef  miUIIixgs_Wl_W4wVLsYp 
#undef mHTHVEBIojnLQ05n1IFY1Xoo8yRGk9N
#undef mYd2qfBcw7m_JRXY9YzqHM7djoobGgj
#undef  mpA7IoUcgx0tZxfdDgbng 
#undef mTLhJYbMiC9paIJsQzViuJk6GeV9Qml
#undef  mDHzEd2dY9kXr9ry8pUQa 
#undef  mqIT8_Nza1Rm8YWjfLBrh 
#undef  mzxyRGuglqsE2o02KL87R 
#undef  mT6WSRMNjEEDdvJFgN93s 
#undef  mXzgiU0iQrt9DSirkn21C 
#undef  mK5hIDIyvZO1sqG_skjPe 
#undef  mWlhlmlVS5zSarlBcuLEj 
#undef  mOW7MNlINYo_RDRuMuiTp 
#undef mROeptCsfoDorEPIXWfJUgGyIabdZn4
#undef  mN2hWrr7Fq4wTsHHP9djz 
#undef  m_lKU44WCQhnC_MbFxFB6 
#undef  mb3yYNcPNZZN4RrkkxcGz 
#undef  mAsIE2jCfQ7BNp9mVg5ux 
#undef  moN35PsIciulFCSovyLKH 
#undef  mstX8kjaW0j3Xtiq5DP06 
#undef  mB0lUkw9tTVxdvICT5bT3 
#undef  mlhQRZeaWoKiZWop9ojAm 
#undef  mnyn3tZm2UXLWfFUCrjxL 
#undef  mU5N_1Ku1Pmo9dNDTJQXD 
#undef  mRVKD0hiLFV6ELDLttDWp 
#undef  mnUibUNXDzlKte2LHgFCe 
#undef mgiVfE3diiEOaOvOsrUikdKCDmVIHzF
#undef msyG2fMJPQEXHD21DX1Iewqn7wJTRvr
#undef  mVMsHzcwvi7KLeVzcW86p 
#undef  mn67YOYg2FfwqMaBNwfE9 
#undef  mvH8SuDoCTNVdmFTSyjjB 
#undef mPzDUZZ_kbe5kz9IB4HnuH0x1xfl0D1
#undef  mIVeutg4VRMPHhpFRgIwY 
#undef mCFz2OndHru2NfdPZhWmk7A9CrdvZdW
#undef md86AcZEaKuFrC2g1NwCjrX7s9B5uKh
#undef  mvMUiPcpEwSd3uvCmRA1t 
#undef mXFAjbCeiAvXH0iUtGF8bHtEVGpMFBo
#undef  mVU0iKF7Tdjoqha32pEEq 
#undef  mUXv8cu8t_0MaegGK0sg0 
#undef  mfZnJQyaae_KYEVBE7S22 
#undef  mWRVh8ig7cMTF9yes4XeR 
#undef  mi8pvV1Llql4tJ6WmbmGe 
#undef  mG_GR1ogoGXTfD_5_eRum 
#undef  mmBqeMkgBMbvX_Gmku2pT 
#undef  mVhwhnLyQ4ovYmaSJWKvX 
#undef  ma60Yc9NzbE1hbICvgixr 
#undef  mVOzK0Z5JfcLN_EF7yv13 
#undef  muFFlL2IYbDkRiGtGx9EB 
#undef mBrzwSG_D2vVdbJEaAOtizM0SnRHEcG
#undef  mIEnKlaSg8RlJm1zQi9Gw 
#undef  mrxkxcNxToJpTh1fUkEul 
#undef mViM41lIbhubh8ZchYo2SQmnTnin6Vk
#undef  mSkRx2DYglW_4bEtkqup6 
#undef  meaSs4YklDqyxOextAI5B 
#undef mj1wI_OjVrYtFaWkxiwsr8_xL2K6JYY
#undef  mxN1F3iKhNIqyvfkD2J82 
#undef  mr5DARZZ3p78VXjgY_mPh 
#undef mC3mzpd3_8BzGzN2xAPettpoE5fjF_m
#undef  mwpd4VQQYYLQMp597a6IP 
#undef  muwd5yuTdIHM5yvjOXt2b 
#undef  myIrOSzzXFMqW2WWaNzuP 
#undef  mApzxbRj6bzi1Wmck3cVa 
#undef  mpVXwwV4ZwyKrySAl2Btu 
#undef  mQid1YzmdBZmKbjKStFJb 
#undef  mQWUwNq7uEpCxeX2rit7j 
#undef  m_hj4ZUIuUHOWJVMEtKD_ 
#undef  mpoqDn0lrqfhopL8RymEa 
#undef  mxVBJH_toxPl6xRUuvLsw 
#undef mm95SrVzVSsRVvfqpOArUOCyBPCGT5D
#undef  mBgNFChGWIfvr1Kp2ebna 
#undef  mMDVm4JhhnSsTO8_x5DKf 
#undef  mMjgYz8lcFJObznk9e8XN 
#undef  mtsXClVW5nzHPHfZYlxVI 
#undef  mM4Qa_HlIMyytwFtcJaqs 
#undef  mbjGmMPB2WNoO5i15pQ6R 
#undef  mkb8bvE9zovjO47f_D_c0 
#undef  mHrMhLNY2xDk8qGq4wNXo 
#undef  mu331Co3cm2hwkQzs5L_s 
#undef mLYFtoRvK3Tuf1cwBiQemmCwbZYVIf2
#undef  mo8k5pbH0hweR97BKhhId 
#undef mr1y_Q63dAcT5i67A6N8ryiYn9QH_kb
#undef  mf__ldQZHOpoDtpPCIeIK 
#undef  maTmTqCfUNdzJJKc3KWn6 
#undef  mKw_J91bG23IWGkhWK1wr 
#undef  mPjb2ma39HrCtg8MqwHur 
#undef  mdqYPeiMhJtXP6iBUiUrT 
#undef  mkFwSrnbZfjJ4IS0YCrmC 
#undef  myQEBnKqQLR8r9jJVGVV1 
#undef  mFRIdofOAeEUb5JTGgXEn 
#undef  meZXxfhkgLqDuwV82TPi3 
#undef  mesjXNXvkVYczPzF30JJM 
#undef  meJOlB5TDp5rXkJEUCf7Z 
#undef  mVnsfTPES43fWFt7l1Pyz 
#undef mBILaznAUurUiFq7NCozmHhwE9sqUti
#undef mH9y1KBwLK5lRauE3t6IjhKj1EmfJzd
#undef  mXPUmpZZq2SHpDxecnI4W 
#undef  mNkdxDsSjuG6Y7qTbpbjo 
#undef  mPqFxQ0z2UYittBHc1Ray 
#undef  mYbCX1gfIAIvvOGwxw14r 
#undef  mte6Fe5A42HNCGFEcMszt 
#undef mQKHSfROS82rgl95L5TtCFIaTeY3LSd
#undef  mFPpg37pUCBloJp7pZEYv 
#undef  mwHUnqdNCTljN9LmUoJEq 
#undef  mpipbTmfmPkFJ_dPVxVZw 
#undef  mogDdQEwLMfxdZfrwnt53 
#undef  mVn7gQ5s8WjC58pso8PRS 
#undef  mdsfbmTFQonqpozABugy0 
#undef  mYudR3lh2Pere0Hvd0ti3 
#undef  m_E1hsBJgj3f3cPgqqwKM 
#undef  mlXoeXOAeWy7YT8Bk860k 
#undef  mSuD09G1UaM5fGM1BJ8En 
#undef  mLd7QoJKSFJ6DRDcYtjYU 
#undef mEk6O8kbchj8ipk9vpGo13SCN0UwwPy
#undef  mJWH5JhjUFhgA_mrhbTKE 
#undef  mvjH29mNn2NFqjnwuqsIJ 
#undef  mxRpg2M9JXlMmAbs6pnMv 
#undef  mcVumPKqKSZU_xiyPudA7 
#undef  mwxTcgqS07UGOKNvRyoAa 
#undef  mRwjJs9dN4XbZsBgd_rSO 
#undef  mz4WU8qCixUY6ByfS_9cP 
#undef  mEyl6LZaQ5pMYLT1Kz8AA 
#undef  mwbtaRfh0nKNIZpa429jk 
#undef  myo3n2ckP6fq2BILj38NA 
#undef  menVrA1oebiqx8otu6RH8 
#undef  mNN1uWUqJhOo_8XiM5kYW 
#undef mi9KvHGcllnGkarIIhYzFL9j88fIYNB
#undef mdlgN3e3L1T33GaAiwPRJ_DLm5pEDCV
#undef  mHHH5Pkq0nMpiCWN0AclH 
#undef  mWa_k2amjUi2EKhL6mUxq 
#undef  mTezgr4r2OKvt_2mh39Cf 
#undef  mIxrbchg7L5FDWZEaEP6j 
#undef  mnhr9dj_T_Ih_QUrNDVOh 
#undef  moP4IzjvDipQU1O5MiHur 
#undef  mKQgkBxLd5AeKc2Kj9GmZ 
#undef  mG6TX_KhIOvUmkLpbp44Z 
#undef  mBeJnG48X6dlDvt4sChrr 
#undef  mrDexwOsYfsLrnFoiMldK 
#undef  mHLllHNqQIYyWL6MXpiu7 
#undef  mxeGTe8e36EvOUtOPXCLY 
#undef  mpf_yUH7_6AlbpQpbS0RO 
#undef  mzuLsRtIwuE3eMBNxCBXp 
#undef  mdd4NkbqgH2ehp30G4u55 
#undef  mpwILa7G44bkm4iEMsA8f 
#undef  mK4HTwuoWie0Aet5piB_c 
#undef  mBf61o7TCoYtqyeH7X5cy 
#undef  mQ2yru5ZxJrR3NWTESArt 
#undef  mrgD24AFGh33zCj8SQMF2 
#undef  mDHcTFhMptw7_tNcdogYj 
#undef  mqVhkJ3au9QMFJQpRdBXy 
#undef mGWcNkz0YSPEBRwv4sIAM0oN3hxHbLD
#undef  mD7DVvL4MYmdF2NaQabvw 
#undef  mDNbH6dIGjEkLeCnBz4bV 
#undef  ml3DPHzmks4AiHAtCG9fO 
#undef  mT3GNyaCvWRLtzaFh8Hda 
#undef  mT7kDvJtcE27jax77otKy 
#undef  mj9RNLDpsGA6QgurJFdpw 
#undef  mVgcgWlNkxqtPh7ooiFFN 
#undef  mqdrSvdjA2WFIKiLxb4hA 
#undef  mlpvtbw4SpRX7RubFGGOD 
#undef  mO3vdkQfvR91ACIjGJhNq 
#undef  mt9NSccTwmpOv0LGu5i_U 
#undef  mbdubbkgxlYXdxC5MKJI_ 
#undef  mGFQRe6bv3_n5nX9lIEn_ 
#undef  mvNTRGlMO_XsTMVsqN0Wh 
#undef  mUKdMx9FehiJxcYWireQ_ 
#undef mr_xel5p0WvztjpkyW83a8jehbh_4RQ
#undef  mZoutcT7k92RUhZpc_Wa8 
#undef  mxoCWpJGLvaIKGWmx6qok 
#undef  mlAeX8C1fo99PjFWJ0KdO 
#undef  myBPz6SmZNQ1APsKVvHwT 
#undef mB_p5sdjWSHmBpHCq3rFLTrfHm6s14Y
#undef  mhNHZ17NyQl2I4EcIVQLD 
#undef  mO20eph0YKJJfg0HOJasl 
#undef  mMU5qJ6Uus46bmamiVQYi 
#undef mnCev88A0G1bW8SzauVsU7yU1p8rwoW
#undef  meLV0JnhXSMJrnJNS4P7K 
#undef  mvMLUxI2amEP4OBdsuOGo 
#undef mxs6br1cw7NTMcMeXPUnNfChaPsDuwR
#undef  mye2iNUA9syMMDzdMdIOZ 
#undef  mxHPpqJps89BlB75DzsiO 
#undef  meDdF8IrSc4AvEbfRvXEH 
#undef  mo6ViZyeIgoyqQVsfy_mX 
#undef  mQ5Z4_QnYGE0fNSUG2J9L 
#undef mpSTNBl2zKCcjvVc5INSvMRklTC01RA
#undef  mhETEpWFxGzmCpLISfQIg 
#undef mHKHoSXzWeBSmJLoH9IivRof504kmZD
#undef  mWKVNKh_9I82K8ZZSMFwI 
#undef  mu4OREkLu_VrpwkiSToNp 
#undef  mXxAGs_lqFXLQ_ZJEDtGE 
#undef  miBvXI4bDsbz9GLhOfK37 
#undef  mQRMy9dFp05zdTgQ4WGJU 
#undef  mdIVDSqvA7YLEsjyYFHpk 
#undef m_7y8nFFsZ0DAIje_ezbigGUwG6bDXD
#undef maks2gY7mNzOX8HYBZWKkFp0NzeRcZt
#undef  musjkOPn4d3Y8jaiGeaaQ 
#undef  mGx9UCb8TXfmeKK_avSOI 
#undef  mbBIU64G78OrWtyUzl2bn 
#undef mcmEPC7MEx0oKn6GbPf5tttmEJTt74h
#undef  mZh5cmwqTnhHa0Uu6glZF 
#undef  mvVwPRFtlQzDxT9jLqLJ1 
#undef  mSos4f6fEUfTAmYIocfZy 
#undef  mjhrLaf0CITuejCBiwaUR 
#undef mYiMMzPp_5maC4wEVjiQmOn6FKCcz7w
#undef  mLB4GVs9AvmzSDVqNm4Cn 
#undef  mTQL1IBPHg4KkHh6NQ4r4 
#undef  moJq9x_5kmACOPXBkJO72 
#undef  mHTLUwyQ_OKqzcKhRVyIF 
#undef  mHHw9aR2tMUSLvvABZ2P_ 
#undef  mx5ua6WlpyLtMvIv0vw5e 
#undef mNuBAAmrMrpCr7LJCJER4e10dv12M9K
#undef mJfZLdo0hBVDmYQbUbMplP4jSYabd4x
#undef  mV0QFCsbReAuzx5R05RvP 
#undef  meqTs2j0ZUg2QWWYf2fFG 
#undef  mg1nTCVNl_qFuDC5yjUId 
#undef  mtRClgllt3O7cnBgpN46u 
#undef  mByJarYh4ZX0qQO3i16vF 
#undef  mUtc_5FsPUZQdx_AE78ny 
#undef  mDcyHo66xqIpHfkOESFnP 
#undef  mPrRI79bfNF6GRVWD8FxW 
#undef  mwmZWcHgxHwU2WoHXAkaN 
#undef  mlGn4bYrunqshMooSnX9F 
#undef  mYiuavdsJlvlbXyAnTW2L 
#undef  mpTq3pRh8cHLTsYwa0HMg 
#undef  mDjIwtlcOd5QXienbfjvA 
#undef  mr8f3Wmz5qy0ciNiz7zH1 
#undef  mipGitOmuPtJ5mrrDcbP_ 
#undef mwmtrQI3VFrziT0D3RKJqIWFWvHjd8N
#undef  mNqGqX9HSO9ynCd_uBQya 
#undef  mz8_eS2Qt_p9SAv1yJ_fM 
#undef  mgz5nF7aVkwpRRh6W2Lu2 
#undef  mbCwvJTwdLxiomxiH56tn 
#undef  mexJ2e3ckKvGXVkXizWPD 
#undef  mC3_i_ZmChrHaE5QV6IWf 
#undef  mqLzAIoycS5nyYDqmnjBo 
#undef mP_fSFFIhXCwCoMEtWC3We2VFZchLRh
#undef  mBEzkQh6xxU7AX5gupceS 
#undef  mzfqMAlHUbCtvfLwd4Avh 
#undef  mBiH7t8nnG9JYuh473018 
#undef  mtB4FpHFMx4LEcvOk6BI8 
#undef  mTgowtnmagqu6aC487oLf 
#undef  mJLUOTkrBc6itu7U0ribf 
#undef  mvEyWD17FEX6AZTc4MHFb 
#undef  majaEI4RfF7XwSNAfqytl 
#undef  mAt9WTcAIWLqWkVwl3l0e 
#undef  mF03_cTqmxcvwqp15Ax8T 
#undef  mBbF84NTouW2JJCOQDgCy 
#undef  mppqhnxpPiECFzEmzD8PO 
#undef  mwkVPV8G1473xkPSb2fuy 
#undef  mjYVzo3uLIybkXSC5HUvT 
#undef  mENuCAW1FZbkzf4DEvlgq 
#undef mXrqqYgHTstptihTk7jkhcmdRw0Yf_I
#undef  mDGjO3X4HmSwS0xhvQxEu 
#undef  m_gdUsrNcXDnE5sW393L2 
#undef  msvnLqCKeOtsIWROhYU8h 
#undef  mM3SKo7PyK2oxtvtoegMX 
#undef  mn07b_W8OQY2L20RPbz1h 
#undef  mvfEKz7DCd0RZl6eRN1IW 
#undef  mEyvLZGxrdUss2_MozUhq 
#endif
