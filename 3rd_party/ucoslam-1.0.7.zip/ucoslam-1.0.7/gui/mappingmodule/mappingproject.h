#ifndef MAPPING_PROJECT
#define MAPPING_PROJECT
#include <string>

class MappingProject{


};

#endif
