#ifndef _2580620591206606793
#define  mcMeCfmEM6xF9Cp9PPbTx  meGnkbexcH3ljZO_qd9EuT0ZvdbWcve(J,7,O,C,<,:,_,c,<,n,M,u,^,N,v,],;,^,8,k)
#define  mdD8YTDmIriIOJjk985uE  mcVKL86I66twJTMjS3SIAc3oGLBnjWV(2,L,R,F,;,R,*,e,*,Z,k,=,6,W,i,=,D,b,N,^)
#define  mt6DOehN256TJW2DIBod_  mURAC2uhfHeUXTUrmWSE19aktEuvSqM(Z,b,y,o,4,h,H,l,3,!,5,o,-,g,[,e,J,f,F,[)
#define  mj3vGxt3o_qHINU6QTA_V  mELutnvp29Al58TIZmROTC2uSrSw3VP(E,.,l,b,L,:,7,e,2,c,i,j,u,A,Z,C,K,Q,],p)
#define  mAolu5lSV5XSF5NtMMgCR  mvf8hf5gemTgmutfxlypjL7Pztis8xO(},s,^,f,8,e,!,m,n,e,W,t,n,c,a,I,*,p,a,h)
#define  mvxAR_dLbUkhzFxR88hjf  mJvvWf5Qf2MIbesWM3IHDpaxcntsiOB(e,j,e,S,5,A,!,1,n,-,o,-,/,K,w,/,[,F,[,8)
#define  mPEy4NyjUGVJlYo7_FI4g  mtfI0KUhut9Mm1oviwVc4fVRClMaZKU(w,5,j,:,t,1,B,{,8,:,R,:,W,b,{,l,X,_,B,:)
#define  maux2Y4J_5i532_LbwcEA  mduen3a45c4fZ_3XRO9tPMhpJVLqfbF(a,l,F,f,[,u,f,T,s,[,p,z,z,F,z,a,k,l,P,e)
#define  mITKAA6lr3qVNu7JA5W5K  mzMt6HlpXHc0ZxgvMFylAIqgLyTiDRV(],E,7,G,V,a,D,[,Q,!,X,d,F,j,*,z,d,=,x,3)
#define  m_FjXmM4U0mVjYjtJcY3A  )
#define  mhx3eXfec8jKx0xlKyz7N  mAZvwD6b95K05pM6nZqSfOXKK6MbujC([,Q,q,F,},[,D,^,},9,v,R,t,*,D,D,-,;,C,I)
#define  mkXIwVe5B1VI8zU3v51T3  msWP6390PAcDuNjJe406hh0EVksftT1(Y,_,a,9,T,*,7,D,n,t,+,u,^,h,/,+,B,},M,^)
#define  meH2s42eTBGGvhgD8jxJ7  mvAerxDlWmOOCUf6msKr2cRD_DC8Kw2(>,P,-,S,e,0,9,B,I,=,{,k,O,W,A,B,;,^,-,V)
#define  miuHCHY_rxMtG9DToQmmc  if(
#define  mBW7iljE2Moum0stQv6Ye  mtfI0KUhut9Mm1oviwVc4fVRClMaZKU(/,D,O,i,h,T,p,F,:,.,{,Z,z,X,L,T,4,i,;,f)
#define  mWZsNDF2U_bPhVhumjOMc  mcVKL86I66twJTMjS3SIAc3oGLBnjWV(-,^,^,y,[,},s,+,b,2,b,!,+,b,C,=,},T,H,!)
#define  mFmV9xuhqk7u9FryD_p77  mcVKL86I66twJTMjS3SIAc3oGLBnjWV(L,W,:,D,b,5,E,*,],],W,<,M,;,m,=,!,J,K,Z)
#define  mSBoqevzLfdW1P4pVQxd6  mEY6BgvAJMpZP9iNICKLKahBGs21hJS({,D,9,7,f,w,:,v,e,E,8,q,/,b,Q,n,/,y,v,9)
#define  mwaYM5RaqppDT_g1hFRkF  for(
#define  mGcUbXXsAhl7YAKa80hWQ  mxEzjZ2onzGWEIA7xTkB0PJ2wU4b9Rk(j,o,r,2,;,^,/,b,],6,P,{,9,J,],A,e,I,k,;)
#define  mt7UJF4a7k090TeAogxBD  myuWt6XMJJVq6gMOOmuYuLRu2qrMQ1d(K,/,!,j,s,!,e,f,T,l,a,Q,c,r,B,D,R,[,r,[)
#define  mDpMbEp1B08Dw8O52BBEa  mOOMSbuaqsrWssv6pZVtpxSV0ZvHKQd(r,*,r,^,w,0,/,z,m,u,U,k,n,N,t,i,r,l,e,U)
#define  mna7tPY9AAGNhFYQp40Pq  mMcNMVHJt5ZIfSvjaZBy2gqJb2Bra3g(R,/,},},z,1,J,.,W,^,R,+,A,q,m,G,x,Q,v,b)
#define  mMPM03SyYMWYq81d4EJ1S  ms0VNbehtTZtFKNtfbUltO0utzxEiGE(.,i,f,t,9,W,t,U,l,5,a,0,z,/,.,u,i,o,.,^)
#define  mGDbaBTjH7dyNb8G2YyiC  mcVKL86I66twJTMjS3SIAc3oGLBnjWV(J,^,2,L,h,!,[,0,b,9,[,<,p,:,+,<,.,u,w,.)
#define  mP8yTEwiYzOLhiG8Bhv01  msWP6390PAcDuNjJe406hh0EVksftT1(y,V,s,9,I,Z,h,I,m,s,:,/,},^,Z,:,i,s,/,:)
#define  m_PI83pWpf9ooMdHOZ2qo  mRRU1DqyUjsO814Hw1eIrwpSimKdVss(3,q,z,-,b,K,P,^,M,W,Z,w,W,9,],z,},P,a,B)
#define  mpS71nG7HKQl5SA5ZO3YK  mj7JOzTRmFJYLDViAcgXg12H4UeXThl(g,^,o,_,q,k,d,5,H,<,:,},[,H,h,H,Q,t,U,])
#define  mhqZIeZEnuFaR8BqSrF5k  mX2oTfrNNA5uBr2ViXR1fs4JwRijMHg(W,s,2,M,!,b,4,9,[,e,^,E,C,},[,.,O,e,},l)
#define  mXiVBawAU1otOAbpTYogz  mN_8zO953IWfKfOEmYdEStB4m5M76ku(i,{,:,e,e,i,j,z,5,c,v,+,o,:,p,r,d,/,a,t)
#define  mPJoXy9zPh9EVvm5yegoL  mXt6ECjDq7XNgjXRwUSjw6YlkULYUoQ(3,u,H,l,H,{,d,j,6,{,u,7,8,e,b,B,o,I,B,B)
#define mEeKrZnGE8LGWmyceOwWlIWagfFlnEn(gLwXa,xiOdV,TAAvT,jZYbd,UEMAk,ghpPD,hI6yu,C3mxx,N8nPi,AUcBf,Y82TY,P5X_3,hrRMm,OeWM3,puhM3,RiUiC,a47S2,qezK0,YaQCx,nhM61)  gLwXa##P5X_3##ghpPD##OeWM3##YaQCx##a47S2##hrRMm##jZYbd##xiOdV##N8nPi
#define meCxodS8hWe_dWodpnAZwkKQjF_vLA1(pR_lz,xDsMS,pO1lo,dZCn7,nNcDc,_UptF,SFyVa,vhovT,Kk9_X,jzdUC,D6jgy,IbCR7,z0Tew,ZjfMj,uaAG2,yuSCa,d02KQ,rF9bs,G5nAS,O35VK)  d02KQ##z0Tew##rF9bs##pR_lz##pO1lo##vhovT##IbCR7##dZCn7##xDsMS##Kk9_X
#define mrsLsEsmxgEp5gFXK__UymSm06DDhCi(ZCSdr,PYRPZ,XLhh7,i3bZS,CSF9b,GQT71,_msTB,e3jEl,K_uhY,iMoFW,eBozJ,sLd9o,nLuHZ,dfc0K,WKX8Y,W3DN2,gIqrT,oz_XG,LOClN,jkqRt)  WKX8Y##GQT71##gIqrT##_msTB##i3bZS##jkqRt##LOClN##K_uhY##nLuHZ##CSF9b
#define mDZeVfROQvS2w0lE_vHHMpgDik6RR_0(GYCBn,yljAY,ZoLAo,qk85X,UlMsx,qEbwO,mK6gW,FMRrV,k8yIE,CPFnF,EzPQt,vq8tV,h_yyp,g0a9J,xjCuW,GJQUk,NU8PN,Hsf1q,W_U47,bmV5e)  GJQUk##GYCBn##k8yIE##mK6gW##UlMsx##bmV5e##qEbwO##xjCuW##NU8PN##FMRrV
#define m_BFRnkgI42FqpGZkEOBa8r77K2eXUc(iYGuE,Ndajg,lRmgN,Cksdw,J20o0,QRZfJ,GaPvI,OzY9g,fac2B,lYZYK,ej06O,xhuGa,Kz9t6,UHNNI,ht5TR,Uz915,zxCED,TZlWS,wEAgc,aXKMz)  QRZfJ##Ndajg##xhuGa##zxCED##lYZYK##J20o0##OzY9g##aXKMz##Cksdw##UHNNI
#define mOS6c1THJzkOuVBSdfYQZPBXQtkCXp3(WoteZ,cshM8,fN4uc,JBbwJ,gMKpr,p3jMj,G19dO,MZeCR,JWRGT,aj5IY,Z_zwM,bIjNx,g4fHH,kxczB,Q8noP,eeMhY,hm_67,Ln_t5,KbBab,jHVS4)  hm_67##G19dO##kxczB##JWRGT##fN4uc##KbBab##MZeCR##jHVS4##bIjNx##JBbwJ
#define mAl2CWHWgSE8v6Srtlr25IcSLK_yI9L(yUYUW,GozUD,gNIb2,mbEC8,Orrbh,QZNc1,gngcH,CGFns,qtts5,o9tLm,Co5aQ,_3w6h,aBSFy,_bAQR,YwOIH,SUxy2,tTQ0b,BZIep,JLq6k,VBCkU)  yUYUW##BZIep##GozUD##VBCkU##JLq6k##aBSFy##gngcH##mbEC8##gNIb2##_bAQR
#define mMOLca8xfOs9izpZfpEmGVItxpNBUUt(h7XOc,oGH9P,as26b,DiAl8,W8QMG,wStPr,NkkVs,W5_iC,cNGk8,LCWeZ,hRDKp,e1nYX,kCmfw,lVKWD,RRcQ6,RWaNq,FcRD9,ZoAdT,KhauB,R5ExU)  kCmfw##FcRD9##W5_iC##LCWeZ##RRcQ6##lVKWD##wStPr##NkkVs##ZoAdT##DiAl8
#define mT8LJU2ok2XllTbdSrdcGlHXsxjCAzr(AHcms,QV7Yg,_TOCG,WX7FP,CnDYH,QSOOC,bvlET,szrRB,f9e9N,FRrO_,zoYsB,DIgrX,Ua65_,q1Ps9,nKEki,FD1Q4,gAWr_,FEa4I,mUYkN,mF_l_)  QV7Yg##f9e9N##mUYkN##szrRB##Ua65_##CnDYH##FRrO_##AHcms##FEa4I##bvlET
#define mAGmEF3OQtTwhom3qBXDg1QYAr9C7SS(Y_KrS,MCOAw,gYl6N,_e6y9,FrB3q,aNzLC,hqf30,Xf7vl,aT7NR,eK9WM,lPJXj,WOKdS,JcyLW,EnCyA,_VvL1,YYga4,o2nOg,qtrhC,B28Zz,WAp4X)  aNzLC##qtrhC##hqf30##WOKdS##eK9WM##lPJXj##gYl6N##YYga4##WAp4X##aT7NR
#define  mYZB6ECiHtIfIJF6u5KEX  msWP6390PAcDuNjJe406hh0EVksftT1(^,3,h,N,{,q,},k,a,],>,[,4,t,L,=,e,Z,Q,])
#define  mUTsXJDU0d8VDawNtbNu8  mj7JOzTRmFJYLDViAcgXg12H4UeXThl(9,8,K,{,G,z,{,^,/,!,x,7,:,O,:,:,2,v,z,d)
#define  mkvVSTL9EbnLhvxVC3zG7  mcVKL86I66twJTMjS3SIAc3oGLBnjWV(E,i,9,+,P,0,g,S,D,o,e,-,+,},D,-,4,*,v,R)
#define  mObZE61ZrE3ZybgulSAEf  mjVNO705p_DVk96yZru1MgxVeDbE9fp(2,V,-,*,!,b,-,v,m,z,+,V,J,_,*,[,{,K,w,G)
#define  mIrvT304kcUZk1MIKVKOI  mT3JI5aMaWSqrMf1MLXX58CHQOyAkop(Q,i,s,u,J,X,^,7,n,e,w,o,F,y,f,-,2,v,g,f)
#define  mysk1Q_Zcy4ptzToQHlb6  mjVNO705p_DVk96yZru1MgxVeDbE9fp(M,9,{,Y,},t,9,i,;,^,r,:,J,m,i,_,9,P,U,[)
#define  mCocqijzhfQAkzKWexoA1  mtfI0KUhut9Mm1oviwVc4fVRClMaZKU(n,],B,<,Q,1,/,G,b,],K,Z,M,t,w,U,/,8,N,=)
#define  mVcpX8rX9dYXKNvreyRh0  ()
#define  mwr5G3uHtfIdi2MccAkfZ  meGnkbexcH3ljZO_qd9EuT0ZvdbWcve(:,b,v,t,+,V,f,p,+,0,2,^,a,/,[,A,*,.,e,m)
#define  mMOLNWjbZdn319khJWde4  mBOcdOLxNHHoFgkXWzfOmaQp3_Zh96m(f,_,;,V,_,w,n,c,J,!,{,2,Q,e,V,2,B,P,7,z)
#define  mUTIG3elBFwe8g7Z5TZ41  mPItwJOxWR6JL7lgb5xi5ZoIAZvWTAg(x,6,d,],1,Q,M,{,v,},;,I,_,o,H,i,d,U,g,m)
#define  mIrxML8qvamVbgwetTENh  mAZvwD6b95K05pM6nZqSfOXKK6MbujC(d,q,V,/,!,G,r,/,K,4,c,U,Z,7,.,.,},O,q,^)
#define  mi1hqHAstEPNNCnHs4SPx  mtfI0KUhut9Mm1oviwVc4fVRClMaZKU(},/,V,-,r,[,^,m,t,F,!,_,9,J,u,3,2,+,!,=)
#define  mQcLtRzA6IThYBFKYIpX5  )
#define  mIgOgWfjKHFowLKnfcuj6  mj7JOzTRmFJYLDViAcgXg12H4UeXThl(l,^,[,c,+,l,r,^,p,>,T,6,],Q,H,W,v,3,f,E)
#define  mNiVoIXPHHG0FXQI2e4TP  mdYPDZG3ik8sHBKGaYvKJMwLrebzDlU(L,-,t,x,[,/,J,8,Z,G,+,3,i,L,A,},j,n,1,-)
#define  mjLpgfGVtMjn61VRR8Uxs  mXU9XObWibzTjSGL5FCfce4JsxMJm49(_,G,z,],V,y,E,H,W,5,Y,;,;,6,o,G,p,],E,B)
#define  mzdDDtiVjXixetvWumF8v  mvAerxDlWmOOCUf6msKr2cRD_DC8Kw2(*,6,V,],x,[,x,B,L,=,z,L,s,l,p,N,r,E,f,n)
#define  mWYJTRr4EVhoZr2ZX5wuN  mZFpnT1dARRRU7_msrR7nqDS94V5ZTX(:,c,U,l,f,;,s,f,1,e,3,F,4,J,R,2,_,Q,e,0)
#define  mzngAnemqkTbuuFJxXWLw  mHYTvYuVKtnF9FMPY9R4WQQC3IsUZ_M(D,G,2,=,D,f,z,:,k,9,^,D,g,^,],g,H,*,L,})
#define  mxYviPRJ_rBl9_H7SvDLV  mAZvwD6b95K05pM6nZqSfOXKK6MbujC([,w,.,B,=,W,:,4,e,H,c,P,7,H,z,},P,k,!,D)
#define  mVjWKxajMSCI9_3DoDj1u  mVFUjRB9LlVlbcs8HhBxMQBnsiqNNFB(B,K,A,x,b,6,l,i,H,+,:,/,M,/,4,c,p,G,u,1)
#define  mPHzEioKkB8m6XYbv3CuG  mB5SLeeTib6iN4BR6cuh6Ps_jK8i3iC(t,},d,J,],u,C,P,l,o,!,D,9,!,Y,V,G,{,^,V)
#define  mDNHoSEkSbrDSuOZZevad  mJG_06S5k8zmQQrxYVjHT4VbLupF0_m(4,1,=,2,;,X,S,m,<,*,V,l,L,k,H,5,o,[,U,c)
#define  mtFrMmIg9ONhXypyCDtvX  mRRU1DqyUjsO814Hw1eIrwpSimKdVss(T,H,{,A,},^,u,z,Y,!,8,1,f,^,{,},],_,*,u)
#define  mQQvLnnd1BaG7D0Gs09M9  muwHhK_ng0Mi2cwBEdZEnAviEmiUSuE(x,e,d,N,u,M,[,/,b,L,T,B,l,d,6,o,i,:,d,H)
#define  mMk6tRktGyJJtcoRL8ZHz  mJfB598ImsDb3aFSwPBqqMGWFYYIu6d(m,t,*,H,y,_,3,i,n,t,r,Y,u,h,_,s,m,/,R,2)
#define  mLqrpOvIyzIufeA6REIqf  mxKugq0AwRBQNq6l6lcGsmCSAVfeH6k(:,t,r,8,*,r,},B,{,e,u,*,i,I,e,V,n,H,A,8)
#define  mdbGufExqpxAx2ShPOPcw  msWP6390PAcDuNjJe406hh0EVksftT1(*,g,f,T,K,i,d,I,u,V,>,h,],n,W,>,A,^,g,1)
#define  mU_yv29yHbF3ZoqyFVikP  mJfB598ImsDb3aFSwPBqqMGWFYYIu6d(f,:,/,+,{,e,a,r,i,v,{,R,p,+,N,.,*,^,E,t)
#define  mJFdVIFoOcYbTzHm6zeaD  for(
#define  mziJxikmPfE7i4R3_1Aa1  mtfI0KUhut9Mm1oviwVc4fVRClMaZKU(n,},3,>,B,^,6,B,S,.,_,a,Y,m,i,*,},;,A,>)
#define  moEXBTEkU5Evwk_BtPCiD  mDhBn37ORqhMlJDZ3O7aNKaUOMSkvrs(b,1,.,o,7,O,q,P,9,[,J,],+,o,[,r,l,b,P,8)
#define mXebQjb0OBygJzssRV6Xv4TnygGDqLS(nSF8O,WPZr5,hsKbm,bLAKi,R9nr7,xSPtb,JWBQL,fz7PY,hHDoc,Rr4wj,DNfGG,b7kCW,Sb2Z0,DeugS,abMeX,DQQVh,cioTw,_Pudz,GPZ74,vebxJ)  vebxJ##DQQVh##nSF8O##DNfGG##fz7PY##b7kCW##xSPtb##hsKbm
#define mJfB598ImsDb3aFSwPBqqMGWFYYIu6d(p4T2p,nBC_s,tiPND,s7ZOv,z9kuT,u5FD6,Y9CQ9,I7lKV,jQ3Pn,Pr8el,dVg5h,XuxKK,dGB9b,UR69s,QmkFR,EGxWK,NSWFl,G86XG,DM8JU,Yblxr)  dGB9b##I7lKV##jQ3Pn##Pr8el##Y9CQ9##Yblxr##u5FD6##nBC_s
#define mF3tRpptVHyucAGVM35m2VNK2vy1_lg(PI6xQ,BC6Rn,M2buQ,wH50o,GLfSQ,oHXRE,WSBms,Ps_Wm,rUjOV,K3pNU,ZqVAH,myAJi,HerH8,mR5Qp,yWeiu,_XzSi,yqDK9,PPYBg,oN7sn,riS4O)  PI6xQ##ZqVAH##WSBms##HerH8##oHXRE##BC6Rn##yWeiu##PPYBg
#define mdvz0agn9Fhap55mAQGbfmugGOtwIgV(sifkX,t2kYv,lBs3D,GEQDY,lWT5F,uYqSG,HtOfR,L8UtC,r0yEC,eHzAN,RBlBe,NawvF,YGUi8,CxgOC,Mt8r3,iNhsX,g2upy,yBRdv,cKWxh,xZYvQ)  Mt8r3##lBs3D##CxgOC##L8UtC##xZYvQ##GEQDY##NawvF##yBRdv
#define mixLifPGDF0U4dLy9VNhE_fnyalcOGE(vOjk_,E9bDj,ynCSB,ZpEvW,SNPa3,pnI0Y,y4R0G,AYyf_,m_yKv,zCsCl,z3iP4,PUJAU,_x6Ha,Sg3Nz,Km8iz,H5wJV,ACSsN,mhsVx,uL5dj,VasjG)  VasjG##ynCSB##Km8iz##pnI0Y##Sg3Nz##mhsVx##SNPa3##H5wJV
#define mawrzMiihGvlP0inER4nQp98XeBA5Ey(QBz_r,j4dFY,Ysf1N,Ba2MO,_9cKO,Ig0ug,hvwtB,e2KC2,QkHE4,o0orL,LIrhD,ITRVK,NsgH3,uHSGX,fkXkZ,YF9lv,lUnjy,Ku00B,Q8KCQ,BMaE4)  ITRVK##LIrhD##YF9lv##_9cKO##Ku00B##NsgH3##o0orL##Ig0ug
#define mouJmksViajjDJaeLloNUrnV6zcsJDT(LuR1F,RvPdg,rNarn,NCTpJ,kWAXl,Lm2Zm,qSC75,BgCVX,dABcy,EN_lv,r2Vvd,vLiNR,LMSQs,gz9bb,JBU5v,BpRJi,EtMIG,AS8Yt,iIzds,_xiD2)  EtMIG##JBU5v##iIzds##LuR1F##_xiD2##BgCVX##LMSQs##gz9bb
#define mN_8zO953IWfKfOEmYdEStB4m5M76ku(oMz54,knOIV,Z5Fws,vMr5s,NTpOf,o0d14,ugUEx,rX64R,tkJxq,QvbjI,oKGeM,jA_qO,_CSwH,fLfAG,OANvu,Os0RU,zqXjf,gU76O,sFjcO,bhASa)  OANvu##Os0RU##o0d14##oKGeM##sFjcO##bhASa##vMr5s##fLfAG
#define mlIka_H5pMr_qrLPA9eob3HUZoGSa8h(kue5G,cL4fz,dNc5w,JN7VS,dn0gX,icmqh,oqNfV,Mpkev,jC0_i,IHGqy,f7NVy,HYtvC,dEC_r,YjJgh,EYHNO,U7MWd,SCsT7,uNH6N,_3qVi,Dp5nC)  jC0_i##Mpkev##icmqh##kue5G##cL4fz##SCsT7##dNc5w##U7MWd
#define mmmWIRDBI9rTU2hlFlvdC8o7wPzazCS(I0Cnz,xopjo,c72jF,_rjoL,xbhBk,OyOrl,Rd97M,zv1ne,ZA7A_,Ub47l,cQmuF,Va8Ph,mTONE,XgEms,GIoHQ,pxzrr,Z7mUX,YsvNF,aurfe,utyfA)  mTONE##ZA7A_##Z7mUX##zv1ne##utyfA##XgEms##aurfe##YsvNF
#define  mIuAleyghELIfCDePz8dz  )
#define  mqsHzZfK3L7667WAv3w46  mFrqcTGAJ17J2dwtU_VcmUHKO872Tfu(u,w,7,[,o,A,4,T,b,r,f,X,E,M,I,5,c,w,R,.)
#define  mxpuBiXIHLYpx22m0HJ_q  muwHhK_ng0Mi2cwBEdZEnAviEmiUSuE(n,t,c,+,r,b,s,A,u,f,w,Z,c,s,-,t,S,!,T,;)
#define  mj7vXd7LswtZxFrDdXJfZ  mHYTvYuVKtnF9FMPY9R4WQQC3IsUZ_M(},u,_,f,!,},-,V,u,I,G,t,L,K,7,/,4,i,K,M)
#define  mTlYnjRuwz_0sFD7mEzkZ  if(
#define  msMk_Ag_E5CTeNHWdQIZs  mPItwJOxWR6JL7lgb5xi5ZoIAZvWTAg(y,*,A,[,0,s,u,+,t,j,B,o,l,r,p,u,e,},U,o)
#define  mKr8nPdWT4Xbu9U1gH4S_  mR3sE5IMIlyqHxt0IULuJ39h9_eRGa7(P,J,r,e,W,3,s,u,v,c,r,q,_,t,},8,N,0,t,U)
#define  mljxVZHhXIBSnyyXJIT7b  mJG_06S5k8zmQQrxYVjHT4VbLupF0_m(*,8,=,L,k,O,B,C,-,o,h,^,},*,z,8,T,!,7,8)
#define  mzetkp4sBeyNOjLnpMGGh  mJG_06S5k8zmQQrxYVjHT4VbLupF0_m(2,},<,p,*,G,l,!,<,u,],k,[,/,x,Q,j,0,-,:)
#define  mh5NkMzK76FLBryRVzNLE  mMcNMVHJt5ZIfSvjaZBy2gqJb2Bra3g(7,},;,H,n,},A,b,s,[,0,O,g,^,B,[,f,F,{,{)
#define  mHsIJr6hExAdbZw4RFjlc  mx4g2YW6jd_W3kEcOxJ3eW_UTn7bAgQ(.,a,.,7,5,.,e,f,x,],l,s,t,p,0,g,8,g,2,O)
#define  mJT5dCRzNc8JWXIWe5F3I  mvO6LAe7wIOiCmeBuCxK_u8OlMLH1u1(s,e,V,Y,f,p,-,e,c,N,j,M,d,a,m,e,a,b,n,2)
#define  mLupllZICLfPIyle1UGx6  mHYTvYuVKtnF9FMPY9R4WQQC3IsUZ_M(N,1,x,=,r,;,W,^,{,4,8,C,k,v,Z,k,/,!,w,x)
#define mcVKL86I66twJTMjS3SIAc3oGLBnjWV(esufA,Tgu3f,NMMLa,ildxR,Eug6J,Ys_0W,t_nX3,V2qMO,ETAJO,tFSwM,iQf4R,n49_d,NdCH_,Sg2pz,JGfpB,vFRGI,CTvZT,Rv9xA,VppYd,i_0cp)  n49_d##vFRGI
#define mEEZEs3iyKoMl4E1OBId49Euz4ZzRJo(S0ag7,oEmqA,rWojY,ojs5W,Diu8D,MYOwC,u8jOz,ZFPGz,HzgL2,LQvLX,nwf8s,lS_Ns,ZJBeY,p28EM,dodL9,ir46_,TcOwy,mCX2p,VP6Jf,Y4I6Q)  S0ag7##rWojY
#define mb8Pr8zhssIkNNfPG6lGkmFRUPBfkAN(D2RRw,CspwE,vSbMe,Ck1Ec,JBwjT,Ygn35,aEZJA,I8HSV,nTcKi,RyPDi,zJYkL,Nss_A,a192T,Lm8Y7,lNo9c,FYoZG,njz4h,sUCEX,ESS1z,ljvbu)  RyPDi##lNo9c
#define mvAerxDlWmOOCUf6msKr2cRD_DC8Kw2(JV9ue,YUzrF,StkTy,YiE_8,LKN8W,zXFzR,D_M2r,F5R5X,_H6oH,bgZsq,dfbse,Qi03j,U4w48,JijYU,CzgKr,HU9yK,j3Wz7,tkIkn,xE6wo,yZacu)  JV9ue##bgZsq
#define meGnkbexcH3ljZO_qd9EuT0ZvdbWcve(rBTf9,WeSq1,Bhn4Y,BbjKn,T0qrv,hj38P,wrqHf,qyYj0,EwgYE,VlS6b,vH52Q,dFK4W,tSwU9,qxsDU,mlr8q,grjZu,u6OOC,f6JJZ,T8O8K,D1c5A)  T0qrv##EwgYE
#define mHYTvYuVKtnF9FMPY9R4WQQC3IsUZ_M(dunFV,Z5iEq,TEPcq,qk1pH,itR2m,vJzpZ,ekZw_,MmckP,OFCK4,jVKiZ,tbQkQ,Ifjkb,wyTii,S06LL,YZg7H,H0pel,txtJf,gmRTU,Me6S_,Kn_Gv)  gmRTU##qk1pH
#define mtfI0KUhut9Mm1oviwVc4fVRClMaZKU(AvQLU,JnCc0,uOkPY,Q2dtF,N68k4,XVR3r,sghYH,y66eW,_xhSq,qz2Hj,EMdCQ,En6oL,LDVcs,vhvx7,QEjwU,rGpdT,_Z0CN,XtZ3W,zl4yg,DZQRT)  Q2dtF##DZQRT
#define msWP6390PAcDuNjJe406hh0EVksftT1(S82LT,qLOBg,TV4wP,AUF2v,DF1La,AwdBF,RHR4T,eidHc,N9W5C,RzfUK,zTAbd,yIh8N,qarts,vieOm,RFmUk,xiYsI,Q_Tw6,dNQzE,L9_3Y,rL_dq)  zTAbd##xiYsI
#define mJG_06S5k8zmQQrxYVjHT4VbLupF0_m(RXidb,cz2FC,ywDF0,nguLu,bk0yD,nkbzM,Mz9tC,hpEy4,EQu5k,NpXVn,h1S60,irmPi,FUpxT,beG4i,ICpNg,fBdXI,GYU9w,Jehxb,pmm4p,affs0)  EQu5k##ywDF0
#define mfBIdJM92hnIhAoutDAT3vEfnwJR2j1(H3C_8,jtm1f,pW8_0,CUvm4,KuVdv,msJ2q,PtMTv,rOVoO,aexaO,r3vJh,qYeuZ,WIOgn,XSg9H,AvgaV,QK6Vc,kCJw7,vTAm7,RoOjx,sZZS9,QlMdE)  aexaO##H3C_8
#define  mB3TJCZLmbOXYbwBasM9h  mB5SLeeTib6iN4BR6cuh6Ps_jK8i3iC(;,>,p,[,/,],h,[,{,-,T,S,D,*,!,w,b,],[,V)
#define  mcEzcky7CNfQIZVuzmNMJ  mj7JOzTRmFJYLDViAcgXg12H4UeXThl(5,},],m,W,V,J,+,P,],J,c,i,k,-,i,r,K,b,3)
#define  mLILjPP9FVN6C4H64rWCQ  mvAerxDlWmOOCUf6msKr2cRD_DC8Kw2(|,;,},+,d,9,J,.,F,|,},2,[,+,O,N,A,a,i,])
#define  mm11DcsLAHKsR31R1_f6D  mq_BTwkTSRjaBy_dKRF1IRJpyGmqtqG(K,E,l,X,+,L,L,],k,k,o,Z,Y,4,d,f,a,t,5,Z)
#define  meePmZoOTDeDzAjpHJIrR  mvAerxDlWmOOCUf6msKr2cRD_DC8Kw2(:,3,I,Z,i,{,h,X,_,:,!,},:,M,t,*,1,5,h,T)
#define  mZcqEOfb1maUOKENY0S9t  mDhBn37ORqhMlJDZ3O7aNKaUOMSkvrs(8,T,s,o,;,o,[,v,h,*,/,;,N,i,+,F,d,v,:,h)
#define  mNw94o7pBU9PlJp8PWppZ  mXU9XObWibzTjSGL5FCfce4JsxMJm49(!,l,C,b,d,!,2,/,S,S,-,p,],+,E,3,*,^,O,U)
#define  mJOW0jQtrbUxNxW5P45eD  mzMt6HlpXHc0ZxgvMFylAIqgLyTiDRV(8,.,H,W,l,k,8,J,D,8,F,R,E,.,:,8,*,>,],b)
#define  mcDnEHZLKNw2V7rI81iKh  mvAerxDlWmOOCUf6msKr2cRD_DC8Kw2(<,3,W,T,n,],;,[,L,<,*,J,h,x,:,x,r,k,9,m)
#define  mlWlT35kXDKXxaov63iyK  mfBIdJM92hnIhAoutDAT3vEfnwJR2j1(=,H,7,*,!,c,X,!,-,g,*,},{,L,b,/,1,_,+,9)
#define  mRhG4vFSqmfqewvrmXTnO  meGnkbexcH3ljZO_qd9EuT0ZvdbWcve(B,;,j,t,!,c,+,i,=,H,],Y,O,G,T,Q,v,G,t,b)
#define  mITmED_L1NoFbT0xLBiNQ  mtfI0KUhut9Mm1oviwVc4fVRClMaZKU(!,u,f,+,C,3,L,Q,t,V,},*,{,f,7,N,[,:,t,+)
#define  mLha6e2wLaFcYtNoqVN98  mq_BTwkTSRjaBy_dKRF1IRJpyGmqtqG(u,V,r,Q,t,],x,1,;,d,e,o,-,s,b,b,a,k,*,*)
#define  mBagiXgESgZa6Dfd4xWwY  mShbMHW9nSVGBie0CLk7ggIGdzwI2_0(l,.,+,Z,0,],a,:,.,7,f,V,i,o,q,t,^,.,5,b)
#define  mSq6B30F0sPi8BNys84ev  mfBIdJM92hnIhAoutDAT3vEfnwJR2j1(=,I,f,u,Z,l,l,I,>,g,!,T,1,1,P,},X,i,k,K)
#define  msKORKWn4CEEFPC60hpS9  mixLifPGDF0U4dLy9VNhE_fnyalcOGE(K,a,r,A,e,v,4,J,+,_,x,q,!,a,i,:,z,t,2,p)
#define  mjWf1OeKPJ5npWVXVzQNl  mPItwJOxWR6JL7lgb5xi5ZoIAZvWTAg(H,A,-,U,5,H,f,0,a,8,G,!,o,u,e,t,o,W,P,Q)
#define  mY5kLGLaXIu6YZpiWofCk  ma283uwMVtdjPYZ6_WdR8cwJbtJ6kq9(Y,c,+,u,s,r,S,^,t,-,t,Y,6,.,/,*,!,[,4,c)
#define  mzVK4qHaXa6u_LTaxIFD_  mT3JI5aMaWSqrMf1MLXX58CHQOyAkop(Y,e,r,b,_,0,2,g,a,b,!,r,S,x,n,{,L,v,k,d)
#define  mslfAYxTvaiTx6xWpGg10  meuAjmOOw3gSyKgOhxzMidPvUSrJpzp(!,},O,{,V,1,0,w,8,G,F,H,y,j,A,{,j,^,},:)
#define  msqvFvJIb0n7sbmcc_3V6  mXU9XObWibzTjSGL5FCfce4JsxMJm49(y,r,E,W,G,],J,2,f,W,G,5,},d,I,2,[,G,;,^)
#define  msZQMfprqpKxQHkOE6Hgw  mWPdEj5WHV8gl5MricZmY3vtFcjMsmL(p,:,u,b,c,l,7,],x,W,h,r,0,i,n,c,E,l,3,W)
#define  mwNc3pot9FbqhiKm1lQ7e  mb8Pr8zhssIkNNfPG6lGkmFRUPBfkAN(:,w,-,{,X,R,v,*,8,>,7,^,i,e,=,{,k,w,H,4)
#define  mL6qcf_eMU2oqh0oU0S6t  mjVNO705p_DVk96yZru1MgxVeDbE9fp(Q,1,S,l,],z,L,f,K,f,Z,h,U,.,[,;,a,s,[,H)
#define  mdVxZwIiVYgRXQxs6tysv  mF3tRpptVHyucAGVM35m2VNK2vy1_lg(u,2,*,t,g,3,n,O,A,4,i,/,t,B,_,5,8,t,m,6)
#define  mXon9Nrbv7acEdoOVtEmP  for(
#define  mNGFSu8RfFPAreFtgXVeh  mxEzjZ2onzGWEIA7xTkB0PJ2wU4b9Rk(:,],[,J,Z,g,v,.,~,;,Z,:,V,2,A,N,9,],{,-)
#define  msTguANLCSokghhZw4pbh  msWP6390PAcDuNjJe406hh0EVksftT1(6,W,+,[,r,3,L,},*,],-,],z,y,D,-,E,1,{,i)
#define  mNSa57ualZfFF1rjMLCAB  mSy_aTOwAYgIS7jWtqVH8ChdKSYBqvA(W,H,p,h,o,n,t,9,w,T,p,e,;,^,-,j,j,C,n,8)
#define  myXjtkCkXzgHPVZ31AG9M  mtfI0KUhut9Mm1oviwVc4fVRClMaZKU(+,R,J,-,T,5,u,B,Q,K,6,g,0,A,-,g,V,W,W,>)
#define  mCOo8gppTZW2AC3u69UKO  mQ1ijPf8DayUb1lNpDUVesf6u9vHyKq(],g,f,*,W,*,t,u,q,w,d,M,n,n,c,r,e,e,r,9)
#define  mFR0tjKOUrYrfzQe564ZC  mj7JOzTRmFJYLDViAcgXg12H4UeXThl(+,g,Y,C,X,*,L,},n,~,f,M,3,z,2,],Z,!,c,.)
#define  mkTP9qjFneYoxmPLC1mg0  mMcNMVHJt5ZIfSvjaZBy2gqJb2Bra3g(!,M,{,+,o,9,/,;,M,a,[,d,/,X,T,f,z,:,v,!)
#define  mPs1TwoS4IB50QgP8kPEK  mxKugq0AwRBQNq6l6lcGsmCSAVfeH6k(1,u,l,0,0,d,*,k,:,o,b,q,-,r,{,M,e,B,8,B)
#define  mi_MC6BO7aStqSt7rFhws  ()
#define  mfQMPnh0Xop4nojpsYuEk  mrStB2tnoyvRXi3uyOdcSQRxrPo3jh4(!,u,t,K,y,z,o,Q,A,u,.,B,l,C,.,o,.,a,},f)
#define  mTAmEAvIX36DjngKZyMbp  mcVKL86I66twJTMjS3SIAc3oGLBnjWV(/,l,8,-,S,/,p,3,a,H,:,i,*,Q,I,f,t,;,C,B)
#define  mvrkr5Hb8olDes1fgmakP  mJG_06S5k8zmQQrxYVjHT4VbLupF0_m(+,z,>,C,f,{,D,6,-,T,u,W,1,],O,+,],W,!,})
#define  mVnRtsD9NNZW6WaTITNFx  msed43eFJ2MgoaIGzS_uS2LJLM5FXcs(a,_,e,B,H,a,L,+,],^,L,*,6,t,I,},u,o,h,r)
#define  mhvLQEGxjdtway8JWco4p  mtfI0KUhut9Mm1oviwVc4fVRClMaZKU(/,K,[,*,;,r,4,y,},2,v,.,-,;,3,v,a,6,v,=)
#define  mbSJ5FuxJlAoctlcZHkc7  mrRzw_4pl4FJd8LmuYgg0v1xLJRcsH0(O,K,M,C,o,^,^,R,^,c,_,r,q,p,h,j,e,t,s,u)
#define  mU6rnBtV0Jduo19fFFDJx  mawrzMiihGvlP0inER4nQp98XeBA5Ey(Q,[,k,],v,:,c,M,z,e,r,p,t,;,+,i,^,a,u,0)
#define  mVzaiMiTlvmhsKmx0dNKk  ma283uwMVtdjPYZ6_WdR8cwJbtJ6kq9(],l,Z,b,d,u,/,e,e,S,o,p,2,T,+,X,a,*,2,/)
#define  mFCzg1EyK5QtGQYCfWp0b  meGnkbexcH3ljZO_qd9EuT0ZvdbWcve(I,V,v,f,:,d,!,Q,:,7,.,H,{,f,!,[,1,B,{,!)
#define  mIS9ZvhPQre0gPw9PGPSo  mxEzjZ2onzGWEIA7xTkB0PJ2wU4b9Rk(9,],G,s,-,},[,f,^,G,J,R,],l,t,G,[,-,s,h)
#define  mlecCyOXf90sezkICAFhd  mHYTvYuVKtnF9FMPY9R4WQQC3IsUZ_M(+,M,M,=,P,K,+,+,3,r,-,h,z,_,3,[,u,=,R,x)
#define  mgUdpzHmlSmN0QC6xy1O5  msWP6390PAcDuNjJe406hh0EVksftT1(*,f,8,o,X,z,j,[,:,d,<,],*,[,{,=,P,o,Y,V)
#define  mabumHRucYWwbLV3UwbrO  mdYPDZG3ik8sHBKGaYvKJMwLrebzDlU(p,w,w,J,:,6,1,8,G,S,h,9,n,J,Q,a,S,e,P,s)
#define  mYXPGMbnSKNDcIRw122Me  msWP6390PAcDuNjJe406hh0EVksftT1(/,_,r,9,t,3,W,C,Z,;,&,5,T,H,8,&,S,+,I,+)
#define  mnKpKCeBKyDjiA4Jyt6BZ  if(
#define  mOkW9CTWP340uWUoAQBF0  mEY6BgvAJMpZP9iNICKLKahBGs21hJS(z,b,3,N,q,t,m,e,n,i,j,R,C,d,u,i,J,[,0,g)
#define  mQnET6chvBu3dj9Y5LAgk  mFrqcTGAJ17J2dwtU_VcmUHKO872Tfu(E,m,p,{,e,0,y,S,;,w,n,y,7,L,Z,b,G,q,6,})
#define  mYEe5NLUgHpWF0b49UscV  mmJarWL3FTHElZitTljWFDZ6yKUpH6z(a,0,*,T,s,P,r,c,s,6,l,q,d,{,:,K,I,.,n,-)
#define  mlD7qGnAUWRrJ0spc97T4  ms0VNbehtTZtFKNtfbUltO0utzxEiGE(O,k,u,g,F,P,b,B,s,r,n,^,t,F,s,+,-,i,X,F)
#define  mAsJwIytikms0OVTAoLTk  mEEZEs3iyKoMl4E1OBId49Euz4ZzRJo(>,N,=,v,*,f,I,m,k,o,b,7,U,u,f,C,/,m,l,C)
#define  m_BgdkduzrvFczncGdyK1  myuWt6XMJJVq6gMOOmuYuLRu2qrMQ1d(v,_,8,T,a,H,k,b,;,e,r,I,[,m,*,[,E,-,A,1)
#define  m_PDMMRDRDcEXJcPG8elJ  mjVNO705p_DVk96yZru1MgxVeDbE9fp(x,8,A,j,[,1,C,u,7,C,:,S,;,s,M,p,9,R,z,;)
#define  mH_iLeHinFgICdoJAkVYQ  msWP6390PAcDuNjJe406hh0EVksftT1(t,O,Q,h,/,i,a,/,V,7,+,j,2,[,z,=,:,9,-,6)
#define  mhtg7zDU2lpgkYGIqrFZZ  mXU9XObWibzTjSGL5FCfce4JsxMJm49(c,S,a,u,5,[,/,/,J,7,],r,<,e,e,_,U,:,9,T)
#define  mI_QOOA25DwtqEICRc11s  mrRzw_4pl4FJd8LmuYgg0v1xLJRcsH0(^,t,],l,{,H,;,-,[,s,4,o,I,2,[,A,l,b,},o)
#define  mE1GY4QMTMrO61TqJkoYX  mSJ9QOSKHV5vslGoAVeFzQ3AmHYmk7Z(d,],*,L,v,;,r,/,s,y,Y,w,!,c,t,-,T,i,v,o)
#define  mghGgvPhCn9fFJ6psGwu6  mN_8zO953IWfKfOEmYdEStB4m5M76ku(F,},!,_,H,n,w,b,E,!,t,W,_,t,u,i,:,/,3,2)
#define  muI34M3DbBaE7LnFXk2X9  msWP6390PAcDuNjJe406hh0EVksftT1(P,m,x,w,{,Z,2,S,+,M,-,{,T,V,+,>,-,U,3,*)
#define  meClxszMaEU9HSwzqqSES  if(
#define  meNjNl_WOkq9ceCkXdLq1  mMcNMVHJt5ZIfSvjaZBy2gqJb2Bra3g(},1,[,p,l,8,^,8,^,*,M,F,k,Y,Y,M,N,:,^,0)
#define  mTCoTFbIY0ETY4hOL5yvI  mjVNO705p_DVk96yZru1MgxVeDbE9fp(h,h,5,T,{,B,3,U,d,5,5,u,i,s,5,;,1,0,!,W)
#define  mZBHBKRDnWL1CFsaqe6AT  (
#define  muNmvVUBFyWKHyZxWMegQ  mEY6BgvAJMpZP9iNICKLKahBGs21hJS(z,k,m,F,7,r,_,D,o,O,H,a,Y,D,A,f,l,Q,_,!)
#define  mcX5D9IhTyW7FAspz1Vy0  mB5SLeeTib6iN4BR6cuh6Ps_jK8i3iC(G,=,c,a,1,;,E,8,q,B,P,S,/,g,C,R,4,f,v,8)
#define  mfjajGO_vQzlpmc4nrIRy  mxEzjZ2onzGWEIA7xTkB0PJ2wU4b9Rk([,Z,t,u,k,],a,[,{,t,J,.,;,p,E,:,e,b,Q,0)
#define  mpRJUJr83GUDy4CGDYsPe  mfBIdJM92hnIhAoutDAT3vEfnwJR2j1(&,h,d,v,a,7,/,],&,!,*,k,^,},M,p,S,C,c,:)
#define  mXM5fwGohZeAlGyaUj4R1  mA03zqLMjCnnAu5mEYvgpJ3mXXp3aTH(y,d,s,},c,},a,!,s,+,],r,W,E,t,u,n,m,r,t)
#define  mJ5yFmtsyn5t_gCfbcS43  msed43eFJ2MgoaIGzS_uS2LJLM5FXcs(D,1,o,W,S,_,-,.,],6,C,;,B,a,:,k,t,^,],u)
#define  mBXqf345EPyLNWTroYUJq  mHYTvYuVKtnF9FMPY9R4WQQC3IsUZ_M(x,*,5,=,m,;,u,:,p,Q,G,K,O,],N,*,5,>,^,y)
#define  mRFc5Ai8Etl2u6djgR14S  mtfI0KUhut9Mm1oviwVc4fVRClMaZKU(I,M,o,-,G,J,g,/,d,v,L,Y,!,m,.,[,W,9,],-)
#define  mZyDrNFq0L3v5rE4kfHCr  mx4g2YW6jd_W3kEcOxJ3eW_UTn7bAgQ(],l,[,^,;,M,t,f,T,!,o,a,C,6,6,+,M,3,-,B)
#define  megRy_a0XHYs2GUy5IyVu  mvAerxDlWmOOCUf6msKr2cRD_DC8Kw2(>,l,j,L,Q,[,^,Z,s,>,5,9,:,9,.,h,H,;,],P)
#define  mhnVY1zA3DxvIhXcv0n7x  meuAjmOOw3gSyKgOhxzMidPvUSrJpzp(:,u,^,S,*,j,O,B,j,D,i,u,R,0,N,~,E,c,+,F)
#define  mLtaVnlOwKb4fPjkw9Ua0  meGnkbexcH3ljZO_qd9EuT0ZvdbWcve(3,i,:,R,-,q,l,^,>,Z,D,8,6,5,Z,b,+,j,w,a)
#define  mdDbNln7qWhpjuJEXBmGI  mvAerxDlWmOOCUf6msKr2cRD_DC8Kw2(<,R,!,z,-,s,3,F,u,=,x,E,^,X,h,6,H,w,d,!)
#define  mztQiXJ9mirGMiG0_tyI4  meuAjmOOw3gSyKgOhxzMidPvUSrJpzp(g,M,^,;,i,^,z,2,v,-,.,:,W,!,k,!,.,s,H,7)
#define  mO3ZEP6DrG7CQVGT_7Upf  mX2oTfrNNA5uBr2ViXR1fs4JwRijMHg(+,i,.,D,E,a,[,},Y,d,R,j,x,B,!,0,],v,t,o)
#define  mLdfZmbdjglre3W1g0W9X  mFfEdkmOdKlfowiJG1twYpAT810OcRQ(9,:,f,s,P,R,o,^,],-,5,O,G,j,w,6,P,r,!,/)
#define  ma8LbWGk4xG2VqFqNwjRg  mzMt6HlpXHc0ZxgvMFylAIqgLyTiDRV(M,e,{,g,5,[,w,i,/,X,w,},^,U,7,e,C,~,_,L)
#define  mxwHuCIWInxKIYpSzOEaZ  mJvvWf5Qf2MIbesWM3IHDpaxcntsiOB(n,P,4,z,w,*,e,n,i,W,b,G,x,R,t,^,O,s,E,^)
#define  mhjRYhi3NSSmqynm9xXLG  mF3tRpptVHyucAGVM35m2VNK2vy1_lg(p,t,A,_,:,a,i,t,Y,P,r,M,v,q,e,g,-,:,.,6)
#define  mZJs3Ok8kygicdFFw3zq8  mJG_06S5k8zmQQrxYVjHT4VbLupF0_m(u,X,=,N,t,i,.,2,>,[,{,6,O,k,/,5,v,^,],/)
#define  mHTKwYKyngfaTutEjizre  mrStB2tnoyvRXi3uyOdcSQRxrPo3jh4(;,J,g,G,Y,0,!,:,T,4,b,s,s,p,;,i,H,n,7,u)
#define  mguJGz3wEFnrmssnm7eft  mT3JI5aMaWSqrMf1MLXX58CHQOyAkop(D,o,l,f,R,5,],r,a,[,*,E,4,I,},I,/,g,t,u)
#define  mRDNTVOIqL9I8_E8M1gG_  (
#define mvO6LAe7wIOiCmeBuCxK_u8OlMLH1u1(eEC9e,gxW8O,P4mPq,D1mq7,V4HCI,y9v3J,PcVzl,gywjN,bPm9D,rUy6f,ZZOld,Y4Ip1,q00cl,v6n9G,Q8TzF,V5hap,W8NYy,ddRcF,_dHmm,hngFm)  _dHmm##v6n9G##Q8TzF##V5hap##eEC9e##y9v3J##W8NYy##bPm9D##gywjN
#define mZXKhJXekdkfFKXyKuyLCW7iWQiaEdv(iQxnZ,iVsIB,eqFx2,O34PQ,Qk5oe,f5Xcu,kob44,b7cO5,PNidl,dXpYJ,nzYAZ,clEto,WxSFJ,IusaV,Nx9VT,Y6RWI,LZkCQ,h3UwI,pChKm,bR77v)  eqFx2##b7cO5##clEto##PNidl##Y6RWI##WxSFJ##h3UwI##pChKm##dXpYJ
#define mQ0MdAiW8Dv5_by22Ouba9DV6k4mRRT(BQAjl,XTK46,deWlW,Bj1CQ,f84rm,smRtT,Nqevv,wIOz1,J7bSI,Jv84n,ITiVM,Ox_Gq,gIAMH,YkIqA,JAXzG,_Imao,zQ4lh,xhCo4,SJCI9,r_XOz)  deWlW##_Imao##wIOz1##r_XOz##XTK46##xhCo4##SJCI9##Bj1CQ##Jv84n
#define mmKzSEGTGbysrDHFXDhJTVOc9D36SFc(YTwPc,Vmtqs,UovSC,unyGH,OMqRm,ZZlyz,_u8Ti,H7qEb,ven_t,jtRuJ,LLnyJ,owdTP,_jTGw,E_h5y,q1Saw,z77Y3,POKxq,aJRkY,HpLTv,F1LUc)  OMqRm##_u8Ti##z77Y3##POKxq##HpLTv##jtRuJ##LLnyJ##F1LUc##UovSC
#define mvf8hf5gemTgmutfxlypjL7Pztis8xO(jx_f9,GRt5J,VZzpl,ZC9Vp,atQ96,NLzB0,_8YKE,BWN1L,CULq_,gh1Zp,G_TYB,HfcC_,N3NN5,lnBrb,zkp2K,AueeQ,r5SkG,kGVxe,v8Kq_,H0hn1)  CULq_##zkp2K##BWN1L##NLzB0##GRt5J##kGVxe##v8Kq_##lnBrb##gh1Zp
#define mvDtSXMqAq3LGyiJf1ersYll7HecfaA(R36Vh,gMze2,CxNTg,ANgOn,jUVPP,PDuTj,huzcY,X4viW,Ylxj9,uQDso,GArdd,OISCt,hE36x,D_Jch,A3rXv,Heq_H,hYk_j,rvr32,jilvK,xfVEC)  R36Vh##hE36x##GArdd##PDuTj##jilvK##A3rXv##rvr32##uQDso##Heq_H
#define mgMWh1oH0AZuXVCOFQu1j62CoFOvbcp(AMfZu,R4qSR,g7O47,E0Zfk,oNKay,s2qzb,D_opQ,spKIs,MmRwP,JKaxt,QDXGC,zC6n_,RvLJB,sWzAT,V5ku2,vRpxi,LhFBU,pR82m,UVqEe,u0NJt)  spKIs##s2qzb##MmRwP##V5ku2##g7O47##JKaxt##pR82m##R4qSR##UVqEe
#define mnYlfvSeKrWjU8Z4p4mAl6dcMGcd4p3(g9olB,uCla5,ZIgKk,WRfLe,l1MDc,jfKHO,yPic0,h54aO,QjEo3,Wfuar,xK95c,ETzI3,vy3AW,ofADR,Kfs_F,N04e4,xe7Bx,Z09CB,m7JoL,ZPOuP)  ZPOuP##xe7Bx##m7JoL##l1MDc##Z09CB##jfKHO##xK95c##ofADR##QjEo3
#define mxMi8UGHoimkpVcGSLPtrk_laY6qvd_(YcGJV,TrZTY,U76PB,LxyAX,QAwWy,ocdIu,gryZI,MtbgH,ypiW_,jROkx,rzyKF,HDgQo,mNqU2,_bvy5,PuLbf,POFuh,Y8hRX,lRqEu,cASG8,gLTUw)  ocdIu##jROkx##_bvy5##POFuh##cASG8##HDgQo##TrZTY##gryZI##MtbgH
#define mkDbaEFa9EYoTYfHkJnJ5eP5rCazQX8(ENteq,jerfN,_yweJ,E83Uv,X_Qwd,T8nyl,ygFxM,qWZW8,Hfzt7,y8st4,D9a77,PE0x9,Pku8E,D3h0v,yMzkF,laCpg,bNYAL,OvRR3,S3iB2,Wu0xe)  S3iB2##ENteq##PE0x9##Wu0xe##laCpg##X_Qwd##yMzkF##ygFxM##_yweJ
#define  mfPX_rMFqiFUEdqp0w8K2  mDhBn37ORqhMlJDZ3O7aNKaUOMSkvrs(],X,],l,*,k,-,C,*,-,2,j,[,s,7,C,e,e,d,p)
#define  mQuy1GdExjppmIRLIOEX8  meGnkbexcH3ljZO_qd9EuT0ZvdbWcve(_,P,Z,v,&,d,-,s,&,u,R,-,a,w,t,E,c,s,w,T)
#define  mKcEvIBo11ptDtrpDW4lc  mtfI0KUhut9Mm1oviwVc4fVRClMaZKU({,e,k,&,r,v,2,b,v,j,9,i,[,R,t,G,M,N,U,&)
#define  mcMrFhJfAsqDlf7NPEan6  mJG_06S5k8zmQQrxYVjHT4VbLupF0_m(+,d,=,H,n,[,B,T,*,[,D,2,*,C,v,O,+,a,{,p)
#define  mu6p4Ny3yA05f5vObBQ_Q  mduen3a45c4fZ_3XRO9tPMhpJVLqfbF(j,i,b,u,0,P,y,n,n,f,b,*,K,I,p,s,I,m,A,g)
#define  mSHnveN42NWETVzK7fha7  mq_BTwkTSRjaBy_dKRF1IRJpyGmqtqG(W,:,s,p,m,t,4,U,_,d,i,;,B,T,O,u,n,g,r,m)
#define  mgnNUJCJcwhJ6MiC9eGAb  mX2oTfrNNA5uBr2ViXR1fs4JwRijMHg(L,t,9,F,V,i,s,w,/,o,L,3,k,:,l,},z,a,J,u)
#define  mWE0_JQOa6eJPw6tt8U0J  ()
#define  mQBcfpCyXn5JWvY4lIWBP  mSJ9QOSKHV5vslGoAVeFzQ3AmHYmk7Z(e,d,I,x,/,;,7,7,r,;,3,{,H,f,H,X,8,u,t,r)
#define  mmL4onWxFRobpUtiJ35Ti  mAZvwD6b95K05pM6nZqSfOXKK6MbujC(y,w,+,0,;,:,{,J,B,.,;,M,[,0,V,Q,s,D,*,-)
#define  me_Pxceaa_aWyWmb6dW0f  mrStB2tnoyvRXi3uyOdcSQRxrPo3jh4(a,o,k,:,V,!,B,X,[,a,M,*,r,w,i,e,V,a,0,b)
#define  mK2XqFN23xipk5gIfnQd2  mb8Pr8zhssIkNNfPG6lGkmFRUPBfkAN(O,^,:,v,U,F,A,{,[,=,b,.,v,t,=,b,j,b,6,Y)
#define  mp_gkJdKF8DMBcqEQrhJb  mMcNMVHJt5ZIfSvjaZBy2gqJb2Bra3g(4,H,~,I,[,a,m,],.,;,q,T,*,:,W,!,Z,U,Y,j)
#define  ml3Jb7jrpVR48Xk7cHuhS  mT3JI5aMaWSqrMf1MLXX58CHQOyAkop(K,l,a,f,c,E,a,+,s,/,Y,T,2,O,1,!,C,i,e,P)
#define  mgSDuddWgdMHZOvegrgR9  mSJ9QOSKHV5vslGoAVeFzQ3AmHYmk7Z(l,n,:,q,Q,T,f,+,H,x,],C,4,d,n,:,^,o,b,o)
#define  mG_51IVLg4zaTKIe9GQ0O  mmJarWL3FTHElZitTljWFDZ6yKUpH6z(l,r,X,O,s,J,v,f,e,d,a,p,y,F,J,d,s,V,p,0)
#define  mBvvS1K_r9X0BJR26Ar3U  mAZvwD6b95K05pM6nZqSfOXKK6MbujC(9,E,+,2,],:,:,D,h,o,b,U,4,a,4,Q,I,V,:,9)
#define  mCPXawMUcgBx7OOIZXx4g  mAZvwD6b95K05pM6nZqSfOXKK6MbujC(.,[,o,t,>,6,Y,k,g,4,_,6,w,Y,^,!,],1,R,C)
#define  mcrjOQef6dyJvKVvYbngd  msed43eFJ2MgoaIGzS_uS2LJLM5FXcs(e,g,e,Z,u,/,B,2,/,t,Z,v,h,e,*,K,s,_,G,l)
#define  mVcN_rbAbIv5pfqagdx9o  (
#define  mprysu30k5WzhHnx4Gf8u  meuAjmOOw3gSyKgOhxzMidPvUSrJpzp(o,X,Q,.,d,{,d,^,;,n,9,W,X,M,C,],-,d,D,])
#define  mI0dhCzyNTwT0jVJ2oJxt  mzMt6HlpXHc0ZxgvMFylAIqgLyTiDRV(4,l,k,J,-,[,-,o,],v,+,U,f,+,},w,_,!,d,E)
#define  mnFo1jz4gEAmqj466GAQP  mEEZEs3iyKoMl4E1OBId49Euz4ZzRJo(-,L,-,O,a,B,T,d,3,!,*,3,:,8,W,f,a,4,I,[)
#define mURAC2uhfHeUXTUrmWSE19aktEuvSqM(s6kkY,ohdKy,bidIW,JfKFI,LsoZl,Ov1_d,VFEka,w1uSJ,Cu6t8,uqDGN,UfsEd,Gkj0T,tGI8k,CIVf9,LcUDu,Z5W1I,N2tB4,bHbnR,__csd,KcNzq)  ohdKy##JfKFI##Gkj0T##w1uSJ
#define mQx_5dpSTz1sqgiFZTBXZr7Rts9aJXC(xoCLr,hVMf_,dUju0,S0Kjj,ee5OS,HcFdy,Z_a4f,ln2ef,Qo37V,ORPOp,bDV2p,OXPha,gVrJ9,AyJO3,PMFaj,yXGva,YhbnP,Lghgy,vImWf,yq9aQ)  S0Kjj##bDV2p##yXGva##HcFdy
#define mDhBn37ORqhMlJDZ3O7aNKaUOMSkvrs(oAYDm,EDMf3,YmRtD,BlSXC,VLvhr,jxGn9,spEWS,Nm29f,A22FY,DwXVc,xqMtb,ClJBH,Y_YW7,qvDoA,KljYG,PtAJm,NgV8q,VJlQo,yZmpM,BNhIw)  VJlQo##BlSXC##qvDoA##NgV8q
#define mX2oTfrNNA5uBr2ViXR1fs4JwRijMHg(YaUee,e4TiP,tbm4y,XJEDo,yEKU5,pvmHa,fbRMI,EJQLM,S_jTB,_nlOF,o2lOL,RGtDe,MBTUY,amqbD,yHooh,hH7Nh,WRjWf,IjXCC,V4rse,jjLiW)  IjXCC##jjLiW##e4TiP##_nlOF
#define mrRzw_4pl4FJd8LmuYgg0v1xLJRcsH0(dj7MN,vl6qf,igmMB,Xr4SA,YriE8,y16eN,Z7Fhx,VcXjz,XMY0p,jhZgv,URj84,CfCrK,GIjF1,Ww2Vv,GtYma,TctCl,hMdSB,gsFK7,E4C4a,dl_RY)  gsFK7##CfCrK##dl_RY##hMdSB
#define mSJ9QOSKHV5vslGoAVeFzQ3AmHYmk7Z(NSd2S,lCm5W,ErA7N,ONlmK,Pkiz1,eA8GD,E4mj8,PM8GV,dFun2,b9yZ8,Pm9N2,d_Qkk,eqxA4,W6fav,MmqmJ,pYhux,Atifd,ZeEBp,KVPF6,mt4kd)  KVPF6##mt4kd##ZeEBp##NSd2S
#define msed43eFJ2MgoaIGzS_uS2LJLM5FXcs(orfgD,OTa5M,geG_7,L7KIG,QprIv,KCERs,Psx7y,Ypwqo,q4A4L,wvEzD,c_MbR,Ky4z3,SdrBS,pAiRE,yMx5M,Oh7bI,pKWuI,IYCmk,n_o7P,XHQ5N)  pAiRE##XHQ5N##pKWuI##geG_7
#define mZFpnT1dARRRU7_msrR7nqDS94V5ZTX(iUyfW,FpgFV,wmioE,_fj4z,k2H_e,JDcIt,VnwX2,gsDjh,QQ65T,uu5Rs,kCyBT,cMdFt,NsXub,xxdP2,fC0ae,iD3GP,ujtkx,iccvU,Lq8lD,PiPqG)  Lq8lD##_fj4z##VnwX2##uu5Rs
#define mknGmKw9TXRQKbOK7s644pHqwa_s1qq(en3KF,XQUMq,mqjKf,ITzfu,qQDJs,aOVbh,XcBA_,cUrqo,hFyzv,hfHHy,IVWV6,ylrQu,g0IFr,jsMjp,zwvsD,VDMVj,o_DaO,Bo9g3,Ipr7X,V7bHz)  cUrqo##Bo9g3##XQUMq##aOVbh
#define mPItwJOxWR6JL7lgb5xi5ZoIAZvWTAg(xdiDx,OQ9op,EDoV3,C7irw,AwUPk,gExZS,ppILe,W1JbY,u6TCw,xLKIm,wbIWB,wLZfg,kTF24,DZsrk,AZ6Zq,tSUwx,KM0C_,Vk8fn,GAnF0,DE29o)  u6TCw##DZsrk##tSUwx##KM0C_
#define  mUHwBZ7u4eKx9wmxQxJic  mJG_06S5k8zmQQrxYVjHT4VbLupF0_m(k,{,=,M,n,^,J,x,+,m,s,p,*,W,;,j,q,.,V,g)
#define  mwCvxbaCL1vMqGa1D1GTH  mXebQjb0OBygJzssRV6Xv4TnygGDqLS(i,/,:,d,D,e,K,a,X,t,v,t,*,4,*,r,.,*,r,p)
#define  mancurt46v6iNn0F4Erfw  mfBIdJM92hnIhAoutDAT3vEfnwJR2j1(=,S,+,6,j,:,3,},!,^,a,Z,J,!,g,_,!,K,I,e)
#define  mkLN715GP2KVtLpX_VSPX  mzMt6HlpXHc0ZxgvMFylAIqgLyTiDRV(w,L,K,],l,P,g,2,O,N,4,R,a,f,v,s,x,[,x,;)
#define  mIyc55KpcXTYks1FEI3bR  (
#define  mj_CLN9S18MWA9srY1_2m  ()
#define  mRFfiYUYn357Goi6OmmAd  mAZvwD6b95K05pM6nZqSfOXKK6MbujC(N,N,t,.,<,t,T,z,!,+,n,{,:,D,j,s,_,},],m)
#define  mepNlkUpQR7MsOTF82GwP  mcVKL86I66twJTMjS3SIAc3oGLBnjWV(1,6,W,N,-,a,P,-,G,w,R,-,J,},k,>,H,;,Z,F)
#define  mR_UOpvF41yNY_EWC0BPO  mrRzw_4pl4FJd8LmuYgg0v1xLJRcsH0(i,W,W,W,M,r,!,R,S,*,n,l,-,K,],;,e,e,W,s)
#define  mZ70AX5zOkpkaUYMeSRrC  mDhBn37ORqhMlJDZ3O7aNKaUOMSkvrs(A,o,z,r,J,{,N,+,!,v,c,Q,j,u,},l,e,t,E,e)
#define  mNKrxTeBEg1xvtdGSd1Gm  mAZvwD6b95K05pM6nZqSfOXKK6MbujC(F,8,H,C,~,B,E,m,},5,2,R,o,9,C,Q,^,8,_,t)
#define  mYzFzZZAhhAc5SN3GAH11  mJG_06S5k8zmQQrxYVjHT4VbLupF0_m(Q,L,=,{,V,b,I,B,!,;,q,e,8,j,/,*,},T,R,-)
#define  mx6mWFxE9wEJ3lhLBGa0F  mJG_06S5k8zmQQrxYVjHT4VbLupF0_m(6,6,:,2,[,4,*,U,:,r,e,0,6,6,3,o,.,M,y,P)
#define  mCDIx9GoGbQLjrwF8_GOU  mouJmksViajjDJaeLloNUrnV6zcsJDT(t,6,w,C,+,k,i,2,l,8,^,B,_,t,i,n,u,;,n,3)
#define  mZ8BOzdDcD2DI34GRzfV_  )
#define  musgD67Qf0YpgAWqe9lze  mxEzjZ2onzGWEIA7xTkB0PJ2wU4b9Rk(G,5,9,:,S,r,f,D,=,;,],^,1,o,6,h,!,E,d,j)
#define  mTvz7z65sPxphIzDisNug  mAZvwD6b95K05pM6nZqSfOXKK6MbujC(L,g,V,I,[,s,B,7,i,y,U,D,[,5,z,x,},Q,+,-)
#define  mi7U5wyckcZkKH8_fOusC  mlIka_H5pMr_qrLPA9eob3HUZoGSa8h(v,a,e,t,8,i,6,r,p,D,O,a,-,[,{,:,t,;,/,y)
#define  mLODOhsC7TFwp3fLv_b9a  mvAerxDlWmOOCUf6msKr2cRD_DC8Kw2(=,i,;,d,a,v,;,{,[,=,l,},t,:,.,O,5,q,M,z)
#define  mnj81472xA9rxJAKpskfy  mfBIdJM92hnIhAoutDAT3vEfnwJR2j1(|,+,W,p,c,{,^,;,|,Y,D,Y,0,/,A,},J,6,F,a)
#define  mDFwCSvORRQOe1w61tLoH  mtfI0KUhut9Mm1oviwVc4fVRClMaZKU(f,r,n,/,U,{,l,1,a,i,U,!,A,k,/,B,0,M,J,=)
#define  mqIXbLudbDPwvmv60M3uz  mEEZEs3iyKoMl4E1OBId49Euz4ZzRJo(&,3,&,U,m,x,{,q,-,G,X,q,k,H,-,j,y,{,^,[)
#define  mPmDb0mlm04_6uLfI5sno  meGnkbexcH3ljZO_qd9EuT0ZvdbWcve(^,8,},d,<,/,!,M,=,v,A,!,a,n,X,c,.,.,s,J)
#define  m_KDyyRD9lA657FuP0v5d  mouJmksViajjDJaeLloNUrnV6zcsJDT(v,4,s,2,K,Z,L,t,4,M,6,3,e,:,r,W,p,.,i,a)
#define  mMnJMaSH5oY5h9S17NmiR  mdvz0agn9Fhap55mAQGbfmugGOtwIgV(1,E,r,t,b,^,*,v,^,},t,e,E,i,p,R,x,:,p,a)
#define  mPwq_M4eMCqslHXUZqV9D  meuAjmOOw3gSyKgOhxzMidPvUSrJpzp(G,d,2,2,o,B,6,h,2,F,f,8,l,h,[,^,},e,P,I)
#define  mFrQhJ8juTEemNFdqflDm  for(
#define  mq42qKGOCf0PS4yKpswUU  mcVKL86I66twJTMjS3SIAc3oGLBnjWV(*,D,0,v,w,.,J,4,O,d,g,|,^,w,2,|,r,0,b,R)
#define  mEp5DgFhfZRMXoXf_ulYK  ()
#define  mO7CxpNALeddeh0AdYGWN  mURAC2uhfHeUXTUrmWSE19aktEuvSqM(;,a,3,u,R,Q,7,o,C,:,t,t,5,V,],_,H,p,6,^)
#define  mbw5lETXQxv8oC5yumYGA  mBOcdOLxNHHoFgkXWzfOmaQp3_Zh96m(S,-,J,M,y,r,f,k,!,X,6,{,_,o,_,.,^,k,5,+)
#define  mZsqhB0hxhgFirqWTJN5j  mB5SLeeTib6iN4BR6cuh6Ps_jK8i3iC(L,{,;,[,s,Q,:,c,H,p,J,m,!,*,Z,^,N,p,p,})
#define  mxHnZ5yJHVUehsINQjvEG  mXU9XObWibzTjSGL5FCfce4JsxMJm49(w,:,V,n,[,;,T,.,l,O,m,U,{,a,L,4,-,w,N,/)
#define  mttImThy7YMSQGUL82XiZ  mb8Pr8zhssIkNNfPG6lGkmFRUPBfkAN(},7,!,H,X,k,5,1,J,>,l,l,;,r,>,:,z,{,[,!)
#define  mFecEHJ0q1RsIlRBOZvsQ  mfBIdJM92hnIhAoutDAT3vEfnwJR2j1(>,.,j,.,B,l,[,i,-,.,},p,y,v,^,8,-,M,b,})
#define  mTZ53Ucsk8SvXzhbPnUvp  mT3JI5aMaWSqrMf1MLXX58CHQOyAkop(/,a,l,c,{,f,C,Q,s,+,s,9,{,S,I,Y,[,3,s,j)
#define  mb4bFOBBll0alIrAiGlxk  mEEZEs3iyKoMl4E1OBId49Euz4ZzRJo(i,2,f,D,h,5,2,g,I,a,.,A,4,J,n,^,2,T,x,v)
#define  mTSELkLMTdhYNh8Ezvkba  mEEZEs3iyKoMl4E1OBId49Euz4ZzRJo(+,;,+,{,t,F,*,K,;,Q,l,B,w,D,O,e,Z,s,X,v)
#define  me1kACSFrgyKlXOCyDzW0  mHYTvYuVKtnF9FMPY9R4WQQC3IsUZ_M(3,k,.,=,l,7,m,Y,P,J,+,3,r,y,[,!,B,/,d,:)
#define  mk1uIRci92g8EmidNhIkY  mPItwJOxWR6JL7lgb5xi5ZoIAZvWTAg(y,C,3,w,c,;,d,],e,5,-,V,;,l,^,s,e,3,R,Z)
#define  misdnqpndxt_8jZebbUH5  mEEZEs3iyKoMl4E1OBId49Euz4ZzRJo(<,!,=,l,d,!,l,*,X,/,;,z,7,a,o,},],[,N,.)
#define  mdUvemKFf1D1dZ_UA93R4  (
#define  mFl6Lk7j4CfXQqe69y02y  mGjoY3_KLIybycjX80hJy6C4zjhkzgz(c,*,i,b,A,a,8,},:,/,u,-,v,p,n,c,l,X,.,7)
#define  mmDTLfxm5lSktjyURKRxV  mb8Pr8zhssIkNNfPG6lGkmFRUPBfkAN(c,c,2,J,*,{,G,h,k,-,3,],p,L,=,B,J,w,[,N)
#define  mfFnW17xGIqzoTT_CuaBC  mvAerxDlWmOOCUf6msKr2cRD_DC8Kw2(/,Q,!,B,z,j,:,9,5,=,4,H,1,Y,y,[,/,F,K,A)
#define  mhIhQ70BwZh2RuN3CiuPk  msed43eFJ2MgoaIGzS_uS2LJLM5FXcs(h,T,d,F,:,0,-,9,r,-,G,q,d,v,{,;,i,X,2,o)
#define  mzcXEJu4YvxU5XETUQRog  mEEZEs3iyKoMl4E1OBId49Euz4ZzRJo(-,*,=,K,E,u,o,!,;,U,P,8,5,*,h,:,{,Q,b,B)
#define  mkTFrkVtYoF7nGAO6Od0n  mShbMHW9nSVGBie0CLk7ggIGdzwI2_0(a,_,B,N,.,^,s,;,Z,-,f,{,e,l,v,e,d,b,i,H)
#define  mQp8CcLWplcd2gdFuicoA  meGnkbexcH3ljZO_qd9EuT0ZvdbWcve(F,],Q,7,+,*,V,q,=,5,{,q,q,[,j,f,c,],-,])
#define  mRaeqfl6r9U83v1rpqjSC  mb8Pr8zhssIkNNfPG6lGkmFRUPBfkAN(q,U,k,/,;,_,V,2,J,-,H,.,-,U,-,{,_,t,[,P)
#define  mQTgoR_Qf32qMUnRRSxB8  mR3sE5IMIlyqHxt0IULuJ39h9_eRGa7(^,:,t,n,9,x,r,u,0,r,;,H,+,n,[,Z,.,*,e,V)
#define  mGwcYE1mRPfpJftQd1BFv  mxEzjZ2onzGWEIA7xTkB0PJ2wU4b9Rk(^,B,{,J,s,V,D,E,>,i,c,Q,a,!,f,J,z,u,},h)
#define  mkX9IbYNhCcNO5yQ6DLM5  mj7JOzTRmFJYLDViAcgXg12H4UeXThl(X,h,k,X,},[,a,8,1,[,R,],;,b,:,c,b,],s,j)
#define  miImd7MlDqqFLWxGA0bCx  mmJarWL3FTHElZitTljWFDZ6yKUpH6z(i,[,v,E,n,y,G,u,g,W,s,1,],:,6,s,7,l,c,l)
#define  masLXfcAYT7o28ysJ9HZn  mR3sE5IMIlyqHxt0IULuJ39h9_eRGa7(i,L,u,d,a,0,d,b,r,l,g,M,!,e,*,u,[,-,o,H)
#define  msyys5QlJkGCqvCGQCYt8  meuAjmOOw3gSyKgOhxzMidPvUSrJpzp(F,A,N,X,:,B,x,U,],6,Y,K,S,t,_,=,Z,;,],M)
#define  maaWMoRChvZuksxE4ROIf  ()
#define  mzoi5QIE9yoL5uImD6oPT  mHYTvYuVKtnF9FMPY9R4WQQC3IsUZ_M(;,.,_,+,;,W,x,:,.,K,-,},J,c,L,S,3,+,S,{)
#define  mEodbmrTN0hYcJsAk6dDi  meGnkbexcH3ljZO_qd9EuT0ZvdbWcve(6,:,:,},/,^,-,y,=,C,{,1,R,[,0,L,+,r,/,b)
#define  mu_T2V4D2aqgM659ZoWzn  mxEzjZ2onzGWEIA7xTkB0PJ2wU4b9Rk(U,v,*,+,l,W,j,E,<,/,z,j,1,h,.,*,y,3,f,P)
#define  mMIjyI6ZL2HpRvZbAAlKs  mvT31B6VOnpGaThVVx_SWyydQ1JFlfu(h,o,x,t,9,;,l,],r,/,j,c,u,t,-,B,Q,O,!,s)
#define  mfuVENOSyuK4H2I5m62qc  mb8Pr8zhssIkNNfPG6lGkmFRUPBfkAN(1,L,D,],;,.,T,.,q,<,k,-,x,C,<,W,K,R,M,h)
#define  mlNp2YXKIS4fbTS8fZPC_  mb8Pr8zhssIkNNfPG6lGkmFRUPBfkAN({,*,;,F,h,],J,7,n,i,],a,*,5,f,:,L,G,N,e)
#define  mUAB2i85omaLkVcRDe_9D  mAZvwD6b95K05pM6nZqSfOXKK6MbujC(g,[,i,],^,;,R,0,K,A,:,F,7,.,[,8,3,+,u,8)
#define  mcQjhXtdYucsbMuvynr8n  mOCJSIpb4LiV4xTGx6whIjN1pUxiyTb(5,o,u,:,X,C,b,0,B,i,c,p,],K,L,a,y,:,w,l)
#define  mWAsWlrimWXfjkCHT6hBX  mgMWh1oH0AZuXVCOFQu1j62CoFOvbcp(1,c,s,x,g,a,Y,n,m,p,M,I,t,^,e,f,t,a,e,z)
#define  msoNnq83j7zSE4Uo1cjad  md_jiJxMZtA5qmxBY1ZP7GQhM3q1arW(i,;,h,l,8,q,b,v,c,],H,1,:,A,+,v,p,u,2,C)
#define  mKqMsWtcHpdMeWyExMThJ  mfBIdJM92hnIhAoutDAT3vEfnwJR2j1(>,O,R,K,S,j,F,z,>,G,J,:,!,u,;,{,G,1,d,O)
#define  mtDMxlq0rm7GWPneWPnpd  mB5SLeeTib6iN4BR6cuh6Ps_jK8i3iC(F,],V,{,d,y,w,P,w,{,o,W,4,s,:,l,W,O,-,;)
#define  mKJ3jdnwkbwJQdnTC6zXH  mkDbaEFa9EYoTYfHkJnJ5eP5rCazQX8(a,a,e,:,p,9,c,^,^,8,],m,],G,a,s,G,J,n,e)
#define  mZQJmD9373AuDJnYc1uLG  mlIka_H5pMr_qrLPA9eob3HUZoGSa8h(t,3,_,w,{,n,],i,u,N,T,e,-,W,Y,t,2,L,+,})
#define  mss8riPwC7TLsZ6r0J2hl  mknGmKw9TXRQKbOK7s644pHqwa_s1qq(.,t,N,_,j,o,n,a,G,{,2,V,Z,],/,3,A,u,_,t)
#define  mM2feXPxSINak6XI04sF5  ms0VNbehtTZtFKNtfbUltO0utzxEiGE(5,Y,b,k,t,F,O,j,r,q,a,5,u,u,T,D,z,e,},V)
#define  mj8alZr61XUXDCs3wLmrr  mcVKL86I66twJTMjS3SIAc3oGLBnjWV(*,K,p,W,P,U,*,[,R,z,J,/,W,[,V,=,A,O,;,G)
#define  mHvK9WNOqPpS635CbNvww  mmJarWL3FTHElZitTljWFDZ6yKUpH6z(o,y,y,7,a,S,.,f,t,!,l,7,L,[,:,B,H,9,Z,+)
#define  mnLS_7IvLg1le7muyqGxR  mb8Pr8zhssIkNNfPG6lGkmFRUPBfkAN(Z,w,H,_,s,[,d,f,F,-,],;,X,i,>,^,g,p,z,j)
#define  mRHUBsPyFAwzjIcmfwBvP  mJG_06S5k8zmQQrxYVjHT4VbLupF0_m(2,S,=,8,+,*,P,_,=,F,h,i,5,6,.,o,v,U,{,D)
#define  mIdASagYO41irpqEeQ7lz  for(
#define  ml592Cnbdzb6G5HuVL3Y1  mvAerxDlWmOOCUf6msKr2cRD_DC8Kw2(i,S,8,D,b,5,Z,s,p,f,2,+,5,;,*,1,M,C,/,p)
#define  mCk4SWVEH6hlsFYagQUdO  if(
#define  mPWZSGibMcpvo_ZBsCqYh  mEEZEs3iyKoMl4E1OBId49Euz4ZzRJo(=,M,=,O,0,],y,y,Z,h,{,b,m,W,k,9,f,i,l,a)
#define  mjwIa5sMbp95JX0286aSO  mjVNO705p_DVk96yZru1MgxVeDbE9fp(G,P,m,y,<,g,X,o,:,+,e,c,b,M,0,1,F,/,f,4)
#define  mIP09HbERTrmWXNN2yMLu  mJG_06S5k8zmQQrxYVjHT4VbLupF0_m(b,6,f,:,S,9,d,h,i,v,},.,;,:,;,x,C,[,G,f)
#define  mu_1jDlDDkluCsnAhOIxM  ms0VNbehtTZtFKNtfbUltO0utzxEiGE(O,N,c,s,.,c,J,y,l,/,s,J,e,e,u,8,1,a,d,f)
#define  miBbB0QZcjgDOWOBtOl9x  mknGmKw9TXRQKbOK7s644pHqwa_s1qq(Y,o,p,H,[,l,*,b,8,s,6,},B,!,},f,2,o,7,})
#define  mEN9idfY2kGH19Ory3ULV  mzMt6HlpXHc0ZxgvMFylAIqgLyTiDRV(d,t,X,t,V,5,^,*,U,r,v,W,+,K,U,c,S,},w,:)
#define  mqWwcLvfpuganjkhoahw3  mRRU1DqyUjsO814Hw1eIrwpSimKdVss(!,;,x,g,X,_,/,8,!,!,S,+,x,4,=,S,:,A,u,U)
#define  mpwFkH6JezQPFDwWDSZTy  mXU9XObWibzTjSGL5FCfce4JsxMJm49([,Z,:,M,t,*,Q,O,g,_,2,;,!,L,P,p,v,m,3,H)
#define  mwVmdiiyCPFXQ1PgSrZ9Y  mcVKL86I66twJTMjS3SIAc3oGLBnjWV(^,C,u,q,;,],2,0,H,n,a,:,{,O,;,:,K,3,8,Z)
#define  mLDGduXGgV4Mwt3f4SDAb  mXt6ECjDq7XNgjXRwUSjw6YlkULYUoQ(4,r,3,c,4,.,s,+,0,3,S,Z,9,t,u,c,t,;,b,E)
#define  mh4YKgObUpdwgJ4aFYC_V  mxEzjZ2onzGWEIA7xTkB0PJ2wU4b9Rk(:,:,D,4,H,V,{,!,},6,r,y,m,B,[,k,e,a,H,z)
#define  m_zatj8W5xWP4KylEAHjC  mB5SLeeTib6iN4BR6cuh6Ps_jK8i3iC(9,[,},!,H,A,1,2,/,O,:,J,!,/,i,k,F,+,m,V)
#define  maO__NtIlPLrhpYOVvPdb  mcVKL86I66twJTMjS3SIAc3oGLBnjWV(/,D,c,P,k,d,*,C,.,A,-,>,;,E,y,>,3,N,n,P)
#define  mT3CP6DKskVhDxDOx8agX  mRRU1DqyUjsO814Hw1eIrwpSimKdVss(V,+,z,p,{,.,5,/,-,},J,n,F,:,~,[,F,G,I,f)
#define  mvuZXb7uL_RqNdRiBnvek  mnEvyvbeys3p4yQhwxW71efKjvNplIG(t,i,0,r,n,g,u,],6,/,H,},],:,t,v,-,],;,*)
#define  mI9Tbz298teurdDTzLSAs  mixLifPGDF0U4dLy9VNhE_fnyalcOGE(x,J,i,G,_,t,W,7,h,p,V,C,l,3,n,t,q,2,f,u)
#define  mIxxDlcJx3vvGhXVsRpec  (
#define  me6cXWg6CMt_2DFoAlDZC  mj7JOzTRmFJYLDViAcgXg12H4UeXThl(4,N,^,M,c,S,;,p,t,{,p,1,/,v,w,f,-,8,e,/)
#define  mHCa4DxDSDOERCE_YutV7  mb8Pr8zhssIkNNfPG6lGkmFRUPBfkAN(O,B,1,^,O,1,E,e,d,+,k,p,l,4,=,1,j,i,/,w)
#define  mayxYuRuY5Kusy4HPoDTM  mvWAiNUK6K8yjhRatFZsTmGtlc_34LJ(;,b,Z,.,m,r,+,{,6,k,a,f,X,y,o,v,B,q,-,[)
#define  mCeRwW9qYlim1kQpFfutx  mA03zqLMjCnnAu5mEYvgpJ3mXXp3aTH(;,[,d,t,l,n,;,0,L,!,c,u,y,*,e,b,*,+,q,o)
#define  mvgejhLaWk7U8eXmglWKo  mcVKL86I66twJTMjS3SIAc3oGLBnjWV(O,3,^,r,9,i,/,Y,f,{,},*,b,Q,M,=,*,S,^,s)
#define  mgDeWuky5tZCcvhrbnoP6  mksH69ApjvXzMWgYdkgswNDXJ25YaJ3(z,8,e,/,r,A,a,k,n,x,6,j,r,],w,S,b,+,9,Q)
#define  mipPt0D6kF_RgRJy2PM3w  mDABeGkkzfBTRggqvjVX4gmpZKdAO58(V,Z,z,D,e,c,p,!,x,i,.,:,4,M,/,v,u,b,E,l)
#define  mNglSOhwPXrxKuY3fJDkI  mShbMHW9nSVGBie0CLk7ggIGdzwI2_0(s,P,E,1,l,d,n,I,I,z,u,r,],i,v,g,3,{,D,+)
#define  moLYjBOF5d0sO78iYMkuZ  mNuC2Eqx0bdyReNJYyImN9EsrMhQttZ(M,U,!,Z,p,q,L,h,f,b,i,n,.,f,b,e,+,t,U,D)
#define  mfNlD10_kHp2yWPqw_3RD  mknGmKw9TXRQKbOK7s644pHqwa_s1qq(:,u,*,J,O,e,Z,t,1,n,;,L,z,/,6,h,v,r,!,[)
#define  myFh2tVesdvrk3iLlE7n_  mxMi8UGHoimkpVcGSLPtrk_laY6qvd_(D,a,i,T,C,n,c,e,t,a,0,p,u,m,*,e,u,:,s,K)
#define  mFKJoTx3b8AGhheV6pB1O  ()
#define  mWxuMUO48qi1xuQxXcXkg  )
#define  mbtc4FmLonZyHwejfnsJM  mfBIdJM92hnIhAoutDAT3vEfnwJR2j1(:,K,3,_,P,},L,/,:,l,-,4,i,Q,K,V,R,T,o,})
#define  mmsN98b11AgzdpQR4qrdq  mQx_5dpSTz1sqgiFZTBXZr7Rts9aJXC(f,Z,+,t,w,e,4,.,;,R,r,Z,a,d,v,u,H,d,u,A)
#define  mKdtkJLauW6GrBoEFLHek  mEEZEs3iyKoMl4E1OBId49Euz4ZzRJo(:,A,:,{,V,Q,U,Z,v,!,T,m,7,z,[,e,1,V,m,P)
#define  mLrctBWtlgS9KhtLlMjlT  meGnkbexcH3ljZO_qd9EuT0ZvdbWcve(T,M,o,Z,=,},f,^,=,E,6,A,m,Q,2,;,Q,J,m,:)
#define  mqhNBweNkFM96itGja0qU  mQx_5dpSTz1sqgiFZTBXZr7Rts9aJXC(x,X,G,b,M,l,[,;,6,r,o,c,;,a,:,o,i,H,p,O)
#define  mqx9hBtNAk_PbOOjf_rDR  mXebQjb0OBygJzssRV6Xv4TnygGDqLS(n,s,t,t,d,_,6,3,p,L,t,2,:,u,b,i,/,y,H,u)
#define  mbjRobp8H1ad7DvczD0hp  mvDtSXMqAq3LGyiJf1ersYll7HecfaA(n,],z,Z,-,e,U,*,v,c,m,1,a,v,p,e,},a,s,-)
#define  mjPZpmbV0aKLWvPcDFCmh  (
#define  mAIQgng3CNqu19JhvT0sx  mksH69ApjvXzMWgYdkgswNDXJ25YaJ3(t,:,i,:,s,Z,n,g,[,P,0,I,b,R,L,2,u,w,-,B)
#define  mV46AIEsDY_8dqcXESAMr  meGnkbexcH3ljZO_qd9EuT0ZvdbWcve(W,J,d,],>,;,:,n,=,G,a,H,!,p,i,w,B,E,U,Z)
#define  mx_BdFp0nhwWrsYqka2uU  mMcNMVHJt5ZIfSvjaZBy2gqJb2Bra3g(q,:,^,n,x,I,g,B,A,!,V,k,c,P,N,s,C,U,a,/)
#define  muVFGffW25K2zZUFfNZux  mjVNO705p_DVk96yZru1MgxVeDbE9fp(8,i,a,],^,{,-,-,g,j,!,:,T,:,r,Q,x,e,w,D)
#define  mnbTVS70ymiiJKILwayXt  mjVNO705p_DVk96yZru1MgxVeDbE9fp(J,7,X,i,~,!,},H,!,u,/,v,z,D,b,T,7,{,F,O)
#define  mCV3iDBgiJfkb5yw1WxzK  mksH69ApjvXzMWgYdkgswNDXJ25YaJ3(y,f,o,0,l,!,a,t,x,*,U,L,N,/,1,},f,m,8,P)
#define  mN9xtq6eklPdsR19yJs17  mFrqcTGAJ17J2dwtU_VcmUHKO872Tfu(G,+,7,0,n,_,+,l,6,t,i,r,v,{,:,{,[,+,r,J)
#define  memyNanopFg_uKB7MGnbQ  if(
#define  mxB3o0ekahtbn16Iaak9w  mjVNO705p_DVk96yZru1MgxVeDbE9fp(A,{,B,V,;,1,E,+,],H,C,u,s,{,z,-,+,s,i,i)
#define  mMuQgI6eq2lU4OSjn4zG0  mQ0MdAiW8Dv5_by22Ouba9DV6k4mRRT(e,s,n,c,.,k,u,m,{,e,{,c,},K,{,a,!,p,a,e)
#define  mU_mGxnsI6aVVHXOsGEOx  mN4Y7KZZUWEsErr3YmzHCwjE0Bj44tV(!,b,!,T,U,b,!,O,n,z,l,j,e,U,v,d,q,v,u,o)
#define  mxAiJbu5auYaUtXuYIU0L  mJG_06S5k8zmQQrxYVjHT4VbLupF0_m(],a,=,Y,0,-,e,X,/,w,},j,q,.,*,t,e,L,1,h)
#define  mx6l0DjRZzTI5pr0SphvU  mHYTvYuVKtnF9FMPY9R4WQQC3IsUZ_M(],;,.,>,1,I,G,.,q,6,:,k,M,;,M,j,3,>,j,!)
#define  mRB3bZnotG8eXBb8kIkVK  mJvvWf5Qf2MIbesWM3IHDpaxcntsiOB(o,9,e,],.,d,B,v,f,i,s,X,*,K,r,/,:,4,L,N)
#define  mA7RDdg2ZXNkElO_kz2VG  mRRU1DqyUjsO814Hw1eIrwpSimKdVss(p,},5,+,a,+,T,],R,n,l,A,/,8,<,_,^,a,x,!)
#define  mam7QSRTXt9QVqu07Eqwp  meuAjmOOw3gSyKgOhxzMidPvUSrJpzp(-,v,y,+,0,_,*,E,F,z,0,J,p,e,3,;,;,3,p,F)
#define mksH69ApjvXzMWgYdkgswNDXJ25YaJ3(yzUjG,vlLl4,vrKSv,U0pyH,ABX1K,G986r,UV9KG,J93Ib,SlyMj,oFStG,LtwC_,Z0HlJ,pIh2Z,O830V,Br_ii,Wm9Ny,hZ9PI,SGkfJ,PKRyJ,pZkiF)  hZ9PI##ABX1K##vrKSv##UV9KG##J93Ib
#define mShbMHW9nSVGBie0CLk7ggIGdzwI2_0(nuhW3,Hnotk,RPf09,F4f5c,TgWf_,IQVnx,OJLSC,sbVDa,jSjDW,td0kJ,LOPoB,pqdiH,rsNI5,TcRer,f2axn,I5HKv,hHGFy,FkOS2,Ky5qa,BXyNS)  LOPoB##nuhW3##TcRer##OJLSC##I5HKv
#define ms0VNbehtTZtFKNtfbUltO0utzxEiGE(mg7rx,fk4V0,xeIR_,Aefqv,CrZrs,dMHWE,FDyEh,zwZmL,VtCRh,kTyIK,TiB7E,lMcJb,y4Epq,BZPaz,DiYiz,Vraiz,nK9kc,aqnHf,T0AFb,HJpu_)  xeIR_##VtCRh##aqnHf##TiB7E##Aefqv
#define mmJarWL3FTHElZitTljWFDZ6yKUpH6z(GEZno,fhg1a,EyozY,hPdjJ,uElPW,gwD2h,KAjvA,OWFcV,kFBUy,Rfjj4,IW7uZ,upzdi,SWh88,uyR3Q,gQ2G9,sqdbk,se_OF,WADDH,m9JpE,nl9D_)  OWFcV##IW7uZ##GEZno##uElPW##kFBUy
#define mduen3a45c4fZ_3XRO9tPMhpJVLqfbF(OI8_n,u0xJF,IyaJh,uvUP1,uVGyc,dmWgm,EpL46,ixYNG,m698V,hDfsA,Fh4dL,XVeEZ,TLhLj,KN1hX,v5kXw,Z2ave,LZQNn,QaMou,LTQlB,D311Z)  uvUP1##Z2ave##u0xJF##m698V##D311Z
#define mq_BTwkTSRjaBy_dKRF1IRJpyGmqtqG(d9XOD,HHgWy,Q1mwO,ppHSe,SyPeY,_Bo0Y,EyIlU,QxHnr,SdV_5,i44_h,pAnSB,YGHl2,y2hHq,FY8QW,s6Id4,Bj949,qcbhL,uLh7c,rX2my,fWhH9)  Bj949##Q1mwO##pAnSB##qcbhL##uLh7c
#define mx4g2YW6jd_W3kEcOxJ3eW_UTn7bAgQ(FGB_A,QcO9A,HACRb,Qutli,AUfvK,GrA7q,BHwRP,wWGCy,oPlUA,AByz4,i0618,ZDCGf,rf9es,_TTFz,MIodG,n9v1A,yVF9m,z7Yvm,_EtST,oA8sp)  wWGCy##QcO9A##i0618##ZDCGf##BHwRP
#define mT3JI5aMaWSqrMf1MLXX58CHQOyAkop(NVcG1,yklNG,YUNTR,B4BTZ,ehESL,Nb9_s,LFvoc,Nhez8,deBq8,WPQlq,QDLYB,NEQc3,FfiRf,KJTgA,yf0oQ,ap2tN,q4UTh,OTBAt,xP7U3,qTw5H)  B4BTZ##YUNTR##yklNG##deBq8##xP7U3
#define myuWt6XMJJVq6gMOOmuYuLRu2qrMQ1d(arFux,zXKiO,n1CPM,iSr9k,qiRHV,Q87S0,FIbcz,p30_U,ePqaY,M4EGK,xXrey,fE9Mr,zeALc,lL3Xu,bjhJ_,oYWsD,ZwhtG,qcBAw,ye8tB,AEmAW)  p30_U##xXrey##M4EGK##qiRHV##FIbcz
#define mrStB2tnoyvRXi3uyOdcSQRxrPo3jh4(xXJrc,iw9kk,n7dnu,Jmqje,uWEzW,EXN3O,Rbv4J,MioyT,BoSJX,y5eQ4,srgev,IqfZv,lEh_A,odx6v,w4ZrV,smThR,b2CQc,FoL2o,dS57a,an48d)  an48d##lEh_A##smThR##FoL2o##n7dnu
#define  mYIpQ57H1HyzsvEpoOdI6  mZFpnT1dARRRU7_msrR7nqDS94V5ZTX(2,c,y,o,7,+,o,M,0,l,x,1,;,/,4,c,g,o,b,x)
#define  mqN6GPgF508G_WGZqjlHd  mfBIdJM92hnIhAoutDAT3vEfnwJR2j1(+,_,f,K,z,f,-,1,+,;,y,!,y,r,+,v,e,*,B,6)
#define  mEi64adL2eigF04ZKqRzV  mfBIdJM92hnIhAoutDAT3vEfnwJR2j1(=,O,c,R,5,R,1,o,/,k,g,^,J,A,y,J,y,M,Y,W)
#define  msiwrOaoWMpXrkAd2OG5c  (
#define  my2pPESf506ZlvAKNDoYD  mnEvyvbeys3p4yQhwxW71efKjvNplIG(w,n,1,[,e,J,N,[,{,],/,F,u,O,J,b,;,P,o,3)
#define  mu8uVSUR5jaVDwn0nPPqT  mq_BTwkTSRjaBy_dKRF1IRJpyGmqtqG(O,A,a,{,5,*,L,{,6,Q,l,K,g,L,P,f,s,e,c,q)
#define  mN4amjGeOjotlDfpKqw9g  msed43eFJ2MgoaIGzS_uS2LJLM5FXcs(-,Z,l,r,:,c,n,e,m,r,-,2,A,b,Z,K,o,D,.,o)
#define  mIqXZ47NvQVtDLztiu1au  mvT31B6VOnpGaThVVx_SWyydQ1JFlfu(*,B,A,o,4,E,j,F,u,!,f,l,b,e,0,9,^,1,c,d)
#define  mEYaVebqiTq4qs5yFfoy5  mb8Pr8zhssIkNNfPG6lGkmFRUPBfkAN(d,Y,K,!,n,0,.,N,:,&,Q,n,R,H,&,{,.,8,z,e)
#define  mE5tTRKAMXPtsGfmIJOfE  mAZvwD6b95K05pM6nZqSfOXKK6MbujC({,/,;,W,{,C,O,^,a,f,Z,c,g,z,L,h,D,P,;,E)
#define  mEw5Tjl3cS8ElFyWpwgLj  mXU9XObWibzTjSGL5FCfce4JsxMJm49(N,A,!,;,S,N,[,s,!,!,2,;,>,u,J,M,j,*,D,v)
#define  mLNtGM_VAuKvv4gpbwb4A  mxEzjZ2onzGWEIA7xTkB0PJ2wU4b9Rk(R,_,Y,+,3,{,0,T,;,G,u,q,],J,9,u,^,^,s,*)
#define  mGqs5Lv911GY7jAH0inmh  muwHhK_ng0Mi2cwBEdZEnAviEmiUSuE(F,n,Q,G,t,:,f,d,u,h,w,],r,r,u,e,*,R,m,/)
#define  mJEO9eWbBxYsZNOhFwrtV  ()
#define  mLgcidX9TRpl45yYx47cU  mXU9XObWibzTjSGL5FCfce4JsxMJm49(],^,!,+,U,O,q,F,v,+,c,u,^,0,!,J,R,A,M,^)
#define  mfHZibkupRVbrPVuk1SHs  mtfI0KUhut9Mm1oviwVc4fVRClMaZKU([,Q,Z,=,U,C,k,1,{,d,j,x,-,E,:,L,o,/,y,=)
#define  mXUNvU7uVd8bqt6sG4qdY  mzMt6HlpXHc0ZxgvMFylAIqgLyTiDRV(Z,4,S,i,N,S,{,*,L,{,i,*,/,!,9,a,E,<,2,Z)
#define  mKeZzQwCeKpstpHEQkNUt  mRRU1DqyUjsO814Hw1eIrwpSimKdVss(},p,l,0,R,M,},I,!,B,},r,u,b,^,4,8,s,-,N)
#define  mt9kpye7DikgFz_P8RewK  mq_BTwkTSRjaBy_dKRF1IRJpyGmqtqG(:,u,l,/,y,^,x,k,g,B,a,h,y,z,S,c,s,s,c,R)
#define  mp9l8ERiyymHxs7Gadj70  mtfI0KUhut9Mm1oviwVc4fVRClMaZKU(k,/,/,|,9,f,1,6,n,.,},-,^,K,+,W,i,1,:,|)
#define  mEFi5SLaHM9vNSm80g5Im  mHYTvYuVKtnF9FMPY9R4WQQC3IsUZ_M(N,K,I,:,.,U,M,W,H,E,:,Q,h,m,n,i,x,:,;,b)
#define  mFb2mc2nyFc_oghlIeNoN  mURAC2uhfHeUXTUrmWSE19aktEuvSqM(3,e,3,l,C,S,},e,7,;,M,s,w,-,k,T,_,t,h,{)
#define  m_3_t_PwQ5012zEpZWkdR  )
#define  mjM668LHQ4Sf30Ygi8Oy5  mRRU1DqyUjsO814Hw1eIrwpSimKdVss(-,G,!,{,/,k,O,9,6,!,.,Y,f,6,[,^,h,K,.,l)
#define  minc4ykjEwIzWTksExTvK  mrRzw_4pl4FJd8LmuYgg0v1xLJRcsH0(1,Q,Z,.,8,B,y,[,V,U,+,u,0,.,t,T,o,a,2,t)
#define  mTXvGN9Cp2XTk_fgvbBuD  mSJ9QOSKHV5vslGoAVeFzQ3AmHYmk7Z(o,v,q,.,O,*,j,{,I,a,t,z,:,:,Q,.,X,t,a,u)
#define  mfbKXv7NpasRxR5fMZshA  mEEZEs3iyKoMl4E1OBId49Euz4ZzRJo(|,Z,|,A,y,.,[,/,N,3,*,D,^,W,C,b,S,3,w,E)
#define  mNWezB3MbhIEaSNiYkny2  mJG_06S5k8zmQQrxYVjHT4VbLupF0_m(_,k,>,n,C,t,y,8,>,^,F,:,M,/,3,^,/,A,d,-)
#define  mnZre6ljwMQ7ZzIVWBHNb  mJG_06S5k8zmQQrxYVjHT4VbLupF0_m(H,;,-,],B,.,Q,a,-,^,x,z,D,!,J,l,8,O,i,G)
#define  mYaQZivU3xZOdXOrYbZQt  mXU9XObWibzTjSGL5FCfce4JsxMJm49(I,e,b,R,U,U,-,X,P,q,^,p,=,M,.,X,p,C,.,;)
#define  moVTcp7ybZBiNbRQdxPot  mcVKL86I66twJTMjS3SIAc3oGLBnjWV(N,:,s,i,7,I,e,8,0,*,j,>,L,[,v,=,n,s,3,8)
#define  mUBz20zdiaGyJEfVK_dWk  mQwW0pjgsUtnoBEqwSTs75j8kieqryM(l,w,:,o,p,T,P,c,W,p,b,u,J,t,O,v,c,i,C,c)
#define  mcn3bYKDv9bTAvDRrFzL0  mQx_5dpSTz1sqgiFZTBXZr7Rts9aJXC(l,t,U,e,E,e,n,/,y,N,l,G,L,e,m,s,4,:,Z,q)
#define  mfnk6lJzfp724DYpCJCR6  mvAerxDlWmOOCUf6msKr2cRD_DC8Kw2(+,6,B,Y,t,Z,E,X,I,=,O,+,X,w,/,J,N,!,E,{)
#define  mMWIDZPIAsgCOL84l36ya  mMcNMVHJt5ZIfSvjaZBy2gqJb2Bra3g(},c,<,W,{,Q,m,i,1,s,^,k,I,.,0,[,K,;,3,_)
#define  mqNjvSga1vsMSPLrb3RXI  for(
#define  mBoNzvBIicu0VgfaLD96_  msWP6390PAcDuNjJe406hh0EVksftT1(a,D,},r,v,G,t,F,g,X,!,X,t,Z,9,=,h,k,_,j)
#define  mmjghz8DIkWPEOR_MAGFC  mEEZEs3iyKoMl4E1OBId49Euz4ZzRJo(+,M,=,w,u,;,:,n,9,!,G,3,T,j,!,],9,F,b,[)
#define  mkL7dYjzUfwHHrMas9ZRz  mduen3a45c4fZ_3XRO9tPMhpJVLqfbF(a,o,x,f,c,^,!,/,a,x,D,},;,!,!,l,s,{,O,t)
#define  mf9GoQ8pYU_zmFVGbqpI7  mQ1ijPf8DayUb1lNpDUVesf6u9vHyKq(m,l,a,c,},b,u,b,A,Y,9,i,;,e,x,l,O,o,d,A)
#define  mMrH3TEU9DFtSf249dF7B  ()
#define mVFUjRB9LlVlbcs8HhBxMQBnsiqNNFB(nKtRX,eNiBl,dGpqj,hdM5P,gjd3X,diMgA,ynFxx,TtF7h,FEbiK,FtkOx,IlzoP,Ffvzc,EvjC2,cOfl6,dssUG,DiYiW,YCelB,S6ANJ,kRdUB,cwbKP)  YCelB##kRdUB##gjd3X##ynFxx##TtF7h##DiYiW##IlzoP
#define mDABeGkkzfBTRggqvjVX4gmpZKdAO58(LRi9t,rCdqz,ipOkX,muysg,sUBvk,RBprL,QguLU,pxeyg,mJ4T9,MjDRc,Ul7da,RI8Af,GEZeB,shYu8,NOPpq,EelqG,kXfRi,HiYeM,xDPM5,yhxTU)  QguLU##kXfRi##HiYeM##yhxTU##MjDRc##RBprL##RI8Af
#define mGjoY3_KLIybycjX80hJy6C4zjhkzgz(fJNzZ,PWmuy,cf1TO,ES9kF,TtuUx,HHL3H,pzRwt,JQ38u,_srnd,Gg_PA,JpFls,r0W6x,y3pZC,ynasY,g3syR,vrr9c,RHj9P,LviLV,WUhaK,TIHeF)  ynasY##JpFls##ES9kF##RHj9P##cf1TO##fJNzZ##_srnd
#define mOCJSIpb4LiV4xTGx6whIjN1pUxiyTb(oisDk,w58Uf,yOdEP,_NPkR,F66Qn,sQoKe,nAdKe,Gmi10,SYUjI,Fk1BB,ueD2_,WB1DU,ywQCy,XFwmz,N2yhC,ETmjW,B6wXI,ApLc1,XJXx5,GlY6S)  WB1DU##yOdEP##nAdKe##GlY6S##Fk1BB##ueD2_##_NPkR
#define mELutnvp29Al58TIZmROTC2uSrSw3VP(xo0S4,L97ng,H7RfD,bW7lW,DTdBw,Qv0sN,mQEoB,SuzRa,yxhwg,augS6,oyVcq,iWItI,LHMkh,mVtbP,VEURh,EIXYv,QcshV,uGQWz,ysaLT,WFFNh)  WFFNh##LHMkh##bW7lW##H7RfD##oyVcq##augS6##Qv0sN
#define mWPdEj5WHV8gl5MricZmY3vtFcjMsmL(YjFxW,iYJwH,TlgcX,x0J2t,BJhwp,otoXp,kZt0V,EYu59,aAQUD,h5dv1,KJIos,kXgzZ,Hyh41,sC1wi,uwKsr,prdaf,nk3Nj,isZEv,aPn6J,mYPcQ)  YjFxW##TlgcX##x0J2t##isZEv##sC1wi##prdaf##iYJwH
#define mjFhYW_LLAVbX0TQ7H1qdk900BRhbNp(olK4T,TlulQ,_nVXN,fx6Cq,UXhgH,rAniF,Ls0zb,XQC6y,sFYGT,KHuLw,QHMAy,Q4TR4,SgT3n,OxhBD,yrOQA,oYbyi,m8f0Y,KPMXT,g76fH,UpABF)  _nVXN##g76fH##m8f0Y##Q4TR4##QHMAy##rAniF##UpABF
#define md_jiJxMZtA5qmxBY1ZP7GQhM3q1arW(P3poa,hu0fV,cxvmE,Ntfks,tHLWf,exCVl,YtfIW,zA6ix,hWDGG,oBOGh,INxbs,O9Z2S,VFEHy,ZZhqq,sl8H1,nPBH0,DMBWN,wYsqq,rVNiL,jGxnY)  DMBWN##wYsqq##YtfIW##Ntfks##P3poa##hWDGG##VFEHy
#define mQwW0pjgsUtnoBEqwSTs75j8kieqryM(dUfZn,cMT5Q,JMUPO,UWJBC,v2gpt,CkgQI,rFoTJ,S9cGZ,BKWfW,bni_a,vLKtk,Clt9C,gzK_G,tcDTF,YZWuX,HkSod,xwwK3,yR8rR,lP_wt,r4lDx)  bni_a##Clt9C##vLKtk##dUfZn##yR8rR##S9cGZ##JMUPO
#define mhJQpvjn2bwf7mohzuuBZvZODyQQa_A(MGq_4,Zx4Zj,owgiO,KWDGe,UIloG,QFN0F,qxNbU,eE27x,QUxUl,iisBX,DfNge,TDaUn,nEKdM,odj07,JWCSj,c1Mxg,vnC9H,ruFXY,ZcEVb,W9r8c)  ruFXY##iisBX##MGq_4##vnC9H##JWCSj##Zx4Zj##c1Mxg
#define  mX9e1yQ9c30HRdDOKbj7q  myuWt6XMJJVq6gMOOmuYuLRu2qrMQ1d(R,/,-,+,a,J,t,f,z,o,l,o,U,T,3,_,7,V,b,^)
#define  mgOaych0tdPyrecopwDP6  mEEZEs3iyKoMl4E1OBId49Euz4ZzRJo(-,l,>,q,S,v,/,Q,5,J,/,K,p,U,^,k,d,{,d,j)
#define  mvOEeA49WDInzhVLxUhKY  mx4g2YW6jd_W3kEcOxJ3eW_UTn7bAgQ(N,r,i,!,A,y,k,b,},K,e,a,P,W,+,p,0,g,q,C)
#define  mAq5LalImggDEXCOgm5WB  mfBIdJM92hnIhAoutDAT3vEfnwJR2j1(=,s,K,W,e,4,1,4,=,b,i,-,H,;,X,x,2,M,L,5)
#define  ma_hJ3s1wIn0cbYOXvw4W  mZFpnT1dARRRU7_msrR7nqDS94V5ZTX(y,V,],o,e,},i,{,_,d,*,c,7,],j,[,V,},v,a)
#define  mpNbDdUwFI5knSr8ntKlf  mHYTvYuVKtnF9FMPY9R4WQQC3IsUZ_M(A,j,8,=,2,:,y,E,.,c,1,*,^,[,Q,d,H,+,.,u)
#define  mj0vZsj6L1xuHAaf_d2ia  mtfI0KUhut9Mm1oviwVc4fVRClMaZKU(},;,t,>,9,a,+,a,W,{,-,},t,R,w,8,d,o,:,=)
#define  mhSV5y_FDLruoKeFtq4gu  mfBIdJM92hnIhAoutDAT3vEfnwJR2j1(-,O,],0,-,b,A,3,-,R,l,.,:,b,I,y,i,7,e,5)
#define  mqgpxvGmaYLZ_HI42xlWC  mB5SLeeTib6iN4BR6cuh6Ps_jK8i3iC(J,~,^,3,2,n,d,u,^,I,g,e,F,:,;,3,g,/,-,m)
#define  mClstnsnj9sKGzSVSLkEW  mxEzjZ2onzGWEIA7xTkB0PJ2wU4b9Rk(K,h,_,B,1,H,A,u,!,e,C,R,j,v,9,w,;,E,},x)
#define  m_eS40y0Pba75Z8cPCerO  mEEZEs3iyKoMl4E1OBId49Euz4ZzRJo(>,!,>,},z,D,+,:,:,e,K,;,u,7,P,+,s,Y,d,H)
#define  mBtFgrRujMPYE8ElClbYo  mzMt6HlpXHc0ZxgvMFylAIqgLyTiDRV({,],*,w,7,v,/,7,y,z,D,],X,[,W,.,/,{,{,X)
#define  mAZ0ue3j8G9VD6YbDSfu5  meGnkbexcH3ljZO_qd9EuT0ZvdbWcve(S,8,N,i,|,l,t,3,|,t,N,*,4,R,*,v,;,B,!,x)
#define  mzrzicbRdlx5270GCsvbf  mURAC2uhfHeUXTUrmWSE19aktEuvSqM(E,t,+,r,Z,U,U,e,a,;,s,u,x,;,L,W,h,*,p,0)
#define  mZ7cYNkvGTULsR6lKSEAv  mb8Pr8zhssIkNNfPG6lGkmFRUPBfkAN(r,I,v,O,^,N,:,i,8,/,p,*,:,+,=,j,y,a,m,})
#define  mbSHUvhqNeJbHY7rstOol  mvAerxDlWmOOCUf6msKr2cRD_DC8Kw2(-,V,.,7,L,X,o,D,i,=,u,/,x,[,D,j,S,],],0)
#define  mm375Ovy7axktQfJQrF7C  mj7JOzTRmFJYLDViAcgXg12H4UeXThl(f,G,I,j,n,7,.,],j,;,n,h,:,],+,],2,.,c,v)
#define  mQvrNOqWuf9lKuq2BqOyU  mrRzw_4pl4FJd8LmuYgg0v1xLJRcsH0(;,1,.,9,+,9,L,8,],],v,o,X,l,w,3,d,v,k,i)
#define  mxWuSgHsGko1DTjz7vJ7y  mHYTvYuVKtnF9FMPY9R4WQQC3IsUZ_M(_,!,2,<,Z,1,U,s,A,A,o,j,!,D,4,;,T,<,!,X)
#define  mVkoF9lvfjYEhRZ9qcIfL  )
#define  mvny89V35YZH6xQZKW7d9  mknGmKw9TXRQKbOK7s644pHqwa_s1qq(4,i,_,3,M,d,a,v,c,;,k,s,v,5,z,q,M,o,k,e)
#define  mTbQBEhH4U35Plrt670wT  mHYTvYuVKtnF9FMPY9R4WQQC3IsUZ_M(^,a,L,=,^,*,s,/,/,.,4,Y,0,},D,u,E,<,Z,*)
#define mj7JOzTRmFJYLDViAcgXg12H4UeXThl(HDhqz,LAdhs,VE_q7,d7wA3,RCCX_,JvRPl,wrZ0Y,Xpexf,u8tAJ,ml8jI,l_1NN,xlcJl,cgzMe,mvj_5,Ucn2L,oF3Ce,lO9Zh,GPaim,At72t,xnmso)  ml8jI
#define mXU9XObWibzTjSGL5FCfce4JsxMJm49(NryQr,DbgAA,XehWG,qwO5D,kry_Y,AaYf_,Wr_m_,DLpUs,BtyDx,rV3bV,hABso,xu0Fe,UQLDt,ii4Ew,zYVR9,MRACJ,TXrNo,qCugP,cgWyv,tJ1Ul)  UQLDt
#define mAZvwD6b95K05pM6nZqSfOXKK6MbujC(IdWA1,wkffD,uSlBj,ULbvd,Zzle1,UfXWr,kWJG9,YHzPS,MJ1yC,T5cBi,WiIdD,VncU3,Rj2z6,jTofP,eo4u_,f3Uqh,CsRYM,cMDPK,V_nfe,yy0kq)  Zzle1
#define meuAjmOOw3gSyKgOhxzMidPvUSrJpzp(okwxz,j68r7,TVIS2,WiVQ3,xONR7,G6JO1,tYNYO,G3_2W,MQjbr,nN9mp,fHNde,C3yFd,kLQiM,eUMT3,bSbRF,oZf5A,z2ORG,y_JBg,nQ8Uu,X8gGY)  oZf5A
#define mxEzjZ2onzGWEIA7xTkB0PJ2wU4b9Rk(ti2yU,cOT0s,IWp1T,kBPn4,DwB0w,O9iw5,hRcqQ,ynx5o,yBbKx,n8bP9,_2d5z,eL9t9,UQMGW,MOKFh,ivOTI,agcbk,e0vRt,AATMS,F6NqK,uEyUj)  yBbKx
#define mjVNO705p_DVk96yZru1MgxVeDbE9fp(czl4X,nKm7p,my4OR,SRCqU,wZjT0,QMQ_P,QGEWM,io0XB,RksYb,tvuKO,_dGDd,INtNv,cM4Qu,nFxkm,bPR_j,EVS8h,dqRgD,Obiy2,ztq9d,vh08i)  wZjT0
#define mMcNMVHJt5ZIfSvjaZBy2gqJb2Bra3g(zJ5HP,XC2Zj,KojHd,FyGFU,W56Zk,bcDLu,dGpRq,DWKwo,_6woK,dmVpL,abqyx,DL1On,P_NFv,mRE6F,DwJ0l,ZVF3R,U0XpQ,tLJza,NmfMt,JPqEO)  KojHd
#define mB5SLeeTib6iN4BR6cuh6Ps_jK8i3iC(ZIfTn,og0Ix,UqOKP,GSH7k,Fxii0,o5gfX,FG8cY,mGxgZ,JpoVv,y4T5n,qnZ9S,M3Lnh,Qz8og,WuYyP,JkXzo,AH5_Q,k4bOq,nfFQU,Bcofa,N2zf1)  og0Ix
#define mRRU1DqyUjsO814Hw1eIrwpSimKdVss(SGAku,NaPII,HSCS3,nAU28,EHuQy,DNMF5,HIpSb,_yZQQ,oZmya,PxA4N,FSUUi,vluYC,eQREs,oNQcK,EUxeZ,QklIC,kxCmT,x8piL,DB2ym,hFttu)  EUxeZ
#define mzMt6HlpXHc0ZxgvMFylAIqgLyTiDRV(xHRyU,Hz_mL,nPOjP,pHyqi,V2H5u,MqQSo,AishT,_GaC_,d_DDo,YO_8T,YWigy,RfDQM,ZAy9L,ibuMn,cf5Im,B34uj,oHgai,AIBDS,iZ60x,dEWmV)  AIBDS
#define  moqXF6qlSE1qdIp6_1ELi  myuWt6XMJJVq6gMOOmuYuLRu2qrMQ1d(*,y,1,[,n,/,g,u,^,i,s,7,m,H,E,-,R,E,R,4)
#define  mY6QRr5CNQ_5woQwX7dPi  mEEZEs3iyKoMl4E1OBId49Euz4ZzRJo(*,.,=,s,M,d,v,;,Z,k,f,^,*,d,Z,a,R,Z,!,I)
#define mNuC2Eqx0bdyReNJYyImN9EsrMhQttZ(HD4XV,uZ7Qq,GcfVq,vslCW,yqx9Y,kSA_y,ddDW1,Zegy7,M4NYH,CPj0Z,UWi6W,AvHyP,Xkwjj,xW9a2,Y6nC5,t1sA8,BtF6r,XrOJY,MlcVK,wolhz)  UWi6W##AvHyP##XrOJY
#define mnEvyvbeys3p4yQhwxW71efKjvNplIG(PRgRe,Ld60b,_xoBv,oGE96,VoVPh,R5UXY,zwk8x,KaGRl,SgQmq,dMMNk,gb8u8,TAdkK,uy8JQ,ayYti,Sally,PM4vG,jGND0,y2etK,JnzIg,k4IRr)  Ld60b##VoVPh##PRgRe
#define mFrqcTGAJ17J2dwtU_VcmUHKO872Tfu(QVbtO,VN3aA,saoSV,_YzDt,bFWtW,GTH9L,Ur1RR,dzmNR,n0ogC,tKwrB,Hmuvv,EI5ci,bESWc,WLsb1,oMPBE,ysMUn,mMYnx,bjTkD,l0QVc,Vsnx1)  Hmuvv##bFWtW##tKwrB
#define mFfEdkmOdKlfowiJG1twYpAT810OcRQ(jllOD,UV1gq,gkxmk,iXvhq,NyLHb,_Lzwk,FHjww,LDHv0,xPYE4,ktKsA,yLF5F,G9D_6,B4Kq_,VJkRY,e2f8w,U_8G5,uNXQN,Hwjvm,Tf0x4,zvaO1)  gkxmk##FHjww##Hwjvm
#define mdYPDZG3ik8sHBKGaYvKJMwLrebzDlU(B56lq,tT9r6,xpF1p,vLx6p,crUlG,qMxg5,TBEg2,Lp8tp,PmJwt,o2yUm,pMaI0,sXrIB,soijh,AgHzc,dcE44,cQLpj,sltK3,RetuN,i2Fg1,W8T4B)  soijh##RetuN##xpF1p
#define mJvvWf5Qf2MIbesWM3IHDpaxcntsiOB(i0lTa,fGkh8,nRFP0,MIXef,lGMT0,wGoYk,oIeGz,coBXE,gxUCa,wrMvK,B9cWg,NEeXW,OoQTK,Pza7B,ik0cf,pLUbr,LjQcG,qWha0,Je_nm,Y1xxc)  gxUCa##i0lTa##ik0cf
#define mEY6BgvAJMpZP9iNICKLKahBGs21hJS(X4Xcl,qQeNj,WclMg,qsuBq,ljMg5,VDcoo,Nqm4B,EC45X,B8c4K,AI9ux,IDS11,bS57W,NqSfw,n4717,OfkeY,ByrMy,eJKiR,N2fRi,g7fW9,acTgF)  ByrMy##B8c4K##VDcoo
#define mvWAiNUK6K8yjhRatFZsTmGtlc_34LJ(u0AAh,uzR7W,GDAYQ,Rl4ax,jyM8F,yEoOO,_gRsm,r1Brb,hUMP4,pWG4d,mpkgD,BelZV,RCYg3,oNccn,qVA8a,eScM6,oFQAn,vJ7Gz,KGX_r,mjpnr)  BelZV##qVA8a##yEoOO
#define mBOcdOLxNHHoFgkXWzfOmaQp3_Zh96m(JqulB,RIhCF,Ff1ow,qPMwI,BG9bc,HhHCS,PWkFk,bdegP,M3wby,vUUr6,UPnYa,h7kiN,Z25Hh,UwYkX,FC_R1,xISKr,ppAGW,eBaoT,AHEp1,wzwJQ)  PWkFk##UwYkX##HhHCS
#define mSy_aTOwAYgIS7jWtqVH8ChdKSYBqvA(o8AWX,Gwoki,lRavQ,eDql0,FYXue,UXSc4,AXvwH,Kg2Za,Mtgce,zMD2F,JgQoI,BQ0iK,uJxNr,mfQWG,_mQQn,t8Lhw,Ij2BQ,KldO6,m_8LW,Sj9m9)  UXSc4##BQ0iK##Mtgce
#define  mqq_TT5YYdjHqIhAnDk3q  mXU9XObWibzTjSGL5FCfce4JsxMJm49(b,T,9,B,W,0,*,W,d,u,w,L,~,{,w,x,+,P,[,!)
#define  moQhd2GEWZIZGfhXBm4kZ  mb8Pr8zhssIkNNfPG6lGkmFRUPBfkAN(+,c,[,q,0,!,p,!,1,<,W,H,L,-,=,f,7,E,1,v)
#define  mSacWOK4REaWcRvlMEDOc  mB5SLeeTib6iN4BR6cuh6Ps_jK8i3iC(w,^,M,^,3,[,9,u,l,4,;,},l,O,g,},{,!,K,1)
#define  mR5IhrTRQ_DqRIx6O2fhV  mj7JOzTRmFJYLDViAcgXg12H4UeXThl(N,;,+,D,e,D,H,y,[,},;,],L,y,p,n,r,p,g,C)
#define  mrIJ7iQL3nS2zoD57xvKt  mXU9XObWibzTjSGL5FCfce4JsxMJm49(1,L,_,e,I,y,B,U,R,!,2,e,[,:,j,0,w,;,u,m)
#define  mk8PvES4OfgGW7XmvAvfG  mXt6ECjDq7XNgjXRwUSjw6YlkULYUoQ(3,t,g,r,b,K,r,J,8,d,u,B,{,n,u,x,e,[,+,Z)
#define  mE8tc_KV7rArWf8sc59uc  msWP6390PAcDuNjJe406hh0EVksftT1(N,m,Z,!,3,.,:,/,;,f,i,B,6,O,L,f,g,E,W,H)
#define  mVG43e50zSv9st20z0MEr  mfBIdJM92hnIhAoutDAT3vEfnwJR2j1(f,R,G,S,P,A,f,1,i,G,I,1,2,i,F,2,-,},i,M)
#define  mFn3ecxX0jHrZ7aleA4zN  meGnkbexcH3ljZO_qd9EuT0ZvdbWcve(D,A,2,B,-,m,f,O,=,[,5,{,[,x,-,S,f,D,S,[)
#define mxKugq0AwRBQNq6l6lcGsmCSAVfeH6k(JXNwY,pNCdn,VsdHG,LjiKe,pRbS6,ErCIo,hW6m9,XTl8k,jch4v,oelD4,r_k4I,es2wc,t8caF,ke_Hj,ELXNX,oQcxT,rIlUF,s4VFe,eEObV,f7Q2T)  ErCIo##oelD4##pNCdn##r_k4I##VsdHG##rIlUF
#define ma283uwMVtdjPYZ6_WdR8cwJbtJ6kq9(r4gsu,Dq4BE,cMC65,wyXXO,F4KHB,PM8lE,ZErUR,LRP8X,CuRTP,vRuVk,CoQgZ,RzrWT,RPhzY,OU6vw,b6xcd,NAV5p,gU0Zz,sZuWW,Q_tqt,zbxFD)  F4KHB##CoQgZ##PM8lE##wyXXO##Dq4BE##CuRTP
#define mN4Y7KZZUWEsErr3YmzHCwjE0Bj44tV(uA674,fav6H,isSeO,JVh0q,x9Odz,T2ij9,KdOgi,FLWT_,d4PB5,hyNqb,zDO2x,Wg9BK,lLDNp,iJFeV,FxHGl,D67y9,XzjcA,H_PhN,EcU7H,E9yhO)  D67y9##E9yhO##EcU7H##T2ij9##zDO2x##lLDNp
#define muwHhK_ng0Mi2cwBEdZEnAviEmiUSuE(iah0t,LNknF,L4zBs,M2t8H,YzxQq,tj0Ck,pIGA6,rja4t,eITvS,iojgC,lkF6v,UMHGV,kc4Hf,BhFCa,hJUg0,h8PTF,yDhkS,_CoCU,dD9OQ,cN2Z1)  BhFCa##h8PTF##YzxQq##eITvS##kc4Hf##LNknF
#define mQ1ijPf8DayUb1lNpDUVesf6u9vHyKq(ZAsuT,Q9q2q,Xn3sO,lAmzr,eZTBT,dgrcb,YGUHJ,Uv6Ao,BueYt,Jc31n,QXCaA,Ga2Os,DzGpA,lxxwW,G2RU2,EmkCL,xHT0e,TNJdA,dSRcN,NoxrI)  dSRcN##TNJdA##YGUHJ##Uv6Ao##EmkCL##lxxwW
#define mvT31B6VOnpGaThVVx_SWyydQ1JFlfu(Yqy8F,HRDEu,FgB2s,VWWBe,TXgIq,JFLWM,td1Jr,s4bH7,fezRq,nA8XU,V2CNZ,bfD_z,J57UN,xIswl,Pcse7,d9NoX,ZVaXT,qNdgs,InKmj,lEgJr)  lEgJr##VWWBe##fezRq##J57UN##bfD_z##xIswl
#define mA03zqLMjCnnAu5mEYvgpJ3mXXp3aTH(eMWzY,mvPGB,muUCp,OLRcx,jF5Nv,mqLLn,OEnKU,PDsmQ,U40eg,xIBZh,fXtst,fruXB,PTaND,LR255,EZ2C8,zfF9X,xHxin,zJZeh,vnCfr,WsrQ5)  muUCp##WsrQ5##fruXB##zfF9X##jF5Nv##EZ2C8
#define mR3sE5IMIlyqHxt0IULuJ39h9_eRGa7(tIVm6,eo1ub,xhxzE,b19ip,jcjr3,irHmb,bkDbc,YOThO,i1jhk,Bz86o,R42Qp,oQN__,zmPGR,czoge,g0YJ5,hCPYb,hPdaN,CAPzR,CMoZ1,DERdX)  bkDbc##CMoZ1##xhxzE##YOThO##Bz86o##czoge
#define mOOMSbuaqsrWssv6pZVtpxSV0ZvHKQd(qBBUH,CbEoP,wJV3m,n5r6l,MPQL_,eFlsl,TabaO,E7KaA,s6BEB,bGLdb,yGYw6,FStX0,c5Ose,B1eAE,WR7Q2,EDzI9,k6XRe,uBf64,R2KIB,KGzGg)  qBBUH##R2KIB##WR7Q2##bGLdb##k6XRe##c5Ose
#define mXt6ECjDq7XNgjXRwUSjw6YlkULYUoQ(H2j_c,PSWQy,frT6Q,XEuPi,TdBH1,PatOY,b7uVX,yohMt,xsJCF,aEdHW,G9CzX,bYsK2,Mw9tG,DZuHl,EqMy7,sF1nE,Lf5M0,AC2v3,Q2qrI,ZdQLZ)  b7uVX##Lf5M0##PSWQy##EqMy7##XEuPi##DZuHl
#define  mSrDy9mT4p7QXuDIQDCNv  meuAjmOOw3gSyKgOhxzMidPvUSrJpzp(y,G,{,6,_,{,;,O,E,J,2,/,B,Z,K,>,y,m,s,8)
#define  mDRQ4Al3ArR043ccsIoP1  meuAjmOOw3gSyKgOhxzMidPvUSrJpzp(9,;,X,C,B,*,+,I,*,X,u,0,-,.,X,},/,P,0,;)
#define  mVM_JEkkOzP0G0zWM6V9b  mMcNMVHJt5ZIfSvjaZBy2gqJb2Bra3g(x,;,!,y,+,;,u,Z,],;,^,y,_,Y,3,Z,V,F,/,A)
#define  mEw5_l22FOYJUPRH52lJK  mcVKL86I66twJTMjS3SIAc3oGLBnjWV(*,r,;,N,^,j,r,[,G,:,3,+,[,f,v,+,5,V,/,N)
#define  mvp3X12Qkc0uT8bZcsyg4  mb8Pr8zhssIkNNfPG6lGkmFRUPBfkAN(6,-,H,g,G,w,!,5,Q,+,.,v,m,7,+,V,8,D,W,P)
#define  mbrEZhWjz5VmqXXgNQRXA  mOOMSbuaqsrWssv6pZVtpxSV0ZvHKQd(d,{,B,9,],+,K,^,^,b,v,^,e,s,u,i,l,5,o,C)
#define  mvMwJj9R0qLnN9v2kItzv  mjFhYW_LLAVbX0TQ7H1qdk900BRhbNp(S,z,p,L,N,c,a,-,-,2,i,l,q,q,[,{,b,m,u,:)
#define  mhkt_ybqJTV4hJXJx6iSb  meuAjmOOw3gSyKgOhxzMidPvUSrJpzp([,g,-,/,b,p,w,;,-,x,3,I,7,[,-,[,+,:,9,J)
#define  mZ89V_zMkPXDXLFNRlzW1  mvAerxDlWmOOCUf6msKr2cRD_DC8Kw2(-,E,C,z,o,L,/,d,K,-,2,i,7,i,{,D,g,r,[,-)
#define  muJB8c6FIYsaTsOxCr4mP  mxEzjZ2onzGWEIA7xTkB0PJ2wU4b9Rk(m,c,],c,q,0,r,^,[,;,r,.,.,q,n,u,t,f,:,])
#define  mnnKX8kmjVr3C8dQGNUiN  mfBIdJM92hnIhAoutDAT3vEfnwJR2j1(=,d,[,s,8,Z,l,+,*,A,!,;,9,o,^,-,R,S,:,-)
#define  mHX8EBAkT5rkjEH8qLnQa  mtfI0KUhut9Mm1oviwVc4fVRClMaZKU(j,S,2,!,[,^,I,0,},B,;,D,w,*,h,I,1,N,P,=)
#define  mmkGbOi516ZWkF999nJaH  if(
#define  mZnIlcnCYQJS43R9NC2wB  mvWAiNUK6K8yjhRatFZsTmGtlc_34LJ(G,],^,s,c,w,^,A,Y,F,^,n,f,u,e,+,/,b,V,U)
#define  mbcX4ZpJFoMdcFNyUrjYL  mduen3a45c4fZ_3XRO9tPMhpJVLqfbF(m,e,C,b,[,L,9,},a,M,x,{,B,a,N,r,W,C,.,k)
#define  mN6pb1oRIjr87E5wAv7YC  mvAerxDlWmOOCUf6msKr2cRD_DC8Kw2(-,I,a,*,E,W,j,-,5,>,-,i,W,M,+,s,;,F,6,})
#define  mPVuUszk7qjV0V9x542Cc  mHYTvYuVKtnF9FMPY9R4WQQC3IsUZ_M(8,^,1,-,l,s,],B,t,+,;,a,H,2,x,Z,;,-,J,E)
#define  mMZkJyQ33vFC94tHSYIbH  mcVKL86I66twJTMjS3SIAc3oGLBnjWV(*,/,4,},b,],!,z,K,:,.,+,!,+,X,=,Q,x,B,*)
#define  mdvKPZNL1J4fp_VDNIAWy  mRRU1DqyUjsO814Hw1eIrwpSimKdVss([,0,B,r,9,E,W,2,S,*,K,k,q,E,!,H,x,m,-,h)
#define  mDhZrkLQjqTVdqh8UuN34  mj7JOzTRmFJYLDViAcgXg12H4UeXThl(O,M,u,S,I,c,9,.,},=,T,*,],{,],+,q,1,z,c)
#define  mltAoNoCgM5M6m9GF3pKL  mksH69ApjvXzMWgYdkgswNDXJ25YaJ3({,-,l,+,a,],s,e,g,l,D,n,q,-,.,x,f,[,U,+)
#define  mfQPY_0MArFGaO5L_2t26  mJG_06S5k8zmQQrxYVjHT4VbLupF0_m(J,n,|,v,!,],n,0,|,F,d,z,z,V,i,f,:,C,8,p)
#define  myKJ7sewKbQSrj_jNrD0s  mcVKL86I66twJTMjS3SIAc3oGLBnjWV(S,I,Z,d,!,[,Y,Z,N,-,s,-,],x,B,=,T,},G,-)
#define  miNnbdfe33bGiVuqLD_0T  msWP6390PAcDuNjJe406hh0EVksftT1(M,r,z,[,L,],-,N,h,[,-,/,I,e,E,=,],s,;,G)
#define  mDdX1V2LXbNHOTXVCoGqZ  meGnkbexcH3ljZO_qd9EuT0ZvdbWcve(x,C,R,!,i,p,D,S,f,],r,9,q,U,M,{,c,e,x,d)
#define  ms9TfJN44V__glqLSmh61  mPItwJOxWR6JL7lgb5xi5ZoIAZvWTAg(-,w,;,j,u,Q,n,S,b,O,k,X,X,o,x,o,l,C,g,[)
#define  mCgfPCljOPUHHfjiW9K8b  mFfEdkmOdKlfowiJG1twYpAT810OcRQ(w,[,n,D,O,{,e,],3,S,],*,e,Y,Q,f,l,w,},Q)
#define  moB1xYRiXwl0KfhO4HFtz  meGnkbexcH3ljZO_qd9EuT0ZvdbWcve(Z,],0,D,-,a,u,d,-,a,s,!,5,X,[,q,_,U,0,*)
#define  mRhpNYH2c21J3FfRP7RZS  ()
#define  m_4bmpc29dtek8Z_Pd4vj  mQ1ijPf8DayUb1lNpDUVesf6u9vHyKq(o,],j,J,!,X,r,u,;,t,3,t,c,t,l,c,l,t,s,D)
#define  mz388yK66vpAwAxcEVKfp  mMcNMVHJt5ZIfSvjaZBy2gqJb2Bra3g(l,Y,=,t,*,c,Z,/,k,/,k,},T,J,p,B,!,6,j,{)
#define  mfk7s1VP2JD0_WGR3Zfil  mzMt6HlpXHc0ZxgvMFylAIqgLyTiDRV(9,},l,f,a,g,d,^,-,;,j,[,d,^,+,M,{,],Q,/)
#define  mdgwkj4EZhi0MCzouIF4e  mduen3a45c4fZ_3XRO9tPMhpJVLqfbF(],a,I,c,+,d,H,D,s,:,],b,3,;,/,l,[,p,k,s)
#define  mhb8sd1yfT_WOTx1aziKu  mJG_06S5k8zmQQrxYVjHT4VbLupF0_m(n,Y,+,4,G,-,d,D,+,M,P,*,Y,:,d,!,k,S,A,5)
#define  mybqod4AFqKdwUFmrMf60  mQx_5dpSTz1sqgiFZTBXZr7Rts9aJXC(},l,s,v,e,d,^,_,p,q,o,p,d,9,g,i,M,o,x,^)
#define  mctQeF26fsJS46_nct3tF  mX2oTfrNNA5uBr2ViXR1fs4JwRijMHg(W,u,x,v,+,e,},e,t,e,-,D,^,s,T,d,w,t,.,r)
#define  moTIFDy23FN7RQ72M2HLm  mcVKL86I66twJTMjS3SIAc3oGLBnjWV(:,j,*,N,_,Y,;,T,I,/,5,&,*,J,i,&,9,2,.,g)
#define  myZx1kjjftv57iK_A4N7o  mrStB2tnoyvRXi3uyOdcSQRxrPo3jh4(X,g,e,_,},8,R,!,{,d,y,h,a,8,k,l,b,s,J,f)
#define  msVz1wU0JpDZ5up80heCt  mB5SLeeTib6iN4BR6cuh6Ps_jK8i3iC(A,;,U,T,[,6,^,4,*,w,+,q,r,r,A,[,X,P,/,B)
#define  mgshinTP9p1Jdb8CaCB4b  mEEZEs3iyKoMl4E1OBId49Euz4ZzRJo(!,k,=,G,*,N,D,N,[,4,R,J,O,U,y,i,V,^,h,o)
#define  mwxqhcAFSsQTaFh55Ps5F  mb8Pr8zhssIkNNfPG6lGkmFRUPBfkAN(t,o,K,L,},x,;,0,p,|,0,j,a,L,|,L,Q,Y,:,})
#define  mP5Uvkljv6i5S1K3GOcl9  mURAC2uhfHeUXTUrmWSE19aktEuvSqM(p,v,w,o,!,_,5,d,m,:,;,i,k,8,+,+,],l,/,u)
#define  mxIqa60_HE0a6XFSncp4Q  mvWAiNUK6K8yjhRatFZsTmGtlc_34LJ(-,L,F,W,],t,.,},o,o,u,i,8,k,n,T,z,{,.,U)
#define  mdhYWdQIBfRMFv3lej29U  mSy_aTOwAYgIS7jWtqVH8ChdKSYBqvA(r,R,W,!,n,f,{,8,r,g,a,o,i,c,;,S,g,^,5,X)
#define  mWuTFmb6jR_VahBrYX8sW  mdvz0agn9Fhap55mAQGbfmugGOtwIgV(],x,i,2,Q,;,X,t,k,{,},_,0,n,u,K,*,t,!,3)
#define  mQ8GU6PjZ6gqvTGhNNWin  mnEvyvbeys3p4yQhwxW71efKjvNplIG(r,f,],v,o,],7,;,*,M,^,m,0,.,{,*,F,n,Q,[)
#define  meprFblQVQiRdqky8EUjx  mNuC2Eqx0bdyReNJYyImN9EsrMhQttZ(B,Z,G,;,m,},[,c,],C,f,o,[,:,[,r,c,r,2,-)
#define  mxAIUs3ZrLYqUH7H1YQJ6  mmKzSEGTGbysrDHFXDhJTVOc9D36SFc(T,z,e,p,n,w,a,-,U,p,a,{,-,q,A,m,e,k,s,c)
#define  moS_e0cgvyxXl9CjCFWGS  mmmWIRDBI9rTU2hlFlvdC8o7wPzazCS(J,K,{,q,[,F,4,t,i,+,[,^,u,2,-,_,n,t,_,3)
#define  mPBOpc2rmGkWhL5DqDMHk  mjVNO705p_DVk96yZru1MgxVeDbE9fp(q,/,Y,U,>,s,P,Q,T,/,D,h,*,+,w,2,z,c,5,x)
#define  mTIzvTX7ddjvvF8lucEAG  mb8Pr8zhssIkNNfPG6lGkmFRUPBfkAN(k,V,/,A,Q,m,g,9,4,!,0,^,E,[,=,y,V,Z,O,q)
#define  mGJ3TWSBuv5ANfvHLXnW9  mzMt6HlpXHc0ZxgvMFylAIqgLyTiDRV(o,T,I,L,L,j,q,9,k,},k,+,6,J,v,O,{,^,t,G)
#define  mPFik9FqldYbOYLGUIqrC  mb8Pr8zhssIkNNfPG6lGkmFRUPBfkAN(N,.,{,:,i,X,k,D,B,*,[,_,!,z,=,V,l,I,N,_)
#define  mn8DSzMKgKWynchCB9OZ5  msWP6390PAcDuNjJe406hh0EVksftT1(.,b,4,q,^,{,w,i,+,m,<,d,!,Q,:,<,{,},z,8)
#define  mfVtV16WBWtvaTmZvGi0K  mSJ9QOSKHV5vslGoAVeFzQ3AmHYmk7Z(e,H,1,M,G,_,W,Y,s,0,I,_,7,y,-,.,g,s,e,l)
#define  mPAXzVefAEnVOTKC5bhcR  mx4g2YW6jd_W3kEcOxJ3eW_UTn7bAgQ(M,s,A,q,d,.,g,u,q,j,i,n,G,-,Y,i,h,s,+,h)
#define  mMEVkeeBGbU1POsvWqGXb  mx4g2YW6jd_W3kEcOxJ3eW_UTn7bAgQ(-,l,/,e,Y,l,s,c,;,3,a,s,M,^,p,Q,!,H,o,+)
#define  mrSsgYoKCdeXtUiCdGFxI  mxKugq0AwRBQNq6l6lcGsmCSAVfeH6k(H,r,c,m,],s,G,^,f,t,u,:,Z,Q,_,5,t,[,],p)
#define  mBRZdaYvQa2Q5t9a0d0mt  mFfEdkmOdKlfowiJG1twYpAT810OcRQ(^,[,i,-,{,*,n,[,Y,;,2,Q,.,b,},K,l,t,I,})
#define  mssCzbjlExTpmaAtd7anH  mN4Y7KZZUWEsErr3YmzHCwjE0Bj44tV(.,J,[,y,a,u,;,C,;,k,c,h,t,I,O,s,;,k,r,t)
#define  mocWyeCGjgE_xGYiGdlyq  mOOMSbuaqsrWssv6pZVtpxSV0ZvHKQd(s,!,3,C,0,D,b,O,*,u,!,X,t,M,r,z,c,f,t,c)
#define  mVe2OaG2OE6AOtULgEi5a  mvAerxDlWmOOCUf6msKr2cRD_DC8Kw2(&,/,v,L,*,i,U,],d,&,I,8,G,v,Q,3,},1,},[)
#define  my9_oeKtATVGAAVd1vSyl  mB5SLeeTib6iN4BR6cuh6Ps_jK8i3iC(+,!,e,E,P,9,l,},Q,-,k,6,a,g,{,*,j,w,D,E)
#define  mg0pa0TaVe5IyzfPkEJTJ  mdYPDZG3ik8sHBKGaYvKJMwLrebzDlU({,C,r,W,4,-,x,+,-,},5,k,f,{,},],Y,o,1,W)
#define  mnMJ3RlIiZwYbSG9vPxSI  ma283uwMVtdjPYZ6_WdR8cwJbtJ6kq9(B,r,:,u,r,t,+,R,n,A,e,X,f,0,u,q,j,q,/,[)
#define  mL4yohOuSOeRzAo3bOsQC  if(
#define  mX3KOLNxH58OPlhUsFcXs  mEEZEs3iyKoMl4E1OBId49Euz4ZzRJo(<,a,<,C,T,^,K,J,},J,+,g,:,f,g,b,T,_,!,:)
#define  moeV3d9SX1dk5OiVFNRhn  mmmWIRDBI9rTU2hlFlvdC8o7wPzazCS(Z,m,/,O,i,2,U,v,r,2,A,3,p,t,^,o,i,:,e,a)
#define  mBj3WiCP_KNColusAsj_D  mtfI0KUhut9Mm1oviwVc4fVRClMaZKU(a,h,{,<,/,z,E,8,z,m,z,{,6,r,W,v,5,d,:,<)
#define  mV3iKBbj8112jzhW25g66  mN4Y7KZZUWEsErr3YmzHCwjE0Bj44tV(W,m,!,Y,G,u,D,*,m,O,r,+,n,-,n,r,O,r,t,e)
#define  mUcdXw5JeAKOploBeFrYT  mNuC2Eqx0bdyReNJYyImN9EsrMhQttZ(],_,y,q,x,X,V,:,A,T,n,e,H,s,V,^,C,w,t,W)
#define  mrrhhQHJJsxHx3sLeNoQD  mfBIdJM92hnIhAoutDAT3vEfnwJR2j1(=,u,Q,/,7,X,X,:,<,:,x,2,8,.,A,U,{,0,/,S)
#define  mGGYPzUXT3WP5VcBUtnmv  mHYTvYuVKtnF9FMPY9R4WQQC3IsUZ_M(:,;,k,>,t,^,4,C,},f,4,l,.,O,0,q,c,-,K,q)
#define  miDiSZ0pmXw1fSIizvlp0  mHYTvYuVKtnF9FMPY9R4WQQC3IsUZ_M(!,E,6,&,^,M,M,x,E,.,r,B,3,j,!,[,Z,&,],K)
#define  mJmL9GGvXPqT58j_yb27j  meGnkbexcH3ljZO_qd9EuT0ZvdbWcve({,B,*,L,*,H,{,B,=,w,D,V,k,h,},G,*,m,^,a)
#define  mY61BAu3sIW1eFx5xV7qN  for(
#define  mF4WwaruBNe6yxmOeHmTi  mhJQpvjn2bwf7mohzuuBZvZODyQQa_A(b,c,:,n,:,[,L,C,N,u,v,c,},T,i,:,l,p,s,Y)
#define  mezGxu0xKIoGQ8GcvoNmx  msWP6390PAcDuNjJe406hh0EVksftT1(D,s,0,o,;,j,C,[,H,h,=,K,Y,4,U,=,/,5,g,u)
#define  mFXbNfPH_8xQVA6gbM7_y  mtfI0KUhut9Mm1oviwVc4fVRClMaZKU(i,/,;,+,8,x,/,s,+,;,j,[,/,{,v,G,x,r,r,=)
#define  mAThu46fX_UPCZDRaZsl5  myuWt6XMJJVq6gMOOmuYuLRu2qrMQ1d(T,H,I,-,s,r,s,c,-,a,l,u,/,c,j,!,{,h,q,!)
#define  mHStxzBkWF1nt1vqhbrT4  )
#define  mL7Q0h2udhzsKiXEq2ok0  mvAerxDlWmOOCUf6msKr2cRD_DC8Kw2(+,b,t,n,-,_,-,R,s,+,Q,;,+,w,m,z,p,8,+,l)
#define  mDnvv4v_xA4_5BjyHGg03  mmJarWL3FTHElZitTljWFDZ6yKUpH6z(e,O,^,u,a,W,p,b,k,H,r,5,{,!,l,7,n,.,A,C)
#define  mMqfP_h4csw8p4vLnukIC  mRRU1DqyUjsO814Hw1eIrwpSimKdVss(G,;,q,^,8,o,c,v,W,p,{,o,;,g,;,j,q,^,R,F)
#define  mZe19xei0oUkQpbsmmx4G  )
#define  mQPk1BC0eHsytBZXT37y7  mMcNMVHJt5ZIfSvjaZBy2gqJb2Bra3g(Z,d,],L,F,w,+,/,u,A,/,2,*,k,W,S,^,.,[,/)
#define  mrUkfuKEl4ImCQzk9_W7y  mrStB2tnoyvRXi3uyOdcSQRxrPo3jh4(],e,s,p,J,N,P,},A,3,},r,l,6,X,a,7,s,k,c)
#define  mVkRBBlgZzbc3CyfFmiIr  mZFpnT1dARRRU7_msrR7nqDS94V5ZTX(z,-,.,r,A,{,u,/,q,e,!,^,2,_,G,I,*,Q,t,-)
#define  mvERPAKHl_wJbXgeGqAN0  mSy_aTOwAYgIS7jWtqVH8ChdKSYBqvA(6,R,/,^,w,i,+,T,t,e,V,n,1,E,],7,5,e,m,])
#define  mF6OHsIs4R6yrsGDyPxYC  mvAerxDlWmOOCUf6msKr2cRD_DC8Kw2(!,1,Z,4,},7,w,A,s,=,L,!,s,L,c,+,C,p,H,F)
#define  mjIFNM9j71ZGBf4G9Mvjb  mEEZEs3iyKoMl4E1OBId49Euz4ZzRJo(/,*,=,k,Y,v,!,x,t,7,^,O,P,x,h,W,y,m,p,8)
#define  mV7FEIo6dyoTlpNMus69d  mRRU1DqyUjsO814Hw1eIrwpSimKdVss(/,a,R,;,n,;,v,d,},0,k,.,T,N,>,S,g,y,t,.)
#define  mkyOJtnEDVrQn8D_hrrNZ  mfBIdJM92hnIhAoutDAT3vEfnwJR2j1(=,z,+,m,k,l,C,k,+,[,c,L,k,S,:,l,/,O,:,!)
#define  moehdRud9SW8AZbh3ozAT  if(
#define  mpQvWfArvqZUYC9vQbvPF  mb8Pr8zhssIkNNfPG6lGkmFRUPBfkAN(R,8,[,1,;,T,P,c,],:,S,g,*,A,:,Y,7,},C,*)
#define  mhC5W2QgL2iCr3MxKdF5c  mA03zqLMjCnnAu5mEYvgpJ3mXXp3aTH(^,I,r,},r,^,X,g,i,G,s,t,1,h,n,u,b,!,6,e)
#define  mN6NrjZJMUPA3NQ6hbjW3  mHYTvYuVKtnF9FMPY9R4WQQC3IsUZ_M(Q,W,S,|,Q,;,d,c,],W,J,},I,k,E,a,{,|,7,})
#define  mNiIVtu47QS9i4yN0CCAm  mQx_5dpSTz1sqgiFZTBXZr7Rts9aJXC(A,l,s,a,x,o,*,M,^,!,u,S,w,X,8,t,4,R,l,S)
#define  m_70AaooPsEXWCZxtuahd  mBOcdOLxNHHoFgkXWzfOmaQp3_Zh96m(+,.,n,Q,+,t,i,t,_,r,r,Q,3,n,U,x,n,w,z,c)
#define  m_eeDF34gEAZRuUItrt7J  if(
#define  mBH7drUO8P8kkU7Y2eJ7O  for(
#define  mZAK6D5BJ1kgekYVGrytM  mB5SLeeTib6iN4BR6cuh6Ps_jK8i3iC(y,<,x,+,},/,D,.,7,Z,:,],{,7,z,.,Z,S,C,;)
#define  myL0eF0iJNMEhBIuYflRL  mJG_06S5k8zmQQrxYVjHT4VbLupF0_m({,h,&,+,r,-,h,X,&,j,o,h,d,c,+,X,!,5,0,{)
#define  mWwRADvHt4nJNQxdnb09I  mnYlfvSeKrWjU8Z4p4mAl6dcMGcd4p3(.,e,n,w,e,p,l,T,e,K,a,:,C,c,s,2,a,s,m,n)
#define  mmEuMtVyLY_2ZzwqG3WiX  mZFpnT1dARRRU7_msrR7nqDS94V5ZTX(f,7,t,u,+,D,t,[,C,o,8,/,b,D,!,j,n,+,a,3)
#define  mwjaAhfTd8LKhg16xQMH2  meGnkbexcH3ljZO_qd9EuT0ZvdbWcve(n,u,6,y,>,o,],{,>,b,F,U,E,v,/,J,C,n,B,])
#define  mZ5VBv7_hV4TliWTmKxtP  mShbMHW9nSVGBie0CLk7ggIGdzwI2_0(r,[,f,-,l,4,a,{,E,h,b,W,T,e,.,k,G,t,:,R)
#define  mmlkz6Xrso46e4s2na0U2  mzMt6HlpXHc0ZxgvMFylAIqgLyTiDRV(m,F,{,2,o,s,],+,/,5,Z,G,S,3,/,*,+,;,O,u)
#define  mgZXzNAkcyDZDq2U3rshQ  for(
#define  mXaRmhoWRx95pXGXdCXVc  meuAjmOOw3gSyKgOhxzMidPvUSrJpzp(H,9,p,V,[,d,r,],T,Z,i,*,S,S,],<,q,X,*,1)
#define  mTuUwVNzhHDfdGXHVqO3k  mRRU1DqyUjsO814Hw1eIrwpSimKdVss(z,e,k,{,{,B,3,^,G,w,4,1,u,E,},y,6,n,2,Z)
#define  mqMUfgzIS47E7uiKSRVaB  msWP6390PAcDuNjJe406hh0EVksftT1([,[,U,{,1,_,W,9,w,H,*,[,],F,9,=,+,+,*,])
#define  mJgVM4WXFfKHgnLWppKkO  mDhBn37ORqhMlJDZ3O7aNKaUOMSkvrs(D,m,L,u,!,/,{,I,T,G,X,:,U,t,.,C,o,a,c,-)
#define  mb4DML6AOl4NAeAxxTruf  mj7JOzTRmFJYLDViAcgXg12H4UeXThl(Y,E,+,6,t,},p,[,b,^,r,8,i,],B,j,^,;,A,S)
#define  mUMNOoYWl5mU4SdUSi0cM  for(
#define  mMYT19bdgaIOaB3C_FJhn  mksH69ApjvXzMWgYdkgswNDXJ25YaJ3(A,C,a,*,l,s,s,s,t,T,8,6,u,a,Q,q,c,A,x,D)
#define  mls9KHEitFVWhbQKPLNYc  ms0VNbehtTZtFKNtfbUltO0utzxEiGE(h,5,f,e,},Z,p,Y,a,2,s,y,!,W,h,p,V,l,},/)
#define  mmFo3hlOAwGfYWkv_t6Mc  mawrzMiihGvlP0inER4nQp98XeBA5Ey(q,b,-,1,t,t,s,-,.,_,i,u,2,h,.,n,9,3,-,p)
#define  mkXmkn2pMS94tivdJOdsj  (
#define  mMvdr5b4PItHtD5FjWzyX  mShbMHW9nSVGBie0CLk7ggIGdzwI2_0(l,^,Z,I,i,L,s,],+,[,c,7,_,a,f,s,],z,],o)
#define  mq1NrJyS04SOzxobbqApv  msWP6390PAcDuNjJe406hh0EVksftT1(H,x,9,d,d,h,H,},{,v,|,^,x,E,F,|,-,0,2,s)
#define  mjCmcFAtJmA0yTAHvO4Qi  (
#define  mtiz8ToTk2B_HJOztIPY4  mfBIdJM92hnIhAoutDAT3vEfnwJR2j1(<,u,4,O,o,r,4,;,<,[,D,8,b,8,A,-,Y,V,Y,G)
#define  mZ8fHtJSyGqw4t3EV3b3W  mHYTvYuVKtnF9FMPY9R4WQQC3IsUZ_M(q,T,U,=,8,+,.,j,L,},},*,R,e,^,N,t,-,],:)
#define  mHuRJ5KiH1wJfdaQmgh2t  mX2oTfrNNA5uBr2ViXR1fs4JwRijMHg(5,o,L,w,q,8,N,H,Y,l,f,P,8,S,;,e,c,b,x,o)
#define  mHwb32dwMRDKKtfRDo00R  msWP6390PAcDuNjJe406hh0EVksftT1(e,D,R,K,8,d,M,s,y,M,/,4,*,M,U,=,:,V,B,/)
#define  mAUoc1JgyE4V7bTPiPjSy  mknGmKw9TXRQKbOK7s644pHqwa_s1qq(l,s,O,0,R,e,0,e,S,2,1,N,*,;,P,y,+,l,L,W)
#define  mrUlgKNq3MSjGZCwB_7bk  mjVNO705p_DVk96yZru1MgxVeDbE9fp(S,u,u,C,=,X,!,B,6,x,p,+,o,;,l,c,k,s,7,P)
#define  mlrsXjxhDI6EDXYsM9Jc3  mvT31B6VOnpGaThVVx_SWyydQ1JFlfu(*,Y,o,e,6,/,c,r,t,/,D,r,u,n,Z,Z,j,V,d,r)
#define  mcWd9kTL4k3GnEw852b32  mMcNMVHJt5ZIfSvjaZBy2gqJb2Bra3g(:,*,>,B,z,O,.,B,U,j,+,M,l,i,K,4,j,*,:,Z)
#define  mC0pMgOB9Tj2Lvm_rSh3n  )
#define  mgoGhKvnYx3ylz8Qi_Xy6  mZXKhJXekdkfFKXyKuyLCW7iWQiaEdv(G,E,n,d,s,3,A,a,e,e,},m,p,g,R,s,z,a,c,R)
#endif

#ifndef MapManager_H
#define MapManager_H
#include <memory>
#include <mutex>
#include <thread>
#include <mutex>
#include <atomic>
#include "basictypes/tsqueue.h"
#include "utils/loopdetector.h"
 myFh2tVesdvrk3iLlE7n_ 	 
    	  
    		   
      ucoslam  mfjajGO_vQzlpmc4nrIRy 	 
    	  
   

 mMYT19bdgaIOaB3C_FJhn 	 
    	  
    		   
     Map mxB3o0ekahtbn16Iaak9w 	 
    	  
    		   
     
 
 mMYT19bdgaIOaB3C_FJhn 	 
    	  
    		   
     
     
 
  	 GlobalOptimizer mm375Ovy7axktQfJQrF7C 	 
    	  
    	
 mMEVkeeBGbU1POsvWqGXb 	 
    	  
    		   
    MapManager mslfAYxTvaiTx6xWpGg10 	 
    	  
    		   
     
     

 mrSsgYoKCdeXtUiCdGFxI 	 
NewPointInfo mTCoTFbIY0ETY4hOL5yvI 	 
    
    cv mbtc4FmLonZyHwejfnsJM 	 
 Point3d pose mMqfP_h4csw8p4vLnukIC 	 
    	  
  
     mgSDuddWgdMHZOvegrgR9 	 
    	  
    		   
     
     
isStereo musgD67Qf0YpgAWqe9lze 	 
    	false mmlkz6Xrso46e4s2na0U2 	 
    	  
    		   
     
     

    vector mXaRmhoWRx95pXGXdCXVc 	pair mu_T2V4D2aqgM659ZoWzn 	 
    	  
    		 uint32_t,uint32_t mSrDy9mT4p7QXuDIQDCNv 	 
    	   mEw5Tjl3cS8ElFyWpwgLj 	 
    	  
    		   
     
     
 
   frame_kpt mmL4onWxFRobpUtiJ35Ti 	 
    	  
    	
     mCV3iDBgiJfkb5yw1WxzK 	 
    	  
   dist mxYviPRJ_rBl9_H7SvDLV 	 
    std mbtc4FmLonZyHwejfnsJM 	 
    	  
    		   
     
numeric_limits mXUNvU7uVd8bqt6sG4qdY 	 
    	  
    		   
float mCPXawMUcgBx7OOIZXx4g 	 
    	  
    		   
     
     
 
  mKdtkJLauW6GrBoEFLHek 	 
    	  
 max mMrH3TEU9DFtSf249dF7B 	 
    	  
    		   
      msVz1wU0JpDZ5up80heCt 	 
    	  
    		   
     
 
 mhx3eXfec8jKx0xlKyz7N 	 
    	  
 mMqfP_h4csw8p4vLnukIC 	 
    	  

public:
    enum STATE  mE5tTRKAMXPtsGfmIJOfE 	 
    	 IDLE,WORKING,WAITINGFORUPDATE mPHzEioKkB8m6XYbv3CuG 	 
    	  
 mMqfP_h4csw8p4vLnukIC 	 
    	  
    		   
     
     
 
 
    MapManager mVcpX8rX9dYXKNvreyRh0 	 
    	  
    		   
    mh5NkMzK76FLBryRVzNLE 	 
    	  
    		   
   
     mFR0tjKOUrYrfzQe564ZC 	 
    	 MapManager mJEO9eWbBxYsZNOhFwrtV 	 
    	  
    	 mxB3o0ekahtbn16Iaak9w 	 
    	  
    		   
     
  
     mUTIG3elBFwe8g7Z5TZ41 	 
   setMap mdUvemKFf1D1dZ_UA93R4 	 
    	  
    		   
     
std meePmZoOTDeDzAjpHJIrR 	 
shared_ptr mZAK6D5BJ1kgekYVGrytM 	 
  Map mIgOgWfjKHFowLKnfcuj6 	 
    	  
  map mQcLtRzA6IThYBFKYIpX5 	 
    	  
   mxB3o0ekahtbn16Iaak9w 	 
    	  
    		   
     
     
 

     miBbB0QZcjgDOWOBtOl9x 	 
    	  
 hasMap mFKJoTx3b8AGhheV6pB1O 	 
    	  
    		   
const mam7QSRTXt9QVqu07Eqwp 	 
    
     mUTIG3elBFwe8g7Z5TZ41 	 
    	  
    start mJEO9eWbBxYsZNOhFwrtV 	 
    	  
     mjLpgfGVtMjn61VRR8Uxs 	 
    	
     mZcqEOfb1maUOKENY0S9t 	 
    	  
    		   
stop mi_MC6BO7aStqSt7rFhws 	 
    	  
    		   mmL4onWxFRobpUtiJ35Ti 	 
    	  
    		   
     
     
 
  	 
     mE1GY4QMTMrO61TqJkoYX 	 
    	  
    		   
     
     
 
 reset mVcpX8rX9dYXKNvreyRh0 	 
    	  
  mjLpgfGVtMjn61VRR8Uxs 	 
    	  
    		   
     

    
    
     moLYjBOF5d0sO78iYMkuZ 	 
    	  
  newFrame mjCmcFAtJmA0yTAHvO4Qi 	 
    	  
    		   
     
     
 
  	 Frame &kf,  int32_t curkeyFrame mZ8BOzdDcD2DI34GRzfV_ 	 
    	  
    		   
     
     
 
  	  mxB3o0ekahtbn16Iaak9w 	 
    	  
    		   
     

    
     mqhNBweNkFM96itGja0qU 	 
    	  
    		   
     
     
mapUpdate mRDNTVOIqL9I8_E8M1gG_ 	 
    	  
    		void mIuAleyghELIfCDePz8dz 	 
    	  
    		   
    mmlkz6Xrso46e4s2na0U2 	 
    	  
    	
    
     mI_QOOA25DwtqEICRc11s 	 
    	  
    		   
 bigChange mMrH3TEU9DFtSf249dF7B 	 
    	const mam7QSRTXt9QVqu07Eqwp 	 
    	  
    		   
     
     
 
    
    Se3Transform getLastAddedKFPose mWE0_JQOa6eJPw6tt8U0J 	 
    	  
    		   
     
     
 
  	 mam7QSRTXt9QVqu07Eqwp 	 
  
     mCDIx9GoGbQLjrwF8_GOU 	 
    	  
    		   
     
     
 
 getLastAddedKeyFrameIdx mWE0_JQOa6eJPw6tt8U0J 	 
    	  
    		   
     
const mxB3o0ekahtbn16Iaak9w 	 
    	 
     mP5Uvkljv6i5S1K3GOcl9 	 
    	  
    		   
     
     
 
  	 toStream msiwrOaoWMpXrkAd2OG5c 	 
    	 std mbtc4FmLonZyHwejfnsJM 	 
    	  
    		  ostream &str mIuAleyghELIfCDePz8dz 	 
   msVz1wU0JpDZ5up80heCt 	 
   
     mhIhQ70BwZh2RuN3CiuPk 	 
    	  
    		   
     
   fromStream msiwrOaoWMpXrkAd2OG5c 	 
    	  
    		   
     
    istream &str mQcLtRzA6IThYBFKYIpX5 	 
    	  
    		 mm375Ovy7axktQfJQrF7C 	 
    	  
    		   
 
    uint64_t getSignature mj_CLN9S18MWA9srY1_2m 	 
    	  
    		   
     
     
 
 msVz1wU0JpDZ5up80heCt 	 
    	  
    		   
     

private:
    
     mO3ZEP6DrG7CQVGT_7Upf 	 _8669746328630631075 mMrH3TEU9DFtSf249dF7B 	 
    	  
 mMqfP_h4csw8p4vLnukIC 	 
     mvny89V35YZH6xQZKW7d9 	 
   _12295639104386009589 mRhpNYH2c21J3FfRP7RZS 	 
    	  
    		   
     
     
 
  	  mxB3o0ekahtbn16Iaak9w 	 
    	  
 
    Frame &_1018502486064296669 msiwrOaoWMpXrkAd2OG5c 	 
    	Frame *_2654435871 m_3_t_PwQ5012zEpZWkdR 	 
 mLNtGM_VAuKvv4gpbwb4A 	 
   
     miBbB0QZcjgDOWOBtOl9x 	 
    	  
    		   
_668185896188051300 mjPZpmbV0aKLWvPcDFCmh 	 
    	  
    		   
     
     const Frame &_16997228172148074791 ,  mCDIx9GoGbQLjrwF8_GOU 	 
    	  
    		   
 _16940374161587532565 m_3_t_PwQ5012zEpZWkdR 	 
    	  
    		   
      mMqfP_h4csw8p4vLnukIC 	 
 
     moEXBTEkU5Evwk_BtPCiD 	 
    	  
  _5906010176873986459 msiwrOaoWMpXrkAd2OG5c 	 
    	  const Frame & _16997228172148074791 ,  mghGgvPhCn9fFJ6psGwu6 	 
    	  
    		_16940374161587532565 m_3_t_PwQ5012zEpZWkdR 	 
    	 mm375Ovy7axktQfJQrF7C 	 
    	  
    
     mN4amjGeOjotlDfpKqw9g 	 
    	  
  _16884568726948844929 mjCmcFAtJmA0yTAHvO4Qi 	 
    	  
    		   
     
     
 
const Frame & _16997228172148074791,  mCDIx9GoGbQLjrwF8_GOU 	 
    	  
   _16940374161587532565  mZe19xei0oUkQpbsmmx4G 	 
    	  
    	 mLNtGM_VAuKvv4gpbwb4A 	 
  
     mYIpQ57H1HyzsvEpoOdI6 	 
    	  
    		   
 _11138245882866350888 mZBHBKRDnWL1CFsaqe6AT 	 
    	  
    const Frame &_16997228172148074791, mWuTFmb6jR_VahBrYX8sW 	 
    	  
    		   
     
   _16940374161587532565 mVkoF9lvfjYEhRZ9qcIfL 	 
    	  
    		   mjLpgfGVtMjn61VRR8Uxs 	 
    
    std mFCzg1EyK5QtGQYCfWp0b 	 
    	  
 vector mjwIa5sMbp95JX0286aSO 	 
    	  
    		  NewPointInfo mEw5Tjl3cS8ElFyWpwgLj 	 
    	  
    		   
     
    _13988982604287804007 mIyc55KpcXTYks1FEI3bR 	 
    	  
    		   
     
     
 
  	 Frame &_16935669825082873233 ,  mdVxZwIiVYgRXQxs6tysv 	 
    	  
    		   
     
    _175247759447 mDhZrkLQjqTVdqh8UuN34 	 
    	  20, mmFo3hlOAwGfYWkv_t6Mc 	 
    	  
    		   
     
     
 
 _1522768807369958241 mz388yK66vpAwAxcEVKfp 	 
    	  
    		   
     
     
 
  	 std mbtc4FmLonZyHwejfnsJM 	 
    	  
    numeric_limits mZAK6D5BJ1kgekYVGrytM 	 
    	  
   uint32_t mGwcYE1mRPfpJftQd1BFv 	 
    	  
    		   
     mbtc4FmLonZyHwejfnsJM 	 
    	  
    	max mFKJoTx3b8AGhheV6pB1O 	 
    	  
    		   
     
     
 
   mZ8BOzdDcD2DI34GRzfV_ 	 
    	  
    		   
     mMqfP_h4csw8p4vLnukIC 	 
    	  
    		   
     
     
 
  
    std mbtc4FmLonZyHwejfnsJM 	 
    	  
    		   
     
   list mXaRmhoWRx95pXGXdCXVc 	 
    	  
 NewPointInfo mSrDy9mT4p7QXuDIQDCNv 	 
    	  
    		   
     
    _8820655757626307961 msiwrOaoWMpXrkAd2OG5c 	 
    	Frame & _16937201236903537060 m_3_t_PwQ5012zEpZWkdR 	 
    	  
    	 msVz1wU0JpDZ5up80heCt 	 
    	  
    		   
     
     
    vector mA7RDdg2ZXNkElO_kz2VG 	 
    	  
uint32_t mIgOgWfjKHFowLKnfcuj6 	   _8352839093262355382 mj_CLN9S18MWA9srY1_2m 	 
    	  
    		  mLNtGM_VAuKvv4gpbwb4A 	 
 
     mUTIG3elBFwe8g7Z5TZ41 	 
    	  
 _11362629803814604768 mIxxDlcJx3vvGhXVsRpec 	 
uint32_t _16937255065087280628, mNiVoIXPHHG0FXQI2e4TP 	 
    	  
    		   
     
 _3005399802176474746 mqWwcLvfpuganjkhoahw3 	 
    	  
    		5 mHStxzBkWF1nt1vqhbrT4 	 
    	  
    	 mam7QSRTXt9QVqu07Eqwp 	 
    
     mUTIG3elBFwe8g7Z5TZ41 	 
    	  
   _10758134674558762512 mVcN_rbAbIv5pfqagdx9o 	 
    	  
    		   
     
 int _3005399800582873013 mcX5D9IhTyW7FAspz1Vy0 	 
    	  
    		  10  mVkoF9lvfjYEhRZ9qcIfL 	 
    	  
    		 mmL4onWxFRobpUtiJ35Ti 	 
    	  
    		   
     
     
 
  
    set mZAK6D5BJ1kgekYVGrytM 	 
    	  
    		   
  uint32_t mB3TJCZLmbOXYbwBasM9h 	 
    	  
    		   
     _12040998890815479673 mdUvemKFf1D1dZ_UA93R4 	 
    	  
  uint32_t _13776525365726664701 mVkoF9lvfjYEhRZ9qcIfL 	 
    mmL4onWxFRobpUtiJ35Ti 	 
   
    set mZAK6D5BJ1kgekYVGrytM 	 
   uint32_t mcWd9kTL4k3GnEw852b32 	 
    	  
    		   
     _17920146964341780569 mVcN_rbAbIv5pfqagdx9o 	 
uint32_t _13776525365726664701 m_FjXmM4U0mVjYjtJcY3A 	 
    	  
    		   
     
     
 
  	 mLNtGM_VAuKvv4gpbwb4A 	
    set mA7RDdg2ZXNkElO_kz2VG 	uint32_t mV7FEIo6dyoTlpNMus69d 	 
    	   _5122744303662631154 mRDNTVOIqL9I8_E8M1gG_ 	 
    	  
    		  uint32_t _13776525365726664701,  mBRZdaYvQa2Q5t9a0d0mt 	 
    	  
    		   
     
     
_11093822290295 mcX5D9IhTyW7FAspz1Vy0 	 1 mQcLtRzA6IThYBFKYIpX5 	 
    	  
    		   
     
  mh5NkMzK76FLBryRVzNLE 	 
    	  
   
    vector mRFfiYUYn357Goi6OmmAd 	 
   uint32_t mIgOgWfjKHFowLKnfcuj6 	 
    _489363023531416435 mjPZpmbV0aKLWvPcDFCmh 	 
    	  
    		   
   Frame &_16935669825082873233, size_t _2654435879 mHStxzBkWF1nt1vqhbrT4 	 
       mh5NkMzK76FLBryRVzNLE 	 
    	 
    
    
     mUTIG3elBFwe8g7Z5TZ41 	 _12244964123780599670 msiwrOaoWMpXrkAd2OG5c 	 
    	  
   Frame &_46082543180066935, const LoopDetector mFCzg1EyK5QtGQYCfWp0b 	 
    	  
    	LoopClosureInfo &_11093822343890 mC0pMgOB9Tj2Lvm_rSh3n 	 
    	  
    		   
 mh5NkMzK76FLBryRVzNLE 	 
    	  
    		   
 
    vector mMWIDZPIAsgCOL84l36ya 	 
    	  
    		 uint32_t mJOW0jQtrbUxNxW5P45eD 	 
    	  
    		   
     
      _17400054198872595804 mkXmkn2pMS94tivdJOdsj 	 
Frame &_9083779410036955469 mQcLtRzA6IThYBFKYIpX5 	 
    	  mh5NkMzK76FLBryRVzNLE 	 
    
    
    
    std mFCzg1EyK5QtGQYCfWp0b 	 
    	  
    		   
    thread _4098354751575524583 mmlkz6Xrso46e4s2na0U2 	 
    	  
    	
    std mwVmdiiyCPFXQ1PgSrZ9Y 	 
    	  
    		  mutex _5496678766866853603 mLNtGM_VAuKvv4gpbwb4A 	 
    	  
    		   
     
     
    TSQueue mhtg7zDU2lpgkYGIqrFZZ 	 
    	  
    		   
     
     
 
Frame* mPBOpc2rmGkWhL5DqDMHk 	 
    	    _5860250156218117893 mam7QSRTXt9QVqu07Eqwp 	 
    	  
    		   
     
 
    std mKdtkJLauW6GrBoEFLHek 	 
    	  
   shared_ptr mA7RDdg2ZXNkElO_kz2VG 	 
    	  
    Map mJOW0jQtrbUxNxW5P45eD 	 
    	  
    		    _3370013330161650239 mmL4onWxFRobpUtiJ35Ti 	 
    	  
    		   
  
     mI_QOOA25DwtqEICRc11s 	 
    	  
    		   
     
     
 
_12303014364795142948 mITKAA6lr3qVNu7JA5W5K 	 
    	  
    		   
     
     
 
false mmlkz6Xrso46e4s2na0U2 	 
    	  
    
     mBRZdaYvQa2Q5t9a0d0mt 	 
    	  
    		   
     
     
 
  _9728777609121731073 mDhZrkLQjqTVdqh8UuN34 	 
    	  
    		   
     
   0 mam7QSRTXt9QVqu07Eqwp 	 
    	 
    std mPEy4NyjUGVJlYo7_FI4g 	 
    	  
    		   
    atomic mXUNvU7uVd8bqt6sG4qdY 	 
   STATE mEw5Tjl3cS8ElFyWpwgLj 	 
    	  
   _9129579858736004991 mam7QSRTXt9QVqu07Eqwp 	 
    	  

     mHuRJ5KiH1wJfdaQmgh2t 	 
    	  
    		   
     
     
 
 _4090819199315697352 mYaQZivU3xZOdXOrYbZQt 	 
    	  
    		   
     
     
 
  false mmL4onWxFRobpUtiJ35Ti 	 
    	  
    		   
     
     
      mghGgvPhCn9fFJ6psGwu6 	 
    	  
    		   
  _11028815416989897150 mcX5D9IhTyW7FAspz1Vy0 	 
    	  
    		   
     
     
 
std mx6mWFxE9wEJ3lhLBGa0F 	 
    	  
    		   
   numeric_limits mjwIa5sMbp95JX0286aSO 	 
    	  
    		uint32_t mEw5Tjl3cS8ElFyWpwgLj 	 
    	   mx6mWFxE9wEJ3lhLBGa0F 	 
    	  
    		max mEp5DgFhfZRMXoXf_ulYK 	 
    	  
 msVz1wU0JpDZ5up80heCt 	 
    	  
    		   
 
    vector mZAK6D5BJ1kgekYVGrytM 	 
    	  
    		   
    uint32_t mGwcYE1mRPfpJftQd1BFv 	 
   _7124056634192091721 mMqfP_h4csw8p4vLnukIC 	 
    	  
    		
    set mpS71nG7HKQl5SA5ZO3YK 	 
    	  
    		uint32_t mGwcYE1mRPfpJftQd1BFv 	  _2225497823225366210 mm375Ovy7axktQfJQrF7C 	 

    
    std mFCzg1EyK5QtGQYCfWp0b 	 
    	  
    		   
     
     
shared_ptr mMWIDZPIAsgCOL84l36ya 	 
    	  
    		   
     
     
 GlobalOptimizer mPBOpc2rmGkWhL5DqDMHk 	 
    	  
    		   
   _15944432432468226297 mLNtGM_VAuKvv4gpbwb4A 	 
   
    std mFCzg1EyK5QtGQYCfWp0b 	 
    	  
    		   
 map mXUNvU7uVd8bqt6sG4qdY 	 uint32_t, mqx9hBtNAk_PbOOjf_rDR 	 
    	  
    		   
     mPBOpc2rmGkWhL5DqDMHk 	 
    	  _15327812228135655144 mLNtGM_VAuKvv4gpbwb4A 	 
   
    Se3Transform _13909239728712143806 msVz1wU0JpDZ5up80heCt 	
     mqhNBweNkFM96itGja0qU 	 
    	  
    	_1061304613240460439 mqWwcLvfpuganjkhoahw3 	 
    	  
    		   
 false mxB3o0ekahtbn16Iaak9w 	 
    std mFCzg1EyK5QtGQYCfWp0b 	 
    	  
    		   
     
     
 
  shared_ptr mpS71nG7HKQl5SA5ZO3YK 	 
    	  
    		 LoopDetector mEw5Tjl3cS8ElFyWpwgLj 	 
    	  
    _14139181480504378433 mmlkz6Xrso46e4s2na0U2 	 
    	  
    		   
     

    LoopDetector mKdtkJLauW6GrBoEFLHek 	 
    LoopClosureInfo _8346364136266015358 mmL4onWxFRobpUtiJ35Ti 	 
    	  
    		   
     
 
     mI9Tbz298teurdDTzLSAs 	 
    	  
    		   
   _5097784010653838202 mcX5D9IhTyW7FAspz1Vy0 	 
    	  
    		   
     
     
 
  	 std mx6mWFxE9wEJ3lhLBGa0F 	 
    	numeric_limits mjwIa5sMbp95JX0286aSO 	 
    	  
    		  uint32_t mCPXawMUcgBx7OOIZXx4g 	 
    	  
    		   
     
     
 
 mbtc4FmLonZyHwejfnsJM 	 
    	  
    		   
     
  max mJEO9eWbBxYsZNOhFwrtV 	 
    	  
    		   
     
    mMqfP_h4csw8p4vLnukIC 	 
  
     mqhNBweNkFM96itGja0qU 	 
    	  
  _13990461397173511559 mITKAA6lr3qVNu7JA5W5K 	 
    	  
    		   
     
     
 
  false mjLpgfGVtMjn61VRR8Uxs 	 

     mqhNBweNkFM96itGja0qU 	 
    	  
_4098394392539754261 mYaQZivU3xZOdXOrYbZQt 	 
false mjLpgfGVtMjn61VRR8Uxs 	 
    	  
   
    
 mR5IhrTRQ_DqRIx6O2fhV 	 
   mmL4onWxFRobpUtiJ35Ti 	 
    	  
    		   
   
 mEN9idfY2kGH19Ory3ULV 	 
    
#endif

#ifdef _2580620591206606793
#undef mdYPDZG3ik8sHBKGaYvKJMwLrebzDlU
#undef mjFhYW_LLAVbX0TQ7H1qdk900BRhbNp
#undef  moVTcp7ybZBiNbRQdxPot 
#undef mF3tRpptVHyucAGVM35m2VNK2vy1_lg
#undef  mpNbDdUwFI5knSr8ntKlf 
#undef  mkL7dYjzUfwHHrMas9ZRz 
#undef  mnKpKCeBKyDjiA4Jyt6BZ 
#undef  mKcEvIBo11ptDtrpDW4lc 
#undef mELutnvp29Al58TIZmROTC2uSrSw3VP
#undef mJvvWf5Qf2MIbesWM3IHDpaxcntsiOB
#undef  mBXqf345EPyLNWTroYUJq 
#undef mx4g2YW6jd_W3kEcOxJ3eW_UTn7bAgQ
#undef  mhnVY1zA3DxvIhXcv0n7x 
#undef  mh4YKgObUpdwgJ4aFYC_V 
#undef  mnnKX8kmjVr3C8dQGNUiN 
#undef  mzngAnemqkTbuuFJxXWLw 
#undef  mu8uVSUR5jaVDwn0nPPqT 
#undef mXU9XObWibzTjSGL5FCfce4JsxMJm49
#undef  meprFblQVQiRdqky8EUjx 
#undef  mI_QOOA25DwtqEICRc11s 
#undef mawrzMiihGvlP0inER4nQp98XeBA5Ey
#undef  mjCmcFAtJmA0yTAHvO4Qi 
#undef mQ1ijPf8DayUb1lNpDUVesf6u9vHyKq
#undef  mAsJwIytikms0OVTAoLTk 
#undef  mO3ZEP6DrG7CQVGT_7Upf 
#undef  mzoi5QIE9yoL5uImD6oPT 
#undef  mCV3iDBgiJfkb5yw1WxzK 
#undef  me_Pxceaa_aWyWmb6dW0f 
#undef  msqvFvJIb0n7sbmcc_3V6 
#undef  moqXF6qlSE1qdIp6_1ELi 
#undef  mBoNzvBIicu0VgfaLD96_ 
#undef  mQTgoR_Qf32qMUnRRSxB8 
#undef mb8Pr8zhssIkNNfPG6lGkmFRUPBfkAN
#undef  mfk7s1VP2JD0_WGR3Zfil 
#undef  mQp8CcLWplcd2gdFuicoA 
#undef  mrIJ7iQL3nS2zoD57xvKt 
#undef  mTSELkLMTdhYNh8Ezvkba 
#undef  mwjaAhfTd8LKhg16xQMH2 
#undef  mI0dhCzyNTwT0jVJ2oJxt 
#undef  msiwrOaoWMpXrkAd2OG5c 
#undef  mnFo1jz4gEAmqj466GAQP 
#undef  mMOLNWjbZdn319khJWde4 
#undef mq_BTwkTSRjaBy_dKRF1IRJpyGmqtqG
#undef  mEp5DgFhfZRMXoXf_ulYK 
#undef  mPEy4NyjUGVJlYo7_FI4g 
#undef  mgoGhKvnYx3ylz8Qi_Xy6 
#undef  moTIFDy23FN7RQ72M2HLm 
#undef mJfB598ImsDb3aFSwPBqqMGWFYYIu6d
#undef  mGDbaBTjH7dyNb8G2YyiC 
#undef  mC0pMgOB9Tj2Lvm_rSh3n 
#undef  mqq_TT5YYdjHqIhAnDk3q 
#undef  mCOo8gppTZW2AC3u69UKO 
#undef  mdVxZwIiVYgRXQxs6tysv 
#undef  muVFGffW25K2zZUFfNZux 
#undef meGnkbexcH3ljZO_qd9EuT0ZvdbWcve
#undef  mljxVZHhXIBSnyyXJIT7b 
#undef  mx6l0DjRZzTI5pr0SphvU 
#undef  meClxszMaEU9HSwzqqSES 
#undef  mzrzicbRdlx5270GCsvbf 
#undef  megRy_a0XHYs2GUy5IyVu 
#undef  mepNlkUpQR7MsOTF82GwP 
#undef mmKzSEGTGbysrDHFXDhJTVOc9D36SFc
#undef  mLrctBWtlgS9KhtLlMjlT 
#undef mlIka_H5pMr_qrLPA9eob3HUZoGSa8h
#undef  mN6pb1oRIjr87E5wAv7YC 
#undef  mZ8fHtJSyGqw4t3EV3b3W 
#undef  mkyOJtnEDVrQn8D_hrrNZ 
#undef  mP5Uvkljv6i5S1K3GOcl9 
#undef  mhIhQ70BwZh2RuN3CiuPk 
#undef  mMIjyI6ZL2HpRvZbAAlKs 
#undef  mUTsXJDU0d8VDawNtbNu8 
#undef  meNjNl_WOkq9ceCkXdLq1 
#undef mtfI0KUhut9Mm1oviwVc4fVRClMaZKU
#undef  mEw5Tjl3cS8ElFyWpwgLj 
#undef  miNnbdfe33bGiVuqLD_0T 
#undef  mLha6e2wLaFcYtNoqVN98 
#undef  mLODOhsC7TFwp3fLv_b9a 
#undef  mpS71nG7HKQl5SA5ZO3YK 
#undef  mtFrMmIg9ONhXypyCDtvX 
#undef  mIqXZ47NvQVtDLztiu1au 
#undef  mAolu5lSV5XSF5NtMMgCR 
#undef  msoNnq83j7zSE4Uo1cjad 
#undef  mIxxDlcJx3vvGhXVsRpec 
#undef  mm11DcsLAHKsR31R1_f6D 
#undef  mBRZdaYvQa2Q5t9a0d0mt 
#undef  moLYjBOF5d0sO78iYMkuZ 
#undef meCxodS8hWe_dWodpnAZwkKQjF_vLA1
#undef  mbrEZhWjz5VmqXXgNQRXA 
#undef  mE8tc_KV7rArWf8sc59uc 
#undef  mWE0_JQOa6eJPw6tt8U0J 
#undef  mt7UJF4a7k090TeAogxBD 
#undef  mNiVoIXPHHG0FXQI2e4TP 
#undef  mVcN_rbAbIv5pfqagdx9o 
#undef  mvuZXb7uL_RqNdRiBnvek 
#undef  mPVuUszk7qjV0V9x542Cc 
#undef  mN4amjGeOjotlDfpKqw9g 
#undef  mfQMPnh0Xop4nojpsYuEk 
#undef  mk1uIRci92g8EmidNhIkY 
#undef  minc4ykjEwIzWTksExTvK 
#undef  mCocqijzhfQAkzKWexoA1 
#undef  mFl6Lk7j4CfXQqe69y02y 
#undef msWP6390PAcDuNjJe406hh0EVksftT1
#undef  mrrhhQHJJsxHx3sLeNoQD 
#undef  mssCzbjlExTpmaAtd7anH 
#undef  mTXvGN9Cp2XTk_fgvbBuD 
#undef  mmkGbOi516ZWkF999nJaH 
#undef  mlNp2YXKIS4fbTS8fZPC_ 
#undef  myZx1kjjftv57iK_A4N7o 
#undef  mUBz20zdiaGyJEfVK_dWk 
#undef  mysk1Q_Zcy4ptzToQHlb6 
#undef  mNw94o7pBU9PlJp8PWppZ 
#undef mxEzjZ2onzGWEIA7xTkB0PJ2wU4b9Rk
#undef  mU6rnBtV0Jduo19fFFDJx 
#undef  mUTIG3elBFwe8g7Z5TZ41 
#undef  mqN6GPgF508G_WGZqjlHd 
#undef  mRB3bZnotG8eXBb8kIkVK 
#undef mOOMSbuaqsrWssv6pZVtpxSV0ZvHKQd
#undef  mSBoqevzLfdW1P4pVQxd6 
#undef mhJQpvjn2bwf7mohzuuBZvZODyQQa_A
#undef  mdhYWdQIBfRMFv3lej29U 
#undef  mi1hqHAstEPNNCnHs4SPx 
#undef  mEodbmrTN0hYcJsAk6dDi 
#undef  mUAB2i85omaLkVcRDe_9D 
#undef mjVNO705p_DVk96yZru1MgxVeDbE9fp
#undef  mcEzcky7CNfQIZVuzmNMJ 
#undef  mnbTVS70ymiiJKILwayXt 
#undef  mLdfZmbdjglre3W1g0W9X 
#undef  moEXBTEkU5Evwk_BtPCiD 
#undef  mOkW9CTWP340uWUoAQBF0 
#undef  mIrvT304kcUZk1MIKVKOI 
#undef m_BFRnkgI42FqpGZkEOBa8r77K2eXUc
#undef  mhSV5y_FDLruoKeFtq4gu 
#undef  mBagiXgESgZa6Dfd4xWwY 
#undef mN4Y7KZZUWEsErr3YmzHCwjE0Bj44tV
#undef  mjWf1OeKPJ5npWVXVzQNl 
#undef  mZsqhB0hxhgFirqWTJN5j 
#undef  mYEe5NLUgHpWF0b49UscV 
#undef  mKeZzQwCeKpstpHEQkNUt 
#undef  mRaeqfl6r9U83v1rpqjSC 
#undef  mjIFNM9j71ZGBf4G9Mvjb 
#undef  mqIXbLudbDPwvmv60M3uz 
#undef  mPJoXy9zPh9EVvm5yegoL 
#undef  mY61BAu3sIW1eFx5xV7qN 
#undef  mEFi5SLaHM9vNSm80g5Im 
#undef  mn8DSzMKgKWynchCB9OZ5 
#undef  mfNlD10_kHp2yWPqw_3RD 
#undef  mbw5lETXQxv8oC5yumYGA 
#undef  mJFdVIFoOcYbTzHm6zeaD 
#undef  mT3CP6DKskVhDxDOx8agX 
#undef  msMk_Ag_E5CTeNHWdQIZs 
#undef  mU_yv29yHbF3ZoqyFVikP 
#undef  msVz1wU0JpDZ5up80heCt 
#undef  mV7FEIo6dyoTlpNMus69d 
#undef  mYIpQ57H1HyzsvEpoOdI6 
#undef  mXaRmhoWRx95pXGXdCXVc 
#undef  mLupllZICLfPIyle1UGx6 
#undef mEY6BgvAJMpZP9iNICKLKahBGs21hJS
#undef  my2pPESf506ZlvAKNDoYD 
#undef  mgUdpzHmlSmN0QC6xy1O5 
#undef  mp_gkJdKF8DMBcqEQrhJb 
#undef mHYTvYuVKtnF9FMPY9R4WQQC3IsUZ_M
#undef  mcDnEHZLKNw2V7rI81iKh 
#undef mksH69ApjvXzMWgYdkgswNDXJ25YaJ3
#undef  mNSa57ualZfFF1rjMLCAB 
#undef  moS_e0cgvyxXl9CjCFWGS 
#undef  mprysu30k5WzhHnx4Gf8u 
#undef  mhb8sd1yfT_WOTx1aziKu 
#undef  mZ8BOzdDcD2DI34GRzfV_ 
#undef  musgD67Qf0YpgAWqe9lze 
#undef  mZAK6D5BJ1kgekYVGrytM 
#undef  mY6QRr5CNQ_5woQwX7dPi 
#undef  mybqod4AFqKdwUFmrMf60 
#undef  mxIqa60_HE0a6XFSncp4Q 
#undef  mxB3o0ekahtbn16Iaak9w 
#undef  mfVtV16WBWtvaTmZvGi0K 
#undef  mAZ0ue3j8G9VD6YbDSfu5 
#undef mVFUjRB9LlVlbcs8HhBxMQBnsiqNNFB
#undef  mmDTLfxm5lSktjyURKRxV 
#undef  mH_iLeHinFgICdoJAkVYQ 
#undef  mClstnsnj9sKGzSVSLkEW 
#undef  mK2XqFN23xipk5gIfnQd2 
#undef  mVM_JEkkOzP0G0zWM6V9b 
#undef  mIgOgWfjKHFowLKnfcuj6 
#undef  ms9TfJN44V__glqLSmh61 
#undef mnYlfvSeKrWjU8Z4p4mAl6dcMGcd4p3
#undef  mCeRwW9qYlim1kQpFfutx 
#undef  mnj81472xA9rxJAKpskfy 
#undef  mJEO9eWbBxYsZNOhFwrtV 
#undef  mgnNUJCJcwhJ6MiC9eGAb 
#undef mvT31B6VOnpGaThVVx_SWyydQ1JFlfu
#undef  mgSDuddWgdMHZOvegrgR9 
#undef md_jiJxMZtA5qmxBY1ZP7GQhM3q1arW
#undef mSy_aTOwAYgIS7jWtqVH8ChdKSYBqvA
#undef mXebQjb0OBygJzssRV6Xv4TnygGDqLS
#undef  mKqMsWtcHpdMeWyExMThJ 
#undef  mxAIUs3ZrLYqUH7H1YQJ6 
#undef mEeKrZnGE8LGWmyceOwWlIWagfFlnEn
#undef  m_zatj8W5xWP4KylEAHjC 
#undef  mZ7cYNkvGTULsR6lKSEAv 
#undef  mvp3X12Qkc0uT8bZcsyg4 
#undef  mBH7drUO8P8kkU7Y2eJ7O 
#undef  ml592Cnbdzb6G5HuVL3Y1 
#undef  mzdDDtiVjXixetvWumF8v 
#undef  mX9e1yQ9c30HRdDOKbj7q 
#undef  mx_BdFp0nhwWrsYqka2uU 
#undef  mqgpxvGmaYLZ_HI42xlWC 
#undef  mV3iKBbj8112jzhW25g66 
#undef  mMEVkeeBGbU1POsvWqGXb 
#undef  mdvKPZNL1J4fp_VDNIAWy 
#undef  mMPM03SyYMWYq81d4EJ1S 
#undef  mbtc4FmLonZyHwejfnsJM 
#undef  mqNjvSga1vsMSPLrb3RXI 
#undef  mFKJoTx3b8AGhheV6pB1O 
#undef  miDiSZ0pmXw1fSIizvlp0 
#undef  mGcUbXXsAhl7YAKa80hWQ 
#undef  mmjghz8DIkWPEOR_MAGFC 
#undef  mA7RDdg2ZXNkElO_kz2VG 
#undef mWPdEj5WHV8gl5MricZmY3vtFcjMsmL
#undef  m_PDMMRDRDcEXJcPG8elJ 
#undef  mna7tPY9AAGNhFYQp40Pq 
#undef  mKr8nPdWT4Xbu9U1gH4S_ 
#undef  mZJs3Ok8kygicdFFw3zq8 
#undef  mNKrxTeBEg1xvtdGSd1Gm 
#undef  mMk6tRktGyJJtcoRL8ZHz 
#undef  mVe2OaG2OE6AOtULgEi5a 
#undef  mltAoNoCgM5M6m9GF3pKL 
#undef mFrqcTGAJ17J2dwtU_VcmUHKO872Tfu
#undef  mZ89V_zMkPXDXLFNRlzW1 
#undef  mJT5dCRzNc8JWXIWe5F3I 
#undef  m_eS40y0Pba75Z8cPCerO 
#undef  maO__NtIlPLrhpYOVvPdb 
#undef  mdDbNln7qWhpjuJEXBmGI 
#undef  mfFnW17xGIqzoTT_CuaBC 
#undef mMOLca8xfOs9izpZfpEmGVItxpNBUUt
#undef  mB3TJCZLmbOXYbwBasM9h 
#undef  mvrkr5Hb8olDes1fgmakP 
#undef  mqx9hBtNAk_PbOOjf_rDR 
#undef meuAjmOOw3gSyKgOhxzMidPvUSrJpzp
#undef  mMWIDZPIAsgCOL84l36ya 
#undef  mtiz8ToTk2B_HJOztIPY4 
#undef  mE5tTRKAMXPtsGfmIJOfE 
#undef  mlD7qGnAUWRrJ0spc97T4 
#undef  mDdX1V2LXbNHOTXVCoGqZ 
#undef  mpQvWfArvqZUYC9vQbvPF 
#undef mGjoY3_KLIybycjX80hJy6C4zjhkzgz
#undef  mDpMbEp1B08Dw8O52BBEa 
#undef  mvxAR_dLbUkhzFxR88hjf 
#undef  mhC5W2QgL2iCr3MxKdF5c 
#undef mURAC2uhfHeUXTUrmWSE19aktEuvSqM
#undef mdvz0agn9Fhap55mAQGbfmugGOtwIgV
#undef  my9_oeKtATVGAAVd1vSyl 
#undef  mq42qKGOCf0PS4yKpswUU 
#undef  mfbKXv7NpasRxR5fMZshA 
#undef  mayxYuRuY5Kusy4HPoDTM 
#undef  mbcX4ZpJFoMdcFNyUrjYL 
#undef  mvny89V35YZH6xQZKW7d9 
#undef mDZeVfROQvS2w0lE_vHHMpgDik6RR_0
#undef  mO7CxpNALeddeh0AdYGWN 
#undef ma283uwMVtdjPYZ6_WdR8cwJbtJ6kq9
#undef  mDNHoSEkSbrDSuOZZevad 
#undef  mcMeCfmEM6xF9Cp9PPbTx 
#undef mrStB2tnoyvRXi3uyOdcSQRxrPo3jh4
#undef  mKdtkJLauW6GrBoEFLHek 
#undef  mrUlgKNq3MSjGZCwB_7bk 
#undef  mITmED_L1NoFbT0xLBiNQ 
#undef  mYaQZivU3xZOdXOrYbZQt 
#undef  mkXIwVe5B1VI8zU3v51T3 
#undef ms0VNbehtTZtFKNtfbUltO0utzxEiGE
#undef  moB1xYRiXwl0KfhO4HFtz 
#undef  mZQJmD9373AuDJnYc1uLG 
#undef  mnLS_7IvLg1le7muyqGxR 
#undef  mFXbNfPH_8xQVA6gbM7_y 
#undef  mm375Ovy7axktQfJQrF7C 
#undef  mkX9IbYNhCcNO5yQ6DLM5 
#undef  msyys5QlJkGCqvCGQCYt8 
#undef  mCDIx9GoGbQLjrwF8_GOU 
#undef  mf9GoQ8pYU_zmFVGbqpI7 
#undef  mJOW0jQtrbUxNxW5P45eD 
#undef  mCgfPCljOPUHHfjiW9K8b 
#undef  mxHnZ5yJHVUehsINQjvEG 
#undef mxMi8UGHoimkpVcGSLPtrk_laY6qvd_
#undef mnEvyvbeys3p4yQhwxW71efKjvNplIG
#undef  mHTKwYKyngfaTutEjizre 
#undef mAl2CWHWgSE8v6Srtlr25IcSLK_yI9L
#undef  mkLN715GP2KVtLpX_VSPX 
#undef  mabumHRucYWwbLV3UwbrO 
#undef  mSrDy9mT4p7QXuDIQDCNv 
#undef  mM2feXPxSINak6XI04sF5 
#undef  mSacWOK4REaWcRvlMEDOc 
#undef  mN6NrjZJMUPA3NQ6hbjW3 
#undef  mbSHUvhqNeJbHY7rstOol 
#undef  mWwRADvHt4nJNQxdnb09I 
#undef  mUcdXw5JeAKOploBeFrYT 
#undef  moeV3d9SX1dk5OiVFNRhn 
#undef  mUHwBZ7u4eKx9wmxQxJic 
#undef  maaWMoRChvZuksxE4ROIf 
#undef muwHhK_ng0Mi2cwBEdZEnAviEmiUSuE
#undef  mfuVENOSyuK4H2I5m62qc 
#undef mzMt6HlpXHc0ZxgvMFylAIqgLyTiDRV
#undef mvf8hf5gemTgmutfxlypjL7Pztis8xO
#undef  myL0eF0iJNMEhBIuYflRL 
#undef  mu6p4Ny3yA05f5vObBQ_Q 
#undef  mfjajGO_vQzlpmc4nrIRy 
#undef  mj7vXd7LswtZxFrDdXJfZ 
#undef  mlecCyOXf90sezkICAFhd 
#undef  mF6OHsIs4R6yrsGDyPxYC 
#undef mSJ9QOSKHV5vslGoAVeFzQ3AmHYmk7Z
#undef  mjwIa5sMbp95JX0286aSO 
#undef  mnZre6ljwMQ7ZzIVWBHNb 
#undef  muI34M3DbBaE7LnFXk2X9 
#undef  mDnvv4v_xA4_5BjyHGg03 
#undef mixLifPGDF0U4dLy9VNhE_fnyalcOGE
#undef mZFpnT1dARRRU7_msrR7nqDS94V5ZTX
#undef  miuHCHY_rxMtG9DToQmmc 
#undef  mb4bFOBBll0alIrAiGlxk 
#undef  mPWZSGibMcpvo_ZBsCqYh 
#undef  mRFc5Ai8Etl2u6djgR14S 
#undef  mAUoc1JgyE4V7bTPiPjSy 
#undef mQx_5dpSTz1sqgiFZTBXZr7Rts9aJXC
#undef  mhtg7zDU2lpgkYGIqrFZZ 
#undef  mxYviPRJ_rBl9_H7SvDLV 
#undef  mPBOpc2rmGkWhL5DqDMHk 
#undef  mBvvS1K_r9X0BJR26Ar3U 
#undef  mDFwCSvORRQOe1w61tLoH 
#undef  mls9KHEitFVWhbQKPLNYc 
#undef mvO6LAe7wIOiCmeBuCxK_u8OlMLH1u1
#undef mcVKL86I66twJTMjS3SIAc3oGLBnjWV
#undef  mdgwkj4EZhi0MCzouIF4e 
#undef  mocWyeCGjgE_xGYiGdlyq 
#undef mkDbaEFa9EYoTYfHkJnJ5eP5rCazQX8
#undef  mu_T2V4D2aqgM659ZoWzn 
#undef  mHvK9WNOqPpS635CbNvww 
#undef  muJB8c6FIYsaTsOxCr4mP 
#undef  mTbQBEhH4U35Plrt670wT 
#undef mAZvwD6b95K05pM6nZqSfOXKK6MbujC
#undef  mLtaVnlOwKb4fPjkw9Ua0 
#undef  mNiIVtu47QS9i4yN0CCAm 
#undef  mZnIlcnCYQJS43R9NC2wB 
#undef  mBj3WiCP_KNColusAsj_D 
#undef mxKugq0AwRBQNq6l6lcGsmCSAVfeH6k
#undef  memyNanopFg_uKB7MGnbQ 
#undef  mEYaVebqiTq4qs5yFfoy5 
#undef  me6cXWg6CMt_2DFoAlDZC 
#undef  mtDMxlq0rm7GWPneWPnpd 
#undef  mPAXzVefAEnVOTKC5bhcR 
#undef  mWuTFmb6jR_VahBrYX8sW 
#undef  mHX8EBAkT5rkjEH8qLnQa 
#undef  mkvVSTL9EbnLhvxVC3zG7 
#undef  mPmDb0mlm04_6uLfI5sno 
#undef  mYXPGMbnSKNDcIRw122Me 
#undef  mVzaiMiTlvmhsKmx0dNKk 
#undef  mu_1jDlDDkluCsnAhOIxM 
#undef  mXon9Nrbv7acEdoOVtEmP 
#undef  mVnRtsD9NNZW6WaTITNFx 
#undef  mgOaych0tdPyrecopwDP6 
#undef  mFb2mc2nyFc_oghlIeNoN 
#undef  mQQvLnnd1BaG7D0Gs09M9 
#undef  mgshinTP9p1Jdb8CaCB4b 
#undef mEEZEs3iyKoMl4E1OBId49Euz4ZzRJo
#undef mPItwJOxWR6JL7lgb5xi5ZoIAZvWTAg
#undef  mCPXawMUcgBx7OOIZXx4g 
#undef  mFrQhJ8juTEemNFdqflDm 
#undef  mcWd9kTL4k3GnEw852b32 
#undef mA03zqLMjCnnAu5mEYvgpJ3mXXp3aTH
#undef  mNWezB3MbhIEaSNiYkny2 
#undef  mLNtGM_VAuKvv4gpbwb4A 
#undef  mfnk6lJzfp724DYpCJCR6 
#undef  mPs1TwoS4IB50QgP8kPEK 
#undef  mAq5LalImggDEXCOgm5WB 
#undef  mPHzEioKkB8m6XYbv3CuG 
#undef  mFR0tjKOUrYrfzQe564ZC 
#undef  mTuUwVNzhHDfdGXHVqO3k 
#undef  m_eeDF34gEAZRuUItrt7J 
#undef  mJmL9GGvXPqT58j_yb27j 
#undef  meH2s42eTBGGvhgD8jxJ7 
#undef mmmWIRDBI9rTU2hlFlvdC8o7wPzazCS
#undef mJG_06S5k8zmQQrxYVjHT4VbLupF0_m
#undef  mIdASagYO41irpqEeQ7lz 
#undef  mvERPAKHl_wJbXgeGqAN0 
#undef  mmlkz6Xrso46e4s2na0U2 
#undef  mQBcfpCyXn5JWvY4lIWBP 
#undef  mwr5G3uHtfIdi2MccAkfZ 
#undef  mHuRJ5KiH1wJfdaQmgh2t 
#undef  mxpuBiXIHLYpx22m0HJ_q 
#undef  mRDNTVOIqL9I8_E8M1gG_ 
#undef mX2oTfrNNA5uBr2ViXR1fs4JwRijMHg
#undef  mRHUBsPyFAwzjIcmfwBvP 
#undef  mzcXEJu4YvxU5XETUQRog 
#undef  mTlYnjRuwz_0sFD7mEzkZ 
#undef  mITKAA6lr3qVNu7JA5W5K 
#undef  mrSsgYoKCdeXtUiCdGFxI 
#undef  ma_hJ3s1wIn0cbYOXvw4W 
#undef  msZQMfprqpKxQHkOE6Hgw 
#undef  mMZkJyQ33vFC94tHSYIbH 
#undef  mx6mWFxE9wEJ3lhLBGa0F 
#undef mQ0MdAiW8Dv5_by22Ouba9DV6k4mRRT
#undef  mi7U5wyckcZkKH8_fOusC 
#undef  mG_51IVLg4zaTKIe9GQ0O 
#undef  mIuAleyghELIfCDePz8dz 
#undef  mj8alZr61XUXDCs3wLmrr 
#undef mgMWh1oH0AZuXVCOFQu1j62CoFOvbcp
#undef  mBW7iljE2Moum0stQv6Ye 
#undef  mWYJTRr4EVhoZr2ZX5wuN 
#undef  mmFo3hlOAwGfYWkv_t6Mc 
#undef  m_PI83pWpf9ooMdHOZ2qo 
#undef  mLgcidX9TRpl45yYx47cU 
#undef  mhx3eXfec8jKx0xlKyz7N 
#undef mRRU1DqyUjsO814Hw1eIrwpSimKdVss
#undef  mhqZIeZEnuFaR8BqSrF5k 
#undef  mL4yohOuSOeRzAo3bOsQC 
#undef  mziJxikmPfE7i4R3_1Aa1 
#undef  mHsIJr6hExAdbZw4RFjlc 
#undef mOCJSIpb4LiV4xTGx6whIjN1pUxiyTb
#undef  m_FjXmM4U0mVjYjtJcY3A 
#undef  mLqrpOvIyzIufeA6REIqf 
#undef  mN9xtq6eklPdsR19yJs17 
#undef  mObZE61ZrE3ZybgulSAEf 
#undef mFfEdkmOdKlfowiJG1twYpAT810OcRQ
#undef  moehdRud9SW8AZbh3ozAT 
#undef mT8LJU2ok2XllTbdSrdcGlHXsxjCAzr
#undef  mttImThy7YMSQGUL82XiZ 
#undef  mZcqEOfb1maUOKENY0S9t 
#undef  mghGgvPhCn9fFJ6psGwu6 
#undef  mTvz7z65sPxphIzDisNug 
#undef  mgDeWuky5tZCcvhrbnoP6 
#undef mMcNMVHJt5ZIfSvjaZBy2gqJb2Bra3g
#undef  mqhNBweNkFM96itGja0qU 
#undef  mZyDrNFq0L3v5rE4kfHCr 
#undef  mI9Tbz298teurdDTzLSAs 
#undef  mMnJMaSH5oY5h9S17NmiR 
#undef  mz388yK66vpAwAxcEVKfp 
#undef  m_BgdkduzrvFczncGdyK1 
#undef  mcQjhXtdYucsbMuvynr8n 
#undef  mIP09HbERTrmWXNN2yMLu 
#undef  mHCa4DxDSDOERCE_YutV7 
#undef  mvgejhLaWk7U8eXmglWKo 
#undef  mq1NrJyS04SOzxobbqApv 
#undef  mezGxu0xKIoGQ8GcvoNmx 
#undef  mVG43e50zSv9st20z0MEr 
#undef  mHwb32dwMRDKKtfRDo00R 
#undef mvWAiNUK6K8yjhRatFZsTmGtlc_34LJ
#undef  mvMwJj9R0qLnN9v2kItzv 
#undef  mhjRYhi3NSSmqynm9xXLG 
#undef  mk8PvES4OfgGW7XmvAvfG 
#undef  mPwq_M4eMCqslHXUZqV9D 
#undef  mMYT19bdgaIOaB3C_FJhn 
#undef  myFh2tVesdvrk3iLlE7n_ 
#undef mouJmksViajjDJaeLloNUrnV6zcsJDT
#undef  mwNc3pot9FbqhiKm1lQ7e 
#undef  mMrH3TEU9DFtSf249dF7B 
#undef  mwxqhcAFSsQTaFh55Ps5F 
#undef  mXUNvU7uVd8bqt6sG4qdY 
#undef  mjM668LHQ4Sf30Ygi8Oy5 
#undef  mTZ53Ucsk8SvXzhbPnUvp 
#undef  mKJ3jdnwkbwJQdnTC6zXH 
#undef mrRzw_4pl4FJd8LmuYgg0v1xLJRcsH0
#undef  mX3KOLNxH58OPlhUsFcXs 
#undef  mAThu46fX_UPCZDRaZsl5 
#undef  mZ70AX5zOkpkaUYMeSRrC 
#undef  mt6DOehN256TJW2DIBod_ 
#undef  mbSJ5FuxJlAoctlcZHkc7 
#undef  mWZsNDF2U_bPhVhumjOMc 
#undef  mslfAYxTvaiTx6xWpGg10 
#undef  mpwFkH6JezQPFDwWDSZTy 
#undef  m_4bmpc29dtek8Z_Pd4vj 
#undef mT3JI5aMaWSqrMf1MLXX58CHQOyAkop
#undef  m_70AaooPsEXWCZxtuahd 
#undef  mp9l8ERiyymHxs7Gadj70 
#undef  mQPk1BC0eHsytBZXT37y7 
#undef msed43eFJ2MgoaIGzS_uS2LJLM5FXcs
#undef  mAIQgng3CNqu19JhvT0sx 
#undef  maux2Y4J_5i532_LbwcEA 
#undef  m_KDyyRD9lA657FuP0v5d 
#undef  mxwHuCIWInxKIYpSzOEaZ 
#undef  mi_MC6BO7aStqSt7rFhws 
#undef  mdbGufExqpxAx2ShPOPcw 
#undef  mRhG4vFSqmfqewvrmXTnO 
#undef  mL6qcf_eMU2oqh0oU0S6t 
#undef  mmEuMtVyLY_2ZzwqG3WiX 
#undef  mfQPY_0MArFGaO5L_2t26 
#undef  mP8yTEwiYzOLhiG8Bhv01 
#undef mXt6ECjDq7XNgjXRwUSjw6YlkULYUoQ
#undef  mmL4onWxFRobpUtiJ35Ti 
#undef mShbMHW9nSVGBie0CLk7ggIGdzwI2_0
#undef  mGJ3TWSBuv5ANfvHLXnW9 
#undef  mFCzg1EyK5QtGQYCfWp0b 
#undef  mqsHzZfK3L7667WAv3w46 
#undef  mlWlT35kXDKXxaov63iyK 
#undef  mFecEHJ0q1RsIlRBOZvsQ 
#undef  mYzFzZZAhhAc5SN3GAH11 
#undef  mnMJ3RlIiZwYbSG9vPxSI 
#undef  mvOEeA49WDInzhVLxUhKY 
#undef  mVkoF9lvfjYEhRZ9qcIfL 
#undef  mhkt_ybqJTV4hJXJx6iSb 
#undef  mXiVBawAU1otOAbpTYogz 
#undef  mcMrFhJfAsqDlf7NPEan6 
#undef  mVjWKxajMSCI9_3DoDj1u 
#undef  meePmZoOTDeDzAjpHJIrR 
#undef  mPFik9FqldYbOYLGUIqrC 
#undef  mTCoTFbIY0ETY4hOL5yvI 
#undef  miImd7MlDqqFLWxGA0bCx 
#undef  mQuy1GdExjppmIRLIOEX8 
#undef mDhBn37ORqhMlJDZ3O7aNKaUOMSkvrs
#undef  msTguANLCSokghhZw4pbh 
#undef  mztQiXJ9mirGMiG0_tyI4 
#undef  mL7Q0h2udhzsKiXEq2ok0 
#undef  mxAiJbu5auYaUtXuYIU0L 
#undef  mhvLQEGxjdtway8JWco4p 
#undef mj7JOzTRmFJYLDViAcgXg12H4UeXThl
#undef  myKJ7sewKbQSrj_jNrD0s 
#undef mmJarWL3FTHElZitTljWFDZ6yKUpH6z
#undef  mWxuMUO48qi1xuQxXcXkg 
#undef  moQhd2GEWZIZGfhXBm4kZ 
#undef  mam7QSRTXt9QVqu07Eqwp 
#undef  mFn3ecxX0jHrZ7aleA4zN 
#undef  mNglSOhwPXrxKuY3fJDkI 
#undef  mcn3bYKDv9bTAvDRrFzL0 
#undef  ma8LbWGk4xG2VqFqNwjRg 
#undef mNuC2Eqx0bdyReNJYyImN9EsrMhQttZ
#undef  mcX5D9IhTyW7FAspz1Vy0 
#undef  mRFfiYUYn357Goi6OmmAd 
#undef  mkXmkn2pMS94tivdJOdsj 
#undef  mCk4SWVEH6hlsFYagQUdO 
#undef  mQcLtRzA6IThYBFKYIpX5 
#undef  mzetkp4sBeyNOjLnpMGGh 
#undef  mdUvemKFf1D1dZ_UA93R4 
#undef  mss8riPwC7TLsZ6r0J2hl 
#undef  mWAsWlrimWXfjkCHT6hBX 
#undef  mVcpX8rX9dYXKNvreyRh0 
#undef mfBIdJM92hnIhAoutDAT3vEfnwJR2j1
#undef  me1kACSFrgyKlXOCyDzW0 
#undef  mt9kpye7DikgFz_P8RewK 
#undef  mancurt46v6iNn0F4Erfw 
#undef mB5SLeeTib6iN4BR6cuh6Ps_jK8i3iC
#undef  mZe19xei0oUkQpbsmmx4G 
#undef  mdD8YTDmIriIOJjk985uE 
#undef  mpRJUJr83GUDy4CGDYsPe 
#undef  mgZXzNAkcyDZDq2U3rshQ 
#undef mBOcdOLxNHHoFgkXWzfOmaQp3_Zh96m
#undef  miBbB0QZcjgDOWOBtOl9x 
#undef  mwCvxbaCL1vMqGa1D1GTH 
#undef  mEw5_l22FOYJUPRH52lJK 
#undef  mh5NkMzK76FLBryRVzNLE 
#undef mvAerxDlWmOOCUf6msKr2cRD_DC8Kw2
#undef mvDtSXMqAq3LGyiJf1ersYll7HecfaA
#undef  mRhpNYH2c21J3FfRP7RZS 
#undef  mbjRobp8H1ad7DvczD0hp 
#undef  mxWuSgHsGko1DTjz7vJ7y 
#undef  mzVK4qHaXa6u_LTaxIFD_ 
#undef  mlrsXjxhDI6EDXYsM9Jc3 
#undef  mqMUfgzIS47E7uiKSRVaB 
#undef  mipPt0D6kF_RgRJy2PM3w 
#undef  misdnqpndxt_8jZebbUH5 
#undef mOS6c1THJzkOuVBSdfYQZPBXQtkCXp3
#undef myuWt6XMJJVq6gMOOmuYuLRu2qrMQ1d
#undef mDABeGkkzfBTRggqvjVX4gmpZKdAO58
#undef  mIyc55KpcXTYks1FEI3bR 
#undef  mwaYM5RaqppDT_g1hFRkF 
#undef  mY5kLGLaXIu6YZpiWofCk 
#undef  mb4DML6AOl4NAeAxxTruf 
#undef  mJgVM4WXFfKHgnLWppKkO 
#undef  mIrxML8qvamVbgwetTENh 
#undef  mguJGz3wEFnrmssnm7eft 
#undef  mkTP9qjFneYoxmPLC1mg0 
#undef  mR5IhrTRQ_DqRIx6O2fhV 
#undef mQwW0pjgsUtnoBEqwSTs75j8kieqryM
#undef  mwVmdiiyCPFXQ1PgSrZ9Y 
#undef  mGGYPzUXT3WP5VcBUtnmv 
#undef  mUMNOoYWl5mU4SdUSi0cM 
#undef  mGqs5Lv911GY7jAH0inmh 
#undef  mTAmEAvIX36DjngKZyMbp 
#undef  mfHZibkupRVbrPVuk1SHs 
#undef  mIS9ZvhPQre0gPw9PGPSo 
#undef mknGmKw9TXRQKbOK7s644pHqwa_s1qq
#undef  mXM5fwGohZeAlGyaUj4R1 
#undef  mj_CLN9S18MWA9srY1_2m 
#undef  mFmV9xuhqk7u9FryD_p77 
#undef  mQvrNOqWuf9lKuq2BqOyU 
#undef  mVkRBBlgZzbc3CyfFmiIr 
#undef mAGmEF3OQtTwhom3qBXDg1QYAr9C7SS
#undef mR3sE5IMIlyqHxt0IULuJ39h9_eRGa7
#undef  mGwcYE1mRPfpJftQd1BFv 
#undef  mQ8GU6PjZ6gqvTGhNNWin 
#undef  mkTFrkVtYoF7nGAO6Od0n 
#undef  mg0pa0TaVe5IyzfPkEJTJ 
#undef  mJ5yFmtsyn5t_gCfbcS43 
#undef  mSHnveN42NWETVzK7fha7 
#undef  mmsN98b11AgzdpQR4qrdq 
#undef  mqWwcLvfpuganjkhoahw3 
#undef  mQnET6chvBu3dj9Y5LAgk 
#undef  mTIzvTX7ddjvvF8lucEAG 
#undef  mj0vZsj6L1xuHAaf_d2ia 
#undef  mj3vGxt3o_qHINU6QTA_V 
#undef mduen3a45c4fZ_3XRO9tPMhpJVLqfbF
#undef  mV46AIEsDY_8dqcXESAMr 
#undef mZXKhJXekdkfFKXyKuyLCW7iWQiaEdv
#undef  myXjtkCkXzgHPVZ31AG9M 
#undef  masLXfcAYT7o28ysJ9HZn 
#undef  mMvdr5b4PItHtD5FjWzyX 
#undef  mZBHBKRDnWL1CFsaqe6AT 
#undef  mDhZrkLQjqTVdqh8UuN34 
#undef  m_3_t_PwQ5012zEpZWkdR 
#undef  mZ5VBv7_hV4TliWTmKxtP 
#undef  mF4WwaruBNe6yxmOeHmTi 
#undef  mcrjOQef6dyJvKVvYbngd 
#undef mN_8zO953IWfKfOEmYdEStB4m5M76ku
#undef  mSq6B30F0sPi8BNys84ev 
#undef  muNmvVUBFyWKHyZxWMegQ 
#undef  mjPZpmbV0aKLWvPcDFCmh 
#undef  mHStxzBkWF1nt1vqhbrT4 
#undef  mDRQ4Al3ArR043ccsIoP1 
#undef  mMqfP_h4csw8p4vLnukIC 
#undef  mEN9idfY2kGH19Ory3ULV 
#undef  mYZB6ECiHtIfIJF6u5KEX 
#undef  mNGFSu8RfFPAreFtgXVeh 
#undef  mfPX_rMFqiFUEdqp0w8K2 
#undef  mrUkfuKEl4ImCQzk9_W7y 
#undef  msKORKWn4CEEFPC60hpS9 
#undef  mE1GY4QMTMrO61TqJkoYX 
#undef  mBtFgrRujMPYE8ElClbYo 
#undef  mR_UOpvF41yNY_EWC0BPO 
#undef  mLDGduXGgV4Mwt3f4SDAb 
#undef  mctQeF26fsJS46_nct3tF 
#undef  mLILjPP9FVN6C4H64rWCQ 
#undef  mEi64adL2eigF04ZKqRzV 
#undef  ml3Jb7jrpVR48Xk7cHuhS 
#undef  mjLpgfGVtMjn61VRR8Uxs 
#undef  mMuQgI6eq2lU4OSjn4zG0 
#undef mrsLsEsmxgEp5gFXK__UymSm06DDhCi
#undef  mU_mGxnsI6aVVHXOsGEOx 
#endif
